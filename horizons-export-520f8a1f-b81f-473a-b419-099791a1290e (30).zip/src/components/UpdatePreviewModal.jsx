import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2 } from 'lucide-react';
import { useSound } from '@/hooks/useSound';

export default function UpdatePreviewModal({ isOpen, onClose, currentData, suggestedChanges, onApply }) {
  const [selectedChanges, setSelectedChanges] = useState({
    name: false,
    description: false,
    personality: false,
    faq: false
  });
  
  const [isApplying, setIsApplying] = useState(false);
  const { play } = useSound();

  useEffect(() => {
    if (isOpen && suggestedChanges) {
      play('notification');
      setSelectedChanges({
        name: !!suggestedChanges.name && suggestedChanges.name !== currentData.name,
        description: !!suggestedChanges.description && suggestedChanges.description !== currentData.description,
        personality: !!suggestedChanges.personality && suggestedChanges.personality !== currentData.personality,
        faq: !!suggestedChanges.faq
      });
    }
  }, [isOpen, suggestedChanges, currentData, play]);

  const handleApply = async () => {
    setIsApplying(true);
    play('click');
    try {
      const changesToApply = {};
      if (selectedChanges.name) changesToApply.name = suggestedChanges.name;
      if (selectedChanges.description) changesToApply.description = suggestedChanges.description;
      if (selectedChanges.personality) changesToApply.personality = suggestedChanges.personality;
      if (selectedChanges.faq) changesToApply.faq = suggestedChanges.faq;
      
      await onApply(changesToApply);
      play('success');
    } catch(err) {
      play('error');
    } finally {
      setIsApplying(false);
    }
  };

  const toggleChange = (field) => {
    setSelectedChanges(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const hasAnyChanges = Object.values(selectedChanges).some(Boolean);

  return (
    <Dialog open={isOpen} onOpenChange={!isApplying ? onClose : undefined}>
      <DialogContent className="bg-black border border-white/10 text-white max-w-4xl max-h-[85vh] overflow-y-auto custom-scrollbar rounded-2xl animate-scale-up">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Revisar Sugestões da IA</DialogTitle>
        </DialogHeader>

        <div className="space-y-8 py-4">
          <div className="grid grid-cols-[auto_1fr_1fr] gap-4 font-semibold text-neutral-400 pb-2 border-b border-white/10 px-2">
            <div className="w-8"></div>
            <div>Atual</div>
            <div className="text-blue-400">Sugestão da IA</div>
          </div>

          {/* Fields */}
          {['name', 'personality', 'description'].map((field) => {
             if (suggestedChanges?.[field] && suggestedChanges[field] !== currentData[field]) {
                return (
                  <div key={field} className="grid grid-cols-[auto_1fr_1fr] gap-4 items-start group transition-all">
                    <div className="pt-4 px-2">
                      <Checkbox 
                        checked={selectedChanges[field]} 
                        onCheckedChange={() => toggleChange(field)} 
                        className="border-neutral-500 data-[state=checked]:bg-blue-600 transition-all duration-200"
                        disabled={isApplying}
                      />
                    </div>
                    <div className="diff-before whitespace-pre-wrap transition-opacity hover:opacity-90">
                      <div className="text-xs text-neutral-500 mb-1 uppercase tracking-wider font-bold">{field === 'name' ? 'Nome' : field === 'personality' ? 'Personalidade' : 'Descrição'}</div>
                      {currentData[field] || '(Vazio)'}
                    </div>
                    <div className={`diff-after whitespace-pre-wrap transition-all duration-300 ${!selectedChanges[field] ? 'opacity-40 grayscale' : 'opacity-100 scale-[1.02]'}`}>
                      <div className="text-xs text-blue-400/70 mb-1 uppercase tracking-wider font-bold">Sugestão</div>
                      {suggestedChanges[field]}
                    </div>
                  </div>
                )
             }
             return null;
          })}

          {/* FAQ Field */}
          {suggestedChanges?.faq && JSON.stringify(suggestedChanges.faq) !== JSON.stringify(currentData.faq) && (
            <div className="grid grid-cols-[auto_1fr_1fr] gap-4 items-start group">
              <div className="pt-4 px-2">
                <Checkbox 
                  checked={selectedChanges.faq} 
                  onCheckedChange={() => toggleChange('faq')} 
                  className="border-neutral-500 data-[state=checked]:bg-blue-600 transition-all duration-200"
                  disabled={isApplying}
                />
              </div>
              <div className="diff-before">
                <div className="text-xs text-neutral-500 mb-2 uppercase tracking-wider font-bold">FAQ Atual ({currentData.faq?.length || 0} itens)</div>
                <ul className="space-y-3">
                  {(currentData.faq || []).map((item, i) => (
                    <li key={i} className="text-sm">
                      <strong className="block text-white">P: {item.question}</strong>
                      <span className="text-neutral-400">R: {item.answer}</span>
                    </li>
                  ))}
                  {(!currentData.faq || currentData.faq.length === 0) && <span className="text-sm italic">(Vazio)</span>}
                </ul>
              </div>
              <div className={`diff-after transition-all duration-300 ${!selectedChanges.faq ? 'opacity-40 grayscale' : 'opacity-100 scale-[1.02]'}`}>
                <div className="text-xs text-blue-400/70 mb-2 uppercase tracking-wider font-bold">Novas FAQs ({suggestedChanges.faq.length} itens)</div>
                <ul className="space-y-3">
                  {suggestedChanges.faq.map((item, i) => (
                    <li key={i} className="text-sm">
                      <strong className="block text-blue-100">Q: {item.question}</strong>
                      <span className="text-blue-300">A: {item.answer}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="mt-6 gap-3">
          <Button variant="ghost" onClick={onClose} disabled={isApplying} className="text-neutral-400 hover:text-white hover:bg-neutral-800">
            Descartar Sugestões
          </Button>
          <Button onClick={handleApply} disabled={!hasAnyChanges || isApplying} className="bg-blue-600 text-white hover:bg-blue-700 border-none px-8 font-bold transition-all active:scale-95">
            {isApplying ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Aplicando...</> : "Aplicar Selecionadas"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}