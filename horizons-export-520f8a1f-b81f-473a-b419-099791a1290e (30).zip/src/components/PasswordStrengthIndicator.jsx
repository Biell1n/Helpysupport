import React from 'react';

export default function PasswordStrengthIndicator({ password }) {
  const calculateStrength = (p) => {
    if (!p) return 0;
    let score = 0;
    if (p.length >= 8) score++;
    if (/[A-Z]/.test(p)) score++;
    if (/[0-9]/.test(p)) score++;
    if (/[^A-Za-z0-9]/.test(p)) score++;
    return score;
  };

  const score = calculateStrength(password || '');
  
  const getStrengthInfo = (score) => {
    if (score === 0) return { label: '', color: 'bg-neutral-800' };
    if (score < 3) return { label: 'Fraca', color: 'bg-red-500' };
    if (score === 3) return { label: 'Média', color: 'bg-yellow-500' };
    return { label: 'Forte', color: 'bg-green-500' };
  };

  const { label, color } = getStrengthInfo(score);
  const percentage = Math.min(100, Math.max(0, (score / 4) * 100));

  return (
    <div className="mt-2 space-y-1">
      <div className="flex justify-between items-end text-xs mb-1">
        <span className="text-neutral-400 font-medium">Força da senha</span>
        <span className={`font-bold transition-colors duration-300 ${score < 3 ? 'text-red-400' : score === 3 ? 'text-yellow-400' : 'text-green-400'}`}>
          {label}
        </span>
      </div>
      <div className="h-1.5 w-full bg-neutral-800 rounded-full overflow-hidden">
        <div 
          className={`h-full transition-all duration-500 ease-out ${color}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}