import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { X, Loader2 } from 'lucide-react';
import { db } from '@/lib/supabase';
import { generateTicketTitle } from '@/lib/openai';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { useSound } from '@/hooks/useSound';
import AnonymousRestrictionModal from './AnonymousRestrictionModal';

export default function TicketModal({ assistantId, onClose, onTicketCreated }) {
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { isAuthenticated, isAnonymous, user } = useAuth();
  const { play } = useSound();

  if (isAnonymous) {
      return <AnonymousRestrictionModal isOpen={true} onClose={onClose} />;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    
    if (!description.trim()) {
      play('error');
      toast({
        title: 'Descrição obrigatória',
        description: 'Por favor, descreva sua situação.',
        variant: 'destructive'
      });
      return;
    }

    setLoading(true);
    play('click');

    try {
      const title = await generateTicketTitle(description);

      const ticket = await db.createTicket({
        assistant_id: assistantId,
        customer_id: user?.id,
        title,
        description: description.trim(),
        status: 'analyzing'
      });

      play('success');
      toast({
        title: 'Ticket criado com sucesso!',
        description: 'Um atendente irá responder em breve.'
      });

      if (onTicketCreated) {
        onTicketCreated(ticket);
      }

      onClose();
    } catch (error) {
      console.error('Error creating ticket:', error);
      play('error');
      toast({
        title: 'Erro ao criar ticket',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-800 border-none rounded-sm p-6 w-full max-w-lg shadow-2xl animate-scale-up">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">Abrir Ticket de Suporte</h2>
            <p className="text-gray-400 text-sm">
              Descreva sua situação e um atendente irá ajudá-lo
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors hover:rotate-90 duration-200"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-300 mb-2">
              Descrição do Problema
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={6}
              required
              className="w-full px-4 py-3 bg-slate-900/50 border-none rounded-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-violet-500 transition-all resize-none"
              placeholder="Descreva detalhadamente sua situação, dúvida ou problema..."
            />
            <p className="text-xs text-gray-500 mt-2">
              A inteligência artificial irá gerar automaticamente um título para seu ticket
            </p>
          </div>

          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1 rounded-sm border-slate-700 bg-transparent text-white hover:bg-slate-700"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="flex-1 rounded-sm bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700 text-white border-none"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Criando...
                </>
              ) : (
                'Criar Ticket'
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}