import React from 'react';
import { Check } from 'lucide-react';

export default function StepIndicator({ steps, currentStep }) {
  return (
    <div className="flex items-center justify-center w-full mb-8">
      {steps.map((step, index) => {
        const isActive = index === currentStep;
        const isCompleted = index < currentStep;
        
        return (
          <React.Fragment key={index}>
            <div className="flex flex-col items-center relative z-10">
              <div 
                className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-300 border-2
                ${isCompleted ? 'bg-blue-600 border-blue-600 text-white' : 
                  isActive ? 'bg-neutral-800 border-blue-500 text-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.3)]' : 
                  'bg-neutral-900 border-neutral-700 text-neutral-500'}`}
              >
                {isCompleted ? <Check className="w-5 h-5" /> : index + 1}
              </div>
              <span className={`absolute top-12 text-xs font-semibold whitespace-nowrap transition-colors
                ${isActive ? 'text-white' : isCompleted ? 'text-neutral-300' : 'text-neutral-600'}`}>
                {step.label}
              </span>
            </div>
            
            {index < steps.length - 1 && (
              <div className={`flex-1 h-1 mx-2 rounded-full transition-colors duration-300
                ${isCompleted ? 'bg-blue-600' : 'bg-neutral-800'}`} 
              />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}