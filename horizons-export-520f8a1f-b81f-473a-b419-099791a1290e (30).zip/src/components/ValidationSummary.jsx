import React from 'react';
import { AlertTriangle } from 'lucide-react';

export default function ValidationSummary({ errors }) {
  if (!errors || errors.length === 0) return null;

  return (
    <div className="bg-red-950/30 border border-red-900/50 rounded-xl p-4 mb-6 animate-shake">
      <div className="flex items-center gap-2 text-red-400 font-bold mb-2">
        <AlertTriangle className="w-5 h-5" />
        Por favor, corrija os erros abaixo:
      </div>
      <ul className="list-disc list-inside text-sm text-red-300/90 space-y-1 ml-1">
        {errors.map((err, i) => (
          <li key={i}>{err}</li>
        ))}
      </ul>
    </div>
  );
}