import React from 'react';
import { Building2, Tag, CheckCircle, ShieldAlert, Sparkles, Workflow, Zap, Check } from 'lucide-react';

export default function OnboardingPreview({ assistantData = {}, progress = 0 }) {
  const {
    business_type,
    goal,
    context_confidence = 0,
    collected_data = {},
    detected_fields = [],
    detected_flows = [],
    detected_automations = [],
    assistant_rules = [],
    restricted_topics = []
  } = assistantData;

  const requiredFields = ['nome_negocio', 'tipo_negocio', 'objetivo_principal'];
  
  return (
    <div className="h-full overflow-y-auto p-6 custom-scrollbar bg-neutral-900 border-l border-white/10">
      <div className="sticky top-0 bg-neutral-900 pb-4 mb-4 border-b border-white/10 z-10">
        <h2 className="text-xl font-bold text-white mb-4">Mapeamento em Tempo Real</h2>
        
        <div className="space-y-1 mb-4">
          <div className="flex justify-between text-xs text-neutral-400">
            <span>Progresso Geral</span>
            <span>{progress}%</span>
          </div>
          <div className="h-2 bg-neutral-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="space-y-1">
          <div className="flex justify-between text-xs text-neutral-400">
            <span>Confiança do Contexto</span>
            <span>{context_confidence}%</span>
          </div>
          <div className="h-1.5 bg-neutral-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-green-500 transition-all duration-500"
              style={{ width: `${context_confidence}%` }}
            />
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-neutral-300 uppercase tracking-wider flex items-center gap-2">
            <Building2 className="w-4 h-4 text-blue-400" /> Negócio
          </h3>
          <div className="bg-black/50 rounded-lg p-3 border border-white/5 text-sm">
            <div className="mb-2"><span className="text-neutral-500">Tipo:</span> <span className="text-white">{business_type || 'Detectando...'}</span></div>
            <div><span className="text-neutral-500">Objetivo:</span> <span className="text-white">{goal || 'Detectando...'}</span></div>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-neutral-300 uppercase tracking-wider flex items-center gap-2">
            <Tag className="w-4 h-4 text-purple-400" /> Dados Coletados
          </h3>
          <div className="space-y-2">
            {requiredFields.map(f => (
              <div key={f} className="flex items-center justify-between bg-black/50 p-2 rounded border border-white/5">
                <span className="text-xs text-neutral-300">{f.replace('_', ' ')}</span>
                {collected_data[f] ? <CheckCircle className="w-4 h-4 text-green-500" /> : <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />}
              </div>
            ))}
            {Object.entries(collected_data).filter(([k]) => !requiredFields.includes(k)).map(([k, v]) => (
              <div key={k} className="flex items-center justify-between bg-black/50 p-2 rounded border border-white/5">
                <span className="text-xs text-neutral-300">{k}</span>
                <Check className="w-4 h-4 text-green-500" />
              </div>
            ))}
          </div>
        </div>

        {detected_flows.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-neutral-300 uppercase tracking-wider flex items-center gap-2">
              <Workflow className="w-4 h-4 text-teal-400" /> Fluxos
            </h3>
            <div className="flex flex-wrap gap-2">
              {detected_flows.map((f, i) => (
                <span key={i} className="px-2 py-1 text-xs bg-teal-500/10 text-teal-300 border border-teal-500/20 rounded">{f}</span>
              ))}
            </div>
          </div>
        )}

        {detected_automations.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-neutral-300 uppercase tracking-wider flex items-center gap-2">
              <Zap className="w-4 h-4 text-yellow-400" /> Automações
            </h3>
            <div className="flex flex-wrap gap-2">
              {detected_automations.map((a, i) => (
                <span key={i} className="px-2 py-1 text-xs bg-yellow-500/10 text-yellow-300 border border-yellow-500/20 rounded">{a}</span>
              ))}
            </div>
          </div>
        )}

        {(assistant_rules.length > 0 || restricted_topics.length > 0) && (
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-neutral-300 uppercase tracking-wider flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-red-400" /> Regras & Restrições
            </h3>
            <div className="space-y-2">
              {assistant_rules.map((r, i) => (
                <div key={i} className="text-xs bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 rounded p-2">Regra: {r}</div>
              ))}
              {restricted_topics.map((t, i) => (
                <div key={i} className="text-xs bg-red-500/10 text-red-300 border border-red-500/20 rounded p-2">Restrito: {t}</div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}