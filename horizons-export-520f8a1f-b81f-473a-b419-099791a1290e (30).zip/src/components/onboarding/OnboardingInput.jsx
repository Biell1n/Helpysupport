import React, { useState } from 'react';
import { Send, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

/**
 * OnboardingInput - Input component for sending messages
 * @param {Object} props
 * @param {Function} props.onSend - Callback when message is sent
 * @param {boolean} props.isLoading - Loading state
 * @param {boolean} props.disabled - Disabled state
 */
export default function OnboardingInput({ onSend, isLoading = false, disabled = false }) {
  const [value, setValue] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (value.trim() && !isLoading && !disabled) {
      onSend(value.trim());
      setValue('');
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 bg-neutral-900/50 border-t border-white/10">
      <div className="flex gap-2">
        <Textarea
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Digite sua mensagem... (Shift+Enter para nova linha)"
          disabled={isLoading || disabled}
          className="min-h-[80px] resize-none bg-neutral-800 border-white/10 text-white placeholder:text-white/40 focus:border-white/30"
          rows={3}
        />
        <Button
          type="submit"
          disabled={!value.trim() || isLoading || disabled}
          className="h-20 w-20 rounded-2xl bg-white text-black hover:bg-neutral-200 disabled:opacity-50 flex-shrink-0"
        >
          {isLoading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <Send className="w-5 h-5" />
          )}
        </Button>
      </div>
      <p className="text-xs text-white/40 mt-2">
        {value.length}/1000 caracteres
      </p>
    </form>
  );
}