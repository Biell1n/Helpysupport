import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function OnboardingChat({ messages = [], loading = false, onSendMessage, context }) {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef(null);

  // BUG B FIX: Ensure messages is an array before .map
  const safeMessages = Array.isArray(messages) ? messages : [];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [safeMessages, loading]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!input.trim() || loading) return;
    
    const textToSend = input;
    setInput('');
    
    try {
      await onSendMessage(textToSend, context);
    } catch (err) {
      setInput(textToSend); // Restore if failed
    }
  };

  return (
    <div className="flex flex-col h-full bg-neutral-950 border border-white/10 rounded-2xl overflow-hidden shadow-xl">
      <div className="bg-neutral-900 border-b border-white/10 p-4 flex items-center gap-4">
        <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center border border-primary/30">
          <Bot className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h2 className="font-bold text-white">Assistente de Configuração</h2>
          <p className="text-xs text-neutral-400">Setup em andamento</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 custom-scrollbar">
        {safeMessages.length === 0 && !loading && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto"
          >
            <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mb-4 border border-primary/30 shadow-[0_0_15px_rgba(var(--primary),0.3)]">
              <Info className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Pronto para Começar!</h3>
            <p className="text-neutral-400 font-medium text-sm">
              Já analisei as informações do seu negócio. Envie um "Olá" para começarmos a estruturar seu assistente.
            </p>
          </motion.div>
        )}

        <AnimatePresence initial={false}>
          {safeMessages.map((msg) => (
            <motion.div 
              key={msg.id || Math.random().toString()} 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm ${
                  msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-neutral-800 border border-white/10'
                }`}>
                  {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4 text-white" />}
                </div>
                
                <div className={`p-4 rounded-2xl ${
                  msg.role === 'user' 
                    ? 'bg-primary text-primary-foreground rounded-tr-sm' 
                    : 'bg-neutral-800 text-neutral-200 rounded-tl-sm border border-white/5 shadow-sm'
                }`}>
                  <p className="whitespace-pre-wrap text-sm leading-relaxed">{msg.content}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {loading && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-start"
          >
            <div className="flex gap-3 max-w-[85%]">
              <div className="w-8 h-8 rounded-full bg-neutral-800 border border-white/10 flex items-center justify-center flex-shrink-0">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="p-4 rounded-2xl bg-neutral-800 border border-white/5 rounded-tl-sm flex items-center gap-2">
                <span className="w-2 h-2 bg-neutral-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                <span className="w-2 h-2 bg-neutral-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                <span className="w-2 h-2 bg-neutral-500 rounded-full animate-bounce"></span>
              </div>
            </div>
          </motion.div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="bg-neutral-900 border-t border-white/10 p-4">
        <form onSubmit={handleSubmit} className="relative flex items-center max-w-4xl mx-auto">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={loading}
            placeholder="Digite sua mensagem..."
            className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-xl py-4 pl-4 pr-14 focus:outline-none focus:border-primary transition-colors disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="absolute right-2 p-2.5 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 disabled:opacity-50 transition-colors shadow-sm flex items-center justify-center"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}