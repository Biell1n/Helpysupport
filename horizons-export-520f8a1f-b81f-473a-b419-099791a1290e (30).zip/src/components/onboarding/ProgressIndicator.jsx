import React from 'react';
import { Check, Circle } from 'lucide-react';

/**
 * ProgressIndicator - Displays onboarding progress and checklist
 * @param {Object} props
 * @param {number} props.progress - Progress percentage
 * @param {Array} props.checklist - Checklist items
 * @param {Array} props.completedFields - Completed field IDs
 */
export default function ProgressIndicator({ progress = 0, checklist = [], completedFields = [] }) {
  const requiredItems = checklist.filter(item => item.required);
  const optionalItems = checklist.filter(item => !item.required);

  return (
    <div className="p-6 bg-neutral-900 border-t border-white/10">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-white">Progresso Geral</h3>
          <span className="text-sm font-bold text-white">{progress}%</span>
        </div>
        <div className="h-2 bg-neutral-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {requiredItems.length > 0 && (
        <div className="mb-4">
          <h4 className="text-xs font-medium text-white/60 mb-2 uppercase tracking-wider">
            Informações Obrigatórias
          </h4>
          <div className="space-y-2">
            {requiredItems.map((item) => (
              <div
                key={item.id}
                className="flex items-center gap-2 text-sm"
              >
                {item.completed ? (
                  <div className="w-5 h-5 rounded-full bg-green-500 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                ) : (
                  <Circle className="w-5 h-5 text-white/20 flex-shrink-0" />
                )}
                <span className={item.completed ? 'text-white' : 'text-white/40'}>
                  {item.label}
                </span>
                {item.confidence !== undefined && item.completed && (
                  <div
                    className={`ml-auto w-2 h-2 rounded-full ${
                      item.confidence === 1
                        ? 'bg-green-500'
                        : item.confidence > 0.5
                        ? 'bg-yellow-500'
                        : 'bg-orange-500'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {optionalItems.length > 0 && (
        <div>
          <h4 className="text-xs font-medium text-white/60 mb-2 uppercase tracking-wider">
            Informações Opcionais
          </h4>
          <div className="space-y-2">
            {optionalItems.map((item) => (
              <div
                key={item.id}
                className="flex items-center gap-2 text-sm"
              >
                {item.completed ? (
                  <div className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                ) : (
                  <Circle className="w-5 h-5 text-white/20 flex-shrink-0" />
                )}
                <span className={item.completed ? 'text-white/80' : 'text-white/30'}>
                  {item.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}