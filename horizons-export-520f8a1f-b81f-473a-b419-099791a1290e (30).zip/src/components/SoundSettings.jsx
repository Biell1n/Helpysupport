import React, { useState, useEffect } from 'react';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { MessageSquare, VolumeX, Sparkles, ZapOff } from 'lucide-react';
import { useSound } from '@/hooks/useSound';

export default function SoundSettings() {
  const [soundsEnabled, setSoundsEnabled] = useState(true);
  const [animationsEnabled, setAnimationsEnabled] = useState(true);
  const [volume, setVolume] = useState([50]);
  const { playMessageReceivedSound } = useSound();

  useEffect(() => {
    const sEnabled = localStorage.getItem('soundsEnabled');
    const aEnabled = localStorage.getItem('animationsEnabled');
    const vol = localStorage.getItem('soundVolume');

    if (sEnabled !== null) setSoundsEnabled(sEnabled === 'true');
    if (aEnabled !== null) setAnimationsEnabled(aEnabled === 'true');
    if (vol !== null) setVolume([parseInt(vol, 10)]);
  }, []);

  const handleSoundToggle = (checked) => {
    setSoundsEnabled(checked);
    localStorage.setItem('soundsEnabled', checked);
    if (checked) {
       setTimeout(() => playMessageReceivedSound(), 50); 
    }
  };

  const handleAnimationToggle = (checked) => {
    setAnimationsEnabled(checked);
    localStorage.setItem('animationsEnabled', checked);
    if (checked) {
      document.body.classList.remove('animate-disabled');
      document.body.classList.add('animate-enabled');
    } else {
      document.body.classList.remove('animate-enabled');
      document.body.classList.add('animate-disabled');
    }
  };

  const handleVolumeChange = (val) => {
    setVolume(val);
    localStorage.setItem('soundVolume', val[0]);
  };

  const handleVolumeCommit = () => {
     playMessageReceivedSound();
  };

  return (
    <div className="bg-neutral-900/50 rounded-3xl p-8 shadow-xl mt-8">
      <h2 className="text-2xl font-bold text-white mb-6">Preferências de Interface</h2>
      
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label className="text-base text-white flex items-center gap-2">
              {soundsEnabled ? <MessageSquare className="w-4 h-4 text-blue-400" /> : <VolumeX className="w-4 h-4 text-neutral-500" />}
              Sons de Mensagem
            </Label>
            <p className="text-sm text-neutral-400">Ativa sons para envio e recebimento de mensagens.</p>
          </div>
          <Switch 
            checked={soundsEnabled} 
            onCheckedChange={handleSoundToggle}
            className="data-[state=checked]:bg-blue-600"
          />
        </div>

        {soundsEnabled && (
          <div className="space-y-3 bg-black/40 p-4 rounded-xl border border-white/5">
            <div className="flex justify-between items-center">
              <Label className="text-sm text-neutral-300">Volume</Label>
              <span className="text-xs font-medium text-blue-400">{volume[0]}%</span>
            </div>
            <Slider 
              value={volume} 
              onValueChange={handleVolumeChange}
              onValueCommit={handleVolumeCommit}
              max={100} 
              step={1}
              className="py-2"
            />
          </div>
        )}

        <div className="flex items-center justify-between border-t border-white/10 pt-6">
          <div className="space-y-0.5">
            <Label className="text-base text-white flex items-center gap-2">
              {animationsEnabled ? <Sparkles className="w-4 h-4 text-purple-400" /> : <ZapOff className="w-4 h-4 text-neutral-500" />}
              Animações Minimalistas
            </Label>
            <p className="text-sm text-neutral-400">Ativa transições suaves e feedback visual em elementos.</p>
          </div>
          <Switch 
            checked={animationsEnabled} 
            onCheckedChange={handleAnimationToggle}
            className="data-[state=checked]:bg-purple-600"
          />
        </div>
      </div>
    </div>
  );
}