import React from 'react';
import { useToast } from './use-toast';
import { X, CheckCircle, AlertTriangle, AlertCircle, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function ToastContainer() {
  const { toasts } = useToast();

  const getVariantStyles = (variant) => {
    switch (variant) {
      case 'success': return 'bg-green-600 text-white border-green-700';
      case 'error': 
      case 'destructive': return 'bg-red-600 text-white border-red-700';
      case 'warning': return 'bg-yellow-600 text-white border-yellow-700';
      case 'info': return 'bg-blue-600 text-white border-blue-700';
      default: return 'bg-neutral-800 text-white border-neutral-700';
    }
  };

  const getIcon = (variant) => {
    switch (variant) {
      case 'success': return <CheckCircle className="w-5 h-5" />;
      case 'error': 
      case 'destructive': return <AlertCircle className="w-5 h-5" />;
      case 'warning': return <AlertTriangle className="w-5 h-5" />;
      case 'info': return <Info className="w-5 h-5" />;
      default: return null;
    }
  };

  return (
    <div className="fixed top-4 right-4 z-[100] flex flex-col gap-2 w-full max-w-sm pointer-events-none">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
            className={`pointer-events-auto flex items-start gap-3 p-4 rounded-xl shadow-2xl border ${getVariantStyles(t.variant)}`}
          >
            <div className="shrink-0 mt-0.5">{getIcon(t.variant)}</div>
            <div className="flex-1">
              {t.title && <h4 className="font-bold text-sm mb-1">{t.title}</h4>}
              {t.description && <p className="text-sm opacity-90">{t.description}</p>}
            </div>
            <button onClick={() => t.dismiss()} className="shrink-0 opacity-70 hover:opacity-100 transition-opacity">
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}