import { useState, useEffect } from "react"

const TOAST_LIMIT = 3

let count = 0
function generateId() {
  count = (count + 1) % Number.MAX_VALUE
  return count.toString()
}

const toastStore = {
  state: {
    toasts: [],
  },
  listeners: [],
  
  getState: () => toastStore.state,
  
  setState: (nextState) => {
    if (typeof nextState === 'function') {
      toastStore.state = nextState(toastStore.state)
    } else {
      toastStore.state = { ...toastStore.state, ...nextState }
    }
    toastStore.listeners.forEach(listener => listener(toastStore.state))
  },
  
  subscribe: (listener) => {
    toastStore.listeners.push(listener)
    return () => {
      toastStore.listeners = toastStore.listeners.filter(l => l !== listener)
    }
  }
}

export const toast = ({ variant = 'default', duration, ...props }) => {
  const id = generateId()
  
  // Set duration based on variant if not explicitly provided
  let defaultDuration = 3000;
  if (variant === 'error' || variant === 'destructive') defaultDuration = 5000;
  if (variant === 'warning') defaultDuration = 4000;
  if (variant === 'info') defaultDuration = 3000;
  
  const finalDuration = duration || defaultDuration;

  const update = (props) =>
    toastStore.setState((state) => ({
      ...state,
      toasts: state.toasts.map((t) =>
        t.id === id ? { ...t, ...props } : t
      ),
    }))

  const dismiss = () => toastStore.setState((state) => ({
    ...state,
    toasts: state.toasts.filter((t) => t.id !== id),
  }))

  toastStore.setState((state) => ({
    ...state,
    toasts: [
      { ...props, id, variant, duration: finalDuration, dismiss },
      ...state.toasts,
    ].slice(0, TOAST_LIMIT),
  }))

  return { id, dismiss, update }
}

export function useToast() {
  const [state, setState] = useState(toastStore.getState())
  
  useEffect(() => {
    const unsubscribe = toastStore.subscribe(setState)
    return unsubscribe
  }, [])
  
  useEffect(() => {
    const timeouts = []
    state.toasts.forEach((toast) => {
      if (toast.duration === Infinity) return
      const timeout = setTimeout(() => {
        toast.dismiss()
      }, toast.duration)
      timeouts.push(timeout)
    })
    return () => timeouts.forEach(clearTimeout)
  }, [state.toasts])

  return { toast, toasts: state.toasts }
}