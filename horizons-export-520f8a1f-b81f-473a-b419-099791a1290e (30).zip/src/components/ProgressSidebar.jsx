import React from 'react';
import { useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';
import { CheckCircle, Circle, Clock, Info, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function ProgressSidebar({ onAdvancedOptionsClick }) {
  const { structuredState, getProgress } = useAssistantMemoryContext();
  const progress = getProgress();

  const fields = Object.entries(structuredState);
  const counts = { completo: 0, parcial: 0, incompleto: 0, ignorado: 0 };
  
  fields.forEach(([_, data]) => {
    if (counts[data.status] !== undefined) {
      counts[data.status]++;
    }
  });

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completo': return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'parcial': return <Clock className="w-5 h-5 text-yellow-400" />;
      case 'incompleto': return <Circle className="w-5 h-5 text-red-400" />;
      case 'ignorado': return <Circle className="w-5 h-5 text-gray-500" />;
      default: return <Circle className="w-5 h-5 text-neutral-500" />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-neutral-950 border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
      <div className="p-5 border-b border-white/10 bg-gradient-to-br from-neutral-900/80 to-neutral-900/50">
        <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4">
          <Info className="w-4 h-4 text-blue-400" /> Progresso Geral
        </h3>
        <div className="bg-black/40 rounded-full h-3 overflow-hidden shadow-inner mb-3">
          <div className="h-full bg-gradient-to-r from-blue-500 via-green-500 to-emerald-500 transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-white">{progress}%</span>
          <span className="text-xs text-neutral-400">completo</span>
        </div>
        
        <div className="flex gap-2 mt-4 flex-wrap">
          <Badge className="bg-green-500/20 text-green-400">{counts.completo} Completo</Badge>
          <Badge className="bg-yellow-500/20 text-yellow-400">{counts.parcial} Parcial</Badge>
          <Badge className="bg-red-500/20 text-red-400">{counts.incompleto} Incompleto</Badge>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {fields.map(([key, data]) => (
          <div key={key} className="flex items-center gap-3 p-3 rounded-xl border border-white/5 bg-white/5">
            {getStatusIcon(data.status)}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-white capitalize truncate">{key}</p>
              <p className="text-xs text-neutral-400 capitalize">{data.status}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-white/10">
        <Button onClick={onAdvancedOptionsClick} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold">
          Ver Dados Estruturados <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}