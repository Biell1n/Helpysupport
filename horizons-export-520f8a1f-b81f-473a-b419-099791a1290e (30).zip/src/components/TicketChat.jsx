import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { X, Send, User, Headphones, CheckCircle2 } from 'lucide-react';
import { db } from '@/lib/supabase';
import { handleAuthError } from '@/lib/authUtils';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { usePolicyEnforcement } from '@/hooks/usePolicyEnforcement';

export default function TicketChat({ ticket, onClose, onUpdate }) {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef(null);
  const { toast } = useToast();
  const { validateChatResponse } = usePolicyEnforcement();

  useEffect(() => {
    loadMessages();
  }, [ticket.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  async function loadMessages() {
    try {
      setLoading(true);
      const data = await db.getTicketMessages(ticket.id);
      setMessages(data || []);
    } catch (error) {
      if (await handleAuthError(error)) return;
      console.error('Error loading messages:', error);
      toast({
        title: 'Erro ao carregar mensagens',
        description: error.message,
        variant: 'destructive'
      });
      setMessages([]);
    } finally {
      setLoading(false);
    }
  }

  async function handleSend(e) {
    e.preventDefault();
    
    if (!input.trim() || sending) return;

    setSending(true);
    
    const messageContent = input.trim();
    
    const policyCheck = validateChatResponse(messageContent, `ticket_${ticket.id}`);
    
    const finalMessage = policyCheck.isViolation ? policyCheck.blockedResponse : messageContent;

    try {
      await db.createTicketMessage({
        ticket_id: ticket.id,
        sender_id: user?.id || null,
        sender_type: 'support_agent',
        message: finalMessage
      });

      if (ticket.status === 'analyzing') {
        await db.updateTicketStatus(ticket.id, 'responded');
        if (onUpdate) onUpdate();
      }

      setInput('');
      
      if (policyCheck.isViolation) {
        toast({
          title: 'Aviso de Política',
          description: 'Sua mensagem original violou nossas diretrizes e foi bloqueada. Uma mensagem de aviso foi enviada no lugar.',
          variant: 'destructive'
        });
      }

      await loadMessages();
    } catch (error) {
      if (await handleAuthError(error)) return;
      console.error('Error sending message:', error);
      toast({
        title: 'Erro ao enviar mensagem',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setSending(false);
    }
  }

  async function handleResolve() {
    try {
      await db.updateTicketStatus(ticket.id, 'resolved');
      toast({
        title: 'Ticket resolvido!',
        description: 'O ticket foi marcado como resolvido.'
      });
      if (onUpdate) onUpdate();
      onClose();
    } catch (error) {
      if (await handleAuthError(error)) return;
      console.error('Error resolving ticket:', error);
      toast({
        title: 'Erro ao resolver ticket',
        description: error.message,
        variant: 'destructive'
      });
    }
  }

  const statusColors = {
    analyzing: 'bg-orange-500/20 text-orange-400 border-orange-500/50',
    responded: 'bg-blue-500/20 text-blue-400 border-blue-500/50',
    resolved: 'bg-green-500/20 text-green-400 border-green-500/50'
  };

  const statusLabels = {
    analyzing: 'Em Análise',
    responded: 'Respondido',
    resolved: 'Resolvido'
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-slate-800 border border-slate-700 rounded-2xl w-full max-w-3xl h-[600px] shadow-2xl flex flex-col"
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-700">
          <div className="flex justify-between items-start mb-4">
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-white mb-1">{ticket.title}</h2>
              <p className="text-gray-400 text-sm line-clamp-2">{ticket.description}</p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors ml-4"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="flex items-center gap-3">
            <span className={`px-3 py-1 rounded-full text-xs font-medium border ${statusColors[ticket.status]}`}>
              {statusLabels[ticket.status]}
            </span>
            
            {ticket.status !== 'resolved' && (
              <Button
                size="sm"
                onClick={handleResolve}
                className="bg-green-600 hover:bg-green-700"
              >
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Marcar como Resolvido
              </Button>
            )}
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
            </div>
          ) : messages.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-400">Nenhuma mensagem ainda. Seja o primeiro a responder!</p>
            </div>
          ) : (
            messages.map((message, index) => {
              const isViolationMsg = message.message.includes('Minhas diretrizes de segurança não permitem');
              
              return (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`flex gap-3 ${
                    message.sender_type === 'support_agent' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  {message.sender_type === 'customer' && (
                    <div className="bg-slate-700 w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0">
                      <User className="w-5 h-5 text-white" />
                    </div>
                  )}

                  <div className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                    message.sender_type === 'support_agent'
                      ? isViolationMsg ? 'bg-red-900/80 border border-red-500 text-white' : 'bg-violet-600 text-white'
                      : 'bg-slate-700 text-white'
                  }`}>
                    <p className="whitespace-pre-wrap">{message.message}</p>
                    <p className="text-xs opacity-70 mt-1">
                      {new Date(message.created_at).toLocaleString('pt-BR')}
                    </p>
                  </div>

                  {message.sender_type === 'support_agent' && (
                    <div className={`${isViolationMsg ? 'bg-red-600' : 'bg-violet-600'} w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <Headphones className="w-5 h-5 text-white" />
                    </div>
                  )}
                </motion.div>
              );
            })
          )}

          {sending && (
            <div className="flex gap-3 justify-end">
              <div className="bg-violet-600 rounded-2xl px-4 py-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
              <div className="bg-violet-600 w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0">
                <Headphones className="w-5 h-5 text-white" />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        {ticket.status !== 'resolved' && (
          <div className="p-6 border-t border-slate-700">
            <form onSubmit={handleSend} className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Digite sua resposta..."
                disabled={sending}
                className="flex-1 px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all"
              />
              <Button
                type="submit"
                disabled={sending || !input.trim()}
                className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
              >
                <Send className="w-5 h-5" />
              </Button>
            </form>
          </div>
        )}
      </motion.div>
    </div>
  );
}