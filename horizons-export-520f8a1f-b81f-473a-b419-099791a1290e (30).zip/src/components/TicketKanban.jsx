import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, CheckCircle2, AlertCircle, MessageSquare } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

const STATUS_CONFIG = {
  'analysis': { label: 'Em Análise', color: 'bg-yellow-500/10 text-yellow-500' },
  'responded': { label: 'Respondido', color: 'bg-white/10 text-white' },
  'resolved': { label: 'Resolvido', color: 'bg-green-500/10 text-green-500' }
};

export default function TicketKanban({ tickets }) {
  const [selectedTicket, setSelectedTicket] = useState(null);

  const columns = [
    { id: 'analysis', title: 'Em Análise', icon: AlertCircle },
    { id: 'responded', title: 'Respondido', icon: MessageSquare },
    { id: 'resolved', title: 'Resolvido', icon: CheckCircle2 }
  ];

  const getTicketsByStatus = (status) => {
    return tickets.filter(ticket => {
        let normalizedStatus = ticket.status || 'analysis';
        if (['open', 'pending'].includes(normalizedStatus)) normalizedStatus = 'analysis';
        if (['in_progress'].includes(normalizedStatus)) normalizedStatus = 'responded';
        if (['closed', 'resolved'].includes(normalizedStatus)) normalizedStatus = 'resolved';
        return normalizedStatus === status;
    });
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'
    });
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 overflow-x-auto pb-4">
        {columns.map(column => (
          <div key={column.id} className="min-w-[280px]">
            <div className="flex items-center gap-2 mb-4 px-2">
              <column.icon className="w-4 h-4 text-neutral-400" />
              <h3 className="font-semibold text-neutral-200">{column.title}</h3>
              <span className="ml-auto bg-neutral-900 text-neutral-500 text-xs px-2 py-0.5 rounded-full shadow-inner">
                {getTicketsByStatus(column.id).length}
              </span>
            </div>
            
            <div className="bg-neutral-900/50 rounded-xl p-3 min-h-[200px] space-y-3 shadow-inner">
              {getTicketsByStatus(column.id).map(ticket => (
                <motion.div
                  key={ticket.id}
                  layoutId={ticket.id}
                  onClick={() => setSelectedTicket(ticket)}
                  className="bg-neutral-900 hover:bg-neutral-800 p-4 rounded-lg cursor-pointer transition-colors shadow-md hover:shadow-lg group"
                >
                  <h4 className="font-medium text-white mb-2 group-hover:text-white transition-colors line-clamp-1">{ticket.title}</h4>
                  <p className="text-sm text-neutral-400 line-clamp-2 mb-3">{ticket.description}</p>
                  
                  <div className="flex items-center justify-between text-xs text-neutral-500 pt-3 border-t border-neutral-800/50">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatDate(ticket.created_at)}
                    </span>
                  </div>
                </motion.div>
              ))}
              
              {getTicketsByStatus(column.id).length === 0 && (
                <div className="text-center py-8 text-neutral-600 text-sm">
                  Nenhum ticket
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <Dialog open={!!selectedTicket} onOpenChange={() => setSelectedTicket(null)}>
        <DialogContent className="bg-neutral-900 border-none shadow-2xl text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">{selectedTicket?.title}</DialogTitle>
            <DialogDescription className="text-neutral-400 pt-2">
               Ticket ID: <span className="font-mono text-xs bg-neutral-950 p-1 rounded">{selectedTicket?.id}</span>
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 mt-4">
             <div className="bg-neutral-950 p-4 rounded-lg shadow-inner">
                <h4 className="text-sm font-medium text-neutral-300 mb-2">Descrição</h4>
                <p className="text-neutral-300 leading-relaxed whitespace-pre-wrap">{selectedTicket?.description}</p>
             </div>

             <div className="flex items-center justify-between text-sm text-neutral-400">
                <span>Criado em: {selectedTicket && formatDate(selectedTicket.created_at)}</span>
                <div className={`px-2 py-1 rounded text-xs shadow-sm ${STATUS_CONFIG[selectedTicket?.status || 'analysis']?.color || 'bg-neutral-800 text-neutral-400'}`}>
                   {STATUS_CONFIG[selectedTicket?.status || 'analysis']?.label || 'Desconhecido'}
                </div>
             </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}