// ============================================================
// HELPY — TelaCodigo v1 — ARQUIVO COMPLETO
//
// As três telas de verificação — e-mail, login e cadastro — pediam a
// mesma coisa de três formas diferentes, com código triplicado. Aqui
// existe uma só; cada página passa o que muda.
//
// Seis casas separadas, colar funciona, apagar volta uma casa, e ao
// completar verifica sozinho.
// ============================================================

import React, { useState, useEffect, useRef, useCallback } from 'react';
import '@/styles/painel.css';

const CASAS = 6;

export default function TelaCodigo({
  eyebrow = 'Verificação',
  titulo,
  descricao,
  destino,                 // e-mail para onde o código foi
  onVerificar,             // (codigo) => Promise<{ success, error? }>
  onReenviar,              // () => Promise<{ success, error? }>
  onVoltar,
  rotuloVoltar = 'Voltar',
  nota,                    // linha extra embaixo, opcional
}) {
  const [casas, setCasas] = useState(Array(CASAS).fill(''));
  const [verificando, setVerificando] = useState(false);
  const [erro, setErro] = useState(null);
  const [reenviando, setReenviando] = useState(false);
  const [espera, setEspera] = useState(0);

  const refs = useRef([]);
  const codigo = casas.join('');

  useEffect(() => {
    refs.current[0]?.focus();
  }, []);

  useEffect(() => {
    if (espera <= 0) return;
    const t = setTimeout(() => setEspera((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [espera]);

  const verificar = useCallback(
    async (valor) => {
      if (valor.length !== CASAS || verificando) return;
      setVerificando(true);
      setErro(null);
      try {
        const r = await onVerificar(valor);
        if (r?.success === false) {
          setErro(r.error || 'Código incorreto ou expirado.');
          setCasas(Array(CASAS).fill(''));
          refs.current[0]?.focus();
        }
      } catch (e) {
        setErro(e?.message || 'Não deu para verificar agora.');
      } finally {
        setVerificando(false);
      }
    },
    [onVerificar, verificando]
  );

  const escrever = (i, bruto) => {
    const so = bruto.replace(/\D/g, '');
    if (!so) {
      setCasas((p) => {
        const n = [...p];
        n[i] = '';
        return n;
      });
      return;
    }

    // colar o código inteiro numa casa distribui pelas seguintes
    setCasas((p) => {
      const n = [...p];
      for (let k = 0; k < so.length && i + k < CASAS; k++) n[i + k] = so[k];
      const cheio = n.join('');
      const proxima = Math.min(CASAS - 1, i + so.length);
      setTimeout(() => refs.current[proxima]?.focus(), 0);
      if (cheio.length === CASAS) setTimeout(() => verificar(cheio), 80);
      return n;
    });
  };

  const teclar = (i, e) => {
    if (e.key === 'Backspace' && !casas[i] && i > 0) {
      e.preventDefault();
      refs.current[i - 1]?.focus();
      setCasas((p) => {
        const n = [...p];
        n[i - 1] = '';
        return n;
      });
    }
    if (e.key === 'ArrowLeft' && i > 0) refs.current[i - 1]?.focus();
    if (e.key === 'ArrowRight' && i < CASAS - 1) refs.current[i + 1]?.focus();
  };

  const reenviar = async () => {
    if (espera > 0 || reenviando) return;
    setReenviando(true);
    setErro(null);
    try {
      const r = await onReenviar?.();
      if (r?.success === false) setErro(r.error || 'Não deu para reenviar.');
      else setEspera(45);
    } catch (e) {
      setErro(e?.message || 'Não deu para reenviar.');
    } finally {
      setReenviando(false);
    }
  };

  return (
    <div className="hd" style={{ display: 'grid', placeItems: 'center', padding: '2rem' }}>
      <div style={{ width: '100%', maxWidth: '26rem' }}>
        <span className="hd-lbl">{eyebrow}</span>

        <h1 className="hd-h1" style={{ fontSize: '2rem', marginTop: '.75rem' }}>
          {titulo}
        </h1>

        {descricao && (
          <p className="hd-sub" style={{ marginTop: '1rem' }}>
            {descricao}
            {destino && (
              <>
                {' '}
                <b style={{ color: 'var(--hd-ink)', fontWeight: 500 }}>{destino}</b>
              </>
            )}
          </p>
        )}

        {/* ---------- as seis casas ---------- */}
        <div style={{ display: 'flex', gap: '.5rem', marginTop: '2.5rem' }}>
          {casas.map((v, i) => (
            <input
              key={i}
              ref={(el) => (refs.current[i] = el)}
              value={v}
              onChange={(e) => escrever(i, e.target.value)}
              onKeyDown={(e) => teclar(i, e)}
              onFocus={(e) => e.target.select()}
              inputMode="numeric"
              autoComplete={i === 0 ? 'one-time-code' : 'off'}
              maxLength={CASAS}
              aria-label={`Dígito ${i + 1} de ${CASAS}`}
              disabled={verificando}
              style={{
                flex: 1,
                height: '3.75rem',
                textAlign: 'center',
                fontFamily: 'inherit',
                fontSize: '1.5rem',
                fontWeight: 200,
                color: 'var(--hd-ink)',
                background: 'none',
                border: 'none',
                borderBottom: `1px solid ${
                  erro ? '#C96A6A' : v ? 'var(--hd-ink)' : 'var(--hd-line-2)'
                }`,
                outline: 'none',
                transition: 'border-color .2s',
                opacity: verificando ? 0.5 : 1,
              }}
            />
          ))}
        </div>

        {/* ---------- estado ---------- */}
        <div style={{ minHeight: '2.5rem', marginTop: '1.25rem' }}>
          {verificando && <span className="hd-lbl">verificando</span>}
          {!verificando && erro && (
            <p className="hd-alert" style={{ margin: 0 }}>
              {erro}
            </p>
          )}
        </div>

        {/* ---------- ações ---------- */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '1rem',
            marginTop: '1.5rem',
            paddingTop: '1.5rem',
            borderTop: '1px solid var(--hd-line)',
          }}
        >
          <button
            type="button"
            className="hd-nav"
            onClick={reenviar}
            disabled={espera > 0 || reenviando}
            style={{ opacity: espera > 0 ? 0.4 : 1 }}
          >
            {reenviando
              ? 'reenviando'
              : espera > 0
              ? `reenviar em ${espera}s`
              : 'reenviar código'}
          </button>

          {onVoltar && (
            <button type="button" className="hd-nav" onClick={onVoltar}>
              {rotuloVoltar}
            </button>
          )}
        </div>

        {nota && (
          <p className="hd-kpi-n" style={{ marginTop: '2rem', lineHeight: 1.6 }}>
            {nota}
          </p>
        )}

        <button
          type="button"
          className="hd-btn hd-btn--solid"
          onClick={() => verificar(codigo)}
          disabled={codigo.length !== CASAS || verificando}
          style={{ width: '100%', justifyContent: 'center', marginTop: '2rem' }}
        >
          {verificando ? 'Verificando' : 'Confirmar'}
        </button>
      </div>
    </div>
  );
}