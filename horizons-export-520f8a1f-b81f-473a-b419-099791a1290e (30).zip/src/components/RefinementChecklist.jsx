import React, { useState } from 'react';
import { CheckCircle2, Circle, AlertCircle, Settings } from 'lucide-react';
import { useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';
import { Button } from '@/components/ui/button';
import AdvancedOptionsModal from '@/components/AdvancedOptionsModal';

export default function RefinementChecklist() {
  const {
    getSectionStatus,
    getCompletionPercentage,
    state
  } = useAssistantMemoryContext();

  const [isAdvancedOptionsOpen, setIsAdvancedOptionsOpen] = useState(false);

  const completionPercentage = getCompletionPercentage();

  const sections = [
    {
      id: 'descricao',
      label: 'Descrição do Negócio',
      status: getSectionStatus('descricao'),
      mandatory: true
    },
    {
      id: 'catalogo',
      label: 'Catálogo de Produtos',
      status: getSectionStatus('catalogo'),
      mandatory: true
    },
    {
      id: 'contato',
      label: 'Canais de Contato',
      status: getSectionStatus('contato'),
      mandatory: true
    },
    {
      id: 'personalidade',
      label: 'Personalidade do Assistente',
      status: getSectionStatus('personalidade'),
      mandatory: true
    },
    {
      id: 'regras',
      label: 'Regras Personalizadas',
      status: getSectionStatus('regras'),
      mandatory: false
    }
  ];

  const getStatusIcon = (status) => {
    if (status === 'green') {
      return <CheckCircle2 className="w-5 h-5 text-green-500 fill-green-500/20" />;
    } else if (status === 'red') {
      return <Circle className="w-5 h-5 text-red-500" />;
    } else if (status === 'gray') {
      return <Circle className="w-5 h-5 text-gray-500" />;
    }
    return <AlertCircle className="w-5 h-5 text-orange-500" />;
  };

  const getStatusLabel = (status) => {
    if (status === 'green') return 'Completo';
    if (status === 'red') return 'Incompleto';
    if (status === 'gray') return 'Opcional';
    return 'Em Progresso';
  };

  const getStatusColor = (status) => {
    if (status === 'green') {
      return 'bg-green-500/10 border-green-500/30';
    } else if (status === 'red') {
      return 'bg-red-500/10 border-red-500/30';
    } else if (status === 'gray') {
      return 'bg-gray-500/10 border-gray-500/30';
    }
    return 'bg-orange-500/10 border-orange-500/30';
  };

  return (
    <>
      <div className="bg-neutral-950 border border-white/10 rounded-3xl p-6 shadow-2xl">
        {/* Header with completion percentage */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-white">Status da Configuração</h2>
            <span className="text-3xl font-bold text-white">{completionPercentage}%</span>
          </div>
          
          {/* Progress bar */}
          <div className="h-3 bg-neutral-900 rounded-full overflow-hidden shadow-inner">
            <div 
              className="h-full bg-gradient-to-r from-blue-500 via-green-500 to-emerald-500 transition-all duration-500"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
          
          <p className="text-sm text-neutral-400 mt-2">
            {completionPercentage === 100 
              ? '✅ Configuração completa!' 
              : `${Math.round((100 - completionPercentage) / 25)} campo(s) obrigatório(s) faltando`
            }
          </p>
        </div>

        {/* Sections list */}
        <div className="space-y-3 mb-6">
          {sections.map((section, index) => (
            <div
              key={section.id}
              className={`rounded-xl border p-4 transition-all duration-200 ${getStatusColor(section.status)}`}
            >
              <div className="flex items-center gap-3">
                <span className="bg-black border border-white/10 text-white w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">
                  {index + 1}
                </span>
                
                {getStatusIcon(section.status)}
                
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-bold text-white">{section.label}</h3>
                  <p className="text-xs text-neutral-400">
                    {getStatusLabel(section.status)}
                    {!section.mandatory && ' (não obrigatório)'}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Advanced Options Button */}
        <Button
          onClick={() => setIsAdvancedOptionsOpen(true)}
          className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold rounded-xl h-12 shadow-lg"
        >
          <Settings className="w-4 h-4 mr-2" />
          Opções Avançadas
        </Button>
      </div>

      {/* Advanced Options Modal */}
      <AdvancedOptionsModal
        isOpen={isAdvancedOptionsOpen}
        onClose={() => setIsAdvancedOptionsOpen(false)}
      />
    </>
  );
}