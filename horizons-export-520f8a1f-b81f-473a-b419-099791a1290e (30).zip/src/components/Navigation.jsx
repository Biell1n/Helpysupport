import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { LayoutDashboard, Crown, Menu, X, LogOut } from 'lucide-react';
import ProfileDropdown from '@/components/ProfileDropdown';
import { motion, AnimatePresence } from 'framer-motion';

export default function Navigation() {
  const { isAuthenticated, isBusinessOwner, isPremium, isPending, logout } = useAuth();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 0);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'p-4' : 'p-0'}`}>
      <div className={`container mx-auto transition-all duration-500 flex items-center justify-between ${
        scrolled 
          ? 'bg-white/5 backdrop-blur-sm rounded-2xl px-6 py-3 shadow-lg' 
          : 'bg-transparent px-4 py-5'
      }`}>
        <Link to="/" className="text-2xl font-bold text-white hover:text-neutral-300 transition-colors flex items-center gap-2">
          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-sm">
            <span className="text-black font-black text-lg">H</span>
          </div>
          Helpy
        </Link>

        <div className="hidden md:flex items-center gap-6">
          {isAuthenticated ? (
            isPending ? (
              <Button
                variant="ghost"
                onClick={logout}
                className="text-neutral-300 hover:text-white hover:bg-white/10 font-medium"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            ) : (
              <>
                {isBusinessOwner && (
                   <div className="flex items-center gap-2">
                      {isPremium ? (
                        <span className="flex items-center gap-1 px-3 py-1.5 bg-white/10 rounded-full text-xs text-white font-medium uppercase tracking-wider">
                          <Crown className="w-3 h-3" /> Premium
                        </span>
                      ) : (
                        <span className="px-3 py-1.5 bg-white/5 rounded-full text-xs text-neutral-400 font-medium uppercase tracking-wider">
                          Free Plan
                        </span>
                      )}
                   </div>
                )}
                
                <Button
                  variant="ghost"
                  onClick={() => navigate('/dashboard')}
                  className="text-neutral-300 hover:text-white hover:bg-white/10 font-medium"
                >
                  <LayoutDashboard className="w-4 h-4 mr-2" />
                  Dashboard
                </Button>

                <ProfileDropdown />
              </>
            )
          ) : (
            <>
              <Button
                variant="ghost"
                onClick={() => navigate('/auth', { state: { view: 'login' } })}
                className="text-neutral-300 hover:text-white hover:bg-white/10 font-medium rounded-xl transition-all"
              >
                Login
              </Button>
              <Button
                onClick={() => navigate('/auth', { state: { view: 'signup' } })}
                className="bg-white hover:bg-neutral-200 text-black font-bold border-none shadow-[0_0_20px_rgba(255,255,255,0.2)] hover:shadow-[0_0_30px_rgba(255,255,255,0.3)] rounded-xl px-6 transition-all"
              >
                Cadastrar-se
              </Button>
            </>
          )}
        </div>

        <button 
          className="md:hidden text-neutral-300 hover:text-white transition-colors"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`md:hidden absolute left-4 right-4 ${scrolled ? 'top-20' : 'top-20'} bg-black/80 backdrop-blur-sm rounded-2xl p-4 flex flex-col gap-4 shadow-2xl`}
          >
            {isAuthenticated ? (
               isPending ? (
                 <Button onClick={() => { logout(); setMobileMenuOpen(false); }} className="w-full justify-start bg-white/10 hover:bg-white/20 text-white border-none rounded-xl">
                   <LogOut className="w-4 h-4 mr-2" /> Sair
                 </Button>
               ) : (
                 <>
                   <Button onClick={() => { navigate('/dashboard'); setMobileMenuOpen(false); }} className="w-full justify-start bg-white/10 hover:bg-white/20 text-white border-none rounded-xl mt-2">
                     <LayoutDashboard className="w-4 h-4 mr-2" /> Dashboard
                   </Button>
                   <Button onClick={() => { navigate('/profile'); setMobileMenuOpen(false); }} variant="outline" className="w-full justify-start bg-transparent border-none text-neutral-300 hover:text-white hover:bg-white/5 rounded-xl shadow-none mt-2">
                     Meu Perfil
                   </Button>
                 </>
               )
            ) : (
               <>
                 <Button onClick={() => { navigate('/auth', { state: { view: 'login' } }); setMobileMenuOpen(false); }} variant="outline" className="w-full bg-transparent border-none text-white hover:bg-white/10 rounded-xl shadow-none">
                   Login
                 </Button>
                 <Button onClick={() => { navigate('/auth', { state: { view: 'signup' } }); setMobileMenuOpen(false); }} className="w-full bg-white text-black font-bold hover:bg-neutral-200 border-none rounded-xl">
                   Cadastrar-se
                 </Button>
               </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}