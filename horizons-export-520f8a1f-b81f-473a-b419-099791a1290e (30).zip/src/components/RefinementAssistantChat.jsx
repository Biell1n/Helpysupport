import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Send, Bot, User, Loader2, Sparkles } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabaseClient';
import { useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';

export default function RefinementAssistantChat() {
  const { 
    structuredState,
    conversationHistory,
    setConversationHistory,
    runFieldAnalysis,
    hasShownInitialMessage,
    setHasShownGreeting
  } = useAssistantMemoryContext();
  
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (!hasShownInitialMessage) {
      setHasShownGreeting(true);
      setConversationHistory(prev => [
        ...prev, 
        { role: 'assistant', content: "Olá, sou o assistente Helpy e vim te ajudar a criar ou configurar o seu assistente." }
      ]);
    }
  }, [hasShownInitialMessage, setHasShownGreeting, setConversationHistory]);

  const handleSend = async (e) => {
    e?.preventDefault();
    const userMsg = input.trim();
    if (!userMsg || loading) return;

    setInput('');
    setConversationHistory(prev => [...prev, { role: 'user', content: userMsg }]);
    setLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('refine-assistant-chat', {
        body: { userMessage: userMsg, currentMemory: structuredState, conversationHistory }
      });

      if (error) throw error;

      if (data && data.response) {
        setConversationHistory(prev => [...prev, { role: 'assistant', content: data.response }]);
      }

      if (data && data.extractedData) {
        await runFieldAnalysis(structuredState);
      }
    } catch (err) {
      console.error(err);
      setConversationHistory(prev => [...prev, { role: 'assistant', content: "Desculpe, tive um problema técnico. Pode repetir?" }]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conversationHistory, loading]);

  return (
    <div className="flex flex-col h-full bg-neutral-950 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl">
      <div className="border-b border-neutral-800 bg-neutral-900/50 p-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center shadow-lg">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-bold text-white">Assistente Helpy</h3>
            <p className="text-xs text-neutral-400">Pronto para te ajudar</p>
          </div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
        {conversationHistory.map((msg, i) => (
          <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg ${
              msg.role === 'user' ? 'bg-blue-600' : 'bg-purple-600'
            }`}>
              {msg.role === 'user' ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-white" />}
            </div>
            <div className={`flex-1 min-w-0 ${msg.role === 'user' ? 'flex justify-end' : ''}`}>
              <div className={`inline-block max-w-[85%] rounded-2xl px-4 py-3 shadow-sm ${
                msg.role === 'user' ? 'bg-blue-600 text-white rounded-tr-sm' : 'bg-neutral-800 text-white rounded-tl-sm'
              }`}>
                <div className="whitespace-pre-wrap break-words text-sm leading-relaxed">{msg.content}</div>
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center shadow-lg">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="inline-block rounded-2xl px-4 py-3 bg-neutral-800 rounded-tl-sm">
              <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSend} className="border-t border-neutral-800 bg-neutral-900/50 p-4">
        <div className="flex gap-2">
          <Input 
            value={input} onChange={(e) => setInput(e.target.value)}
            placeholder="Digite sua mensagem..."
            className="flex-1 bg-neutral-950 border-neutral-700 text-white placeholder-neutral-500"
            disabled={loading}
          />
          <Button type="submit" disabled={!input.trim() || loading} className="bg-blue-600 hover:bg-blue-700">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </form>
    </div>
  );
}