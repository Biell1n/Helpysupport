import React, { useEffect } from 'react';
import { ShieldAlert, X, Lightbulb } from 'lucide-react';
import { useSound } from '@/hooks/useSound';

export default function PolicyValidationAlert({ violation, onClose }) {
  const { play } = useSound();

  useEffect(() => {
    if (violation) {
      play('error');
    }
  }, [violation, play]);

  if (!violation) return null;

  return (
    <div className="mb-6 overflow-hidden animate-slide-in-right animate-shake">
      <div className="bg-red-950/40 border border-red-500/50 rounded-2xl p-5 relative shadow-[0_0_15px_rgba(220,38,38,0.15)] transition-all">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-red-400 hover:text-red-300 hover:bg-red-900/50 p-1 rounded-md transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
        
        <div className="flex gap-4">
          <div className="bg-red-500/20 p-3 rounded-full h-fit border border-red-500/30">
            <ShieldAlert className="w-6 h-6 text-red-500" />
          </div>
          
          <div className="flex-1 pr-6">
            <h3 className="text-lg font-bold text-red-400 mb-1">
              Violação de Política: {violation.name}
            </h3>
            <p className="text-red-200/80 text-sm mb-4">
              O conteúdo fornecido foi sinalizado pelos nossos sistemas de segurança.
            </p>
            
            <div className="space-y-3">
              <div className="bg-black/40 rounded-lg p-3 border border-red-900/30">
                <strong className="text-red-300 text-xs uppercase tracking-wider block mb-1">Motivo</strong>
                <p className="text-red-100 text-sm">{violation.reason}</p>
              </div>
              
              <div className="bg-black/40 rounded-lg p-3 border border-red-900/30">
                <strong className="text-red-300 text-xs uppercase tracking-wider block mb-1">Exemplos Não Permitidos</strong>
                <p className="text-red-100 text-sm italic">"{violation.examples}"</p>
              </div>

              <div className="flex items-start gap-2 bg-blue-950/30 rounded-lg p-3 border border-blue-900/50 mt-4">
                <Lightbulb className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-blue-300 text-xs uppercase tracking-wider block mb-1">Sugestão de Correção</strong>
                  <p className="text-blue-100 text-sm">{violation.suggestion}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}