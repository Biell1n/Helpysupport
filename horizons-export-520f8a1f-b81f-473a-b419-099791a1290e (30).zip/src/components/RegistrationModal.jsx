import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Loader2, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import PasswordRequirements from './PasswordRequirements';
import PasswordStrengthIndicator from './PasswordStrengthIndicator';
import { useToast } from '@/components/ui/use-toast';
import AccountTypeSelector from './AccountTypeSelector';

export default function RegistrationModal({ isOpen, onClose, context }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedType, setSelectedType] = useState(null);
  const [showTypeSelector, setShowTypeSelector] = useState(true);
  
  const { register, createAnonymousSession } = useAuth();
  const { toast } = useToast();

  const isPasswordValid = 
    password.length >= 8 && 
    /[A-Z]/.test(password) && 
    /[0-9]/.test(password) && 
    /[^A-Za-z0-9]/.test(password);

  const handleSubmit = useCallback(async (e) => {
    e.preventDefault();
    if (!isPasswordValid || !selectedType) return;
    
    setLoading(true);
    try {
      const success = await register(email, password, selectedType);
      if (success) {
        onClose();
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [email, password, selectedType, isPasswordValid, register, onClose]);

  const handleAnonymous = useCallback(() => {
    createAnonymousSession();
    onClose();
    toast({
      title: "Modo Anônimo",
      description: "Você está usando o chat temporariamente."
    });
  }, [createAnonymousSession, onClose, toast]);

  const handleClose = useCallback(() => {
    setShowTypeSelector(true);
    setSelectedType(null);
    setEmail('');
    setPassword('');
    onClose();
  }, [onClose]);

  const handleTypeSelect = useCallback((type) => {
    setSelectedType(type);
    setShowTypeSelector(false);
  }, []);

  const handleSelectorClose = useCallback(() => {
    setShowTypeSelector(false);
    if (!selectedType) {
      setTimeout(() => {
        setSelectedType(prev => {
          if (!prev) handleClose();
          return prev;
        });
      }, 50);
    }
  }, [selectedType, handleClose]);

  if (!isOpen) return null;

  return (
    <>
      <AccountTypeSelector 
        isOpen={isOpen && showTypeSelector}
        onClose={handleSelectorClose}
        onSelect={handleTypeSelect}
      />

      <AnimatePresence>
        {isOpen && !showTypeSelector && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-neutral-900 border-none outline-none ring-0 rounded-sm w-full max-w-md shadow-2xl overflow-hidden"
            >
              <div className="p-8">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="text-xl font-bold text-white mb-1">Crie sua conta</h2>
                    <p className="text-sm text-neutral-400">
                      {selectedType === 'end_customer' ? 'Conta de Cliente' : 'Conta Empresarial'}
                    </p>
                  </div>
                  <button onClick={handleClose} className="text-neutral-500 hover:text-white transition-colors border-none outline-none focus:ring-0">
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-1.5">Email</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-4 py-3 bg-neutral-950 border-none outline-none ring-0 focus:ring-0 rounded-sm text-white placeholder-neutral-500"
                      placeholder="seu@email.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-1.5">Senha</label>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-3 bg-neutral-950 border-none outline-none ring-0 focus:ring-0 rounded-sm text-white placeholder-neutral-500"
                      placeholder="••••••••"
                    />
                    <PasswordStrengthIndicator password={password} />
                    <PasswordRequirements password={password} />
                  </div>

                  <div className="pt-4">
                    <Button 
                      type="submit" 
                      disabled={loading || !isPasswordValid}
                      className="w-full bg-white hover:bg-neutral-200 text-black border-none ring-0 outline-none focus:ring-0 font-bold py-6 rounded-sm"
                    >
                      {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Criar Conta'}
                    </Button>
                  </div>
                </form>

                <div className="mt-8 flex items-center gap-4">
                  <div className="h-px bg-neutral-800 flex-1"></div>
                  <span className="text-xs text-neutral-500 font-medium">OU</span>
                  <div className="h-px bg-neutral-800 flex-1"></div>
                </div>

                <button 
                  onClick={handleAnonymous}
                  className="mt-6 w-full flex items-center justify-center gap-2 text-sm text-neutral-400 hover:text-white transition-colors py-2 border-none outline-none"
                >
                  Continuar como Anônimo <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}