import React from 'react';
import { useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';
import { CheckCircle2, AlertCircle, AlertTriangle, Circle } from 'lucide-react';

export default function StatusIndicator() {
  const { structuredState } = useAssistantMemoryContext();

  const getStatusIcon = (status) => {
    switch(status) {
      case 'completo': return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'parcial': return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'incompleto': return <AlertCircle className="w-5 h-5 text-red-500" />;
      case 'ignorado': return <Circle className="w-5 h-5 text-gray-500" />;
      default: return <Circle className="w-5 h-5 text-neutral-500" />;
    }
  };

  const getBorderColor = (cor) => {
    switch(cor) {
      case 'verde': return 'border-green-500/30 bg-green-500/5';
      case 'amarelo': return 'border-yellow-500/30 bg-yellow-500/5';
      case 'vermelho': return 'border-red-500/30 bg-red-500/5';
      case 'cinza': return 'border-gray-500/30 bg-gray-500/5';
      default: return 'border-neutral-800 bg-neutral-900';
    }
  };

  const fields = [
    { key: 'descricao', label: 'Descrição do Negócio' },
    { key: 'endereco', label: 'Endereço' },
    { key: 'contato', label: 'Canais de Contato' },
    { key: 'produtos', label: 'Produtos e Serviços' }
  ];

  return (
    <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden shadow-2xl h-full flex flex-col">
      <div className="p-4 border-b border-neutral-800 bg-neutral-900/50">
        <h3 className="font-bold text-white">Status dos Campos</h3>
        <p className="text-xs text-neutral-400">Análise inteligente da configuração</p>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
        {fields.map(field => {
          const data = structuredState[field.key];
          if (!data) return null;

          return (
            <div key={field.key} className={`p-4 rounded-lg border ${getBorderColor(data.cor)}`}>
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center gap-2">
                  {getStatusIcon(data.status)}
                  <h4 className="font-bold text-white text-sm capitalize">{field.label}</h4>
                </div>
                <span className="text-xs px-2 py-1 rounded bg-black/50 text-white capitalize">{data.status}</span>
              </div>
              <p className="text-xs text-neutral-300 mt-2 leading-relaxed">
                {data.diagnostico || 'Aguardando informações para gerar o diagnóstico...'}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}