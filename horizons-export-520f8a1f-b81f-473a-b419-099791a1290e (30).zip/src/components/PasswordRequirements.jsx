import React from 'react';
import { Check, X } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function PasswordRequirements({ password }) {
  const requirements = [
    { label: "Mínimo 8 caracteres", test: (p) => p.length >= 8 },
    { label: "Pelo menos 1 letra maiúscula", test: (p) => /[A-Z]/.test(p) },
    { label: "Pelo menos 1 número", test: (p) => /[0-9]/.test(p) },
    { label: "Pelo menos 1 caractere especial", test: (p) => /[^A-Za-z0-9]/.test(p) },
  ];

  return (
    <div className="grid grid-cols-2 gap-2 mt-3">
      {requirements.map((req, index) => {
        const isMet = req.test(password || '');
        return (
          <div 
            key={index} 
            className={cn(
              "flex items-center gap-2 text-xs transition-colors duration-200",
              isMet ? "text-green-400" : "text-neutral-500"
            )}
          >
            {isMet ? (
              <Check className="w-3 h-3 text-green-500" />
            ) : (
              <X className="w-3 h-3 text-neutral-600" />
            )}
            <span>{req.label}</span>
          </div>
        );
      })}
    </div>
  );
}