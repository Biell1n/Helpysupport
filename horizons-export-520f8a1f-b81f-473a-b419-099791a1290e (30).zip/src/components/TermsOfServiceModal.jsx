import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { ShieldAlert, CheckCircle, AlertTriangle, Scale, Lock, FileText } from 'lucide-react';
import { useSound } from '@/hooks/useSound';

export default function TermsOfServiceModal({ isOpen, onClose, isForceOpen = false, onDecline }) {
  const [agreed, setAccepted] = useState(false);
  const [show, setShow] = useState(false);
  const { play } = useSound();

  useEffect(() => {
    if (isOpen || isForceOpen) {
      setShow(true);
      play('notification');
    } else {
      setShow(false);
    }
  }, [isOpen, isForceOpen, play]);

  const handleAccept = () => {
    play('success');
    localStorage.setItem('termsAccepted', 'true');
    setShow(false);
    if (onClose) onClose();
  };

  const handleDecline = () => {
    if (onDecline) onDecline();
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-neutral-950 border border-neutral-800 rounded-3xl w-full max-w-3xl flex flex-col shadow-2xl max-h-[90vh] overflow-hidden animate-scale-up">
        {/* Header */}
        <div className="p-6 border-b border-neutral-800 bg-neutral-900/50 flex items-center gap-4">
          <div className="bg-blue-600/20 p-3 rounded-xl border border-blue-500/30">
            <Scale className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Termos de Serviço e Políticas de Uso</h2>
            <p className="text-neutral-400 text-sm mt-1">Por favor, leia atentamente antes de continuar.</p>
          </div>
          {!isForceOpen && onClose && (
             <button onClick={onClose} className="ml-auto text-neutral-500 hover:text-white transition-colors">
                <FileText className="w-6 h-6" />
             </button>
          )}
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-8 custom-scrollbar">
          
          <section>
            <h3 className="text-xl font-semibold text-white flex items-center gap-2 mb-4">
              <ShieldAlert className="w-5 h-5 text-red-400" /> 1. Conteúdo Proibido
            </h3>
            <p className="text-neutral-300 mb-4 leading-relaxed">
              Nossos serviços utilizam inteligência artificial avançada. Para garantir um ambiente seguro e profissional, é estritamente proibido criar assistentes ou gerar conteúdos que se enquadrem nas seguintes categorias:
            </p>
            <ul className="space-y-4 text-sm text-neutral-400">
              <li className="bg-neutral-900/50 p-4 rounded-xl border border-neutral-800 transition-all hover:bg-neutral-900">
                <strong className="text-white block mb-1">Racismo e Discurso de Ódio</strong>
                Qualquer linguagem que promova discriminação, ódio ou violência contra grupos baseados em raça, religião, orientação sexual ou deficiência.
              </li>
              <li className="bg-neutral-900/50 p-4 rounded-xl border border-neutral-800 transition-all hover:bg-neutral-900">
                <strong className="text-white block mb-1">Violência e Atividades Ilegais</strong>
                Incentivo a danos físicos, terrorismo, venda de substâncias ilícitas, pirataria, fraudes, ou instruções para cometer crimes.
              </li>
              <li className="bg-neutral-900/50 p-4 rounded-xl border border-neutral-800 transition-all hover:bg-neutral-900">
                <strong className="text-white block mb-1">Conteúdo Sexual Explícito e Assédio</strong>
                Promoção de pornografia, serviços de acompanhantes, bullying, doxxing, chantagem ou qualquer forma de intimidação direcionada.
              </li>
              <li className="bg-neutral-900/50 p-4 rounded-xl border border-neutral-800 transition-all hover:bg-neutral-900">
                <strong className="text-white block mb-1">Desinformação Grave</strong>
                Disseminação de informações falsas que possam causar riscos à saúde pública, segurança ou processos eleitorais.
              </li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-white flex items-center gap-2 mb-4">
              <CheckCircle className="w-5 h-5 text-green-400" /> 2. Direitos e Responsabilidades do Usuário
            </h3>
            <p className="text-neutral-300 leading-relaxed">
              Você é inteiramente responsável pelos dados, instruções e configurações que fornece ao seu assistente. Você garante que possui os direitos necessários para usar as informações fornecidas e concorda em não tentar contornar nossos sistemas de moderação de segurança.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-white flex items-center gap-2 mb-4">
              <Lock className="w-5 h-5 text-blue-400" /> 3. Compromisso de Uso Ético
            </h3>
            <p className="text-neutral-300 leading-relaxed">
              Ao utilizar nossa plataforma, você se compromete a usar a Inteligência Artificial de maneira ética, construtiva e voltada para a melhoria do atendimento ao cliente e suporte a negócios legítimos.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-white flex items-center gap-2 mb-4">
              <AlertTriangle className="w-5 h-5 text-orange-400" /> 4. Consequências de Violações
            </h3>
            <p className="text-neutral-300 leading-relaxed">
              A violação destas políticas resultará em ações imediatas, que podem incluir: bloqueio das respostas do assistente, suspensão temporária da conta, exclusão permanente de assistentes infratores ou banimento definitivo da plataforma sem direito a reembolso.
            </p>
          </section>

        </div>

        {/* Footer Action Area */}
        <div className="p-6 border-t border-neutral-800 bg-neutral-950 flex flex-col gap-4">
           {isForceOpen && (
              <div className="flex items-start gap-3 p-4 bg-neutral-900 rounded-xl border border-neutral-800 transition-colors hover:border-neutral-700">
                <Checkbox 
                   id="terms" 
                   checked={agreed} 
                   onCheckedChange={(checked) => setAccepted(checked)}
                   className="mt-1 border-neutral-600 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                />
                <div className="grid gap-1.5 leading-none">
                  <label htmlFor="terms" className="text-sm font-medium text-white cursor-pointer select-none">
                    Eu compreendo e concordo com os Termos de Serviço
                  </label>
                  <p className="text-xs text-neutral-400">
                    Ao marcar esta opção, confirmo que li as políticas e aceito cumpri-las integralmente.
                  </p>
                </div>
              </div>
           )}

          <div className="flex gap-3 justify-end mt-2">
            {isForceOpen && (
              <Button variant="ghost" onClick={handleDecline} className="text-neutral-400 hover:text-white hover:bg-neutral-800">
                Recusar
              </Button>
            )}
            {isForceOpen ? (
              <Button 
                 onClick={handleAccept} 
                 disabled={!agreed}
                 className={`font-bold px-8 ${agreed ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'}`}
              >
                Aceitar e Continuar
              </Button>
            ) : (
              <Button onClick={onClose} className="bg-white text-black hover:bg-neutral-200 font-bold px-8">
                Fechar
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}