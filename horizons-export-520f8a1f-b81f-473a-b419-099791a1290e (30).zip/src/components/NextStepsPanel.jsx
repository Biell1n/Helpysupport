import React from 'react';
import { CheckCircle, Circle, TrendingUp, Sparkles } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function NextStepsPanel({ completionStatus, nextStep, progress }) {
  if (!completionStatus && !nextStep && !progress) return null;

  const {
    mandatoryFields = [],
    completedMandatory = [],
    missingMandatory = []
  } = completionStatus || {};

  const fieldLabels = {
    'descricao': 'Descrição do negócio',
    'catalogo': 'Catálogo de produtos',
    'contato': 'Informações de contato',
    'personalidade': 'Personalidade do assistente',
    'regras': 'Regras de atendimento'
  };

  const currentProgress = progress || completionStatus?.progress || 0;

  return (
    <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/30 p-4 shadow-lg">
      <div className="flex items-center gap-2 mb-3">
        <Sparkles className="w-5 h-5 text-green-400" />
        <h3 className="text-lg font-bold text-green-400">Próximos Passos</h3>
        <Badge variant="outline" className="ml-auto bg-green-500/20 text-green-300 border-green-500/50">
          {currentProgress}% completo
        </Badge>
      </div>

      <div className="space-y-2">
        {mandatoryFields.map((field) => {
          const isComplete = completedMandatory.includes(field);
          const isCurrent = nextStep === field;
          
          return (
            <div 
              key={field}
              className={`flex items-center gap-3 p-2 rounded-lg transition-all ${
                isCurrent 
                  ? 'bg-blue-500/20 border border-blue-500/50' 
                  : isComplete 
                    ? 'bg-green-500/10' 
                    : 'bg-neutral-800/50'
              }`}
            >
              {isComplete ? (
                <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
              ) : (
                <Circle className={`w-5 h-5 flex-shrink-0 ${isCurrent ? 'text-blue-400' : 'text-neutral-500'}`} />
              )}
              
              <div className="flex-1 min-w-0">
                <p className={`text-sm font-medium ${
                  isComplete 
                    ? 'text-green-300' 
                    : isCurrent 
                      ? 'text-blue-300' 
                      : 'text-neutral-400'
                }`}>
                  {fieldLabels[field] || field}
                </p>
                {isCurrent && (
                  <p className="text-xs text-blue-400 mt-0.5">← Você está aqui</p>
                )}
                {isComplete && (
                  <p className="text-xs text-green-500 mt-0.5">✓ Completo!</p>
                )}
              </div>

              {isCurrent && (
                <TrendingUp className="w-4 h-4 text-blue-400 animate-pulse" />
              )}
            </div>
          );
        })}
      </div>

      {currentProgress >= 100 && (
        <div className="mt-4 pt-4 border-t border-green-500/30">
          <p className="text-sm text-green-300 font-medium text-center">
            🎉 Configuração 100% completa! Seu assistente está pronto!
          </p>
        </div>
      )}

      {currentProgress < 100 && missingMandatory.length > 0 && (
        <div className="mt-4 pt-4 border-t border-green-500/30">
          <p className="text-xs text-neutral-400 text-center">
            Faltam {missingMandatory.length} campo(s) obrigatório(s) para completar
          </p>
        </div>
      )}
    </Card>
  );
}