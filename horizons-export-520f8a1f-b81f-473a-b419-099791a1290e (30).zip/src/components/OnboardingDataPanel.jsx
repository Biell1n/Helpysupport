import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, AlertCircle, Clock, Database, ChevronRight } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

const FieldBadge = ({ status, depthLevel }) => {
  if (status === 'confirmed') {
    return (
      <div className="flex items-center gap-1 text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-green-500/20 text-green-400">
        <CheckCircle2 className="w-3 h-3" /> Confirmed
      </div>
    );
  }
  if (status === 'partial') {
    return (
      <div className="flex items-center gap-1 text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-400">
        <AlertCircle className="w-3 h-3" /> Partial ({depthLevel}/3)
      </div>
    );
  }
  return (
    <div className="flex items-center gap-1 text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-500">
      <Clock className="w-3 h-3" /> Pending
    </div>
  );
};

const FieldItem = ({ fieldName, isCritical, extractedData, depthAnalysis }) => {
  const data = extractedData[fieldName];
  const depth = depthAnalysis[fieldName];
  const status = data ? data.status : 'pending';
  const displayValue = data ? (typeof data.value === 'object' ? JSON.stringify(data.value) : String(data.value)) : 'Not provided yet';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      className={`p-3 rounded-lg border ${
        status === 'confirmed' ? 'bg-green-950/10 border-green-900/30' : 
        status === 'partial' ? 'bg-yellow-950/10 border-yellow-900/30' : 
        'bg-neutral-900/50 border-white/5'
      }`}
    >
      <div className="flex items-center justify-between mb-1.5">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-white capitalize">{fieldName.replace(/_/g, ' ')}</span>
          {isCritical && <span className="text-[9px] px-1 bg-red-500/20 text-red-400 rounded uppercase font-bold">Critical</span>}
        </div>
        <FieldBadge status={status} depthLevel={depth?.current_depth || 0} />
      </div>
      
      <p className={`text-xs ${status === 'pending' ? 'text-neutral-500 italic' : 'text-neutral-300'} line-clamp-2`}>
        {displayValue}
      </p>

      {status === 'partial' && depth?.missing_details?.length > 0 && (
        <div className="mt-2 pl-2 border-l-2 border-yellow-500/30">
          <p className="text-[10px] text-neutral-400 mb-1">Missing details:</p>
          <ul className="space-y-0.5">
            {depth.missing_details.map((detail, i) => (
              <li key={i} className="text-[10px] text-yellow-500/80 flex items-center gap-1">
                <ChevronRight className="w-2.5 h-2.5" /> {detail}
              </li>
            ))}
          </ul>
        </div>
      )}
    </motion.div>
  );
};

export default function OnboardingDataPanel({ sessionState }) {
  const { 
    critical_fields = [], 
    important_fields = [], 
    optional_fields = [], 
    extracted_data = {}, 
    depth_analysis = {},
    next_objective = ""
  } = sessionState || {};

  return (
    <div className="flex flex-col h-full bg-neutral-950 border-l border-white/10 w-80 lg:w-96 shrink-0">
      <div className="p-4 border-b border-white/10 bg-neutral-900/30">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2">
          <Database className="w-4 h-4 text-primary" />
          Data Extraction Status
        </h2>
        {next_objective && (
          <div className="mt-3 p-2 bg-primary/10 border border-primary/20 rounded-md">
            <p className="text-[10px] text-primary/80 font-bold uppercase mb-0.5">Current Focus</p>
            <p className="text-xs text-primary-foreground font-medium">{next_objective}</p>
          </div>
        )}
      </div>

      <ScrollArea className="flex-1 p-4">
        <div className="space-y-6 pb-10">
          
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider sticky top-0 bg-neutral-950/90 backdrop-blur-sm py-1 z-10">
              Critical Requirements ({critical_fields.filter(f => extracted_data[f]?.status === 'confirmed').length}/{critical_fields.length})
            </h3>
            <div className="space-y-2">
              <AnimatePresence>
                {critical_fields.map(field => (
                  <FieldItem 
                    key={field} 
                    fieldName={field} 
                    isCritical={true}
                    extractedData={extracted_data} 
                    depthAnalysis={depth_analysis} 
                  />
                ))}
              </AnimatePresence>
              {critical_fields.length === 0 && (
                <p className="text-xs text-neutral-500 italic text-center py-2">Detecting business type...</p>
              )}
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider sticky top-0 bg-neutral-950/90 backdrop-blur-sm py-1 z-10">
              Important Enhancements ({important_fields.filter(f => extracted_data[f]?.status === 'confirmed').length}/{important_fields.length})
            </h3>
            <div className="space-y-2">
              <AnimatePresence>
                {important_fields.map(field => (
                  <FieldItem 
                    key={field} 
                    fieldName={field} 
                    isCritical={false}
                    extractedData={extracted_data} 
                    depthAnalysis={depth_analysis} 
                  />
                ))}
              </AnimatePresence>
              {important_fields.length === 0 && (
                <p className="text-xs text-neutral-500 italic text-center py-2">Waiting for discovery phase...</p>
              )}
            </div>
          </div>

        </div>
      </ScrollArea>
    </div>
  );
}