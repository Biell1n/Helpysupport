import React from 'react';
import { Button } from '@/components/ui/button';
import { ChevronRight, ChevronLeft } from 'lucide-react';

export default function StepContainer({ 
  children, 
  currentStep, 
  totalSteps, 
  onNext, 
  onPrev, 
  isNextDisabled = false,
  nextLabel = "Avançar",
  showControls = true
}) {
  return (
    <div className="flex flex-col h-full animate-fade-in">
      <div className="flex-1">
        {children}
      </div>
      
      {showControls && (
        <div className="flex justify-between items-center mt-8 pt-6 border-t border-white/10">
          <Button
            variant="ghost"
            onClick={onPrev}
            disabled={currentStep === 0}
            className={`text-neutral-400 hover:text-white hover:bg-neutral-800 ${currentStep === 0 ? 'invisible' : ''}`}
          >
            <ChevronLeft className="w-4 h-4 mr-2" /> Voltar
          </Button>
          
          <Button
            onClick={onNext}
            disabled={isNextDisabled}
            className="bg-white text-black hover:bg-neutral-200 font-bold px-8 transition-all active:scale-95"
          >
            {nextLabel} {currentStep < totalSteps - 1 && <ChevronRight className="w-4 h-4 ml-2" />}
          </Button>
        </div>
      )}
    </div>
  );
}