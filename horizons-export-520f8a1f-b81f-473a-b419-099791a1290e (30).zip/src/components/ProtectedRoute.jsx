import React, { useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { storageKind } from '@/lib/supabase';
import { Loader2 } from 'lucide-react';

/**
 * Tela de espera. Depois de 6 segundos ela para de ser só uma rodinha e
 * mostra o que está acontecendo, com uma saída manual. Diagnosticar no
 * celular sem console é praticamente impossível, então a informação
 * aparece na própria tela.
 */
function TelaCarregando({ fase, diag }) {
  const [demorou, setDemorou] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setDemorou(true), 6000);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-black relative px-6">
      <div className="absolute inset-0 bg-neutral-950/50 backdrop-blur-sm z-0"></div>
      <div className="z-10 flex flex-col items-center text-center">
        <Loader2 className="w-12 h-12 text-white animate-spin mb-4" />
        <p className="text-neutral-400 font-medium animate-pulse">Verificando autenticação...</p>

        {demorou && (
          <div className="mt-8 max-w-xs w-full">
            <p className="text-xs text-neutral-500 leading-relaxed mb-4">
              Está demorando mais que o normal. Isso costuma ser conexão lenta.
            </p>
            <div className="text-[10px] font-mono text-neutral-600 mb-5 break-all space-y-1 text-left">
              <p>armazenamento: {storageKind}</p>
              <p>etapa: {fase || 'desconhecida'}</p>
              <p>usuario: {diag?.temUser ? 'sim' : 'nao'}</p>
              <p>autenticado: {diag?.auth ? 'sim' : 'nao'}</p>
              <p>2fa pendente: {diag?.dois ? 'SIM' : 'nao'}</p>
              <p>perfil: {diag?.perfil || 'nenhum'}</p>
              <p>online: {typeof navigator !== 'undefined' && navigator.onLine ? 'sim' : 'não'}</p>
            </div>
            <a
              href="/auth"
              className="inline-block text-xs text-neutral-300 border border-neutral-700 px-4 py-2 hover:text-white hover:border-neutral-400 transition-colors"
            >
              Ir para o login
            </a>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ProtectedRoute({ children, checkPermission, allowAnonymous = false }) {
  const { isAuthenticated, isAnonymous, isEmailVerified, userProfile, isPending, loading, error, signOut, clearError, authPhase, user, pendingTwoFactor } = useAuth();
  const location = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    if (error) {
      toast({ 
        title: 'Sessão Expirada', 
        description: 'Sua sessão expirou. Por favor, faça login novamente.', 
        variant: 'destructive' 
      });
      clearError();
      signOut();
    }
  }, [error, toast, signOut, clearError]);

  if (loading) {
    return (
      <TelaCarregando
        fase={authPhase}
        diag={{
          temUser: !!user,
          auth: isAuthenticated,
          dois: pendingTwoFactor,
          perfil: userProfile?.user_type,
        }}
      />
    );
  }

  if (error) {
    return <Navigate to="/auth" state={{ view: 'login', message: "Sua sessão expirou ou é inválida. Faça login novamente." }} replace />;
  }

  if (allowAnonymous && isAnonymous) {
      return children;
  }

  if (!isAuthenticated) {
    if (isAnonymous && !allowAnonymous) {
        return <Navigate to="/auth" state={{ from: location, message: "Faça login para acessar esta página", view: 'login' }} replace />;
    }
    return <Navigate to="/auth" state={{ from: location, view: 'login' }} replace />;
  }

  if (isPending && location.pathname !== '/complete-cadastro') {
      return <Navigate to="/complete-cadastro" replace />;
  }

  if (!isPending && location.pathname === '/complete-cadastro') {
      return <Navigate to="/dashboard" replace />;
  }

  if ((userProfile?.user_type === 'business_owner' || userProfile?.user_type === 'business') && !isEmailVerified && location.pathname !== '/complete-cadastro' && location.pathname !== '/verify-registration') {
     return <Navigate to="/verify-registration" state={{ userId: userProfile?.id, email: userProfile?.email, companyName: userProfile?.company_name }} replace />;
  }

  if (checkPermission && !checkPermission()) {
      return <Navigate to="/forbidden" replace />;
  }

  return children;
}