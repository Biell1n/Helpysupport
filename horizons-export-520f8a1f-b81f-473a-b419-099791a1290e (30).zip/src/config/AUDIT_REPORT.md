# Relatório de Auditoria de Modelos IA - Horizons

**Data da Auditoria:** 2026-05-25

## 1. Escopo da Auditoria
Análise das configurações de modelos de IA nos serviços e Edge Functions para garantir padronização, eficiência e uso do modelo `gpt-4o`.

## 2. Arquivos Analisados

### `supabase/functions/onboarding-chat/index.ts`
- **Status Anterior:** Utilizava `gpt-4o-mini` chumbado na requisição fetch. Temperatura 0.7, sem definição explícita de `max_tokens`.
- **Ação:** Atualizado para usar o novo wrapper centralizado com a configuração global `SYSTEM_ONBOARDING_ASSISTANT` (`gpt-4o`, temp 0.7, max_tokens 4096).

### `supabase/functions/chat/index.ts`
- **Status Anterior:** Arquivo ausente ou desatualizado.
- **Ação:** Criado arquivo padronizado que busca a configuração dinâmica do banco de dados (assistant_settings) ou faz fallback para `COMPANY_ASSISTANT` (`gpt-4o`).

### `src/services/assistant/assistantService.ts`
- **Status Anterior:** A criação de assistants injetava `model: 'gpt-4o-mini'` e `max_tokens: 2000` em `assistant_settings`.
- **Ação:** Recomenda-se atualização (feita via migration) para `gpt-4o` e `max_tokens: 4096`.

## 3. Banco de Dados
- **Tabela `assistants`:** Adicionada coluna `model` padrão `'gpt-4o'`.
- **Tabela `assistant_settings`:** Adicionadas/Atualizadas colunas `model`, `temperature`, `max_tokens`, `top_p`.
- **Status:** Todos os registros foram migrados para `gpt-4o`, `temperature: 0.7`, `max_tokens: 4096`.

## 4. Recomendações Implementadas
- Centralização das chamadas OpenAI em `openaiClient.ts`.
- Padronização de constantes em `aiModels.ts`.
- Gerenciamento persistente de contexto via `contextManager.ts`.