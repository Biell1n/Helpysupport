/**
 * Configuração Global de Modelos de Inteligência Artificial
 */

export interface ModelConfig {
  model: string;
  temperature: number;
  max_tokens: number;
  top_p: number;
  description?: string;
}

export const DEFAULT_MODEL_CONFIG: ModelConfig = {
  model: 'gpt-4o',
  temperature: 0.7,
  max_tokens: 4096,
  top_p: 1.0,
};

export const AI_MODELS = {
  // Consultor IA para onboarding inteligente. Usa gpt-4o para contexto estendido e reasoning superior.
  SYSTEM_ONBOARDING_ASSISTANT: {
    model: 'gpt-4o',
    temperature: 0.7,
    max_tokens: 4096,
    top_p: 1.0,
    description: 'Consultor IA para onboarding inteligente'
  } as ModelConfig,

  // Assistant final configurado para as empresas atenderem clientes.
  COMPANY_ASSISTANT: {
    model: 'gpt-4o',
    temperature: 0.7,
    max_tokens: 4096,
    top_p: 1.0,
    description: 'Assistant final das empresas'
  } as ModelConfig,

  // Gerador de prompts estruturados para a plataforma. Menor temperatura para evitar alucinações de schema.
  PROMPT_GENERATOR: {
    model: 'gpt-4o',
    temperature: 0.5,
    max_tokens: 2048,
    top_p: 1.0,
    description: 'Gerador de prompts estruturados'
  } as ModelConfig,
};