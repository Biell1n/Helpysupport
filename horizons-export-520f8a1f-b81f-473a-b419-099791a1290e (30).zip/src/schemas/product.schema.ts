/**
 * Zod validation schemas for product operations
 */

import { z } from 'zod';

/**
 * Schema for creating a product
 */
export const CreateProductSchema = z.object({
  assistant_id: z.string().uuid('ID do assistente inválido'),
  
  name: z.string()
    .min(2, 'Nome deve ter no mínimo 2 caracteres')
    .max(200, 'Nome deve ter no máximo 200 caracteres'),
  
  description: z.string()
    .max(1000, 'Descrição deve ter no máximo 1000 caracteres')
    .optional()
    .nullable(),
  
  price: z.number()
    .positive('Preço deve ser positivo')
    .max(999999.99, 'Preço muito alto'),
  
  stock: z.number()
    .int('Estoque deve ser um número inteiro')
    .nonnegative('Estoque não pode ser negativo')
    .optional()
    .nullable(),
  
  metadata: z.record(z.any()).optional(),
});

/**
 * Schema for updating a product
 */
export const UpdateProductSchema = z.object({
  name: z.string()
    .min(2, 'Nome deve ter no mínimo 2 caracteres')
    .max(200, 'Nome deve ter no máximo 200 caracteres')
    .optional(),
  
  description: z.string()
    .max(1000, 'Descrição deve ter no máximo 1000 caracteres')
    .optional()
    .nullable(),
  
  price: z.number()
    .positive('Preço deve ser positivo')
    .max(999999.99, 'Preço muito alto')
    .optional(),
  
  stock: z.number()
    .int('Estoque deve ser um número inteiro')
    .nonnegative('Estoque não pode ser negativo')
    .optional()
    .nullable(),
  
  metadata: z.record(z.any()).optional(),
});

export type CreateProductInput = z.infer<typeof CreateProductSchema>;
export type UpdateProductInput = z.infer<typeof UpdateProductSchema>;