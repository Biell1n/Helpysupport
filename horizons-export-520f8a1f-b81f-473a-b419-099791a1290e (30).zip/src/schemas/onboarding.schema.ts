/**
 * Zod validation schemas for onboarding operations
 */

import { z } from 'zod';

/**
 * Schema for onboarding chat payload (session-based, absolutely NO assistant_id required)
 */
export const OnboardingChatPayloadSchema = z.object({
  message: z.string()
    .min(1, 'Mensagem não pode estar vazia')
    .max(5000, 'Mensagem muito longa'),
  
  session_id: z.string().uuid('Session ID inválido'),
  
  user_id: z.string().uuid('User ID inválido').optional(),
  
  onboarding_state: z.object({
    name: z.string().optional(),
    description: z.string().optional(),
    niche: z.string().optional(),
    tone_of_voice: z.string().optional(),
    personality: z.record(z.any()).optional(),
    rules: z.record(z.any()).optional(),
    products: z.array(z.any()).optional(),
    services: z.array(z.any()).optional(),
    contact: z.record(z.any()).optional(),
  }).optional(),
  
  extracted_data: z.object({
    name: z.string().optional(),
    description: z.string().optional(),
    niche: z.string().optional(),
    tone_of_voice: z.string().optional(),
    personality: z.record(z.any()).optional(),
    rules: z.record(z.any()).optional(),
    products: z.array(z.any()).optional(),
    services: z.array(z.any()).optional(),
    contact: z.record(z.any()).optional(),
  }).optional(),
  
  progress: z.number()
    .min(0, 'Progresso não pode ser negativo')
    .max(100, 'Progresso não pode exceder 100')
    .optional(),
  
  onboarding_completed: z.boolean().optional(),
});

/**
 * Schema for onboarding message 
 * REMOVED assistant_id completely to ensure strict session-based flow
 */
export const OnboardingMessageSchema = z.object({
  role: z.enum(['user', 'assistant', 'system'], {
    errorMap: () => ({ message: 'Tipo de mensagem inválido' })
  }),
  
  message: z.string()
    .min(1, 'Mensagem não pode estar vazia')
    .max(5000, 'Mensagem muito longa'),
  
  metadata: z.record(z.any()).optional(),
});

/**
 * Schema for onboarding state
 */
export const OnboardingStateSchema = z.object({
  currentStep: z.enum([
    'welcome',
    'company_info',
    'tone_personality',
    'products_services',
    'faqs',
    'rules',
    'complete'
  ], {
    errorMap: () => ({ message: 'Etapa de onboarding inválida' })
  }),
  
  completedSteps: z.array(z.enum([
    'welcome',
    'company_info',
    'tone_personality',
    'products_services',
    'faqs',
    'rules',
    'complete'
  ])),
  
  data: z.object({
    companyDescription: z.string().optional(),
    toneOfVoice: z.string().optional(),
    personality: z.string().optional(),
    behaviorStyle: z.string().optional(),
    products: z.array(z.object({
      name: z.string(),
      price: z.number().positive(),
      description: z.string().optional(),
    })).optional(),
    services: z.array(z.object({
      name: z.string(),
      price: z.number().positive(),
      duration: z.number().positive(),
      description: z.string().optional(),
    })).optional(),
    faqs: z.array(z.object({
      question: z.string(),
      answer: z.string(),
    })).optional(),
    rules: z.array(z.object({
      type: z.string(),
      content: z.string(),
    })).optional(),
  }),
  
  lastUpdated: z.string().datetime(),
});

export type OnboardingChatPayload = z.infer<typeof OnboardingChatPayloadSchema>;
export type OnboardingMessageInput = z.infer<typeof OnboardingMessageSchema>;
export type OnboardingStateInput = z.infer<typeof OnboardingStateSchema>;