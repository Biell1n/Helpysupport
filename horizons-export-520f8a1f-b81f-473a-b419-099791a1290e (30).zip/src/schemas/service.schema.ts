/**
 * Zod validation schemas for service operations
 */

import { z } from 'zod';

/**
 * Schema for creating a service
 */
export const CreateServiceSchema = z.object({
  assistant_id: z.string().uuid('ID do assistente inválido'),
  
  name: z.string()
    .min(2, 'Nome deve ter no mínimo 2 caracteres')
    .max(200, 'Nome deve ter no máximo 200 caracteres'),
  
  description: z.string()
    .max(1000, 'Descrição deve ter no máximo 1000 caracteres')
    .optional()
    .nullable(),
  
  duration_minutes: z.number()
    .int('Duração deve ser um número inteiro')
    .positive('Duração deve ser positiva')
    .max(1440, 'Duração não pode ser maior que 24 horas'),
  
  price: z.number()
    .positive('Preço deve ser positivo')
    .max(999999.99, 'Preço muito alto'),
  
  metadata: z.record(z.any()).optional(),
});

/**
 * Schema for updating a service
 */
export const UpdateServiceSchema = z.object({
  name: z.string()
    .min(2, 'Nome deve ter no mínimo 2 caracteres')
    .max(200, 'Nome deve ter no máximo 200 caracteres')
    .optional(),
  
  description: z.string()
    .max(1000, 'Descrição deve ter no máximo 1000 caracteres')
    .optional()
    .nullable(),
  
  duration_minutes: z.number()
    .int('Duração deve ser um número inteiro')
    .positive('Duração deve ser positiva')
    .max(1440, 'Duração não pode ser maior que 24 horas')
    .optional(),
  
  price: z.number()
    .positive('Preço deve ser positivo')
    .max(999999.99, 'Preço muito alto')
    .optional(),
  
  metadata: z.record(z.any()).optional(),
});

export type CreateServiceInput = z.infer<typeof CreateServiceSchema>;
export type UpdateServiceInput = z.infer<typeof UpdateServiceSchema>;