import { z } from 'zod';

/**
 * Schema for individual service extracted from conversation
 */
const ExtractedServiceSchema = z.object({
  name: z.string().min(1, 'Nome do serviço é obrigatório'),
  description: z.string().optional(),
  price: z.number().positive('Preço deve ser positivo').optional(),
  duration: z.number().positive('Duração deve ser positiva').optional(),
});

/**
 * Schema for individual product extracted from conversation
 */
const ExtractedProductSchema = z.object({
  name: z.string().min(1, 'Nome do produto é obrigatório'),
  description: z.string().optional(),
  price: z.number().positive('Preço deve ser positivo').optional(),
  stock: z.number().int().nonnegative('Estoque deve ser não-negativo').optional(),
});

/**
 * Schema for extracted business data from user messages
 */
export const ExtractedBusinessDataSchema = z.object({
  businessName: z.string().optional(),
  niche: z.string().optional(),
  description: z.string().optional(),
  services: z.array(ExtractedServiceSchema).optional().default([]),
  products: z.array(ExtractedProductSchema).optional().default([]),
  professionals: z.number().int().positive().optional(),
  toneOfVoice: z.string().optional(),
  personalityTraits: z.array(z.string()).optional().default([]),
  missingInformation: z.array(z.string()).default([]),
  confidenceScore: z.number().min(0).max(1).default(0),
});

/**
 * Schema for checklist item
 */
const ChecklistItemSchema = z.object({
  id: z.string(),
  label: z.string(),
  completed: z.boolean(),
  required: z.boolean(),
  confidence: z.number().min(0).max(1).optional(),
});

/**
 * Schema for onboarding message
 */
export const OnboardingMessageSchema = z.object({
  role: z.enum(['user', 'assistant', 'system']),
  content: z.string().min(1, 'Conteúdo da mensagem não pode estar vazio'),
  timestamp: z.string().datetime(),
  metadata: z.record(z.any()).optional(),
});

/**
 * Schema for complete onboarding context
 */
export const OnboardingContextSchema = z.object({
  assistantId: z.string().uuid('ID do assistente inválido'),
  userId: z.string().uuid('ID do usuário inválido'),
  extractedData: ExtractedBusinessDataSchema,
  conversationHistory: z.array(OnboardingMessageSchema),
  progress: z.number().min(0).max(100),
  completedFields: z.array(z.string()),
  checklist: z.array(ChecklistItemSchema),
  lastUpdated: z.string().datetime(),
});

/**
 * Schema for onboarding state
 */
export const OnboardingStateSchema = z.object({
  stage: z.enum(['initial', 'gathering', 'refining', 'completing']),
  completionPercentage: z.number().min(0).max(100),
  isComplete: z.boolean(),
  contextualChecklist: z.array(ChecklistItemSchema),
  extractedData: ExtractedBusinessDataSchema,
});

/**
 * Exported TypeScript types
 */
export type ExtractedService = z.infer<typeof ExtractedServiceSchema>;
export type ExtractedProduct = z.infer<typeof ExtractedProductSchema>;
export type ExtractedBusinessData = z.infer<typeof ExtractedBusinessDataSchema>;
export type ChecklistItem = z.infer<typeof ChecklistItemSchema>;
export type OnboardingMessage = z.infer<typeof OnboardingMessageSchema>;
export type OnboardingContext = z.infer<typeof OnboardingContextSchema>;
export type OnboardingState = z.infer<typeof OnboardingStateSchema>;