/**
 * Centralized schema exports
 */

export * from './assistant.schema';
export * from './onboarding.schema';
export * from './product.schema';
export * from './service.schema';
export * from './appointment.schema';