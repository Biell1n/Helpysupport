/**
 * Zod validation schemas for appointment operations
 */

import { z } from 'zod';

/**
 * Schema for creating an appointment
 */
export const CreateAppointmentSchema = z.object({
  assistant_id: z.string().uuid('ID do assistente inválido'),
  
  customer_name: z.string()
    .min(2, 'Nome deve ter no mínimo 2 caracteres')
    .max(200, 'Nome deve ter no máximo 200 caracteres'),
  
  customer_contact: z.string()
    .min(5, 'Contato inválido')
    .max(100, 'Contato muito longo'),
  
  professional_id: z.string()
    .uuid('ID do profissional inválido')
    .optional()
    .nullable(),
  
  start_time: z.string()
    .datetime('Data/hora de início inválida'),
  
  end_time: z.string()
    .datetime('Data/hora de término inválida'),
  
  status: z.enum(['pending', 'confirmed', 'cancelled', 'completed'], {
    errorMap: () => ({ message: 'Status inválido' })
  }).optional(),
  
  metadata: z.record(z.any()).optional(),
}).refine(
  (data) => new Date(data.end_time) > new Date(data.start_time),
  {
    message: 'Data/hora de término deve ser posterior à data/hora de início',
    path: ['end_time'],
  }
);

/**
 * Schema for updating an appointment
 */
export const UpdateAppointmentSchema = z.object({
  customer_name: z.string()
    .min(2, 'Nome deve ter no mínimo 2 caracteres')
    .max(200, 'Nome deve ter no máximo 200 caracteres')
    .optional(),
  
  customer_contact: z.string()
    .min(5, 'Contato inválido')
    .max(100, 'Contato muito longo')
    .optional(),
  
  professional_id: z.string()
    .uuid('ID do profissional inválido')
    .optional()
    .nullable(),
  
  start_time: z.string()
    .datetime('Data/hora de início inválida')
    .optional(),
  
  end_time: z.string()
    .datetime('Data/hora de término inválida')
    .optional(),
  
  status: z.enum(['pending', 'confirmed', 'cancelled', 'completed'], {
    errorMap: () => ({ message: 'Status inválido' })
  }).optional(),
  
  metadata: z.record(z.any()).optional(),
}).refine(
  (data) => {
    if (data.start_time && data.end_time) {
      return new Date(data.end_time) > new Date(data.start_time);
    }
    return true;
  },
  {
    message: 'Data/hora de término deve ser posterior à data/hora de início',
    path: ['end_time'],
  }
);

export type CreateAppointmentInput = z.infer<typeof CreateAppointmentSchema>;
export type UpdateAppointmentInput = z.infer<typeof UpdateAppointmentSchema>;