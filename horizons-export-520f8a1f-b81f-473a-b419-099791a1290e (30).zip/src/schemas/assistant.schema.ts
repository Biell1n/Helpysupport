/**
 * Zod validation schemas for assistant operations
 */

import { z } from 'zod';
import { VALID_ASSISTANT_STATUSES } from '@/constants/assistantStatus';

/**
 * Schema for creating a new assistant
 */
export const CreateAssistantSchema = z.object({
  name: z.string()
    .min(3, 'Nome deve ter no mínimo 3 caracteres')
    .max(100, 'Nome deve ter no máximo 100 caracteres'),
  
  niche: z.string()
    .min(3, 'Nicho deve ter no mínimo 3 caracteres')
    .max(100, 'Nicho deve ter no máximo 100 caracteres'),
  
  status: z.enum(['draft', 'active', 'inactive', 'archived'] as const, {
    errorMap: () => ({ message: 'Status inválido. Valores permitidos: draft, active, inactive, archived' })
  }).optional().default('draft'),
  
  timezone: z.string()
    .optional()
    .default('America/Sao_Paulo'),
  
  logo_url: z.string()
    .url('URL do logo inválida')
    .optional()
    .nullable(),
});

/**
 * Schema for updating an existing assistant
 */
export const UpdateAssistantSchema = z.object({
  name: z.string()
    .min(3, 'Nome deve ter no mínimo 3 caracteres')
    .max(100, 'Nome deve ter no máximo 100 caracteres')
    .optional(),
  
  niche: z.string()
    .min(3, 'Nicho deve ter no mínimo 3 caracteres')
    .max(100, 'Nicho deve ter no máximo 100 caracteres')
    .optional(),
  
  status: z.enum(['draft', 'active', 'inactive', 'archived'] as const, {
    errorMap: () => ({ message: 'Status inválido. Valores permitidos: draft, active, inactive, archived' })
  }).optional(),
  
  onboarding_completed: z.boolean().optional(),
  
  onboarding_progress: z.number()
    .min(0, 'Progresso não pode ser negativo')
    .max(100, 'Progresso não pode ser maior que 100')
    .optional(),
  
  timezone: z.string().optional(),
  
  logo_url: z.string()
    .url('URL do logo inválida')
    .optional()
    .nullable(),
});

/**
 * Schema for assistant profile
 */
export const AssistantProfileSchema = z.object({
  company_description: z.string()
    .min(10, 'Descrição deve ter no mínimo 10 caracteres')
    .max(1000, 'Descrição deve ter no máximo 1000 caracteres')
    .optional()
    .nullable(),
  
  tone_of_voice: z.string()
    .min(3, 'Tom de voz deve ter no mínimo 3 caracteres')
    .max(200, 'Tom de voz deve ter no máximo 200 caracteres')
    .optional()
    .nullable(),
  
  personality: z.string()
    .min(3, 'Personalidade deve ter no mínimo 3 caracteres')
    .max(200, 'Personalidade deve ter no máximo 200 caracteres')
    .optional()
    .nullable(),
  
  behavior_style: z.string()
    .min(3, 'Estilo de comportamento deve ter no mínimo 3 caracteres')
    .max(200, 'Estilo de comportamento deve ter no máximo 200 caracteres')
    .optional()
    .nullable(),
  
  onboarding_state: z.record(z.any()).optional(),
});

/**
 * Schema for assistant rule
 */
export const AssistantRuleSchema = z.object({
  rule_type: z.enum(['behavior', 'restriction', 'guideline', 'custom'], {
    errorMap: () => ({ message: 'Tipo de regra inválido' })
  }),
  
  content: z.string()
    .min(5, 'Conteúdo da regra deve ter no mínimo 5 caracteres')
    .max(500, 'Conteúdo da regra deve ter no máximo 500 caracteres'),
});

/**
 * Validates assistant status value
 * @param status Status to validate
 * @returns True if valid, false otherwise
 */
export function isValidAssistantStatus(status: string): boolean {
  return VALID_ASSISTANT_STATUSES.includes(status);
}

export type CreateAssistantInput = z.infer<typeof CreateAssistantSchema>;
export type UpdateAssistantInput = z.infer<typeof UpdateAssistantSchema>;
export type AssistantProfileInput = z.infer<typeof AssistantProfileSchema>;
export type AssistantRuleInput = z.infer<typeof AssistantRuleSchema>;