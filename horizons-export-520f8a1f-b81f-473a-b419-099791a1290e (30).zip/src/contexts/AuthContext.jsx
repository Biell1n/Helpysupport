import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { supabase, db } from '@/lib/supabase';
import { handleAuthError } from '@/lib/authUtils';
import { useToast } from '@/components/ui/use-toast';
import { retryWithBackoff, isNetworkError, isAuthTokenError } from '@/lib/supabaseHealthCheck';

const AuthContext = createContext(null);

const MAX_RETRY_ATTEMPTS = 3;
// Era 5000. No 4G, DNS + TLS + primeira consulta passam disso com
// facilidade, e quando passava o login ficava morto até recarregar.
const INIT_TIMEOUT_MS = 20000;

const mapAuthError = (error) => {
  const message = error?.message || '';
  if (message.includes('Invalid login credentials')) return 'Email ou senha incorretos.';
  if (message.includes('User already registered')) return 'Este email já está em uso.';
  if (message.includes('refresh_token_not_found')) return 'Sua sessão expirou.';
  if (message.includes('Supabase client not initialized')) return 'Erro de conexão. Verifique sua internet e tente novamente.';
  if (isNetworkError(error)) return 'Erro de rede. Verifique sua conexão com a internet.';
  return message || 'Ocorreu um erro de autenticação.';
};

// Era 10000. O login encadeia signInWithPassword + consulta em users +
// possível envio de e-mail de 2FA. No celular isso estourava.
const withTimeout = async (promise, timeoutMs = 30000) => {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => {
      const e = new Error('A requisição demorou muito para responder.');
      // marca para quem chama saber que foi LENTIDÃO, não sessão inválida
      e.isTimeout = true;
      reject(e);
    }, timeoutMs))
  ]);
};

/**
 * Identificador deste navegador, criado uma vez e guardado localmente.
 *
 * A confiança do 2FA é DESTE aparelho, não da conta. Antes era da conta:
 * quem verificasse uma vez liberava a senha sozinha em qualquer lugar
 * por 30 dias, o que anula o propósito do 2FA.
 *
 * Se o navegador não permitir armazenar, devolve null — e aí o código é
 * pedido sempre. Preferir errar para o lado seguro.
 */
export function obterDeviceId() {
  const CHAVE = 'helpy_device_id';
  try {
    let v = window.localStorage.getItem(CHAVE);
    if (!v) {
      v =
        typeof crypto !== 'undefined' && crypto.randomUUID
          ? crypto.randomUUID()
          : `d${Date.now()}${Math.random().toString(36).slice(2)}`;
      window.localStorage.setItem(CHAVE, v);
    }
    return v;
  } catch (_) {
    return null;
  }
}

/** Nome legível do aparelho, para a pessoa reconhecer na lista. */
export function rotuloDoAparelho() {
  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : '';
  const nav =
    /Edg\//.test(ua) ? 'Edge' :
    /OPR\//.test(ua) ? 'Opera' :
    /Chrome\//.test(ua) ? 'Chrome' :
    /Firefox\//.test(ua) ? 'Firefox' :
    /Safari\//.test(ua) ? 'Safari' : 'Navegador';
  const so =
    /Windows/.test(ua) ? 'Windows' :
    /Android/.test(ua) ? 'Android' :
    /iPhone|iPad/.test(ua) ? 'iOS' :
    /Mac OS/.test(ua) ? 'Mac' :
    /Linux/.test(ua) ? 'Linux' : '';
  return so ? `${nav} no ${so}` : nav;
}

const ehLentidao = (e) =>
  !!e?.isTimeout || /demorou muito|timeout|network|fetch|load failed/i.test(e?.message || '');

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [supabaseReady, setSupabaseReady] = useState(false);
  // Em que etapa a autenticação está. Aparece na tela de espera depois
  // de alguns segundos — diagnosticar celular sem console é inviável.
  const [authPhase, setAuthPhase] = useState('iniciando');
  const [initError, setInitError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  const [connectionError, setConnectionError] = useState(null);
  
  const [isEmailVerified, setIsEmailVerified] = useState(false);
  const [pendingTwoFactor, setPendingTwoFactor] = useState(false);
  const [pendingUserId, setPendingUserId] = useState(null);
  const [authError, setAuthError] = useState(null);
  
  const { toast } = useToast();
  const initAttemptedRef = useRef(false);
  const authListenerRef = useRef(null);

  const clearError = useCallback(() => {
    setAuthError(null);
    setConnectionError(null);
    setInitError(null);
  }, []);

  // 1. INITIALIZATION - Runs once on mount
  useEffect(() => {
    let mounted = true;
    let timeoutId;

    const initializeSupabase = async () => {
      if (initAttemptedRef.current && supabaseReady) {
        console.log('[AuthContext] Already initialized');
        return;
      }

      console.log('[AuthContext] Starting Supabase initialization...');
      initAttemptedRef.current = true;

      try {
        // Check if supabase client exists
        if (!supabase) {
          throw new Error('Supabase client not initialized. Check environment variables.');
        }

        // Check if supabase has required methods
        if (!supabase.auth || !supabase.from) {
          throw new Error('Supabase client is missing required methods (auth, from)');
        }

        // Set timeout for initialization
        const initPromise = new Promise(async (resolve, reject) => {
          try {
            // Verificação LOCAL. Antes aqui havia uma consulta de rede à
            // tabela "assistants", feita antes do login, dentro de um
            // prazo curto. Quando a rede demorava, supabaseReady nunca
            // virava true e o botão de entrar ficava morto para sempre.
            // Nada disso é necessário: se as credenciais existem e o
            // cliente foi construído, é o próprio login que deve dizer
            // se há problema de rede.
            if (!supabase?.auth?.signInWithPassword) {
              reject(new Error('Cliente Supabase incompleto'));
              return;
            }

            // getSession lê do armazenamento local; se precisar renovar o
            // token faz rede, então não deixamos isso travar a inicialização.
            try {
              await Promise.race([
                supabase.auth.getSession(),
                new Promise((r) => setTimeout(r, 3000)),
              ]);
            } catch (e) {
              console.warn('[AuthContext] getSession warning:', e);
            }

            resolve(true);
          } catch (err) {
            reject(err);
          }
        });

        // Falha ABERTA, de propósito. Se a inicialização demorar, o app
        // libera o login mesmo assim: é melhor tentar entrar e receber um
        // erro de verdade do que ficar com o botão inerte.
        timeoutId = setTimeout(() => {
          if (mounted) {
            console.warn('[AuthContext] Inicialização demorou; liberando login mesmo assim');
            setSupabaseReady(true);
            setLoading(false);
          }
        }, INIT_TIMEOUT_MS);

        await initPromise;

        if (mounted) {
          console.log('[AuthContext] Supabase initialized successfully ✓');
          setAuthPhase('conectado');
          setSupabaseReady(true);
          setInitError(null);
          setConnectionError(null);
          clearTimeout(timeoutId);
        }
      } catch (error) {
        console.error('[AuthContext] Initialization error:', error);
        if (mounted) {
          const errorMsg = error.message || 'Failed to initialize Supabase';
          setConnectionError(errorMsg);
          setLoading(false);
          // Só tranca o login se o próprio cliente não existir. Qualquer
          // outra falha aqui é de rede, e quem tem que reportar isso é a
          // tentativa de login, com mensagem específica.
          if (!supabase) {
            setInitError(errorMsg);
          } else {
            setSupabaseReady(true);
          }
        }
      }
    };

    initializeSupabase();

    return () => {
      mounted = false;
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [retryCount]); // Depend on retryCount to allow retries

  // Rede de segurança da tela de carregamento.
  // O ProtectedRoute mostra "Verificando autenticação..." enquanto
  // loading for true. Se qualquer coisa travar — rede pendurada, promise
  // que nunca resolve, erro fora de um try — a tela ficava presa para
  // sempre. Aqui ela é liberada de qualquer jeito: sem sessão, o
  // ProtectedRoute manda para o login, o que é uma resposta. Rodinha
  // infinita não é.
  useEffect(() => {
    if (!loading) return;
    const destravar = setTimeout(() => {
      console.warn('[AuthContext] carregamento preso por 12s; liberando a tela');
      setAuthPhase((f) => `destravado (${f})`);
      setLoading(false);
    }, 12000);
    return () => clearTimeout(destravar);
  }, [loading]);

  const handleRetry = useCallback(() => {
    if (retryCount >= MAX_RETRY_ATTEMPTS) {
      console.error('[AuthContext] Max retry attempts reached');
      toast({
        title: 'Muitas Tentativas',
        description: 'Não foi possível conectar. Entre em contato com o suporte.',
        variant: 'destructive'
      });
      return;
    }

    console.log(`[AuthContext] Retry attempt ${retryCount + 1}/${MAX_RETRY_ATTEMPTS}`);
    setRetryCount(prev => prev + 1);
    setInitError(null);
    setConnectionError(null);
    setSupabaseReady(false);
    initAttemptedRef.current = false;
  }, [retryCount, toast]);

  const checkAnonymousSession = useCallback(() => {
    const anonSession = localStorage.getItem('anonymousSession');
    if (anonSession) {
      try {
        const parsedSession = JSON.parse(anonSession);
        setUser(parsedSession);
        setUserProfile({ user_type: 'anonymous' });
        setIsEmailVerified(true);
      } catch (e) {
        localStorage.removeItem('anonymousSession');
        setUser(null);
        setUserProfile(null);
      }
    } else {
      setUser(null);
      setUserProfile(null);
    }
  }, []);

  const loadUserProfile = useCallback(async (userId) => {
    if (!supabaseReady) {
      console.warn('[AuthContext] Cannot load profile - Supabase not ready');
      return;
    }

    if (!supabase) {
      console.error('[AuthContext] Cannot load profile - Supabase client null');
      return;
    }

    try {
      console.log('[AuthContext] Loading user profile for:', userId);
      
      // Retry profile fetch with backoff
      const profile = await retryWithBackoff(
        async () => {
          const result = await db.getUserProfile(userId);
          if (!result && userId) {
            throw new Error('Profile not found');
          }
          return result;
        },
        2,
        600
      );
      
      setUserProfile(profile);
      
      if (profile) {
        if (profile.user_type === 'end_customer') {
          setIsEmailVerified(true);
        } else if (profile.user_type === 'business_owner' || profile.user_type === 'business') {
          setIsEmailVerified(!!profile.registration_verified || !!profile.email_verified);
        } else {
           setIsEmailVerified(false);
        }
      } else {
        setUserProfile(null);
        setIsEmailVerified(false);
      }
    } catch (error) {
      console.error('[AuthContext] Error loading user profile:', error);
      
      if (isNetworkError(error)) {
        toast({
          title: 'Erro de Conexão',
          description: 'Não foi possível carregar seu perfil. Verifique sua internet.',
          variant: 'destructive'
        });
      }
      
      setUserProfile(null);
    }
  }, [supabaseReady, toast]);

  const validateSession = useCallback(async () => {
    if (!supabaseReady) {
      throw new Error('Supabase not ready');
    }

    if (!supabase) {
      throw new Error('Supabase client not initialized');
    }

    const { data: { session }, error } = await supabase.auth.getSession();
    if (error) {
      await handleAuthError(error);
      throw error;
    }
    return session;
  }, [supabaseReady]);

  const checkSession = useCallback(async () => {
    try {
      setLoading(true);
      
      if (!supabaseReady) {
        console.warn('[AuthContext] Supabase not ready, checking anonymous session');
        setAuthPhase('aguardando conexão');
        checkAnonymousSession();
        return;
      }
      setAuthPhase('lendo sessão');

      if (!supabase) {
        console.error('[AuthContext] Supabase client is null');
        checkAnonymousSession();
        return;
      }

      // Prazo duro para a tela não ficar presa. Mas ATENÇÃO: estourar o
      // prazo significa rede lenta, NÃO sessão inválida. Se tratarmos
      // como inválida, o usuário é deslogado por estar no 4G.
      let session = null;
      try {
        session = await withTimeout(validateSession(), 20000);
      } catch (e) {
        if (ehLentidao(e)) {
          console.warn('[AuthContext] getSession demorou; mantendo o estado e deixando o listener resolver');
          return; // o finally libera a tela; ninguém é deslogado
        }
        throw e;
      }

      if (!session) {
        setAuthPhase('sem sessão');
        checkAnonymousSession();
      } else {
        setUser(session.user);
        setAuthPhase('sessão ok');
        setLoading(false); // libera já; o perfil vem depois

        withTimeout(loadUserProfile(session.user.id), 15000)
          .then(() => setAuthPhase('pronto'))
          .catch((e) => {
            console.warn('[AuthContext] perfil demorou, seguindo sem ele:', e?.message);
            setAuthPhase('sem perfil');
          });
      }
    } catch (error) {
      console.error('[AuthContext] Session check error:', error);
      if (ehLentidao(error)) {
        // problema de rede não é sessão expirada. Não desloga ninguém.
        console.warn('[AuthContext] falha de rede na verificação; mantendo o estado');
      } else {
        setAuthError(error);
        setUser(null);
        setUserProfile(null);
        checkAnonymousSession();
      }
    } finally {
      setLoading(false);
    }
  }, [supabaseReady, checkAnonymousSession, loadUserProfile, validateSession]);

  // 2. SESSION CHECK - Runs after supabase is ready
  useEffect(() => {
    if (!supabaseReady) {
      console.log('[AuthContext] Waiting for Supabase to be ready before checking session');
      return;
    }

    console.log('[AuthContext] Supabase ready, checking session...');
    checkSession();
  }, [supabaseReady]); // Only run when supabaseReady changes to true

  // 3. AUTH LISTENER SETUP - Runs only after supabase is ready
  useEffect(() => {
    if (!supabaseReady) {
      console.log('[AuthContext] Waiting for Supabase to be ready before setting up auth listener');
      return;
    }

    if (!supabase) {
      console.error('[AuthContext] Cannot set up auth listener - Supabase client null');
      setLoading(false);
      return;
    }

    let mounted = true;

    console.log('[AuthContext] Setting up auth state listener...');

    try {
      const { data } = supabase.auth.onAuthStateChange(async (event, session) => {
        if (!mounted) {
          console.log('[AuthContext] Component unmounted, ignoring auth change');
          return;
        }
        
        console.log('[AuthContext] Auth state changed:', event);
        
        if (event === 'PASSWORD_RECOVERY' || window.location.pathname === '/reset-password') {
           if (session?.user) setUser(session.user);
           setLoading(false);
           return; 
        }

        if (event === 'SIGNED_OUT' || event === 'USER_DELETED') {
          setUser(null);
          setUserProfile(null);
          setIsEmailVerified(false);
          setPendingTwoFactor(false);
          setPendingUserId(null);
          checkAnonymousSession();
          setLoading(false);
          return;
        }

        if (event === 'TOKEN_REFRESHED' && !session) {
          const err = new Error('refresh_token_not_found');
          setAuthError(err);
          await handleAuthError(err);
          return;
        }

        if (session?.user) {
          const pendingType = localStorage.getItem('pendingUserType');
          if (pendingType) {
            try {
              const { error: updateError } = await supabase.from('users').update({ user_type: pendingType }).eq('id', session.user.id);
              if (updateError) throw updateError;
              localStorage.removeItem('pendingUserType');
            } catch (e) {
              console.error("Failed to update user_type", e);
              await handleAuthError(e);
            }
          }

          if (!pendingTwoFactor) {
             // A sessão JÁ autentica. isAuthenticated depende só de "user".
             // Segurar a tela esperando o perfil era o que deixava o
             // celular preso em "Verificando autenticação...".
             setUser(session.user);
             setAuthPhase('sessão ok');
             setLoading(false);
             try { localStorage.removeItem('anonymousSession'); } catch (_) {}

             // perfil em segundo plano, sem travar nada
             withTimeout(loadUserProfile(session.user.id), 15000)
               .then(() => setAuthPhase('pronto'))
               .catch((e) => {
                 console.warn('[AuthContext] perfil em segundo plano falhou:', e?.message);
                 setAuthPhase('sem perfil');
               });
          }
        } else {
          checkAnonymousSession();
          setAuthPhase('sem sessão');
        }
        setLoading(false);
      });

      authListenerRef.current = data?.subscription;
      console.log('[AuthContext] Auth listener set up successfully ✓');

    } catch (err) {
       console.error('[AuthContext] Failed to initialize auth listener:', err);
       setLoading(false);
       setAuthError(err);
    }

    return () => {
      mounted = false;
      console.log('[AuthContext] Cleaning up auth listener');
      if (authListenerRef.current) {
        authListenerRef.current.unsubscribe();
        authListenerRef.current = null;
      }
    };
  }, [supabaseReady, pendingTwoFactor, checkAnonymousSession, loadUserProfile]); // Depend on supabaseReady

  const checkUserExists = useCallback(async (email) => {
    if (!email || !supabaseReady) return false;
    if (!supabase) {
      console.error('[checkUserExists] Supabase client null');
      return false;
    }

    try {
      const { data, error } = await supabase.from('users').select('id, user_type').eq('email', email).maybeSingle();
      if (error) {
        await handleAuthError(error);
        return false;
      }
      return data;
    } catch (err) {
      return false;
    }
  }, [supabaseReady]);

  const signInWithGoogle = useCallback(async () => {
    if (!supabaseReady) {
      toast({ title: 'Aguarde', description: 'Aguarde a conexão ser estabelecida.', variant: 'destructive' });
      return { success: false, error: 'Supabase not ready' };
    }

    if (!supabase) {
      toast({ title: 'Erro', description: 'Cliente não inicializado.', variant: 'destructive' });
      return { success: false, error: 'Supabase client null' };
    }

    try {
      const { data, error } = await withTimeout(supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin + '/auth/callback',
          queryParams: { access_type: 'offline', prompt: 'consent' },
        },
      }));
      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      toast({ title: 'Erro de Login', description: mapAuthError(error), variant: 'destructive' });
      return { success: false, error: error.message };
    }
  }, [supabaseReady, toast]);

  const signInWithApple = useCallback(async () => {
    if (!supabaseReady) {
      toast({ title: 'Aguarde', description: 'Aguarde a conexão ser estabelecida.', variant: 'destructive' });
      return { success: false, error: 'Supabase not ready' };
    }

    if (!supabase) {
      toast({ title: 'Erro', description: 'Cliente não inicializado.', variant: 'destructive' });
      return { success: false, error: 'Supabase client null' };
    }

    try {
      const { data, error } = await withTimeout(supabase.auth.signInWithOAuth({
        provider: 'apple',
        options: { redirectTo: window.location.origin + '/auth/callback' },
      }));
      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      toast({ title: 'Erro de Login', description: mapAuthError(error), variant: 'destructive' });
      return { success: false, error: error.message };
    }
  }, [supabaseReady, toast]);

  const completeGoogleSignup = useCallback(async (profileData) => {
    if (!supabaseReady) {
      toast({ title: 'Erro', description: 'Conexão não estabelecida.', variant: 'destructive' });
      return { success: false, error: 'Supabase not ready' };
    }

    if (!supabase) {
      toast({ title: 'Erro', description: 'Cliente não inicializado.', variant: 'destructive' });
      return { success: false, error: 'Supabase client null' };
    }

    try {
      setLoading(true);
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) throw sessionError;
      if (!session?.user) throw new Error("Usuário não autenticado.");

      const updates = {
        ...profileData,
        plan: 'free',
        is_anonymous: false
      };

      const { error } = await supabase.from('users').update(updates).eq('id', session.user.id);
      if (error) throw error;
      await loadUserProfile(session.user.id);
      return { success: true };
    } catch (error) {
      await handleAuthError(error);
      toast({ title: 'Erro', description: mapAuthError(error), variant: 'destructive' });
      return { success: false, error: error.message };
    } finally {
      setLoading(false);
    }
  }, [supabaseReady, loadUserProfile, toast]);

  const isProfileComplete = useCallback(() => {
    return userProfile && userProfile.company_name && userProfile.company_name.trim().length > 0;
  }, [userProfile]);

  const clearAnonymousSession = useCallback(() => {
    localStorage.removeItem('anonymousSession');
    if (user?.isAnonymous) {
      setUser(null);
      setUserProfile(null);
    }
  }, [user]);

  const registerBusiness = useCallback(async (email, password, companyName) => {
    if (!supabaseReady) {
      toast({ title: 'Erro', description: 'Conexão não estabelecida.', variant: 'destructive' });
      return { success: false, error: 'Supabase not ready' };
    }

    if (!supabase) {
      toast({ title: 'Erro', description: 'Cliente não inicializado.', variant: 'destructive' });
      return { success: false, error: 'Supabase client null' };
    }

    try {
      setLoading(true);
      if (!companyName) throw new Error("Nome da empresa é obrigatório.");

      const { data, error } = await withTimeout(supabase.auth.signUp({
        email,
        password,
        options: {
          data: { user_type: 'pending', plan: 'free', company_name: companyName, is_anonymous: false, registration_verified: false, two_factor_enabled: true }
        }
      }));

      if (error) throw error;
      if (!data.user) throw new Error("Erro ao criar usuário.");

      clearAnonymousSession();
      return { success: true, userId: data.user.id };
    } catch (error) {
      const friendlyMsg = mapAuthError(error);
      toast({ title: 'Erro no Cadastro', description: friendlyMsg, variant: 'destructive' });
      return { success: false, error: friendlyMsg };
    } finally {
      setLoading(false);
    }
  }, [supabaseReady, clearAnonymousSession, toast]);

  const register = useCallback(async (email, password, userType = 'pending', plan = 'free', companyName = null, fullName = null) => {
    if (!supabaseReady) {
      toast({ title: 'Erro', description: 'Conexão não estabelecida.', variant: 'destructive' });
      return { success: false, error: 'Supabase not ready' };
    }

    if (!supabase) {
      toast({ title: 'Erro', description: 'Cliente não inicializado.', variant: 'destructive' });
      return { success: false, error: 'Supabase client null' };
    }

    try {
      setLoading(true);
      const { data, error } = await withTimeout(supabase.auth.signUp({
        email, password, options: { data: { user_type: userType, plan: plan, company_name: companyName, full_name: fullName, is_anonymous: false } }
      }));

      if (error) throw error;
      clearAnonymousSession();
      toast({ title: 'Conta criada!', description: 'Por favor, complete seu cadastro.' });
      return { success: true, data };
    } catch (error) {
      toast({ title: 'Erro', description: mapAuthError(error), variant: 'destructive' });
      return { success: false, error: mapAuthError(error) };
    } finally {
      setLoading(false);
    }
  }, [supabaseReady, clearAnonymousSession, toast]);

  const login = useCallback(async (email, password) => {
    if (!supabaseReady) {
      toast({ title: 'Aguarde', description: 'Aguarde a conexão ser estabelecida.', variant: 'destructive' });
      return { success: false, error: 'Supabase not ready' };
    }

    if (!supabase) {
      toast({ title: 'Erro', description: 'Cliente não inicializado.', variant: 'destructive' });
      return { success: false, error: 'Supabase client null' };
    }

    try {
      setLoading(true);
      const { data, error } = await withTimeout(supabase.auth.signInWithPassword({ email, password }));
      if (error) throw error;
      
      clearAnonymousSession();

      const { data: userRecord, error: userError } = await withTimeout(
        supabase.from('users').select('two_factor_enabled, registration_verified, user_type, two_factor_verified_until').eq('id', data.user.id).maybeSingle()
      );
      if (userError) throw userError;

      if (!userRecord) {
         return { success: true, requiresVerification: false, user: data.user };
      }

      const needsRegistration = (userRecord.user_type === 'business_owner' || userRecord.user_type === 'business') && !userRecord.registration_verified;
      if (needsRegistration) {
         return { success: true, requiresVerification: true, verificationType: 'registration', user: data.user };
      }

      if (userRecord.two_factor_enabled) {
         // Confiança POR APARELHO. Sem device_id (navegador bloqueando
         // armazenamento), o código é pedido — melhor pecar pelo seguro.
         const deviceId = obterDeviceId();
         let aparelhoConfiavel = false;

         if (deviceId) {
            try {
               const { data: dev } = await withTimeout(
                  supabase
                     .from('trusted_devices')
                     .select('id, expira_em')
                     .eq('user_id', data.user.id)
                     .eq('device_id', deviceId)
                     .maybeSingle(),
                  8000
               );
               if (dev?.expira_em && new Date(dev.expira_em) > new Date()) {
                  aparelhoConfiavel = true;
                  // registra o uso, sem travar o login se falhar
                  supabase
                     .from('trusted_devices')
                     .update({ usado_em: new Date().toISOString() })
                     .eq('id', dev.id)
                     .then(() => {}, () => {});
               }
            } catch (e) {
               console.warn('[AuthContext] não deu para checar o aparelho:', e?.message);
            }
         }

         if (aparelhoConfiavel) {
            return { success: true, requiresVerification: false, user: data.user };
         }

         const code = Math.floor(100000 + Math.random() * 900000).toString();
         const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

         await withTimeout(
            supabase.from('verification_codes').insert({ user_id: data.user.id, code: code, expires_at: expiresAt, type: 'login', created_at: new Date().toISOString() })
         );

         await withTimeout(
            supabase.functions.invoke('send-2fa-email', { body: { email: data.user.email, code, type: 'login' } })
         );

         setPendingTwoFactor(true);
         setPendingUserId(data.user.id);
         return { success: true, requiresVerification: true, verificationType: '2fa', user: data.user };
      }

      return { success: true, requiresVerification: false, user: data.user };

    } catch (error) {
      await handleAuthError(error);
      const friendlyMsg = mapAuthError(error);
      toast({ title: 'Erro no Login', description: friendlyMsg, variant: 'destructive' });
      return { success: false, error: friendlyMsg };
    } finally {
      setLoading(false);
    }
  }, [supabaseReady, clearAnonymousSession, toast]);

  const logout = useCallback(async () => {
    try {
      if (user?.isAnonymous) {
        clearAnonymousSession();
        return;
      }
      
      if (supabase && supabaseReady) {
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
      }
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      for (let key in window.localStorage) {
        if (key.startsWith('sb-') && key.endsWith('-auth-token')) {
          window.localStorage.removeItem(key);
        }
      }
      setUser(null);
      setUserProfile(null);
      setIsEmailVerified(false);
      setPendingTwoFactor(false);
      setPendingUserId(null);
      setAuthError(null);
    }
  }, [user, supabaseReady, clearAnonymousSession]);

  const clearPendingTwoFactor = useCallback(() => {
     setPendingTwoFactor(false);
     setPendingUserId(null);
  }, []);

  const verifyTwoFactorCode = useCallback(async (code) => {
    if (!pendingUserId || !code || !supabaseReady) return { success: false, error: "Dados inválidos" };
    if (!supabase) return { success: false, error: "Cliente não inicializado" };

    try {
       setLoading(true);
       const { data, error } = await withTimeout(
        supabase.from('verification_codes').select('*').eq('user_id', pendingUserId).eq('code', code).eq('type', 'login').gt('expires_at', new Date().toISOString()).order('created_at', { ascending: false }).limit(1).maybeSingle()
       );
       if (error) throw error;
       if (!data) throw new Error("Código inválido ou expirado.");

       clearPendingTwoFactor();
       const session = await withTimeout(validateSession(), 12000);
       if (session?.user) {
          setUser(session.user);
          try {
            await withTimeout(loadUserProfile(session.user.id), 10000);
          } catch (e) {
            console.warn('[AuthContext] perfil demorou, seguindo sem ele:', e?.message);
          }
       }
       return { success: true };
    } catch (error) {
       await handleAuthError(error);
       return { success: false, error: error.message };
    } finally {
       setLoading(false);
    }
  }, [pendingUserId, supabaseReady, clearPendingTwoFactor, loadUserProfile, validateSession]);

  const resendTwoFactorCode = useCallback(async () => {
     if (!pendingUserId || !supabaseReady) return { success: false, error: "Usuário não identificado" };
     if (!supabase) return { success: false, error: "Cliente não inicializado" };

     try {
       const session = await validateSession();
       const email = session?.user?.email;
       if (!email) return { success: false, error: "Email não encontrado." };

        const code = Math.floor(100000 + Math.random() * 900000).toString();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

        await withTimeout(
          supabase.from('verification_codes').insert({ user_id: pendingUserId, code: code, expires_at: expiresAt, type: 'login', created_at: new Date().toISOString() })
        );

        await withTimeout(
          supabase.functions.invoke('send-2fa-email', { body: { email, code, type: 'login' } })
        );

        toast({ title: 'Código reenviado', description: `Um novo código foi enviado para ${email}` });
        return { success: true };
     } catch (error) {
        await handleAuthError(error);
        return { success: false, error: error.message };
     }
  }, [pendingUserId, supabaseReady, toast, validateSession]);

  const verifyCodeLogic = useCallback(async (userId, code) => {
    if (!userId || !code || !supabaseReady) return false;
    if (!supabase) return false;

    try {
      const { data, error } = await withTimeout(
        supabase.from('verification_codes').select('*').eq('user_id', userId).eq('code', String(code)).gt('expires_at', new Date().toISOString()).order('created_at', { ascending: false }).limit(1).maybeSingle()
      );
      if (error) throw error;
      if (!data) return false;
      return true;
    } catch (error) {
      await handleAuthError(error);
      return false;
    }
  }, [supabaseReady]);

  const verifyCode = useCallback(async (code, targetUserId = null) => {
    const uId = targetUserId || user?.id;
    if (!supabaseReady) return { success: false, error: 'Conexão não estabelecida' };
    if (!supabase) return { success: false, error: 'Cliente não inicializado' };

    try {
      const isValid = await verifyCodeLogic(uId, code);
      if (!isValid) throw new Error("Código inválido ou expirado");
      const { error } = await withTimeout(supabase.from('users').update({ email_verified: true }).eq('id', uId));
      if (error) throw error;
      setIsEmailVerified(true);
      return { success: true };
    } catch (error) {
      await handleAuthError(error);
      toast({ title: 'Erro', description: error.message, variant: 'destructive' });
      return { success: false, error: error.message };
    }
  }, [user, supabaseReady, verifyCodeLogic, toast]);

  const verifyLogin = useCallback(async (userId, code) => {
    return await verifyCode(code, userId);
  }, [verifyCode]);

  const verifyRegistration = useCallback(async (userId, code) => {
    if (!supabaseReady) return { success: false, error: 'Conexão não estabelecida' };
    if (!supabase) return { success: false, error: 'Cliente não inicializado' };

    try {
      setLoading(true);
      const isValid = await verifyCodeLogic(userId, code);
      if (!isValid) throw new Error("Código inválido ou expirado");

      const { error } = await withTimeout(
        supabase.from('users').update({ registration_verified: true, two_factor_enabled: true, email_verified: true }).eq('id', userId)
      );
      if (error) throw error;
      await loadUserProfile(userId);
      return { success: true };
    } catch (error) {
      await handleAuthError(error);
      toast({ title: 'Falha na verificação', description: mapAuthError(error), variant: 'destructive' });
      return { success: false, error: error.message };
    } finally {
      setLoading(false);
    }
  }, [supabaseReady, verifyCodeLogic, loadUserProfile, toast]);

  const sendVerificationCode = useCallback(async (targetUserId = null, targetEmail = null) => {
    if (!supabaseReady) return { success: false, error: 'Conexão não estabelecida' };
    if (!supabase) return { success: false, error: 'Cliente não inicializado' };

    const uId = targetUserId || user?.id;
    const uEmail = targetEmail || user?.email;
    if (!uId || !uEmail) return { success: false, error: "Usuário não identificado" };
    try {
      const { error } = await withTimeout(
        supabase.functions.invoke('send-verification-email', { body: { email: uEmail, userId: uId } })
      );
      if (error) throw error;
      toast({ title: 'Código enviado', description: `Verifique o email ${uEmail}` });
      return { success: true };
    } catch (error) {
      await handleAuthError(error);
      toast({ title: 'Erro', description: 'Erro ao enviar código. Tente novamente.', variant: 'destructive' });
      return { success: false, error: error.message };
    }
  }, [user, supabaseReady, toast]);

  const resendRegistrationCode = useCallback(async (userId) => {
     if (!supabaseReady) return { success: false, error: 'Conexão não estabelecida' };
     if (!supabase) return { success: false, error: 'Cliente não inicializado' };

     try {
       const { data: userData, error } = await withTimeout(supabase.from('users').select('email').eq('id', userId).maybeSingle());
       if (error) throw error;
       if (!userData) return { success: false, error: "Usuário não encontrado" };
       return await sendVerificationCode(userId, userData.email);
     } catch (error) {
       await handleAuthError(error);
       return { success: false, error: error.message };
     }
  }, [supabaseReady, sendVerificationCode]);

  const toggleTwoFactor = useCallback(async (userId, enabled) => {
    if (!supabaseReady) return { success: false, error: 'Conexão não estabelecida' };
    if (!supabase) return { success: false, error: 'Cliente não inicializado' };

    try {
      setLoading(true);
      const { error } = await withTimeout(supabase.from('users').update({ two_factor_enabled: enabled }).eq('id', userId));
      if (error) throw error;
      setUserProfile(prev => ({ ...prev, two_factor_enabled: enabled }));
      toast({ title: 'Sucesso', description: `Verificação ${enabled ? 'ativada' : 'desativada'} com sucesso.` });
      return { success: true };
    } catch (error) {
      await handleAuthError(error);
      toast({ title: 'Erro', description: mapAuthError(error), variant: 'destructive' });
      return { success: false, error: error.message };
    } finally {
      setLoading(false);
    }
  }, [supabaseReady, toast]);

  const updateProfile = useCallback(async (data) => {
    if (!supabaseReady) throw new Error('Conexão não estabelecida');
    if (!supabase) throw new Error('Cliente não inicializado');

    try {
      const { error } = await withTimeout(supabase.from('users').update(data).eq('id', user.id));
      if (error) throw error;
      setUserProfile(prev => ({ ...prev, ...data }));
      return { ...userProfile, ...data };
    } catch (error) {
      await handleAuthError(error);
      toast({ title: 'Erro', description: mapAuthError(error), variant: 'destructive' });
      throw error;
    }
  }, [user, userProfile, supabaseReady, toast]);

  const uploadProfilePhoto = useCallback(async (file) => {
    if (!supabaseReady) throw new Error('Conexão não estabelecida');
    if (!supabase) throw new Error('Cliente não inicializado');

    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;
      const { error } = await withTimeout(supabase.storage.from('profile-photos').upload(fileName, file));
      if (error) throw error;
      const { data: { publicUrl } } = supabase.storage.from('profile-photos').getPublicUrl(fileName);
      return publicUrl;
    } catch (error) {
      await handleAuthError(error);
      throw error;
    }
  }, [user, supabaseReady]);

  const deleteAccount = useCallback(async () => {
    if (!supabaseReady) throw new Error('Conexão não estabelecida');
    if (!supabase) throw new Error('Cliente não inicializado');

    try {
      const { error } = await withTimeout(supabase.from('users').delete().eq('id', user.id));
      if (error) throw error;
      await logout();
      return true;
    } catch (error) {
      await handleAuthError(error);
      toast({ title: 'Erro', description: mapAuthError(error), variant: 'destructive' });
      throw error;
    }
  }, [user, supabaseReady, logout, toast]);

  const createAnonymousSession = useCallback(() => {
    const sessionId = `anon_${Math.random().toString(36).substring(2)}_${Date.now()}`;
    const anonUser = {
      id: sessionId,
      email: null,
      isAnonymous: true,
      created_at: new Date().toISOString()
    };
    localStorage.setItem('anonymousSession', JSON.stringify(anonUser));
    setUser(anonUser);
    setUserProfile({ user_type: 'anonymous' });
    setIsEmailVerified(true);
    return sessionId;
  }, []);

  const resetPassword = useCallback(async (email) => {
    if (!supabaseReady) {
      toast({ title: 'Erro', description: 'Conexão não estabelecida.', variant: 'destructive' });
      return false;
    }

    if (!supabase) {
      toast({ title: 'Erro', description: 'Cliente não inicializado.', variant: 'destructive' });
      return false;
    }

    try {
      const { error } = await withTimeout(
        supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin + '/reset-password' })
      );
      if (error) throw error;
      toast({ title: 'Email enviado', description: 'Verifique sua caixa de entrada.' });
      return true;
    } catch (error) {
      toast({ title: 'Erro', description: mapAuthError(error), variant: 'destructive' });
      return false;
    }
  }, [supabaseReady, toast]);

  const updatePassword = useCallback(async (newPassword) => {
    if (!supabaseReady) {
      toast({ title: 'Erro', description: 'Conexão não estabelecida.', variant: 'destructive' });
      return false;
    }

    if (!supabase) {
      toast({ title: 'Erro', description: 'Cliente não inicializado.', variant: 'destructive' });
      return false;
    }

    try {
      const { error } = await withTimeout(supabase.auth.updateUser({ password: newPassword }));
      if (error) throw error;
      toast({ title: 'Sucesso', description: 'Senha atualizada.' });
      return true;
    } catch (error) {
      await handleAuthError(error);
      toast({ title: 'Erro', description: mapAuthError(error), variant: 'destructive' });
      return false;
    }
  }, [supabaseReady, toast]);

  const value = useMemo(() => ({
    user, userProfile, loading, 
    supabaseReady,
    initError,
    retryCount,
    maxRetries: MAX_RETRY_ATTEMPTS,
    handleRetry,
    connectionError,
    authPhase,
    isAuthenticated: !!user && !user.isAnonymous && !pendingTwoFactor,
    isAnonymous: !!user?.isAnonymous,
    isPending: userProfile?.user_type === 'pending',
    isBusinessOwner: userProfile?.user_type === 'business_owner' || userProfile?.user_type === 'business',
    isPremium: userProfile?.plan === 'premium',
    isEmailVerified, 
    pendingTwoFactor, pendingUserId,
    register, registerBusiness, verifyRegistration, resendRegistrationCode, login, verifyLogin, logout, signInWithGoogle, signInWithApple, completeGoogleSignup,
    createAnonymousSession, clearAnonymousSession, checkUserExists,
    updateProfile, uploadProfilePhoto, deleteAccount, toggleTwoFactor, 
    sendVerificationCode, verifyCode, resendVerificationCode: sendVerificationCode, 
    resetPassword, updatePassword,
    verifyTwoFactorCode, resendTwoFactorCode, clearPendingTwoFactor, isProfileComplete,
    error: authError, clearError,
    signIn: login, signUp: register, signOut: logout
  }), [
    user, userProfile, loading, supabaseReady, initError, retryCount, handleRetry, connectionError, isEmailVerified, pendingTwoFactor, pendingUserId,
    register, registerBusiness, verifyRegistration, resendRegistrationCode, login, verifyLogin, logout, signInWithGoogle, signInWithApple, completeGoogleSignup,
    createAnonymousSession, clearAnonymousSession, checkUserExists,
    updateProfile, uploadProfilePhoto, deleteAccount, toggleTwoFactor, 
    sendVerificationCode, verifyCode, 
    resetPassword, updatePassword,
    verifyTwoFactorCode, resendTwoFactorCode, clearPendingTwoFactor, isProfileComplete,
    authError, clearError
  ]);

  // Render error UI if initialization failed
  if (initError && !loading && retryCount >= MAX_RETRY_ATTEMPTS) {
    return (
      <AuthContext.Provider value={value}>
        <div className="min-h-screen bg-black flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-neutral-900 border border-red-900/50 rounded-2xl p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-950/30 flex items-center justify-center">
              <svg className="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">Erro de Conexão</h2>
            <p className="text-neutral-300 mb-2">{initError}</p>
            <p className="text-sm text-neutral-400 mb-6">Máximo de tentativas atingido ({MAX_RETRY_ATTEMPTS}/{MAX_RETRY_ATTEMPTS})</p>
            <p className="text-xs text-neutral-500">Entre em contato com o suporte técnico.</p>
          </div>
        </div>
      </AuthContext.Provider>
    );
  }

  // Render retry UI if error exists but retries available
  if (initError && !loading) {
    return (
      <AuthContext.Provider value={value}>
        <div className="min-h-screen bg-black flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-neutral-900 border border-orange-900/50 rounded-2xl p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-orange-950/30 flex items-center justify-center">
              <svg className="w-8 h-8 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">Falha na Conexão</h2>
            <p className="text-neutral-300 mb-6">{initError}</p>
            <p className="text-sm text-neutral-400 mb-6">Tentativa {retryCount + 1} de {MAX_RETRY_ATTEMPTS}</p>
            <button
              onClick={handleRetry}
              className="w-full bg-white text-black hover:bg-neutral-200 font-bold rounded-xl h-12 px-6 transition-colors"
            >
              Tentar Novamente
            </button>
          </div>
        </div>
      </AuthContext.Provider>
    );
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}