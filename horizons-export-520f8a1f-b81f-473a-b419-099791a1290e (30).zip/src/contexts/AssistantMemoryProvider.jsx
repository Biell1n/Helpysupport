import React, { createContext, useContext, useMemo } from 'react';
import { useAssistantIntelligence } from '@/hooks/useAssistantIntelligence';

export const AssistantMemoryContext = createContext(null);

export function AssistantMemoryProvider({ children }) {
  const intelligence = useAssistantIntelligence();

  const contextValue = useMemo(() => {
    return {
      ...intelligence
    };
  }, [intelligence]);

  return (
    <AssistantMemoryContext.Provider value={contextValue}>
      {children}
    </AssistantMemoryContext.Provider>
  );
}

export function useAssistantMemoryContext() {
  const context = useContext(AssistantMemoryContext);
  if (!context) throw new Error('useAssistantMemoryContext must be used within AssistantMemoryProvider');
  return context;
}