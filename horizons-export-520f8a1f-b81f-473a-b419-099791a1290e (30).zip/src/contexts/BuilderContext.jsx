// ============================================================
// HELPY BUILDER v10 — ARQUIVO COMPLETO
//
// Confirmação: ao abrir a tela, o console imprime
// "[Helpy] BuilderContext v10".
//
// Mudança principal em relação à v6: progresso, "falta", itens
// incompletos e liberação do Publicar passam a ser calculados AQUI, a
// cada mudança da config. Antes vinham só do servidor, então editar um
// campo à mão não mexia em nada — o medidor ficava parado até você
// mandar uma mensagem no chat.
// ============================================================

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useMemo,
  useRef,
} from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

const BuilderContext = createContext(null);

const EMPTY_CONFIG = {
  fields: {},
  collections: {},
  declined: { collections: [], item_fields: {}, more: [] },
};

const EMPTY_SCHEMA = { sections: [] };
const AUTOSAVE_MS = 900;

// ------------------------------------------------------------------
// Normalização
// ------------------------------------------------------------------

const normalize = (cfg) => {
  const d = cfg?.declined || {};
  return {
    fields: cfg?.fields && typeof cfg.fields === 'object' ? cfg.fields : {},
    collections: cfg?.collections && typeof cfg.collections === 'object' ? cfg.collections : {},
    declined: {
      collections: Array.isArray(d.collections) ? d.collections : [],
      item_fields: d.item_fields && typeof d.item_fields === 'object' ? d.item_fields : {},
      more: Array.isArray(d.more) ? d.more : [],
    },
  };
};

// ------------------------------------------------------------------
// Cálculo do estado — mesma regra da edge function, rodando aqui
// ------------------------------------------------------------------

const flatFields = (schema) => (schema?.sections || []).flatMap((s) => s.fields || []);
const flatCollections = (schema) => (schema?.sections || []).flatMap((s) => s.collections || []);

const isFilled = (e) => !!e && (e.status === 'ignorado' || String(e.value ?? '').trim() !== '');

const bucketOf = (importance) =>
  importance === 'critical' ? 'critical' : importance === 'important' ? 'important' : 'optional';

function computeState(schema, rawConfig) {
  const cfg = normalize(rawConfig);
  const missing = { critical: [], important: [], optional: [] };
  const incomplete = [];
  const askMore = [];
  let done = 0;
  let total = 0;

  for (const f of flatFields(schema)) {
    total++;
    if (isFilled(cfg.fields[f.key])) done++;
    else missing[bucketOf(f.importance)].push(f.key);
  }

  for (const c of flatCollections(schema)) {
    const declined = cfg.declined.collections.includes(c.key);
    const list = Array.isArray(cfg.collections[c.key]) ? cfg.collections[c.key] : [];
    const min = typeof c.min === 'number' ? c.min : 1;

    total++;
    if (declined || list.length >= min) done++;
    else missing[bucketOf(c.importance)].push(c.key);

    if (declined) continue;

    const skipped = cfg.declined.item_fields[c.key] || [];
    const reqs = (c.item_fields || []).filter((f) => f.required && !skipped.includes(f.key));

    list.forEach((item, idx) => {
      const faltando = [];
      for (const rf of reqs) {
        total++;
        if (String(item?.[rf.key] ?? '').trim() !== '') done++;
        else faltando.push({ key: rf.key, label: rf.label });
      }
      if (faltando.length) {
        incomplete.push({
          collection: c.key,
          collection_label: c.label,
          index: idx,
          item_name: item?.nome || item?.modelo || item?.titulo || item?.pergunta || `item ${idx + 1}`,
          fields: faltando,
        });
      }
    });

    if (list.length > 0 && !cfg.declined.more.includes(c.key)) {
      total++;
      askMore.push(c.key);
    }
  }

  const criticalOpen = missing.critical.length;
  return {
    progress: total === 0 ? 0 : Math.round((done / total) * 100),
    missing,
    incomplete,
    askMore,
    ready: criticalOpen === 0 && total > 0,
    exhausted:
      criticalOpen === 0 &&
      missing.important.length === 0 &&
      missing.optional.length === 0 &&
      incomplete.length === 0 &&
      askMore.length === 0,
  };
}

// ------------------------------------------------------------------
// Chamada à edge function, lendo o erro de verdade
// ------------------------------------------------------------------

async function invoke(body) {
  const { data, error } = await supabase.functions.invoke('assistant-builder-chat', { body });
  if (error) {
    let detalhe = error.message || 'Erro na função';
    try {
      const ctx = error.context;
      if (ctx && typeof ctx.text === 'function') {
        const txt = await ctx.text();
        try {
          detalhe = JSON.parse(txt)?.error || txt || detalhe;
        } catch {
          detalhe = txt || detalhe;
        }
      }
    } catch (_) {
      /* mantém a mensagem genérica */
    }
    throw new Error(detalhe);
  }
  if (data?.error) throw new Error(data.error);
  return data;
}

export const useBuilder = () => {
  const ctx = useContext(BuilderContext);
  if (!ctx) throw new Error('useBuilder precisa estar dentro de BuilderProvider');
  return ctx;
};

/**
 * @param assistantId  quando informado, o builder abre em modo EDIÇÃO:
 *                     a sessão nasce carregada com a configuração do
 *                     assistente e salvar ATUALIZA em vez de criar.
 */
export const BuilderProvider = ({ children, assistantId = null }) => {
  const { user } = useAuth();

  useEffect(() => {
    console.log('[Helpy] BuilderContext v10');
  }, []);

  const [sessionId, setSessionId] = useState(null);
  const [businessType, setBusinessType] = useState(null);
  const [schema, setSchema] = useState(EMPTY_SCHEMA);
  const [config, setConfig] = useState(EMPTY_CONFIG);
  const [messages, setMessages] = useState([]);

  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [saveState, setSaveState] = useState('idle');
  const [freshKeys, setFreshKeys] = useState([]);
  const [loadError, setLoadError] = useState(null);
  const [publico, setPublico] = useState(null); // { token, is_public, name }
  const editando = !!assistantId;

  const saveTimer = useRef(null);
  const sessionRef = useRef(null);
  // O React 18 executa o efeito duas vezes em desenvolvimento. Sem esta
  // trava, duas cargas simultâneas podiam abrir duas sessões.
  const loadedFor = useRef(null);

  // mantém o id atual acessível dentro dos timers
  useEffect(() => {
    sessionRef.current = sessionId;
  }, [sessionId]);

  // ---- estado derivado: recalcula a cada tecla ----------------------
  const state = useMemo(() => computeState(schema, config), [schema, config]);

  const incompleteBy = useMemo(() => {
    const map = {};
    for (const it of state.incomplete) map[`${it.collection}:${it.index}`] = it.fields;
    return map;
  }, [state.incomplete]);

  const flash = useCallback((keys) => {
    const list = (keys || []).filter(Boolean);
    if (!list.length) return;
    setFreshKeys(list);
    setTimeout(() => setFreshKeys([]), 2600);
  }, []);

  const absorb = useCallback((data) => {
    if (!data) return;
    if (data.session_id) setSessionId(data.session_id);
    if (data.business_type !== undefined) setBusinessType(data.business_type);
    if (data.schema?.sections) setSchema({ sections: data.schema.sections });
    if (data.config) setConfig(normalize(data.config));
    if (data.publico !== undefined) setPublico(data.publico);
    // progresso e "falta" não vêm mais do servidor: são calculados acima
  }, []);

  // ---- carga inicial ------------------------------------------------
  useEffect(() => {
    if (!user) return;
    const chave = `${user.id}:${assistantId ?? 'novo'}`;
    if (loadedFor.current === chave) return;
    loadedFor.current = chave;

    let cancelled = false;

    (async () => {
      setLoading(true);
      try {
        const data = await invoke({ action: 'load', assistant_id: assistantId });
        if (cancelled) return;
        absorb(data);
        setMessages(data?.messages || []);
        setLoadError(null);
      } catch (err) {
        console.error('[Builder] falha ao carregar:', err);
        if (!cancelled) {
          setLoadError(err.message);
          loadedFor.current = null; // deixa tentar de novo
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [user, absorb, assistantId]);

  useEffect(() => () => clearTimeout(saveTimer.current), []);

  // ---- autosave -----------------------------------------------------
  const persistConfig = useCallback((nextConfig) => {
    const id = sessionRef.current;
    if (!id) return;
    clearTimeout(saveTimer.current);
    setSaveState('saving');
    saveTimer.current = setTimeout(async () => {
      // se a sessão trocou no meio do caminho, não grava por cima da nova
      if (sessionRef.current !== id) return;
      const { error } = await supabase
        .from('assistants_creation_sessions')
        .update({ configuration: nextConfig })
        .eq('id', id);
      if (error) {
        console.error('[Builder] autosave falhou:', error);
        setSaveState('error');
      } else {
        setSaveState('saved');
        setTimeout(() => setSaveState('idle'), 1800);
      }
    }, AUTOSAVE_MS);
  }, []);

  const mutate = useCallback(
    (fn) => {
      setConfig((prev) => {
        const next = fn(normalize(JSON.parse(JSON.stringify(prev))));
        persistConfig(next);
        return next;
      });
    },
    [persistConfig]
  );

  // ---- chat ----------------------------------------------------------
  const sendMessage = useCallback(
    async (text) => {
      const content = String(text || '').trim();
      if (!content || sending) return;

      setMessages((prev) => [...prev, { role: 'user', content }]);
      setSending(true);

      try {
        const data = await invoke({ action: 'message', message: content, assistant_id: assistantId });
        absorb(data);
        flash((data?.ops || []).map((o) => o.key));
        setMessages((prev) => [...prev, { role: 'assistant', content: data.message }]);
      } catch (err) {
        console.error('[Builder] erro no chat:', err);
        setMessages((prev) => [
          ...prev,
          { role: 'assistant', content: `Deu erro aqui do meu lado: ${err.message}` },
        ]);
      } finally {
        setSending(false);
      }
    },
    [sending, absorb, flash]
  );

  const generateIdeas = useCallback(() => {
    sendMessage(
      businessType
        ? 'O que mais eu poderia informar aqui que ajudaria o assistente a atender melhor?'
        : 'Não sei por onde começar. Me dá exemplos de negócios que dá pra configurar aqui.'
    );
  }, [sendMessage, businessType]);

  // ---- campos ---------------------------------------------------------
  const setField = useCallback(
    (key, value) =>
      mutate((c) => {
        c.fields[key] = { value, status: value ? 'confirmado' : 'vazio' };
        return c;
      }),
    [mutate]
  );

  const skipField = useCallback(
    (key) =>
      mutate((c) => {
        c.fields[key] = { value: '', status: 'ignorado' };
        return c;
      }),
    [mutate]
  );

  // ---- coleções --------------------------------------------------------
  const addItem = useCallback(
    (colKey) =>
      mutate((c) => {
        c.collections[colKey] = [...(c.collections[colKey] || []), {}];
        c.declined.more = c.declined.more.filter((k) => k !== colKey);
        c.declined.collections = c.declined.collections.filter((k) => k !== colKey);
        return c;
      }),
    [mutate]
  );

  const setItemField = useCallback(
    (colKey, index, key, value) =>
      mutate((c) => {
        const list = [...(c.collections[colKey] || [])];
        list[index] = { ...list[index], [key]: value };
        c.collections[colKey] = list;
        return c;
      }),
    [mutate]
  );

  const removeItem = useCallback(
    (colKey, index) =>
      mutate((c) => {
        const list = [...(c.collections[colKey] || [])];
        list.splice(index, 1);
        c.collections[colKey] = list;
        return c;
      }),
    [mutate]
  );

  // ---- recusa e reativação ---------------------------------------------
  const skipCollection = useCallback(
    (colKey) =>
      mutate((c) => {
        if (!c.declined.collections.includes(colKey)) c.declined.collections.push(colKey);
        return c;
      }),
    [mutate]
  );

  const skipItemField = useCallback(
    (colKey, fieldKey) =>
      mutate((c) => {
        const cur = c.declined.item_fields[colKey] || [];
        if (!cur.includes(fieldKey)) cur.push(fieldKey);
        c.declined.item_fields[colKey] = cur;
        return c;
      }),
    [mutate]
  );

  const restoreCollection = useCallback(
    (colKey) =>
      mutate((c) => {
        c.declined.collections = c.declined.collections.filter((k) => k !== colKey);
        return c;
      }),
    [mutate]
  );

  const restoreItemField = useCallback(
    (colKey, fieldKey) =>
      mutate((c) => {
        c.declined.item_fields[colKey] = (c.declined.item_fields[colKey] || []).filter(
          (k) => k !== fieldKey
        );
        return c;
      }),
    [mutate]
  );

  // ---- salvar / publicar / recomeçar ------------------------------------
  const saveDraft = useCallback(async () => {
    const id = sessionRef.current;
    if (!id) return;
    clearTimeout(saveTimer.current);
    setSaveState('saving');
    const { error } = await supabase
      .from('assistants_creation_sessions')
      .update({ configuration: config })
      .eq('id', id);
    setSaveState(error ? 'error' : 'saved');
    if (!error) setTimeout(() => setSaveState('idle'), 1800);
  }, [config]);

  const publish = useCallback(async () => {
    clearTimeout(saveTimer.current);
    const id = sessionRef.current;
    if (id) {
      // garante que a última edição manual foi gravada antes de publicar
      await supabase
        .from('assistants_creation_sessions')
        .update({ configuration: config })
        .eq('id', id);
    }
    const data = await invoke({ action: 'finalize', assistant_id: assistantId });
    return data.assistant;
  }, [config]);

  /** Lê ou grava os limites de mensagem do assistente. */
  const limites = useCallback(
    async (novos = null) => {
      if (!assistantId) throw new Error('Só um assistente publicado tem limites.');
      const data = await invoke({
        action: 'limits',
        assistant_id: assistantId,
        salvar: !!novos,
        ...(novos ?? {}),
      });
      setPublico((p) => ({ ...(p ?? {}), limites: data.limites }));
      return data.limites;
    },
    [assistantId]
  );

  /**
   * Cria um campo que não existe no schema.
   * Serve para o que o negócio precisa e o modelo não previu.
   */
  const adicionarCampo = useCallback(
    async ({ section, label, type = 'text', hint = '' }) => {
      const data = await invoke({
        action: 'add_field',
        assistant_id: assistantId,
        section,
        label,
        type,
        hint,
      });
      absorb(data);
      return true;
    },
    [assistantId, absorb]
  );

  /** Gera (ou regenera) o link público do assistente. */
  const gerarLink = useCallback(
    async (opcoes = {}) => {
      if (!assistantId) throw new Error('Só é possível gerar link de um assistente já publicado.');
      const data = await invoke({
        action: 'share',
        assistant_id: assistantId,
        regenerar: opcoes.regenerar === true,
        ligado: opcoes.ligado !== false,
      });
      setPublico({ token: data.token, is_public: data.is_public });
      return data.token;
    },
    [assistantId]
  );

  const resetSession = useCallback(async () => {
    // mata qualquer autosave pendente ANTES de trocar de sessão, senão
    // ele grava a config velha por cima da sessão nova
    clearTimeout(saveTimer.current);
    setSaveState('idle');
    setLoading(true);

    try {
      const data = await invoke({ action: 'reset', assistant_id: assistantId });

      // zera na marra, sem depender do que o servidor devolveu
      setSessionId(data?.session_id ?? null);
      sessionRef.current = data?.session_id ?? null;
      setBusinessType(null);
      setSchema(data?.schema?.sections ? { sections: data.schema.sections } : EMPTY_SCHEMA);
      setConfig(EMPTY_CONFIG);
      setMessages([]);
      setFreshKeys([]);
      setLoadError(null);
    } finally {
      setLoading(false);
    }
  }, []);

  return (
    <BuilderContext.Provider
      value={{
        sessionId,
        businessType,
        schema,
        config,
        messages,
        progress: state.progress,
        missing: state.missing,
        incomplete: state.incomplete,
        incompleteBy,
        ready: state.ready,
        exhausted: state.exhausted,
        loading,
        sending,
        saveState,
        freshKeys,
        loadError,
        sendMessage,
        generateIdeas,
        setField,
        skipField,
        addItem,
        setItemField,
        removeItem,
        skipCollection,
        skipItemField,
        restoreCollection,
        restoreItemField,
        saveDraft,
        publish,
        resetSession,
        gerarLink,
        limites,
        adicionarCampo,
        publico,
        editando,
        assistantId,
      }}
    >
      {children}
    </BuilderContext.Provider>
  );
};