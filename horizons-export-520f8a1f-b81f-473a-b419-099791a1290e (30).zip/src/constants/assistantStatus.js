/**
 * Valid assistant status values
 * These values MUST match the database CHECK constraint on assistants.status
 * 
 * Database constraint: CHECK (status IN ('draft', 'active', 'inactive', 'archived'))
 * 
 * Status definitions:
 * - draft: Assistant is being created/configured (default for new assistants)
 * - active: Assistant is fully configured and actively serving users
 * - inactive: Assistant is temporarily disabled but can be reactivated
 * - archived: Assistant is permanently archived (soft delete)
 */
export const ASSISTANT_STATUS = {
  DRAFT: 'draft',
  ACTIVE: 'active',
  INACTIVE: 'inactive',
  ARCHIVED: 'archived',
};

/**
 * Array of all valid status values (for validation)
 */
export const VALID_ASSISTANT_STATUSES = Object.values(ASSISTANT_STATUS);

/**
 * Default status for new assistants
 */
export const DEFAULT_ASSISTANT_STATUS = ASSISTANT_STATUS.DRAFT;

/**
 * Human-readable labels for each status
 */
export const ASSISTANT_STATUS_LABELS = {
  [ASSISTANT_STATUS.DRAFT]: 'Rascunho',
  [ASSISTANT_STATUS.ACTIVE]: 'Ativo',
  [ASSISTANT_STATUS.INACTIVE]: 'Inativo',
  [ASSISTANT_STATUS.ARCHIVED]: 'Arquivado',
};