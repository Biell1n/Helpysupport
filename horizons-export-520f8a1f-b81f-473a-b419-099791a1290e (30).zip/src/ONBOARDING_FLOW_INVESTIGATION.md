# INVESTIGAÇÃO DO FLUXO DE ONBOARDING E CHAT

## 1. Edge Functions Chamadas no Fluxo
Após análise do código-fonte, a Edge Function responsável pelo onboarding é a **`onboarding-chat`**.

### Arquivos que fazem a chamada:
- **`src/hooks/useOnboardingChat.js`**: Usa `supabase.functions.invoke('onboarding-chat', { body: requestBody })`. Este é o hook principal usado pela página `OnboardingChatPage.jsx`.
- **`src/services/onboarding/onboardingService.js`**: Usa `supabase.functions.invoke('onboarding-chat', { body: payload })`. Usado como método utilitário.

## 2. Identificação de Chamadas Diretas
- **OpenAI Direta**: Nenhuma chamada direta à API da OpenAI (`fetch('https://api.openai.com...')` ou SDK) foi encontrada no frontend (`src/`). Todas as interações estão corretamente isoladas nas Edge Functions.
- **Frontend APIs**: O frontend utiliza exclusivamente o SDK do Supabase (`supabase.functions.invoke`) para interagir com o modelo de IA.

## 3. Comparação de Funções de Chat (Edge Functions)

### A. `supabase/functions/onboarding-chat/index.ts`
- **Uso**: Configuração do negócio do usuário (coleta de dados).
- **Prompt Anterior**: "Você é o HELPY ASSISTANT, um consultor de negócios especializado em IA... Se o usuário mencionar um assunto fora de tópico... Reconheça o tópico educadamente... Redirecione IMEDIATAMENTE..."
- **Análise**: O prompt possuía diretrizes de redirecionamento, mas não era estrito o suficiente. A IA (GPT-4o) costuma ser prestativa demais e acabava "esquecendo" do onboarding ao tentar agradar o usuário sobre tópicos paralelos (ex: Roblox).

### B. `supabase/functions/chat/index.ts`
- **Uso**: Chat geral de clientes conversando com o assistente criado.
- **Prompt**: Usa dinamicamente o `system_prompt` salvo na tabela `assistants` para aquele assistente específico.
- **Análise**: Função genérica para uso final. Não interfere no processo de onboarding.

### C. Outras funções
- **`customer-chat`**: Contém apenas inicialização do client (admin.ts).
- **`refine-assistant-chat`**: Função mencionada nos metadados, usada possivelmente no painel de edição do assistente pós-onboarding.

## Conclusão da Investigação
O problema de "mudança de assunto" ocorre estritamente na função **`onboarding-chat`**. O prompt existente era excessivamente brando no tratamento de tópicos paralelos (Guardrails fracos). Precisamos injetar logs de monitoramento e substituir o prompt por um com regras mandatórias, claras e estritas.