import { supabase } from '@/lib/supabase/client';

/**
 * Utility to clean up expired sessions.
 * Can be run manually or triggered via a cron job.
 */
export async function cleanupExpiredSessions() {
  try {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const { data, error } = await supabase
      .from('onboarding_sessions')
      .update({ session_status: 'expired', updated_at: new Date().toISOString() })
      .eq('session_status', 'active')
      .lt('created_at', thirtyDaysAgo.toISOString())
      .select('id');

    if (error) {
      throw error;
    }

    console.log(`Successfully expired ${data?.length || 0} orphaned sessions.`);
    return data;
  } catch (error) {
    console.error('Error cleaning up expired sessions:', error);
    throw error;
  }
}