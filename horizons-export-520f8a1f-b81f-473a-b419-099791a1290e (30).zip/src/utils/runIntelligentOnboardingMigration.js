import { seedBusinessTypeDefinitions } from '../services/onboarding/businessTypeDefinitions';

export async function runIntelligentOnboardingMigration() {
  try {
    console.log("Starting intelligent onboarding migration & seeding...");
    // Migrations are handled by Edge SQL execution, so we just run the seeder
    await seedBusinessTypeDefinitions();
    console.log("Intelligent onboarding seeding completed successfully.");
    return true;
  } catch (error) {
    console.error("Migration/Seeding failed:", error);
    return false;
  }
}