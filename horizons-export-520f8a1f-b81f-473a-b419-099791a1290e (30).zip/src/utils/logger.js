export const LogLevel = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3
};

const CURRENT_LEVEL = LogLevel.DEBUG; // Change this to disable logs in production

export const logger = {
  debug: (context, message, data = null) => {
    if (CURRENT_LEVEL <= LogLevel.DEBUG) {
      console.log(`[DEBUG] [${new Date().toISOString()}] [${context}] ${message}`, data || '');
    }
  },
  info: (context, message, data = null) => {
    if (CURRENT_LEVEL <= LogLevel.INFO) {
      console.info(`[INFO] [${new Date().toISOString()}] [${context}] ${message}`, data || '');
    }
  },
  warn: (context, message, error = null) => {
    if (CURRENT_LEVEL <= LogLevel.WARN) {
      console.warn(`[WARN] [${new Date().toISOString()}] [${context}] ${message}`, error || '');
    }
  },
  error: (context, message, error = null) => {
    if (CURRENT_LEVEL <= LogLevel.ERROR) {
      console.error(`[ERROR] [${new Date().toISOString()}] [${context}] ${message}`, error || '');
    }
  },
  state: (context, state) => {
    if (CURRENT_LEVEL <= LogLevel.DEBUG) {
      console.log(`[STATE] [${new Date().toISOString()}] [${context}]`, state);
    }
  },
  phase: (phase, objective) => {
    if (CURRENT_LEVEL <= LogLevel.INFO) {
      console.info(`🚀 [PHASE TRANSITION] [${new Date().toISOString()}] Phase: ${phase} | Objective: ${objective}`);
    }
  }
};