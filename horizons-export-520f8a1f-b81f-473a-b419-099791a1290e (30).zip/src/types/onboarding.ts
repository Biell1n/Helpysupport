export interface OnboardingResponse {
  message: string;
  business_type: string;
  goal: string;
  required_fields: string[];
  recommended_fields: string[];
  new_fields: string[];
  new_flows: string[];
  new_automations: string[];
  assistant_rules: string[];
  restricted_topics: string[];
  collected_data: Record<string, any>;
  context_confidence: number;
  next_action: string;
}

export interface OnboardingSession {
  id: string;
  user_id: string;
  initial_business_type: string;
  initial_description: string;
  initial_goal: string;
  messages: Array<{ role: string; content: string; timestamp?: string }>;
  collected_data: Record<string, any>;
  detected_fields: string[];
  detected_flows: string[];
  detected_automations: string[];
  assistant_rules: string[];
  restricted_topics: string[];
  progress: number;
  current_step: number;
  status: 'in_progress' | 'completed' | 'abandoned';
  created_assistant_id?: string;
  created_at: string;
  updated_at: string;
  context_confidence: number;
}