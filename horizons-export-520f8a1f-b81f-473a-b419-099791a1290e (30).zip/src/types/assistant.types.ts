/**
 * Assistant-related type definitions
 */

import type { Database } from './database.types';

// Extract types from Database schema
export type Assistant = Database['public']['Tables']['assistants']['Row'];
export type AssistantInsert = Database['public']['Tables']['assistants']['Insert'];
export type AssistantUpdate = Database['public']['Tables']['assistants']['Update'];

export type AssistantProfile = Database['public']['Tables']['assistant_profiles']['Row'];
export type AssistantProfileInsert = Database['public']['Tables']['assistant_profiles']['Insert'];
export type AssistantProfileUpdate = Database['public']['Tables']['assistant_profiles']['Update'];

export type AssistantRule = Database['public']['Tables']['assistant_rules']['Row'];
export type AssistantRuleInsert = Database['public']['Tables']['assistant_rules']['Insert'];

/**
 * Assistant status enum
 */
export type AssistantStatus = 'active' | 'inactive' | 'archived';

/**
 * Rule type enum
 */
export type RuleType = 'behavior' | 'restriction' | 'guideline' | 'custom';

/**
 * Complete assistant data with profile
 */
export interface AssistantWithProfile extends Assistant {
  profile: AssistantProfile | null;
  rules?: AssistantRule[];
}

/**
 * Assistant metadata structure
 */
export interface AssistantMetadata {
  theme?: {
    primaryColor?: string;
    secondaryColor?: string;
    logo?: string;
  };
  settings?: {
    language?: string;
    timezone?: string;
    notifications?: boolean;
  };
  integrations?: {
    whatsapp?: boolean;
    telegram?: boolean;
    email?: boolean;
  };
}

/**
 * Assistant configuration for creation
 */
export interface AssistantConfig {
  name: string;
  niche: string;
  timezone?: string;
  logo_url?: string;
  profile?: {
    company_description?: string;
    tone_of_voice?: string;
    personality?: string;
    behavior_style?: string;
  };
}