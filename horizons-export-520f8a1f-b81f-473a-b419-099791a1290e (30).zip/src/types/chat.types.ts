/**
 * Chat and conversation type definitions
 */

import type { Database } from './database.types';

export type ConversationMessage = Database['public']['Tables']['conversation_messages']['Row'];
export type ConversationMessageInsert = Database['public']['Tables']['conversation_messages']['Insert'];

/**
 * Message role types
 */
export type MessageRole = 'user' | 'assistant' | 'system';

/**
 * Chat message structure (unified for display)
 */
export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: string;
  metadata?: ChatMetadata;
}

/**
 * Chat metadata structure
 */
export interface ChatMetadata {
  sentiment?: 'positive' | 'neutral' | 'negative';
  intent?: string;
  extractedEntities?: Record<string, any>;
  confidence?: number;
  suggestions?: string[];
}

/**
 * Conversation context
 */
export interface Conversation {
  assistantId: string;
  customerId: string;
  messages: Message[];
  createdAt: string;
  lastMessageAt: string;
}

/**
 * Chat response from AI
 */
export interface ChatResponse {
  message: string;
  metadata?: ChatMetadata;
  shouldEndConversation?: boolean;
  actionRequired?: {
    type: 'schedule_appointment' | 'collect_contact' | 'send_catalog';
    data?: Record<string, any>;
  };
}