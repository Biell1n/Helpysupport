/**
 * Onboarding-related type definitions
 */

import type { Database } from './database.types';

export type OnboardingMessage = Database['public']['Tables']['onboarding_messages']['Row'];
export type OnboardingMessageInsert = Database['public']['Tables']['onboarding_messages']['Insert'];

/**
 * Onboarding step definitions
 */
export type OnboardingStep = 
  | 'welcome'
  | 'company_info'
  | 'tone_personality'
  | 'products_services'
  | 'faqs'
  | 'rules'
  | 'complete';

/**
 * Onboarding state structure stored in assistant_profiles.onboarding_state
 */
export interface OnboardingState {
  currentStep: OnboardingStep;
  completedSteps: OnboardingStep[];
  data: {
    companyDescription?: string;
    toneOfVoice?: string;
    personality?: string;
    behaviorStyle?: string;
    products?: Array<{ name: string; price: number; description?: string }>;
    services?: Array<{ name: string; price: number; duration: number; description?: string }>;
    faqs?: Array<{ question: string; answer: string }>;
    rules?: Array<{ type: string; content: string }>;
  };
  lastUpdated: string;
}

/**
 * Onboarding progress tracking
 */
export interface OnboardingProgress {
  step: OnboardingStep;
  percentage: number;
  isComplete: boolean;
  remainingSteps: OnboardingStep[];
}

/**
 * Message metadata structure
 */
export interface OnboardingMessageMetadata {
  extractedData?: Record<string, any>;
  stepCompleted?: boolean;
  nextStep?: OnboardingStep;
  validationErrors?: string[];
}