/**
 * Database type definitions auto-generated from Supabase schema
 * These types represent the structure of database tables
 */

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      assistants: {
        Row: {
          id: string
          user_id: string
          name: string
          logo_url: string | null
          niche: string
          status: 'active' | 'inactive' | 'archived'
          onboarding_completed: boolean
          onboarding_progress: number
          timezone: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          logo_url?: string | null
          niche: string
          status?: 'active' | 'inactive' | 'archived'
          onboarding_completed?: boolean
          onboarding_progress?: number
          timezone?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          logo_url?: string | null
          niche?: string
          status?: 'active' | 'inactive' | 'archived'
          onboarding_completed?: boolean
          onboarding_progress?: number
          timezone?: string
          created_at?: string
          updated_at?: string
        }
      }
      assistant_profiles: {
        Row: {
          id: string
          assistant_id: string
          company_description: string | null
          tone_of_voice: string | null
          personality: string | null
          behavior_style: string | null
          onboarding_state: Json
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          company_description?: string | null
          tone_of_voice?: string | null
          personality?: string | null
          behavior_style?: string | null
          onboarding_state?: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          company_description?: string | null
          tone_of_voice?: string | null
          personality?: string | null
          behavior_style?: string | null
          onboarding_state?: Json
          created_at?: string
          updated_at?: string
        }
      }
      assistant_rules: {
        Row: {
          id: string
          assistant_id: string
          rule_type: 'behavior' | 'restriction' | 'guideline' | 'custom'
          content: string
          created_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          rule_type: 'behavior' | 'restriction' | 'guideline' | 'custom'
          content: string
          created_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          rule_type?: 'behavior' | 'restriction' | 'guideline' | 'custom'
          content?: string
          created_at?: string
        }
      }
      services: {
        Row: {
          id: string
          assistant_id: string
          name: string
          description: string | null
          duration_minutes: number
          price: number
          metadata: Json
          created_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          name: string
          description?: string | null
          duration_minutes: number
          price: number
          metadata?: Json
          created_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          name?: string
          description?: string | null
          duration_minutes?: number
          price?: number
          metadata?: Json
          created_at?: string
        }
      }
      products: {
        Row: {
          id: string
          assistant_id: string
          name: string
          description: string | null
          price: number
          stock: number | null
          metadata: Json
          created_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          name: string
          description?: string | null
          price: number
          stock?: number | null
          metadata?: Json
          created_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          name?: string
          description?: string | null
          price?: number
          stock?: number | null
          metadata?: Json
          created_at?: string
        }
      }
      faqs: {
        Row: {
          id: string
          assistant_id: string
          question: string
          answer: string
          created_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          question: string
          answer: string
          created_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          question?: string
          answer?: string
          created_at?: string
        }
      }
      onboarding_messages: {
        Row: {
          id: string
          assistant_id: string
          role: 'user' | 'assistant' | 'system'
          message: string
          metadata: Json
          created_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          role: 'user' | 'assistant' | 'system'
          message: string
          metadata?: Json
          created_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          role?: 'user' | 'assistant' | 'system'
          message?: string
          metadata?: Json
          created_at?: string
        }
      }
      conversation_messages: {
        Row: {
          id: string
          assistant_id: string
          customer_id: string
          role: 'user' | 'assistant' | 'system'
          message: string
          metadata: Json
          created_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          customer_id: string
          role: 'user' | 'assistant' | 'system'
          message: string
          metadata?: Json
          created_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          customer_id?: string
          role?: 'user' | 'assistant' | 'system'
          message?: string
          metadata?: Json
          created_at?: string
        }
      }
      appointments: {
        Row: {
          id: string
          assistant_id: string
          customer_name: string
          customer_contact: string
          professional_id: string | null
          start_time: string
          end_time: string
          status: 'pending' | 'confirmed' | 'cancelled' | 'completed'
          metadata: Json
          created_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          customer_name: string
          customer_contact: string
          professional_id?: string | null
          start_time: string
          end_time: string
          status?: 'pending' | 'confirmed' | 'cancelled' | 'completed'
          metadata?: Json
          created_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          customer_name?: string
          customer_contact?: string
          professional_id?: string | null
          start_time?: string
          end_time?: string
          status?: 'pending' | 'confirmed' | 'cancelled' | 'completed'
          metadata?: Json
          created_at?: string
        }
      }
      professionals: {
        Row: {
          id: string
          assistant_id: string
          name: string
          role: string | null
          availability: Json
          created_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          name: string
          role?: string | null
          availability?: Json
          created_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          name?: string
          role?: string | null
          availability?: Json
          created_at?: string
        }
      }
      uploaded_files: {
        Row: {
          id: string
          assistant_id: string
          file_name: string
          file_url: string
          extracted_text: string | null
          metadata: Json
          created_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          file_name: string
          file_url: string
          extracted_text?: string | null
          metadata?: Json
          created_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          file_name?: string
          file_url?: string
          extracted_text?: string | null
          metadata?: Json
          created_at?: string
        }
      }
      embeddings: {
        Row: {
          id: string
          assistant_id: string
          content: string
          embedding: Json
          metadata: Json
          created_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          content: string
          embedding: Json
          metadata?: Json
          created_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          content?: string
          embedding?: Json
          metadata?: Json
          created_at?: string
        }
      }
      usage_logs: {
        Row: {
          id: string
          assistant_id: string
          model_used: string
          tokens_input: number
          tokens_output: number
          estimated_cost: number
          feature_type: 'onboarding' | 'chat' | 'embedding' | 'scheduling' | 'upload'
          created_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          model_used: string
          tokens_input: number
          tokens_output: number
          estimated_cost: number
          feature_type: 'onboarding' | 'chat' | 'embedding' | 'scheduling' | 'upload'
          created_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          model_used?: string
          tokens_input?: number
          tokens_output?: number
          estimated_cost?: number
          feature_type?: 'onboarding' | 'chat' | 'embedding' | 'scheduling' | 'upload'
          created_at?: string
        }
      }
      memory_versions: {
        Row: {
          id: string
          assistant_id: string
          snapshot: Json
          created_at: string
        }
        Insert: {
          id?: string
          assistant_id: string
          snapshot: Json
          created_at?: string
        }
        Update: {
          id?: string
          assistant_id?: string
          snapshot?: Json
          created_at?: string
        }
      }
    }
  }
}