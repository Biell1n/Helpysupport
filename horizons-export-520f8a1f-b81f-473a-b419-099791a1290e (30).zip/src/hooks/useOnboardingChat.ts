// DEPRECATED FILE
// Due to environment constraints, all hooks MUST use the .js extension.
// The code from this file was unified and merged into src/hooks/useOnboardingChat.js
// Please use the .js version for correct body format (onboarding_session_id) and proper try/catch/finally loading states.
export function useOnboardingChat() {
  console.warn("DEPRECATED: Import from useOnboardingChat.js instead.");
  return {
    messages: [],
    loading: false,
    error: null,
    loadHistory: () => {},
    sendMessage: () => {}
  };
}