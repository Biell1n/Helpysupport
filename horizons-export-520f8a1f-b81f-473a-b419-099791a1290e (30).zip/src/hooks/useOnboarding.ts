/**
 * React hook for managing onboarding state and progress
 * Refactored to use sessionId instead of assistantId during the onboarding phase
 */

import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase/client';
import { onboardingService } from '@/services/onboarding/onboardingService';
import type { OnboardingProgress, OnboardingStateInput } from '@/types/onboarding.types';

interface UseOnboardingReturn {
  progress: number;
  loading: boolean;
  error: string | null;
  sessionData: any | null;
  fetchSession: (sessionId: string) => Promise<void>;
  updateState: (sessionId: string, state: any) => Promise<boolean>;
}

export function useOnboarding(): UseOnboardingReturn {
  const [progress, setProgress] = useState<number>(0);
  const [sessionData, setSessionData] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchSession = useCallback(async (sessionId: string) => {
    if (!sessionId) return;

    setLoading(true);
    setError(null);

    try {
      const { data: { session }, error: authError } = await supabase.auth.getSession();
      if (authError || !session?.user) throw new Error('Usuário não autenticado');

      const data = await onboardingService.getSession(sessionId, session.user.id);
      
      setSessionData(data);
      setProgress(data.onboarding_progress || data.context_confidence || 0);
    } catch (err: any) {
      setError(err.message || 'Erro ao carregar sessão de onboarding');
    } finally {
      setLoading(false);
    }
  }, []);

  const updateState = async (sessionId: string, updates: any): Promise<boolean> => {
    if (!sessionId) {
      setError('ID da sessão não fornecido');
      return false;
    }

    setLoading(true);
    setError(null);

    try {
      const data = await onboardingService.updateSession(sessionId, updates);
      
      setSessionData(data);
      setProgress(data.onboarding_progress || data.context_confidence || 0);
      return true;
    } catch (err: any) {
      setError(err.message || 'Erro ao atualizar estado do onboarding');
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    progress,
    loading,
    error,
    sessionData,
    fetchSession,
    updateState,
  };
}