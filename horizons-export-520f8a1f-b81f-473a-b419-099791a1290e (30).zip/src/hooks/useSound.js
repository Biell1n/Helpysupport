import { useCallback } from 'react';

// Shared AudioContext to save resources
let audioCtx = null;

const initAudio = () => {
  if (!audioCtx && typeof window !== 'undefined') {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (AudioContext) {
      audioCtx = new AudioContext();
    }
  }
  return audioCtx;
};

export function useSound() {
  const getVolume = () => {
    const vol = localStorage.getItem('soundVolume');
    return vol ? parseInt(vol, 10) / 100 : 0.5;
  };

  const isEnabled = () => {
    return localStorage.getItem('soundsEnabled') !== 'false';
  };

  const playTone = useCallback((frequency, type, duration, volMultiplier = 1) => {
    const ctx = initAudio();
    if (!ctx || !isEnabled()) return;

    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(frequency, ctx.currentTime);

    const baseVolume = getVolume() * volMultiplier;
    gainNode.gain.setValueAtTime(baseVolume, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + duration);
  }, []);

  const playMessageSentSound = useCallback(() => {
    if (!isEnabled()) return;
    playTone(400, 'sine', 0.1, 0.30); // 30% volume level
  }, [playTone]);

  const playMessageReceivedSound = useCallback(() => {
    if (!isEnabled()) return;
    playTone(600, 'sine', 0.15, 0.35); // 35% volume level
  }, [playTone]);

  return { playMessageSentSound, playMessageReceivedSound };
}