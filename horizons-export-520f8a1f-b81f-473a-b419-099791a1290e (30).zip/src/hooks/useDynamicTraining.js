import { useState, useEffect, useCallback } from 'react';
import { getFieldsByBusinessType, BUSINESS_TYPES } from '@/lib/businessTypeFields';
import { supabase } from '@/lib/supabase';

export function useDynamicTraining() {
  const [businessType, setBusinessType] = useState(BUSINESS_TYPES.VENDAS);
  const [formData, setFormData] = useState({});
  const [fieldStatuses, setFieldStatuses] = useState({});

  // Load progress from localStorage on mount
  useEffect(() => {
    const savedData = localStorage.getItem('dynamicTrainingProgress');
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData);
        if (parsed.businessType) setBusinessType(parsed.businessType);
        if (parsed.formData) setFormData(parsed.formData);
      } catch (e) {
        console.error('Failed to parse saved training progress');
      }
    }
  }, []);

  const fields = getFieldsByBusinessType(businessType);

  // Validate all current fields whenever formData or businessType changes
useEffect(() => {
  const validateWithAI = async () => {
    const newStatuses = {};

    for (const field of fields) {
      const content = formData[field.name] || '';

      try {
        if (!content.trim()) {
          newStatuses[field.name] = {
            status: field.required ? 'empty' : 'optional',
            reason: 'Campo vazio'
          };
          continue;
        }

        const { data, error } = await supabase.functions.invoke('analyze-content-quality', {
          body: {
            fieldType: field.name,
            fieldValue: content,
            businessType: businessType
          }
        });

        if (error || !data) {
          newStatuses[field.name] = {
            status: 'incomplete',
            reason: 'Erro ao validar com IA'
          };
        } else {
          newStatuses[field.name] = {
            status:
              data.status === 'green' ? 'valid' :
              data.status === 'orange' ? 'incomplete' :
              data.status === 'purple' ? 'invalid' : 'empty',
            reason: data.feedback
          };
        }

      } catch (err) {
        newStatuses[field.name] = {
          status: 'incomplete',
          reason: 'Erro inesperado'
        };
      }
    }

    setFieldStatuses(newStatuses);
  };

  validateWithAI();
}, [formData, businessType, fields]);

  const updateField = useCallback((fieldName, content) => {
    setFormData(prev => ({ ...prev, [fieldName]: content }));
  }, []);

  const handleBusinessTypeChange = useCallback((newType) => {
    setBusinessType(newType);
    // Optionally clear data that doesn't match new fields, but keeping it is usually better for UX
  }, []);

  const saveProgress = useCallback(() => {
    const dataToSave = {
      businessType,
      formData
    };
    localStorage.setItem('dynamicTrainingProgress', JSON.stringify(dataToSave));
    return true;
  }, [businessType, formData]);

  const getValidationStatus = useCallback(() => {
    const counts = { empty: 0, incomplete: 0, valid: 0, invalid: 0, optional: 0 };
    let coreValid = true;

    fields.forEach(field => {
      const statusObj = fieldStatuses[field.name];
      if (statusObj) {
        counts[statusObj.status] = (counts[statusObj.status] || 0) + 1;
        
        if (field.required && statusObj.status !== 'valid') {
           coreValid = false;
        }
      } else {
        counts.empty++;
        if (field.required) coreValid = false;
      }
    });

    return { counts, totalFields: fields.length, isReadyToContinue: coreValid };
  }, [fields, fieldStatuses]);

  return {
    businessType,
    setBusinessType: handleBusinessTypeChange,
    fields,
    formData,
    fieldStatuses,
    updateField,
    saveProgress,
    getValidationStatus
  };
}