import { useState, useEffect, useRef } from 'react';
import { validateFieldContentAsync, validateFieldContent } from '@/lib/contentValidationRules';

export function useContentAnalysis(fieldId, fieldLabel, fieldValue, businessType, notApplicableFields = [], delay = 500) {
  const [status, setStatus] = useState('loading');
  const [feedback, setFeedback] = useState('Analisando...');
  const [isLoading, setIsLoading] = useState(false);
  
  // Track previous definitive status to gracefully degrade on timeout/error
  const prevStatusRef = useRef('loading');

  // Stringify the array to prevent infinite re-renders if passed as a new array literal on every render
  const naString = JSON.stringify(notApplicableFields);

  useEffect(() => {
    let isMounted = true;
    
    // Quick sync check first
    const syncRes = validateFieldContent(fieldId, fieldValue, businessType, true, notApplicableFields);
    
    if (syncRes.status !== 'loading') {
      setStatus(syncRes.status);
      setFeedback(syncRes.message);
      setIsLoading(false);
      prevStatusRef.current = syncRes.status;
      return;
    }

    setIsLoading(true);
    setStatus('loading');
    setFeedback('Validando detalhes...');

    const controller = new AbortController();

    const handler = setTimeout(async () => {
      try {
        // Implement 10-second timeout for the async validation
        const timeoutFallback = {
          status: prevStatusRef.current !== 'loading' ? prevStatusRef.current : 'orange',
          message: 'Análise demorou muito. Último estado mantido.'
        };

        const timeoutPromise = new Promise(resolve => 
          setTimeout(() => resolve(timeoutFallback), 10000)
        );

        const asyncRes = await Promise.race([
          validateFieldContentAsync(fieldId, fieldValue, businessType, true, notApplicableFields),
          timeoutPromise
        ]);

        if (isMounted) {
          setStatus(asyncRes.status);
          setFeedback(asyncRes.message);
          if (asyncRes.status !== 'loading') {
            prevStatusRef.current = asyncRes.status;
          }
        }
      } catch (err) {
        if (isMounted) {
          const fallbackStatus = prevStatusRef.current !== 'loading' ? prevStatusRef.current : 'orange';
          setStatus(fallbackStatus);
          setFeedback('Erro na validação. Último estado mantido.');
        }
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }, delay);

    return () => {
      isMounted = false;
      clearTimeout(handler);
      controller.abort();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fieldId, fieldValue, businessType, naString, delay]);

  return { status, feedback, isLoading };
}