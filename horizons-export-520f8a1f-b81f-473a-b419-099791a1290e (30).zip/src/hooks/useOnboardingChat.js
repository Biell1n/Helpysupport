import { useState, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

export function useOnboardingChat(initialSessionId) {
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);
  const [sessionState, setSessionState] = useState({
    extracted_data: {},
    missing_information: { critical: [], important: [], optional: [] },
    next_objective: '',
    context_sufficiency: 0
  });
  const [progress, setProgress] = useState(null);
  const [validations, setValidations] = useState(null);

  const loadHistory = useCallback(async (sessionId) => {
    if (!sessionId) return;
    try {
      setLoading(true);
      const { data: session } = await supabase
        .from('onboarding_sessions')
        .select('*')
        .eq('id', sessionId)
        .single();
        
      if (session) {
        setHistory(session.conversation_history || []);
        setSessionState({
          extracted_data: session.extracted_data || {},
          missing_information: session.missing_information || { critical: [], important: [], optional: [] },
          next_objective: session.next_objective || '',
          context_sufficiency: session.context_sufficiency || 0
        });
      }
    } catch (err) {
      console.error("Failed to load history:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  const sendMessage = async (message, sessionId, userId) => {
    try {
      setLoading(true);
      
      // Optimistic update
      const newUserMsg = { id: Date.now(), role: 'user', content: message };
      setHistory(prev => [...prev, newUserMsg]);

      const { data, error } = await supabase.functions.invoke('onboarding-chat', {
        body: { message, onboarding_session_id: sessionId, user_id: userId }
      });

      if (error) throw error;

      if (data) {
        if (data.session_state?.conversation_history) {
           setHistory(data.session_state.conversation_history);
        } else if (data.message) {
           setHistory(prev => [...prev, { id: Date.now() + 1, role: 'assistant', content: data.message }]);
        }
        
        if (data.session_state) setSessionState(data.session_state);
        if (data.progress) setProgress(data.progress);
        if (data.validation) setValidations(data.validation);
      }
    } catch (err) {
      console.error("Chat error:", err);
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    history,
    sendMessage,
    loadHistory,
    extractedData: sessionState.extracted_data,
    missingInformation: sessionState.missing_information,
    nextObjective: sessionState.next_objective,
    contextSufficiency: sessionState.context_sufficiency,
    progress,
    validations
  };
}