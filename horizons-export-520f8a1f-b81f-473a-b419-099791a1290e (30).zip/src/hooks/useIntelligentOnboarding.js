import { useState, useCallback, useEffect, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { logger } from '@/utils/logger';
import { useToast } from '@/hooks/use-toast';

export function useIntelligentOnboarding(initialSessionId) {
  const { toast } = useToast();
  const [sessionId, setSessionId] = useState(initialSessionId);
  const [loading, setLoading] = useState(false);
  const [sessionState, setSessionState] = useState({
    business_type: null,
    critical_fields: [],
    important_fields: [],
    optional_fields: [],
    extracted_data: {},
    depth_analysis: {},
    missing_information: { critical: [], important: [], optional: [] },
    next_objective: "",
    update_count: 0
  });
  const [history, setHistory] = useState([]);
  const [updates, setUpdates] = useState([]);
  const renderCount = useRef(0);

  useEffect(() => {
    renderCount.current += 1;
    logger.debug('useIntelligentOnboarding', `Hook rendered. Count: ${renderCount.current}`);
  });

  const fetchSessionState = useCallback(async () => {
    if (!sessionId) return;
    try {
      logger.info('fetchSessionState', `Fetching session state for ID: ${sessionId}`);
      const { data, error } = await supabase
        .from('onboarding_sessions')
        .select('*')
        .eq('id', sessionId)
        .single();
      
      if (error) throw error;

      if (data) {
        setSessionState({
          business_type: data.business_type,
          critical_fields: data.critical_fields || [],
          important_fields: data.important_fields || [],
          optional_fields: data.optional_fields || [],
          extracted_data: data.extracted_data || {},
          depth_analysis: data.depth_analysis || {},
          missing_information: data.missing_information || { critical: [], important: [], optional: [] },
          next_objective: data.next_objective || "",
          update_count: data.update_count || 0
        });
        
        // Fetch real history from messages table to avoid sync issues
        const { data: messages, error: msgError } = await supabase
          .from('onboarding_messages')
          .select('role, content')
          .eq('session_id', sessionId)
          .order('created_at', { ascending: true });
          
        if (!msgError && messages) {
           setHistory(messages);
           logger.state('fetchSessionState', { historyLength: messages.length });
        }
      }
    } catch (err) {
      logger.error('fetchSessionState', 'Failed to fetch session state', err);
    }
  }, [sessionId]);

  useEffect(() => {
    fetchSessionState();
    // Intentionally only run on mount and when sessionId changes. 
    // Do NOT clear state during re-renders.
  }, [fetchSessionState]);

  const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  const sendMessage = async (message, userId, retryCount = 0) => {
    try {
      setLoading(true);
      logger.info('sendMessage', `Sending message. Attempt: ${retryCount + 1}`);
      
      // Optimistic UI update
      if (retryCount === 0) {
        const newUserMsg = { role: 'user', content: message };
        setHistory(prev => {
          const updated = [...prev, newUserMsg];
          logger.debug('sendMessage', 'Optimistically updating history', updated.length);
          return updated;
        });
      }

      const { data, error } = await supabase.functions.invoke('onboarding-chat', {
        body: { message, onboarding_session_id: sessionId, user_id: userId }
      });

      if (error) throw error;

      if (data) {
        logger.debug('sendMessage', 'Received Edge Function response', { 
          hasUpdates: data.updates?.length > 0,
          historyLength: data.session_state?.conversation_history?.length
        });

        if (data.session_state?.conversation_history) {
          setHistory(data.session_state.conversation_history);
        } else if (data.message) {
          setHistory(prev => [...prev, { role: 'assistant', content: data.message }]);
        }

        if (data.session_state) {
          setSessionState(prev => ({
            ...prev,
            ...data.session_state,
            extracted_data: data.session_state.extracted_data || prev.extracted_data,
            depth_analysis: data.session_state.depth_analysis || prev.depth_analysis,
            missing_information: data.session_state.missing_information || prev.missing_information,
            next_objective: data.session_state.next_objective || prev.next_objective
          }));
        }
        
        if (data.updates && data.updates.length > 0) {
          setUpdates(data.updates);
          data.updates.forEach(u => toast({
            title: "Information Updated",
            description: `Updated ${u.field}`,
            variant: "default",
          }));
          setTimeout(() => setUpdates([]), 4000);
        }
      }
    } catch (err) {
      logger.error('sendMessage', `Error on attempt ${retryCount + 1}`, err);
      
      if (retryCount < 3) {
        const backoffMs = Math.pow(2, retryCount) * 1000;
        logger.info('sendMessage', `Retrying in ${backoffMs}ms...`);
        toast({
          title: "Connection Error",
          description: `Retrying in ${backoffMs/1000}s...`,
          variant: "destructive",
        });
        await delay(backoffMs);
        return sendMessage(message, userId, retryCount + 1);
      } else {
        toast({
          title: "Failed to send message",
          description: "Could not reach the server. Please try again later.",
          variant: "destructive",
        });
        // Remove optimistic message on permanent failure
        setHistory(prev => prev.filter((_, i) => i !== prev.length - 1));
      }
    } finally {
      setLoading(false);
    }
  };

  const getProgress = useCallback(() => {
    const { critical_fields, important_fields, optional_fields, extracted_data, depth_analysis } = sessionState;
    const isComplete = (f) => extracted_data[f] && depth_analysis[f]?.status === 'confirmed';
    
    const critC = critical_fields.filter(isComplete).length;
    const impC = important_fields.filter(isComplete).length;
    const optC = optional_fields.filter(isComplete).length;
    
    const total = (critical_fields.length * 2) + important_fields.length;
    const score = (critC * 2) + impC;
    const overall = total === 0 ? 0 : Math.round((score / total) * 100);

    return {
      critical: critC, critical_total: critical_fields.length,
      important: impC, important_total: important_fields.length,
      optional: optC, optional_total: optional_fields.length,
      overall
    };
  }, [sessionState]);

  return {
    sessionId,
    setSessionId,
    loading,
    sessionState,
    history,
    updates,
    sendMessage,
    getProgress,
    fetchSessionState
  };
}