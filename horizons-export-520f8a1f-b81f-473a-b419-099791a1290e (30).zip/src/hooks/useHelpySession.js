import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/AuthContext';

export function useHelpySession() {
  const { user } = useAuth();
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadSession = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error: fetchError } = await supabase
        .from('assistants_creation_sessions')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'in_progress')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (fetchError) throw fetchError;

      if (data) {
        setSession(data);
      } else {
        const newSession = {
          user_id: user.id,
          status: 'in_progress',
          configuration: {},
          conversation_history: [],
          active_fields: {},
          ignored_fields: {},
          brain_state: {}
        };
        const { data: created, error: insertError } = await supabase
          .from('assistants_creation_sessions')
          .insert(newSession)
          .select()
          .single();
          
        if (insertError) throw insertError;
        setSession(created);
      }
    } catch (err) {
      console.error("Error loading session:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadSession();
  }, [loadSession]);

  const updateSessionState = async (updates) => {
    if (!session) return;
    const newSession = { ...session, ...updates, updated_at: new Date().toISOString() };
    setSession(newSession);
    try {
      await supabase
        .from('assistants_creation_sessions')
        .update(updates)
        .eq('id', session.id);
    } catch (err) {
      console.error("Error updating session:", err);
    }
  };

  const updateConfiguration = async (updates) => {
    if (!session) return;
    const newConfig = { ...session.configuration, ...updates };
    await updateSessionState({ configuration: newConfig });
  };

  const setAssistantType = async (type) => {
    if (!session) return;
    await updateSessionState({ assistant_type: type });
  };

  const addMessage = async (role, content) => {
    if (!session) return;
    const newHistory = [...(session.conversation_history || []), { role, content, timestamp: new Date().toISOString() }];
    await updateSessionState({ conversation_history: newHistory });
  };

  const completeSession = async () => {
    if (!session || !user) return;
    try {
      const { error } = await supabase
        .from('assistants_creation_sessions')
        .update({ status: 'completed', completed_at: new Date().toISOString() })
        .eq('id', session.id);
      if (error) throw error;
      
      const assistant = {
        user_id: user.id,
        name: session.configuration.nome || 'Novo Assistente',
        type: session.assistant_type || 'informativo',
        configuration: session.configuration,
        creation_conversation: session.conversation_history
      };
      
      const { error: asstError } = await supabase.from('assistants').insert(assistant);
      if (asstError) throw asstError;
      
      return true;
    } catch (err) {
      console.error("Error completing session:", err);
      return false;
    }
  };

  return {
    session,
    loading,
    error,
    updateConfiguration,
    setAssistantType,
    addMessage,
    completeSession,
    updateSessionState,
    refreshSession: loadSession
  };
}