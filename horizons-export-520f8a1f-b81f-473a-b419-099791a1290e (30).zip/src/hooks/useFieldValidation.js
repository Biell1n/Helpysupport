export function validateEmail(email) {
  if (!email) return { isValid: false, message: 'Email ausente.' };
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!regex.test(email)) return { isValid: false, message: 'Formato de email inválido. Deve conter @ e domínio válido.' };
  return { isValid: true, message: 'Email válido.' };
}

export function validatePhone(phone) {
  if (!phone) return { isValid: false, message: 'Telefone ausente.' };
  const regex = /^[\d\s\-\(\)\+]{10,}$/;
  if (!regex.test(phone)) return { isValid: false, message: 'Formato de telefone inválido (mínimo 10 dígitos, use apenas números, espaços, +, - ou parênteses).' };
  return { isValid: true, message: 'Telefone válido.' };
}

export function validateAddress(address) {
  if (!address) return { isValid: false, message: 'Endereço ausente.' };
  if (!/\d/.test(address)) return { isValid: false, message: 'Endereço deve conter um número.' };
  return { isValid: true, message: 'Endereço válido.' };
}

export function validateProduct(product) {
  if (!product || !product.nome) return { isValid: false, message: 'Nome do produto/serviço ou categoria é obrigatório.' };
  // Removed strict numeric validation to allow ranges like "R$ 30 - R$ 50", "A partir de R$ 90", etc.
  return { isValid: true, message: 'Produto/Categoria válido.' };
}

export function validatePersonality(content) {
  if (!content) return { isValid: false, message: 'Conteúdo ausente.' };
  return { isValid: true, message: 'Personalidade válida.' };
}

export function validateRules(rulesArray) {
  if (!Array.isArray(rulesArray) || rulesArray.length === 0) return { isValid: false, message: 'Regras ausentes.' };
  return { isValid: true, message: 'Regras válidas.' };
}

export function useFieldValidation() {
  return {
    validateEmail,
    validatePhone,
    validateAddress,
    validateProduct,
    validatePersonality,
    validateRules
  };
}