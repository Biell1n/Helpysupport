import { useState } from 'react';

export function useAssistantForm() {
  const [formData, setFormData] = useState({
    assistantName: '',
    personality: '',
    customPersonality: '',
    assistantFunction: '',
    faqItems: []
  });

  const updateField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addFaqItem = () => {
    setFormData(prev => ({
      ...prev,
      faqItems: [...prev.faqItems, { question: '', answer: '' }]
    }));
  };

  const removeFaqItem = (index) => {
    setFormData(prev => ({
      ...prev,
      faqItems: prev.faqItems.filter((_, i) => i !== index)
    }));
  };

  const updateFaqItem = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      faqItems: prev.faqItems.map((item, i) => 
        i === index ? { ...item, [field]: value } : item
      )
    }));
  };

  const validate = () => {
    if (!formData.assistantName.trim()) return "O nome do assistente é obrigatório.";
    if (!formData.personality) return "Selecione uma personalidade.";
    if (formData.personality === 'Personalizado' && !formData.customPersonality.trim()) {
      return "Defina a personalidade personalizada.";
    }
    if (!formData.assistantFunction.trim()) return "A função do assistente é obrigatória.";
    return null;
  };

  const resetForm = () => {
    setFormData({
      assistantName: '',
      personality: '',
      customPersonality: '',
      assistantFunction: '',
      faqItems: []
    });
  };

  return {
    formData,
    updateField,
    addFaqItem,
    removeFaqItem,
    updateFaqItem,
    validate,
    resetForm
  };
}