import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

export function useStreamingChat(onSuggestionApply) {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Olá! Estou aqui para ajudar a refinar as configurações do seu assistente. O que você gostaria de melhorar?', isStreaming: false }
  ]);
  const [isStreaming, setIsStreaming] = useState(false);

  const processStream = async (reader, decoder, assistantMessageIndex) => {
    let done = false;
    let fullContent = '';

    while (!done) {
      const { value, done: readerDone } = await reader.read();
      done = readerDone;

      if (value) {
        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');
        
        for (const line of lines) {
          if (line.startsWith('data: ') && line !== 'data: [DONE]') {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.choices[0].delta.content) {
                fullContent += data.choices[0].delta.content;
                setMessages(prev => {
                  const newMsgs = [...prev];
                  newMsgs[assistantMessageIndex] = {
                    ...newMsgs[assistantMessageIndex],
                    content: fullContent
                  };
                  return newMsgs;
                });
              }
            } catch (e) {
              // Ignore parse errors on incomplete chunks
            }
          }
        }
      }
    }

    setMessages(prev => {
      const newMsgs = [...prev];
      newMsgs[assistantMessageIndex] = {
        ...newMsgs[assistantMessageIndex],
        isStreaming: false
      };
      return newMsgs;
    });

    // Check for auto-apply triggers
    detectSuggestion(fullContent);
  };

  const detectSuggestion = (content) => {
    // Simple logic to ask user if they want to apply if the AI suggested a change
    if (content.toLowerCase().includes('sugiro alterar') || content.toLowerCase().includes('que tal mudar')) {
      setMessages(prev => [
        ...prev,
        { role: 'assistant', content: 'Quer que eu faça essa alteração no formulário para você?', isSystemPrompt: true }
      ]);
    }
  };

  const handleUserConfirmation = (userMsg) => {
    const affirmativeResponses = ['sim', 'ok', 'yes', 'pode fazer', 'claro'];
    const msgLower = userMsg.toLowerCase().trim();
    
    if (affirmativeResponses.some(resp => msgLower.includes(resp))) {
      // In a real scenario, we'd extract the exact field and value from the AI's previous context.
      // Here we just notify the parent component that a confirmation happened.
      if (onSuggestionApply) {
        onSuggestionApply();
      }
    }
  };

  const sendMessage = useCallback(async (text, currentFormData) => {
    if (!text.trim() || isStreaming) return;

    handleUserConfirmation(text);

    const newMessages = [...messages, { role: 'user', content: text }];
    setMessages(newMessages);
    setIsStreaming(true);

    const assistantMsgIndex = newMessages.length;
    setMessages(prev => [...prev, { role: 'assistant', content: '', isStreaming: true }]);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/refine-assistant`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token || import.meta.env.VITE_SUPABASE_ANON_KEY}`
        },
        body: JSON.stringify({
          message: text,
          name: currentFormData.assistantName,
          personality: currentFormData.personality,
          function: currentFormData.assistantFunction,
          faq: currentFormData.faqItems
        })
      });

      if (!response.ok) throw new Error('Falha na comunicação com a IA');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      
      await processStream(reader, decoder, assistantMsgIndex);

    } catch (error) {
      console.error(error);
      setMessages(prev => {
        const newMsgs = [...prev];
        newMsgs[assistantMsgIndex] = {
          role: 'assistant',
          content: 'Ocorreu um erro ao processar sua mensagem.',
          isError: true,
          isStreaming: false
        };
        return newMsgs;
      });
    } finally {
      setIsStreaming(false);
    }
  }, [messages, isStreaming, onSuggestionApply]);

  const clearMessages = () => {
    setMessages([{ role: 'assistant', content: 'Olá! Estou aqui para ajudar a refinar as configurações do seu assistente. O que você gostaria de melhorar?', isStreaming: false }]);
  };

  return { messages, isStreaming, sendMessage, clearMessages };
}