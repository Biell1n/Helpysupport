import { useState, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { analyzeLocalStructure } from '@/lib/FieldAnalysisEngine';

const defaultStructure = {
  descricao: {
    status: 'incompleto', diagnostico: '', cor: 'vermelho', required: true, ignored: false,
    subfields: {
      nicho: { value: '', status: 'incompleto', ignored: false },
      caracteristicas: { value: '', status: 'incompleto', ignored: false },
      diferenciais: { value: '', status: 'incompleto', ignored: false }
    }
  },
  endereco: {
    status: 'incompleto', diagnostico: '', cor: 'vermelho', required: false, ignored: false,
    subfields: {
      rua: { value: '', status: 'incompleto', ignored: false },
      numero: { value: '', status: 'incompleto', ignored: false },
      bairro: { value: '', status: 'incompleto', ignored: false },
      cidade: { value: '', status: 'incompleto', ignored: false },
      complemento: { value: '', status: 'incompleto', ignored: false },
      referencia: { value: '', status: 'incompleto', ignored: false }
    }
  },
  produtos: {
    status: 'incompleto', diagnostico: '', cor: 'vermelho', required: true, ignored: false, items: []
  },
  contato: {
    status: 'incompleto', diagnostico: '', cor: 'vermelho', required: true, ignored: false, items: []
  }
};

export function useAssistantIntelligence() {
  const [structuredState, setStructuredState] = useState(defaultStructure);
  const [conversationHistory, setConversationHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [hasShownInitialMessage, setHasShownGreeting] = useState(false);

  const runFieldAnalysis = useCallback(async (newState) => {
    try {
      const { data, error } = await supabase.functions.invoke('analyze-field-structure', {
        body: { fields: newState }
      });
      if (!error && data?.success && data.analysis) {
        setStructuredState(prev => {
          const updatedWithAnalysis = { ...prev };
          Object.keys(data.analysis).forEach(key => {
            if (updatedWithAnalysis[key]) {
              updatedWithAnalysis[key] = {
                ...updatedWithAnalysis[key],
                status: data.analysis[key].status,
                cor: data.analysis[key].cor,
                diagnostico: data.analysis[key].diagnostico
              };
            }
          });
          return updatedWithAnalysis;
        });
      }
    } catch (err) {
      console.error('Analysis error:', err);
    }
  }, []);

  const updateStructuredField = useCallback((fieldName, newData) => {
    setStructuredState(prev => {
      const updated = { ...prev, [fieldName]: { ...prev[fieldName], ...newData } };
      const localValidation = analyzeLocalStructure(updated[fieldName]);
      updated[fieldName].status = localValidation.status;
      updated[fieldName].cor = localValidation.cor;
      runFieldAnalysis(updated);
      return updated;
    });
  }, [runFieldAnalysis]);

  return {
    structuredState,
    conversationHistory,
    setConversationHistory,
    loading,
    updateStructuredField,
    runFieldAnalysis,
    hasShownInitialMessage,
    setHasShownGreeting
  };
}