import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

export function useImageUpload(bucketName) {
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState(null);

  const validateImage = useCallback((file) => {
    if (!file) {
      return { isValid: false, error: 'Nenhum arquivo selecionado.' };
    }

    const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      return { isValid: false, error: 'Formato inválido. Use JPG, PNG ou WebP.' };
    }

    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
      return { isValid: false, error: 'A imagem excede o limite máximo de 5MB.' };
    }

    return { isValid: true, error: null };
  }, []);

  const uploadImage = useCallback(async (file, path) => {
    setIsUploading(true);
    setError(null);
    try {
      const { error: uploadError } = await supabase.storage
        .from(bucketName)
        .upload(path, file, {
          upsert: true,
          cacheControl: '3600'
        });

      if (uploadError) {
        throw uploadError;
      }

      const { data: { publicUrl } } = supabase.storage
        .from(bucketName)
        .getPublicUrl(path);

      return publicUrl;
    } catch (err) {
      console.error('Image upload error:', err);
      setError(err.message || 'Erro ao fazer upload da imagem.');
      throw err;
    } finally {
      setIsUploading(false);
    }
  }, [bucketName]);

  return {
    validateImage,
    uploadImage,
    isUploading,
    error
  };
}