import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { createHistoryEntry, addToHistory, undoHistory, canUndo, getCurrentState } from '@/lib/EditHistory';

export function useEditHistory(assistantId) {
  const [history, setHistory] = useState([]);

  const loadHistory = useCallback(async (memoryId) => {
    if (!memoryId) return;
    try {
      const { data, error } = await supabase
        .from('assistant_memory')
        .select('history_log')
        .eq('id', memoryId)
        .single();
      if (!error && data?.history_log) {
        setHistory(data.history_log);
      }
    } catch (err) {
      console.error("Failed to load history:", err);
    }
  }, []);

  const saveHistory = useCallback(async (memoryId, newHistory) => {
    if (!memoryId) return;
    try {
      await supabase
        .from('assistant_memory')
        .update({ history_log: newHistory })
        .eq('id', memoryId);
    } catch (err) {
      console.error("Failed to save history:", err);
    }
  }, []);

  const addHistoryEntryLocal = useCallback((memoryId, previousState, currentState, action, sectionName) => {
    const entry = createHistoryEntry(previousState, currentState, action, sectionName);
    setHistory(prev => {
      const newHistory = addToHistory(prev, entry);
      saveHistory(memoryId, newHistory);
      return newHistory;
    });
    return entry;
  }, [saveHistory]);

  const popHistory = useCallback((memoryId) => {
    let lastEntry = null;
    setHistory(prev => {
      if (!canUndo(prev)) return prev;
      lastEntry = prev[prev.length - 1];
      const newHistory = undoHistory(prev);
      saveHistory(memoryId, newHistory);
      return newHistory;
    });
    return lastEntry;
  }, [saveHistory]);

  const clearHistory = useCallback((memoryId) => {
    setHistory([]);
    saveHistory(memoryId, []);
  }, [saveHistory]);

  return {
    history,
    loadHistory,
    addHistoryEntry: addHistoryEntryLocal,
    undo: popHistory,
    canUndo: () => canUndo(history),
    getCurrentState: () => getCurrentState(history),
    clearHistory
  };
}