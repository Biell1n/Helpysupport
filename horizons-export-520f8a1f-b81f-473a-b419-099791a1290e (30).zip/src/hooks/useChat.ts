/**
 * React hook for managing conversation messages and chat state
 */

import { useState, useEffect, useCallback } from 'react';
import {
  saveMessage as saveMessageService,
  getConversationHistory as getConversationHistoryService,
  deleteConversation as deleteConversationService,
  getLastMessages as getLastMessagesService,
} from '@/services/chat/chatService';
import type { Message, MessageRole } from '@/types/chat.types';

interface UseChatReturn {
  messages: Message[];
  loading: boolean;
  error: string | null;
  sendMessage: (role: MessageRole, content: string, metadata?: Record<string, any>) => Promise<boolean>;
  loadHistory: (limit?: number) => Promise<void>;
  deleteHistory: () => Promise<boolean>;
  refetch: () => Promise<void>;
}

export function useChat(assistantId?: string, customerId?: string): UseChatReturn {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const loadHistory = useCallback(async (limit: number = 50) => {
    if (!assistantId || !customerId) return;

    setLoading(true);
    setError(null);

    try {
      const { data, error: historyError } = await getConversationHistoryService(
        assistantId,
        customerId,
        limit
      );
      
      if (historyError) {
        setError(historyError);
        return;
      }

      setMessages(data);
    } catch (err: any) {
      setError(err.message || 'Erro ao carregar histórico');
    } finally {
      setLoading(false);
    }
  }, [assistantId, customerId]);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  const sendMessage = async (
    role: MessageRole,
    content: string,
    metadata?: Record<string, any>
  ): Promise<boolean> => {
    if (!assistantId || !customerId) {
      setError('IDs do assistente ou cliente não fornecidos');
      return false;
    }

    setLoading(true);
    setError(null);

    try {
      const { data, error: sendError } = await saveMessageService(
        assistantId,
        customerId,
        role,
        content,
        metadata
      );
      
      if (sendError) {
        setError(sendError);
        return false;
      }

      // Add message to local state
      if (data) {
        const newMessage: Message = {
          id: data.id,
          role: data.role,
          content: data.message,
          timestamp: data.created_at,
          metadata: data.metadata as any,
        };
        setMessages(prev => [...prev, newMessage]);
      }

      return true;
    } catch (err: any) {
      setError(err.message || 'Erro ao enviar mensagem');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const deleteHistory = async (): Promise<boolean> => {
    if (!assistantId || !customerId) {
      setError('IDs do assistente ou cliente não fornecidos');
      return false;
    }

    setLoading(true);
    setError(null);

    try {
      const { success, error: deleteError } = await deleteConversationService(
        assistantId,
        customerId
      );
      
      if (deleteError) {
        setError(deleteError);
        return false;
      }

      setMessages([]);
      return success;
    } catch (err: any) {
      setError(err.message || 'Erro ao deletar histórico');
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    messages,
    loading,
    error,
    sendMessage,
    loadHistory,
    deleteHistory,
    refetch: loadHistory,
  };
}