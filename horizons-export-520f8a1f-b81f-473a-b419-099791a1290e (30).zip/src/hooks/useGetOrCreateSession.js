import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { getActiveSession } from '@/lib/getActiveSession';

export function useGetOrCreateSession(initialUserId = null) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (initialUserId) {
      console.log('[HOOK] Hook inicializado com user_id:', initialUserId);
    }
  }, [initialUserId]);

  const getOrCreateSession = useCallback(async (user_id, business_type, business_description, business_goal) => {
    console.log('[SESSION] INÍCIO: getOrCreateSession chamado com parâmetros:', { user_id, business_type, business_description, business_goal });

    if (!user_id) {
      const err = new Error('user_id is required');
      console.error('[SESSION] ERRO VALIDAÇÃO: user_id nulo ou undefined', err);
      throw err;
    }

    setIsLoading(true);
    setError(null);

    try {
      console.log('[SESSION] BUSCA DE SESSÃO EXISTENTE: Verificando sessões ativas...');
      
      // Utilizando nossa função utilitária para garantir um ponto único de checagem
      let existingSession = await getActiveSession(user_id);

      if (existingSession) {
        console.log('[SESSION] SESSÃO ATIVA ENCONTRADA:', { 
          session_id: existingSession.id, 
          status: existingSession.status, 
          created_at: existingSession.created_at 
        });
        
        setIsLoading(false);
        return {
          sessionId: existingSession.id,
          isNew: false,
          session: existingSession
        };
      }

      console.log('[SESSION] Nenhuma sessão ativa encontrada. Iniciando criação de nova sessão...');
      
      // Correção nos nomes das colunas de acordo com o schema atual
      const newSessionData = {
        user_id,
        business_type,
        business_description: business_description || '',
        assistant_goal: business_goal || '', // Antes estava como 'goal'
        status: 'active', // Antes estava como 'session_status'
        onboarding_progress: 0,
        extracted_data: {}
      };

      const { data: newSession, error: insertError } = await supabase
        .from('onboarding_sessions')
        .insert(newSessionData)
        .select()
        .single();

      if (insertError) {
        // Tratamento específico para Erro 23505 (Conflito de chave única)
        // Isso acontece se uma requisição criou a sessão entre nossa checagem (Select) e a inserção (Insert)
        if (insertError.code === '23505') {
          console.warn('[SESSION] CONFLITO DETECTADO (409/23505): Sessão já foi criada por outro processo. Tentando recuperar...');
          
          existingSession = await getActiveSession(user_id);
          
          if (existingSession) {
            console.log('[SESSION] SESSÃO RECUPERADA APÓS CONFLITO:', existingSession.id);
            setIsLoading(false);
            return {
              sessionId: existingSession.id,
              isNew: false,
              session: existingSession
            };
          }
        }
        
        console.error('[SESSION] ERRO AO INSERIR NOVA SESSÃO:', insertError);
        throw insertError;
      }

      console.log('[SESSION] CRIAÇÃO DE NOVA SESSÃO CONCLUÍDA:', { session_id: newSession.id });
      setIsLoading(false);
      return {
        sessionId: newSession.id,
        isNew: true,
        session: newSession
      };

    } catch (err) {
      console.error('[HOOK] Erro durante o fluxo de getOrCreateSession:', err.message, err.stack);
      setError(err.message || 'Falha ao buscar ou criar sessão de onboarding.');
      setIsLoading(false); // Garantimos a liberação do estado de loading mesmo com erro
      throw err;
    }
  }, []);

  return { getOrCreateSession, isLoading, error };
}