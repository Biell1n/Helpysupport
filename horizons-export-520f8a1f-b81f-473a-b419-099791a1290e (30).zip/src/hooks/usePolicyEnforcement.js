import { useCallback } from 'react';
import { validateAgainstPolicies, POLICY_CATEGORIES } from '../lib/policyValidator';

export function usePolicyEnforcement() {
  const validateChatResponse = useCallback((response, assistantId = 'unknown') => {
    const validation = validateAgainstPolicies(response);
    
    if (!validation.isValid) {
      // Log for moderation (in a real app this might go to a secure backend logging service)
      console.warn(`[MODERATION LOG] Policy Violation Detected:`, {
        timestamp: new Date().toISOString(),
        assistant_id: assistantId,
        violation_type: validation.violatedPolicy,
        blocked_content_snippet: response.substring(0, 100) + '...'
      });

      const policyName = POLICY_CATEGORIES[validation.violatedPolicy]?.name || 'nossas diretrizes';

      return {
        isViolation: true,
        blockedResponse: `⚠️ Desculpe, não posso ajudar com isso. Minhas diretrizes de segurança não permitem discussões que envolvam ${policyName}. Por favor, vamos focar em outro assunto relacionado aos nossos serviços.`
      };
    }

    return {
      isViolation: false,
      response: response
    };
  }, []);

  return { validateChatResponse };
}