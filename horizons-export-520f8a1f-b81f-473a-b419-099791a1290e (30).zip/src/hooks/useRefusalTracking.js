import { useCallback } from 'react';
import { useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';

export function useRefusalTracking() {
  // Call the hook unconditionally at the top level to comply with React Hooks rules
  const context = useAssistantMemoryContext();

  // Establish default fallbacks to ensure dependent hooks execute safely
  const refusedFields = context?.refusedFields || [];
  const addRefusedField = context?.addRefusedField || (() => {});
  const removeRefusedField = context?.removeRefusedField || (() => {});

  const isFieldRefused = useCallback((field) => {
    return refusedFields.includes(field);
  }, [refusedFields]);

  const markAsRefused = useCallback((field) => {
    addRefusedField(field);
  }, [addRefusedField]);

  const unmarkAsRefused = useCallback((field) => {
    removeRefusedField(field);
  }, [removeRefusedField]);

  const getRefusedFields = useCallback(() => {
    return refusedFields;
  }, [refusedFields]);

  const clearRefusals = useCallback(() => {
    refusedFields.forEach(f => removeRefusedField(f));
  }, [refusedFields, removeRefusedField]);

  // After all hooks are called, handle the case where context is unavailable
  if (!context) {
    return {
      isFieldRefused: () => false,
      markAsRefused: () => {},
      unmarkAsRefused: () => {},
      getRefusedFields: () => [],
      clearRefusals: () => {}
    };
  }

  // Return full functionality if context is successfully loaded
  return {
    isFieldRefused,
    markAsRefused,
    unmarkAsRefused,
    getRefusedFields,
    clearRefusals
  };
}