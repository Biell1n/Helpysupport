import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

export function useAssistantUpload() {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const [photoUrl, setPhotoUrl] = useState(null);
  const { toast } = useToast();

  const validateFile = useCallback((file) => {
    if (!file.type.startsWith('image/')) {
      return 'Por favor, selecione apenas arquivos de imagem.';
    }
    
    // Max size 5MB
    const maxSize = 5 * 1024 * 1024;
    if (file.size > maxSize) {
      return 'A imagem deve ter no máximo 5MB.';
    }
    
    return null;
  }, []);

  const uploadImage = useCallback(async (file) => {
    setError(null);
    const validationError = validateFile(file);
    
    if (validationError) {
      setError(validationError);
      toast({ title: 'Erro de Validação', description: validationError, variant: 'destructive' });
      return null;
    }

    try {
      setUploading(true);
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2, 15)}_${Date.now()}.${fileExt}`;
      const filePath = `public/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('assistant-photos')
        .upload(filePath, file);

      if (uploadError) {
        throw uploadError;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('assistant-photos')
        .getPublicUrl(filePath);

      setPhotoUrl(publicUrl);
      return publicUrl;
    } catch (err) {
      console.error('Upload error:', err);
      const msg = 'Falha ao fazer upload da imagem. Tente novamente.';
      setError(msg);
      toast({ title: 'Erro de Upload', description: msg, variant: 'destructive' });
      return null;
    } finally {
      setUploading(false);
    }
  }, [toast, validateFile]);

  return { uploadImage, uploading, error, photoUrl };
}