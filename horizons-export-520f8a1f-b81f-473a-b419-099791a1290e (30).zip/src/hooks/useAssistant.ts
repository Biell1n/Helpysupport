/**
 * React hook for managing assistant data
 * Updated to use user_id and auth.uid() (Fase 1 architecture)
 */

import { useState, useEffect, useCallback } from 'react';
import { 
  createAssistant as createAssistantService,
  updateAssistant as updateAssistantService,
  getAssistant as getAssistantService,
  deleteAssistant as deleteAssistantService,
  getAssistantProfile as getAssistantProfileService,
  updateAssistantProfile as updateAssistantProfileService,
} from '@/services/assistant/assistantService';
import { getCurrentUserId } from '@/lib/supabase/client';
import type { Assistant, AssistantProfile } from '@/types/assistant.types';
import type { CreateAssistantInput, UpdateAssistantInput, AssistantProfileInput } from '@/schemas/assistant.schema';

interface UseAssistantReturn {
  assistant: Assistant | null;
  profile: AssistantProfile | null;
  loading: boolean;
  error: string | null;
  createAssistant: (input: CreateAssistantInput) => Promise<Assistant | null>;
  updateAssistant: (input: UpdateAssistantInput) => Promise<Assistant | null>;
  deleteAssistant: () => Promise<boolean>;
  updateProfile: (input: AssistantProfileInput) => Promise<AssistantProfile | null>;
  refetch: () => Promise<void>;
}

export function useAssistant(assistantId?: string): UseAssistantReturn {
  const [assistant, setAssistant] = useState<Assistant | null>(null);
  const [profile, setProfile] = useState<AssistantProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchAssistant = useCallback(async () => {
    if (!assistantId) return;

    setLoading(true);
    setError(null);

    try {
      const { data: assistantData, error: assistantError } = await getAssistantService(assistantId);
      
      if (assistantError) {
        setError(assistantError);
        return;
      }

      setAssistant(assistantData);

      // Fetch profile
      const { data: profileData } = await getAssistantProfileService(assistantId);
      setProfile(profileData);
    } catch (err: any) {
      setError(err.message || 'Erro ao carregar assistente');
    } finally {
      setLoading(false);
    }
  }, [assistantId]);

  useEffect(() => {
    fetchAssistant();
  }, [fetchAssistant]);

  const createAssistant = async (input: CreateAssistantInput): Promise<Assistant | null> => {
    setLoading(true);
    setError(null);

    try {
      const userId = await getCurrentUserId();
      if (!userId) {
        setError('Usuário não autenticado');
        return null;
      }

      const { data, error: createError } = await createAssistantService(userId, input);
      
      if (createError) {
        setError(createError);
        return null;
      }

      setAssistant(data);
      return data;
    } catch (err: any) {
      setError(err.message || 'Erro ao criar assistente');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const updateAssistant = async (input: UpdateAssistantInput): Promise<Assistant | null> => {
    if (!assistantId) {
      setError('ID do assistente não fornecido');
      return null;
    }

    setLoading(true);
    setError(null);

    try {
      const { data, error: updateError } = await updateAssistantService(assistantId, input);
      
      if (updateError) {
        setError(updateError);
        return null;
      }

      setAssistant(data);
      return data;
    } catch (err: any) {
      setError(err.message || 'Erro ao atualizar assistente');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const deleteAssistant = async (): Promise<boolean> => {
    if (!assistantId) {
      setError('ID do assistente não fornecido');
      return false;
    }

    setLoading(true);
    setError(null);

    try {
      const { success, error: deleteError } = await deleteAssistantService(assistantId);
      
      if (deleteError) {
        setError(deleteError);
        return false;
      }

      setAssistant(null);
      setProfile(null);
      return success;
    } catch (err: any) {
      setError(err.message || 'Erro ao deletar assistente');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const updateProfile = async (input: AssistantProfileInput): Promise<AssistantProfile | null> => {
    if (!assistantId) {
      setError('ID do assistente não fornecido');
      return null;
    }

    setLoading(true);
    setError(null);

    try {
      const { data, error: profileError } = await updateAssistantProfileService(assistantId, input);
      
      if (profileError) {
        setError(profileError);
        return null;
      }

      setProfile(data);
      return data;
    } catch (err: any) {
      setError(err.message || 'Erro ao atualizar perfil');
      return null;
    } finally {
      setLoading(false);
    }
  };

  return {
    assistant,
    profile,
    loading,
    error,
    createAssistant,
    updateAssistant,
    deleteAssistant,
    updateProfile,
    refetch: fetchAssistant,
  };
}