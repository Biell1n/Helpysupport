import { supabase } from '@/lib/supabase';
import { extractOnboardingData } from '@/services/onboarding/extractionService';
import { calculateOnboardingProgress } from '@/services/onboarding/progressEngine';

export async function createOnboardingSession(userId) {
  if (!userId) throw new Error('User ID is required');

  const { data, error } = await supabase
    .from('onboarding_sessions')
    .insert({
      user_id: userId,
      messages: [],
      collected_data: {},
      status: 'in_progress'
    })
    .select('id')
    .single();

  if (error) throw error;
  return data.id;
}

function generateSystemPrompt(collectedData) {
  let prompt = `Você é o assistente virtual da empresa ${collectedData.business_name || 'Sem nome'}.\n\n`;
  prompt += `Tipo de Negócio: ${collectedData.business_type || 'Não especificado'}\n`;
  prompt += `Objetivo Principal: ${collectedData.goal || 'Não especificado'}\n\n`;
  
  if (collectedData.fields && Object.keys(collectedData.fields).length > 0) {
    prompt += `INFORMAÇÕES ADICIONAIS:\n${JSON.stringify(collectedData.fields, null, 2)}\n\n`;
  }
  
  prompt += `Atenda os clientes de forma profissional e orientada para o objetivo descrito acima.`;
  return prompt;
}

export async function createAssistant(collectedData, sessionId, userId) {
  if (!userId || !sessionId) throw new Error('User ID and Session ID are required');
  
  if (!collectedData.business_name || !collectedData.business_type) {
    throw new Error('Nome do negócio e tipo são obrigatórios.');
  }

  const systemPrompt = generateSystemPrompt(collectedData);

  // 1. Create Assistant
  const { data: assistant, error: assistantError } = await supabase
    .from('assistants')
    .insert({
      user_id: userId,
      name: collectedData.business_name,
      description: `Assistente para o negócio de ${collectedData.business_type}`,
      niche: collectedData.business_type,
      system_prompt: systemPrompt,
      status: 'active',
      is_public: false,
      onboarding_completed: true,
      onboarding_progress: 100
    })
    .select('id')
    .single();

  if (assistantError) throw assistantError;

  const assistantId = assistant.id;

  // 2. Create Settings
  await supabase.from('assistant_settings').insert({
    id: crypto.randomUUID ? crypto.randomUUID() : undefined,
    assistant_id: assistantId,
    model: 'gpt-4o',
    temperature: 0.7,
    max_tokens: 2000
  });

  // 3. Create Memory
  await supabase.from('assistant_memory').insert({
    assistant_id: assistantId,
    tipo_negocio: collectedData.business_type,
    descricao_negocio: `Objetivo: ${collectedData.goal}`,
    completion_percentage: 100,
    mandatory_fields_complete: true
  });

  // 4. Update Session
  await supabase
    .from('onboarding_sessions')
    .update({
      status: 'completed',
      created_assistant_id: assistantId,
      updated_at: new Date().toISOString()
    })
    .eq('id', sessionId);

  return assistantId;
}