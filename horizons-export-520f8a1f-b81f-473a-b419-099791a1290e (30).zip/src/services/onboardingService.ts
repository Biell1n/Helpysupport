import { supabase } from '@/lib/supabase/client';

export async function createAssistant(sessionId: string, userId: string) {
  try {
    // 1. Load Session
    const { data: session, error: sessionError } = await supabase
      .from('onboarding_sessions')
      .select('*')
      .eq('id', sessionId)
      .single();

    if (sessionError || !session) throw new Error("Sessão não encontrada");

    const collectedData = session.collected_data || {};
    const detectedFields = session.detected_fields || [];
    const detectedFlows = session.detected_flows || [];
    const detectedAutomations = session.detected_automations || [];

    if (!collectedData.business_type || !collectedData.goal) {
      throw new Error("Dados insuficientes para criar assistente.");
    }

    const businessName = collectedData.business_name || session.initial_description?.substring(0, 50) || 'Meu Assistente';
    
    // 2. Generate Prompt
    const systemPrompt = generateSystemPrompt(collectedData, detectedFields, detectedFlows, detectedAutomations);

    // 3. Create Assistant
    const { data: assistant, error: assistantError } = await supabase
      .from('assistants')
      .insert({
        user_id: userId,
        name: businessName,
        description: session.initial_goal || collectedData.goal,
        niche: collectedData.business_type || session.initial_business_type,
        system_prompt: systemPrompt,
        status: 'active',
        is_public: false,
        onboarding_completed: true,
        onboarding_progress: 100
      })
      .select('id')
      .single();

    if (assistantError) throw assistantError;

    // 4. Create Settings
    await supabase.from('assistant_settings').insert({
      id: crypto.randomUUID ? crypto.randomUUID() : undefined,
      assistant_id: assistant.id,
      model: 'claude-3-5-sonnet-20241022',
      temperature: 0.7,
      max_tokens: 2000
    });

    // 5. Create Memory
    await supabase.from('assistant_memory').insert({
      assistant_id: assistant.id,
      tipo_negocio: collectedData.business_type,
      descricao_negocio: collectedData.goal,
      produtos: detectedFields,
      regras_fala: detectedFlows,
      completion_percentage: 100,
      mandatory_fields_complete: true
    });

    // 6. Update Session
    await supabase.from('onboarding_sessions').update({
      created_assistant_id: assistant.id,
      status: 'completed',
      updated_at: new Date().toISOString()
    }).eq('id', sessionId);

    return assistant.id;
  } catch (error: any) {
    console.error("Error creating assistant:", error);
    throw error;
  }
}

export function generateSystemPrompt(collectedData: any, fields: any[], flows: any[], automations: any[]) {
  let prompt = `Você é um assistente virtual focado em ${collectedData.business_type || 'atendimento'}.\n`;
  prompt += `Seu objetivo principal é: ${collectedData.goal || 'ajudar os clientes'}.\n\n`;
  
  if (fields && fields.length > 0) {
    prompt += `INFORMAÇÕES RELEVANTES PARA COLETA:\n- ${fields.join('\n- ')}\n\n`;
  }
  
  if (flows && flows.length > 0) {
    prompt += `FLUXO DE CONVERSA ESPERADO:\n- ${flows.join('\n- ')}\n\n`;
  }

  if (automations && automations.length > 0) {
    prompt += `AUTOMAÇÕES E GATILHOS:\n- ${automations.join('\n- ')}\n\n`;
  }

  prompt += `Seja educado, direto e cumpra o objetivo delineado de forma profissional.`;
  return prompt;
}