/**
 * Chat service layer
 * Business logic for chat and conversation operations
 */

import { supabase } from '@/lib/supabase/client';
import type { 
  ConversationMessage, 
  Message,
  MessageRole 
} from '@/types/chat.types';

/**
 * Save a chat message
 */
export async function saveMessage(
  assistantId: string,
  customerId: string,
  role: MessageRole,
  message: string,
  metadata?: Record<string, any>
): Promise<{ data: ConversationMessage | null; error: string | null }> {
  try {
    const { data, error } = await supabase
      .from('conversation_messages')
      .insert({
        assistant_id: assistantId,
        customer_id: customerId,
        role,
        message,
        metadata: metadata || {},
      })
      .select()
      .single();

    if (error) {
      return { data: null, error: error.message };
    }

    return { data, error: null };
  } catch (error: any) {
    return { 
      data: null, 
      error: error.message || 'Erro ao salvar mensagem' 
    };
  }
}

/**
 * Get conversation history
 */
export async function getConversationHistory(
  assistantId: string,
  customerId: string,
  limit: number = 50
): Promise<{ data: Message[]; error: string | null }> {
  try {
    const { data, error } = await supabase
      .from('conversation_messages')
      .select('*')
      .eq('assistant_id', assistantId)
      .eq('customer_id', customerId)
      .order('created_at', { ascending: true })
      .limit(limit);

    if (error) {
      return { data: [], error: error.message };
    }

    // Transform to Message format
    const messages: Message[] = (data || []).map(msg => ({
      id: msg.id,
      role: msg.role,
      content: msg.message,
      timestamp: msg.created_at,
      metadata: msg.metadata as any,
    }));

    return { data: messages, error: null };
  } catch (error: any) {
    return { 
      data: [], 
      error: error.message || 'Erro ao buscar histórico de conversa' 
    };
  }
}

/**
 * Delete conversation
 */
export async function deleteConversation(
  assistantId: string,
  customerId: string
): Promise<{ success: boolean; error: string | null }> {
  try {
    const { error } = await supabase
      .from('conversation_messages')
      .delete()
      .eq('assistant_id', assistantId)
      .eq('customer_id', customerId);

    if (error) {
      return { success: false, error: error.message };
    }

    return { success: true, error: null };
  } catch (error: any) {
    return { 
      success: false, 
      error: error.message || 'Erro ao deletar conversa' 
    };
  }
}

/**
 * Get last N messages from conversation
 */
export async function getLastMessages(
  assistantId: string,
  customerId: string,
  count: number = 10
): Promise<{ data: Message[]; error: string | null }> {
  try {
    const { data, error } = await supabase
      .from('conversation_messages')
      .select('*')
      .eq('assistant_id', assistantId)
      .eq('customer_id', customerId)
      .order('created_at', { ascending: false })
      .limit(count);

    if (error) {
      return { data: [], error: error.message };
    }

    // Transform and reverse to get chronological order
    const messages: Message[] = (data || [])
      .reverse()
      .map(msg => ({
        id: msg.id,
        role: msg.role,
        content: msg.message,
        timestamp: msg.created_at,
        metadata: msg.metadata as any,
      }));

    return { data: messages, error: null };
  } catch (error: any) {
    return { 
      data: [], 
      error: error.message || 'Erro ao buscar últimas mensagens' 
    };
  }
}