/**
 * Assistant service layer
 * Business logic for assistant operations
 * Updated to use user_id and auth.uid() (Fase 1 architecture)
 */

import { supabase } from '@/lib/supabase/client';
import { 
  UpdateAssistantSchema, 
  AssistantProfileSchema,
  isValidAssistantStatus,
  type UpdateAssistantInput,
  type AssistantProfileInput
} from '@/schemas/assistant.schema';
import { DEFAULT_ASSISTANT_STATUS } from '@/constants/assistantStatus';
import { validateMinimalCompletion } from '@/lib/onboarding-utils';
import type { Assistant, AssistantProfile } from '@/types/assistant.types';

/**
 * Persist assistant from completed onboarding data
 * This is the ONLY way to create a new assistant - after onboarding is complete
 * @param userId - Authenticated user ID
 * @param onboardingData - Complete onboarding data from temporary state
 * @returns Promise with new assistant ID or error
 */
export async function persistAssistantFromOnboarding(
  userId: string,
  onboardingData: any
): Promise<{ assistantId: string | null; error: string | null }> {
  try {
    // Step 1: Validate minimal completion
    const validation = validateMinimalCompletion(onboardingData);
    
    if (!validation.isValid) {
      return {
        assistantId: null,
        error: `Onboarding incompleto. Campos faltando: ${validation.missingFields.join(', ')}`
      };
    }

    // Step 2: Extract and validate required fields
    const name = onboardingData.name?.trim();
    const description = onboardingData.description?.trim();
    const niche = onboardingData.niche?.trim() || 'general';
    const tone_of_voice = onboardingData.tone_of_voice?.trim() || 'friendly';

    if (!name || name.length < 3) {
      return { assistantId: null, error: 'Nome do assistente deve ter no mínimo 3 caracteres' };
    }

    if (!description || description.length < 10) {
      return { assistantId: null, error: 'Descrição deve ter no mínimo 10 caracteres' };
    }

    // Step 3: Prepare personality and rules as JSONB
    const personality = onboardingData.personality && typeof onboardingData.personality === 'object'
      ? onboardingData.personality
      : { tone: tone_of_voice, style: 'professional' };

    const rules = onboardingData.rules && typeof onboardingData.rules === 'object'
      ? onboardingData.rules
      : {};

    // Step 4: Insert assistant with validated data
    const { data: newAssistant, error: insertError } = await supabase
      .from('assistants')
      .insert({
        user_id: userId,
        name: name,
        description: description,
        niche: niche,
        tone_of_voice: tone_of_voice,
        personality: personality,
        rules: rules,
        status: DEFAULT_ASSISTANT_STATUS,
        onboarding_completed: true,
        onboarding_progress: 100,
      })
      .select()
      .single();

    if (insertError) {
      console.error('Error inserting assistant:', insertError);
      return { assistantId: null, error: insertError.message };
    }

    if (!newAssistant) {
      return { assistantId: null, error: 'Failed to create assistant' };
    }

    // Step 5: Create assistant_settings record
    const { error: settingsError } = await supabase
      .from('assistant_settings')
      .insert({
        assistant_id: newAssistant.id,
        temperature: 0.7,
        max_tokens: 2000,
        model: 'gpt-4o-mini',
        enable_web_search: false,
        enable_function_calling: true,
        response_format: 'text',
      });

    if (settingsError) {
      console.error('Error creating assistant settings:', settingsError);
      // Continue anyway - settings can be created later
    }

    // Step 6: Create assistant_memory record (if table exists)
    const { error: memoryError } = await supabase
      .from('assistant_memory')
      .insert({
        assistant_id: newAssistant.id,
        tipo_negocio: niche.toUpperCase(),
        descricao_negocio: description,
        produtos: onboardingData.products || [],
        regras_fala: onboardingData.rules || [],
        contato: onboardingData.contact || {},
        personalidade: personality,
        completion_percentage: 100,
        mandatory_fields_complete: true,
      });

    if (memoryError) {
      console.error('Error creating assistant memory:', memoryError);
      // Continue anyway - memory can be created later
    }

    // Step 7: Create assistant_profiles record
    const { error: profileError } = await supabase
      .from('assistant_profiles')
      .insert({
        assistant_id: newAssistant.id,
        company_description: description,
        tone_of_voice: tone_of_voice,
        personality: JSON.stringify(personality),
        behavior_style: personality.style || 'professional',
        onboarding_state: {
          completed: true,
          completedAt: new Date().toISOString(),
          finalData: onboardingData,
        },
      });

    if (profileError) {
      console.error('Error creating assistant profile:', profileError);
      // Continue anyway - profile can be created later
    }

    return { assistantId: newAssistant.id, error: null };
  } catch (error: any) {
    console.error('Unexpected error persisting assistant:', error);
    return { 
      assistantId: null, 
      error: error.message || 'Erro inesperado ao criar assistente' 
    };
  }
}

/**
 * Update an existing assistant
 */
export async function updateAssistant(
  assistantId: string,
  input: UpdateAssistantInput
): Promise<{ data: Assistant | null; error: string | null }> {
  try {
    // Validate input
    const validated = UpdateAssistantSchema.parse(input);

    // Validate status if provided
    if (validated.status && !isValidAssistantStatus(validated.status)) {
      return { 
        data: null, 
        error: `Status inválido: ${validated.status}. Valores permitidos: draft, active, inactive, archived` 
      };
    }

    const { data, error } = await supabase
      .from('assistants')
      .update(validated)
      .eq('id', assistantId)
      .select()
      .single();

    if (error) {
      return { data: null, error: error.message };
    }

    return { data, error: null };
  } catch (error: any) {
    return { 
      data: null, 
      error: error.message || 'Erro ao atualizar assistente' 
    };
  }
}

/**
 * Get assistant by ID
 */
export async function getAssistant(
  assistantId: string
): Promise<{ data: Assistant | null; error: string | null }> {
  try {
    const { data, error } = await supabase
      .from('assistants')
      .select('*')
      .eq('id', assistantId)
      .single();

    if (error) {
      return { data: null, error: error.message };
    }

    return { data, error: null };
  } catch (error: any) {
    return { 
      data: null, 
      error: error.message || 'Erro ao buscar assistente' 
    };
  }
}

/**
 * Delete assistant
 */
export async function deleteAssistant(
  assistantId: string
): Promise<{ success: boolean; error: string | null }> {
  try {
    const { error } = await supabase
      .from('assistants')
      .delete()
      .eq('id', assistantId);

    if (error) {
      return { success: false, error: error.message };
    }

    return { success: true, error: null };
  } catch (error: any) {
    return { 
      success: false, 
      error: error.message || 'Erro ao deletar assistente' 
    };
  }
}

/**
 * Get assistant profile
 */
export async function getAssistantProfile(
  assistantId: string
): Promise<{ data: AssistantProfile | null; error: string | null }> {
  try {
    const { data, error } = await supabase
      .from('assistant_profiles')
      .select('*')
      .eq('assistant_id', assistantId)
      .single();

    if (error && error.code !== 'PGRST116') {
      return { data: null, error: error.message };
    }

    return { data: data || null, error: null };
  } catch (error: any) {
    return { 
      data: null, 
      error: error.message || 'Erro ao buscar perfil do assistente' 
    };
  }
}

/**
 * Update assistant profile
 */
export async function updateAssistantProfile(
  assistantId: string,
  input: AssistantProfileInput
): Promise<{ data: AssistantProfile | null; error: string | null }> {
  try {
    // Validate input
    const validated = AssistantProfileSchema.parse(input);

    // Check if profile exists
    const { data: existing } = await supabase
      .from('assistant_profiles')
      .select('id')
      .eq('assistant_id', assistantId)
      .single();

    let data, error;

    if (existing) {
      // Update existing profile
      const result = await supabase
        .from('assistant_profiles')
        .update(validated)
        .eq('assistant_id', assistantId)
        .select()
        .single();
      
      data = result.data;
      error = result.error;
    } else {
      // Create new profile
      const result = await supabase
        .from('assistant_profiles')
        .insert({
          assistant_id: assistantId,
          ...validated,
        })
        .select()
        .single();
      
      data = result.data;
      error = result.error;
    }

    if (error) {
      return { data: null, error: error.message };
    }

    return { data, error: null };
  } catch (error: any) {
    return { 
      data: null, 
      error: error.message || 'Erro ao atualizar perfil do assistente' 
    };
  }
}

/**
 * Get all assistants for current user (uses auth.uid() via RLS)
 */
export async function getCurrentUserAssistants(): Promise<{ data: Assistant[]; error: string | null }> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return { data: [], error: 'Usuário não autenticado' };
    }

    const { data, error } = await supabase
      .from('assistants')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      return { data: [], error: error.message };
    }

    return { data: data || [], error: null };
  } catch (error: any) {
    return { 
      data: [], 
      error: error.message || 'Erro ao buscar assistentes' 
    };
  }
}