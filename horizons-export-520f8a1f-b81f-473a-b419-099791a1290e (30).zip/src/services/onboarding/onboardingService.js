import { supabase } from '@/lib/supabase/client';
import { getActiveSession } from '@/lib/getActiveSession';

export const onboardingService = {
  createSession: async (userId, businessType, description, goal) => {
    console.log('🔵 [onboardingService:createSession] Starting creation', { userId, businessType, goal });
    
    // FIX BUG A: Avoid duplication via service methods
    let existingSession = await getActiveSession(userId);
    if (existingSession) {
       console.log('✅ [onboardingService:createSession] Found existing active session:', existingSession.id);
       return existingSession;
    }

    const initialMessage = {
      role: 'assistant',
      content: `Olá! Eu sou o especialista em IA. Vi que você quer criar um assistente para o seu negócio de ${businessType}. Pode me contar um pouco mais sobre como funciona o seu dia a dia?`,
      timestamp: new Date().toISOString()
    };

    const newSessionData = {
      user_id: userId,
      business_type: businessType,
      business_name: description?.slice(0, 50) || 'Novo Negócio',
      goal: goal,
      status: 'in_progress',
      current_step: 1,
      messages: [initialMessage],
      collected_data: {
        tipo_negocio: businessType,
        objetivo_principal: goal
      }
    };

    console.log('📋 [onboardingService:createSession] Inserting data:', newSessionData);

    const { data, error } = await supabase
      .from('onboarding_sessions')
      .insert([newSessionData])
      .select()
      .single();

    if (error) {
      if (error.code === '23505') {
         existingSession = await getActiveSession(userId);
         if (existingSession) return existingSession;
      }
      console.error('❌ [onboardingService:createSession] Insert error:', error);
      throw error;
    }
    
    console.log('✅ [onboardingService:createSession] Created session successfully:', data.id);
    return data;
  },

  getSession: async (sessionId, userId) => {
    console.log(`🔵 [onboardingService:getSession] Fetching session: ${sessionId} for user: ${userId}`);
    const { data, error } = await supabase
      .from('onboarding_sessions')
      .select('*')
      .eq('id', sessionId)
      .eq('user_id', userId)
      .single();

    if (error) {
      console.error('❌ [onboardingService:getSession] Fetch error:', error);
      throw error;
    }
    console.log('✅ [onboardingService:getSession] Fetched session successfully');
    return data;
  },

  sendMessage: async (message, sessionId, userId) => {
    console.log(`🔵 [onboardingService:sendMessage] Preparing to send message. Session ID: ${sessionId}, User ID: ${userId}`);
    
    if (!message || !sessionId || !userId) {
      console.error('❌ [onboardingService:sendMessage] Missing required parameters', { message: !!message, sessionId, userId });
      throw new Error('message, session_id, and user_id are required');
    }

    const { data: { session }, error: authError } = await supabase.auth.getSession();
    if (authError || !session) {
      console.error('❌ [onboardingService:sendMessage] Auth error:', authError);
      throw new Error('User not authenticated');
    }

    const payload = {
      message,
      session_id: sessionId,
      user_id: userId
    };

    console.log(`📥 [onboardingService:sendMessage] Payload ready for Edge Function:`, payload);
    console.log(`🌐 [onboardingService:sendMessage] Calling Edge Function 'onboarding-chat' via supabase.functions.invoke`);
    
    try {
      const { data: responseData, error: invokeError } = await supabase.functions.invoke('onboarding-chat', {
        body: payload
      });

      if (invokeError) {
        console.error(`❌ [onboardingService:sendMessage] Edge Function network/invocation error:`, invokeError);
        throw invokeError;
      }

      if (responseData?.error) {
        console.error(`❌ [onboardingService:sendMessage] Edge Function business error response:`, responseData.error, responseData.details);
        throw new Error(responseData.error || 'Unknown API error');
      }

      console.log('✅ [onboardingService:sendMessage] Edge Function processed successfully. Received data keys:', Object.keys(responseData || {}));
      return responseData;
    } catch (err) {
      console.error('❌ [onboardingService:sendMessage] Exception occurred during invoke:', err.message, err.stack);
      throw err;
    }
  },

  updateSession: async (sessionId, updates) => {
    console.log(`💾 [onboardingService:updateSession] Updating session: ${sessionId}`, updates);
    const { data, error } = await supabase
      .from('onboarding_sessions')
      .update(updates)
      .eq('id', sessionId)
      .select()
      .single();

    if (error) {
      console.error('❌ [onboardingService:updateSession] Update error:', error);
      throw error;
    }
    console.log('✅ [onboardingService:updateSession] Session updated successfully');
    return data;
  },

  generateSystemPrompt: (session) => {
    console.log('🤖 [onboardingService:generateSystemPrompt] Generating prompt from session data');
    const collectedData = session.collected_data || {};
    const businessName = collectedData.nome_negocio || session.business_name || 'Novo Assistente';
    const businessType = session.business_type || 'Geral';
    
    return `Você é um assistente virtual para ${businessName}, um negócio do tipo ${businessType}.
Objetivo: ${session.goal || 'Atender clientes e fornecer informações'}.
Regras: ${(session.assistant_rules || []).join(', ')}.
Tópicos Restritos: ${(session.restricted_topics || []).join(', ')}.
Dados conhecidos: ${JSON.stringify(collectedData)}.
Aja de forma profissional.`;
  },

  createAssistant: async (sessionId, userId) => {
    console.log(`🚀 [onboardingService:createAssistant] Finalizing creation. Session: ${sessionId}`);
    
    if (!sessionId || !userId) {
      throw new Error('Session ID and User ID are required');
    }

    const session = await onboardingService.getSession(sessionId, userId);
    if (!session) throw new Error('Onboarding session not found');

    const collectedData = session.collected_data || {};
    const businessName = collectedData.nome_negocio || session.business_name || 'Novo Assistente';
    const businessType = session.business_type || 'Geral';
    const systemPrompt = onboardingService.generateSystemPrompt(session);

    console.log('📋 [onboardingService:createAssistant] Inserting assistant record');
    const { data: assistant, error: assistantError } = await supabase
      .from('assistants')
      .insert({
        user_id: userId,
        name: businessName,
        description: session.goal || 'Assistente gerado via Onboarding',
        niche: businessType,
        system_prompt: systemPrompt,
        status: 'active',
        is_public: false,
        onboarding_completed: true,
        onboarding_progress: 100,
        rules: session.assistant_rules || [],
      })
      .select('id')
      .single();

    if (assistantError) {
      console.error('❌ [onboardingService:createAssistant] Assistant creation failed:', assistantError);
      throw new Error(`Failed to create assistant: ${assistantError.message}`);
    }

    const assistantId = assistant.id;
    console.log(`✅ [onboardingService:createAssistant] Assistant created: ${assistantId}. Proceeding to settings/memory.`);

    await supabase.from('assistant_settings').insert({
      assistant_id: assistantId,
      model: 'gpt-4o-mini',
      temperature: 0.7,
      max_tokens: 1000,
      enable_web_search: false,
      enable_function_calling: true,
    });

    await supabase.from('assistant_memory').insert({
      assistant_id: assistantId,
      tipo_negocio: businessType,
      descricao_negocio: session.goal || '',
      history_log: session.messages || [],
      business_type_detected: businessType,
    });

    console.log('💾 [onboardingService:createAssistant] Updating session status to completed');
    await onboardingService.updateSession(sessionId, { 
      created_assistant_id: assistantId,
      status: 'completed'
    });

    console.log('🎉 [onboardingService:createAssistant] All done!');
    return assistantId;
  }
};