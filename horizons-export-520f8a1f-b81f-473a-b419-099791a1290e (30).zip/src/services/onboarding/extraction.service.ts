import OpenAI from 'openai';
import { ExtractedBusinessDataSchema, type ExtractedBusinessData } from '@/schemas/onboarding-extraction.schema';

/**
 * ExtractionService - Extracts structured business information from user messages (no assistant_id required)
 */
export class ExtractionService {
  private openai: OpenAI;

  constructor(apiKey: string) {
    this.openai = new OpenAI({ apiKey, dangerouslyAllowBrowser: true });
  }

  /**
   * Extracts structured business data from user message
   * @param message User's message
   * @param context Previous conversation context
   * @returns Extracted and validated business data
   */
  async extractBusinessData(
    message: string,
    context: any = {}
  ): Promise<ExtractedBusinessData> {
    const systemPrompt = this.buildExtractionPrompt(context);

    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: message },
        ],
        temperature: 0.3,
        response_format: { type: 'json_object' },
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {
        throw new Error('No response from OpenAI');
      }

      const parsed = JSON.parse(content);
      
      // Validate with Zod schema
      const validated = ExtractedBusinessDataSchema.parse(parsed);
      
      return validated;
    } catch (error) {
      console.error('Error extracting business data:', error);
      
      // Return empty extraction on error
      return ExtractedBusinessDataSchema.parse({
        missingInformation: ['Não foi possível extrair informações dessa mensagem'],
        confidenceScore: 0,
      });
    }
  }

  /**
   * Extracts data from AI response and merges with current data
   * @param aiResponse AI assistant response
   * @param currentExtractedData Current extracted data
   * @returns Updated extracted data
   */
  async extractDataFromResponse(
    aiResponse: string,
    currentExtractedData: any = {}
  ): Promise<any> {
    const extractionPrompt = this.buildMergePrompt(currentExtractedData, aiResponse);

    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: extractionPrompt },
          { role: 'user', content: 'Extraia e faça merge dos dados.' },
        ],
        temperature: 0.3,
        response_format: { type: 'json_object' },
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {
        return currentExtractedData;
      }

      const extracted = JSON.parse(content);

      // Intelligent merge: preserve existing, add new, update contradicted
      return {
        ...currentExtractedData,
        ...extracted,
        products: extracted.products || currentExtractedData.products || [],
        services: extracted.services || currentExtractedData.services || [],
        personality: { ...currentExtractedData.personality, ...extracted.personality },
        rules: { ...currentExtractedData.rules, ...extracted.rules },
        contact: { ...currentExtractedData.contact, ...extracted.contact },
      };
    } catch (error) {
      console.error('Extraction from response error:', error);
      return currentExtractedData;
    }
  }

  /**
   * Builds the extraction prompt based on context
   */
  private buildExtractionPrompt(context: any): string {
    return `Você é um extrator de informações de negócios especializado.

Sua tarefa é extrair informações estruturadas das mensagens do usuário sobre seu negócio.

INFORMAÇÕES A EXTRAIR:
- businessName: Nome do negócio
- niche: Nicho/segmento (ex: barbearia, loja, clínica, restaurante)
- description: Descrição do negócio
- services: Array de serviços (name, description?, price?, duration?)
- products: Array de produtos (name, description?, price?, stock?)
- professionals: Número de profissionais
- toneOfVoice: Tom de voz desejado
- personalityTraits: Array de traços de personalidade
- missingInformation: Array de informações ainda faltando
- confidenceScore: Confiança na extração (0-1)

CONTEXTO EXISTENTE:
${JSON.stringify(context.extractedData || {}, null, 2)}

INSTRUÇÕES:
1. Extraia APENAS informações explicitamente mencionadas
2. NÃO invente ou assuma informações não ditas
3. Mantenha dados já extraídos se não forem contraditos
4. Identifique informações faltantes importantes
5. Calcule confidence score baseado na clareza das informações

FORMATO DE RESPOSTA (JSON):
{
  "businessName": "string ou null",
  "niche": "string ou null",
  "description": "string ou null",
  "services": [{"name": "string", "price": number?, "duration": number?}],
  "products": [{"name": "string", "price": number?, "stock": number?}],
  "professionals": number ou null,
  "toneOfVoice": "string ou null",
  "personalityTraits": ["trait1", "trait2"],
  "missingInformation": ["info1", "info2"],
  "confidenceScore": 0.0 a 1.0
}`;
  }

  /**
   * Builds merge prompt for extracting data from AI response
   */
  private buildMergePrompt(currentData: any, aiResponse: string): string {
    return `Extraia informações estruturadas da seguinte conversa de onboarding.

DADOS ATUAIS:
${JSON.stringify(currentData, null, 2)}

NOVA MENSAGEM DO ASSISTENTE:
${aiResponse}

INSTRUÇÕES:
1. Extraia APENAS novas informações mencionadas
2. NÃO sobrescreva dados existentes a menos que explicitamente contraditos
3. Mantenha todos os campos existentes
4. Adicione novos campos quando identificar informações relevantes

CAMPOS POSSÍVEIS:
- name: Nome do assistente/negócio
- description: Descrição do negócio
- niche: Nicho/segmento
- tone_of_voice: Tom de voz
- personality: { traits: [], style: "" }
- products: [{ name, price?, description? }]
- services: [{ name, price?, duration?, description? }]
- contact: { phone?, email?, whatsapp?, website? }
- rules: { greeting?, farewell?, restrictions? }

Retorne JSON com dados atualizados (merge inteligente).`;
  }
}