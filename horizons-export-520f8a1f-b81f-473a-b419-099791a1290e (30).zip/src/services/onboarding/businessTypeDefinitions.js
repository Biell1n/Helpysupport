import { supabase } from '@/lib/customSupabaseClient';

export const businessTypes = [
  {
    business_type: "clinic",
    display_name: "Clínica",
    critical_fields: ["clinic_name", "specialties", "target_audience", "operating_hours", "contact_channels"],
    important_fields: ["insurance_accepted", "average_consultation_time", "cancellation_policy"],
    optional_fields: ["social_media", "clinic_history", "mission_values"],
    field_descriptions: {
      clinic_name: "O nome oficial da clínica.",
      specialties: "As especialidades médicas ou de saúde oferecidas.",
      target_audience: "O perfil dos pacientes atendidos.",
      operating_hours: "Dias e horários de funcionamento.",
      contact_channels: "Como os pacientes podem agendar ou tirar dúvidas."
    },
    aprofundamento_questions: {
      specialties: ["Quais são os procedimentos mais comuns?", "Vocês têm especialistas específicos para crianças ou idosos?"]
    }
  },
  {
    business_type: "store",
    display_name: "Loja",
    critical_fields: ["store_name", "products_sold", "target_audience", "contact_channels", "delivery_options"],
    important_fields: ["price_range", "most_sold_products", "payment_methods"],
    optional_fields: ["store_history", "brand_values", "social_media"],
    field_descriptions: {
      store_name: "O nome da loja.",
      products_sold: "Os principais produtos vendidos.",
      target_audience: "O perfil dos clientes ideais.",
      contact_channels: "Como os clientes entram em contato.",
      delivery_options: "Métodos de envio e entrega."
    },
    aprofundamento_questions: {
      products_sold: ["Quais são os produtos mais populares?", "Vocês vendem produtos de marca própria ou multimarcas?"]
    }
  },
  {
    business_type: "consultancy",
    display_name: "Consultoria",
    critical_fields: ["consultancy_name", "services_offered", "target_audience", "contact_channels"],
    important_fields: ["consultation_format", "expertise_areas", "pricing_model"],
    optional_fields: ["case_studies", "team_info", "certifications"],
    field_descriptions: {
      consultancy_name: "O nome da consultoria.",
      services_offered: "Serviços prestados aos clientes.",
      target_audience: "Empresas ou indivíduos que vocês ajudam.",
      contact_channels: "Canais de comunicação."
    },
    aprofundamento_questions: {
      services_offered: ["Como é o processo de consultoria na prática?", "Vocês oferecem acompanhamento a longo prazo?"]
    }
  }
];

export async function seedBusinessTypeDefinitions() {
  for (const def of businessTypes) {
    const { error } = await supabase
      .from('business_type_definitions')
      .upsert({
        business_type: def.business_type,
        display_name: def.display_name,
        critical_fields: def.critical_fields,
        important_fields: def.important_fields,
        optional_fields: def.optional_fields,
        field_descriptions: def.field_descriptions,
        aprofundamento_questions: def.aprofundamento_questions
      }, { onConflict: 'business_type' });

    if (error) console.error(`Error seeding ${def.business_type}:`, error);
  }
  console.log("Business type definitions seeded.");
}