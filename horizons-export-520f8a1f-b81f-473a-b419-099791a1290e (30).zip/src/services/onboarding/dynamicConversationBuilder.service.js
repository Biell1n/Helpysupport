// Client-side wrappers for the Edge Function Dynamic Conversation Builder
export class DynamicConversationBuilderService {
  buildSystemPrompt(sessionData) {
    return `System prompt builder wrapper`;
  }
  async buildNextQuestion(sessionData) {
    return `What's next?`;
  }
  buildAprofundamentoPrompt(field, currentValue, missingDetails, businessType) {
    return `Can you tell me more about ${field}?`;
  }
  buildUpdateConfirmation(field, oldValue, newValue) {
    return `Updated ${field} from ${oldValue} to ${newValue}.`;
  }
}