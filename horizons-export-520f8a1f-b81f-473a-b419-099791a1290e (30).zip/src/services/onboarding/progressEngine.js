function determineCurrentStep(collectedData) {
  if (!collectedData.business_name) return 1;
  if (!collectedData.business_type) return 2;
  if (!collectedData.goal) return 3;
  if (!collectedData.template) return 4;
  return 5;
}

export function calculateOnboardingProgress(collectedData) {
  let filledFields = 0;
  let totalRequiredFields = 3;

  if (collectedData.business_name?.trim()) filledFields++;
  if (collectedData.business_type?.trim()) filledFields++;
  if (collectedData.goal?.trim()) filledFields++;

  if (collectedData.template) {
    totalRequiredFields += 1;
    filledFields++;
  }

  const hasRequiredFields = !!(
    collectedData.business_name?.trim() &&
    collectedData.business_type?.trim() &&
    collectedData.goal?.trim()
  );

  const percentage = Math.min(100, Math.round((filledFields / totalRequiredFields) * 100));
  const current_step = determineCurrentStep(collectedData);
  const completed = percentage >= 100 && hasRequiredFields;

  return {
    percentage,
    step: current_step,
    completed
  };
}