import type { ExtractedBusinessData } from '@/schemas/onboarding-extraction.schema';

/**
 * SemanticAnalysisService - Analyzes message quality and business context
 */
export class SemanticAnalysisService {
  /**
   * Analyzes the quality of extracted business description
   * @param description Business description
   * @returns Quality score (0-1) and feedback
   */
  analyzeQuality(description: string): { score: number; feedback: string[] } {
    if (!description || description.length === 0) {
      return { score: 0, feedback: ['Descrição está vazia'] };
    }

    const feedback: string[] = [];
    let score = 0;

    // Length check
    if (description.length < 20) {
      feedback.push('Descrição muito curta - adicione mais detalhes');
      score += 0.1;
    } else if (description.length < 50) {
      feedback.push('Descrição básica - considere adicionar mais informações');
      score += 0.3;
    } else if (description.length < 100) {
      feedback.push('Boa descrição - poderia ter mais detalhes');
      score += 0.6;
    } else {
      feedback.push('Descrição rica e detalhada');
      score += 0.9;
    }

    // Word count
    const wordCount = description.split(/\s+/).length;
    if (wordCount < 5) {
      feedback.push('Use mais palavras para descrever seu negócio');
    } else if (wordCount > 20) {
      score += 0.1;
    }

    return { score: Math.min(score, 1), feedback };
  }

  /**
   * Detects business niche from description and context
   * @param description Business description
   * @param services Services offered
   * @param products Products offered
   * @returns Detected niche and confidence
   */
  detectNiche(
    description: string,
    services: any[] = [],
    products: any[] = []
  ): { niche: string | null; confidence: number } {
    const text = `${description} ${services.map(s => s.name).join(' ')} ${products.map(p => p.name).join(' ')}`.toLowerCase();

    const nichePatterns = {
      barbearia: ['barba', 'cabelo', 'corte', 'barbeiro', 'navalha', 'barbershop'],
      loja: ['loja', 'produto', 'venda', 'estoque', 'mercadoria'],
      clinica: ['clínica', 'médico', 'consulta', 'saúde', 'paciente', 'tratamento'],
      restaurante: ['restaurante', 'comida', 'prato', 'cardápio', 'delivery', 'refeição'],
      academia: ['academia', 'treino', 'musculação', 'fitness', 'exercício'],
      salao: ['salão', 'beleza', 'cabelo', 'unha', 'manicure', 'estética'],
    };

    let bestMatch = { niche: null as string | null, confidence: 0 };

    for (const [niche, keywords] of Object.entries(nichePatterns)) {
      let matches = 0;
      keywords.forEach(keyword => {
        if (text.includes(keyword)) {
          matches++;
        }
      });

      const confidence = matches / keywords.length;
      if (confidence > bestMatch.confidence) {
        bestMatch = { niche, confidence };
      }
    }

    return bestMatch;
  }

  /**
   * Calculates overall confidence score for extracted data
   * @param extractedData Extracted business data
   * @returns Confidence score (0-1)
   */
  calculateConfidenceScore(extractedData: ExtractedBusinessData): number {
    let totalConfidence = 0;
    let fieldCount = 0;

    // Business name confidence
    if (extractedData.businessName) {
      totalConfidence += extractedData.businessName.length > 3 ? 1 : 0.5;
      fieldCount++;
    }

    // Niche confidence
    if (extractedData.niche) {
      totalConfidence += 1;
      fieldCount++;
    }

    // Description quality
    if (extractedData.description) {
      const quality = this.analyzeQuality(extractedData.description);
      totalConfidence += quality.score;
      fieldCount++;
    }

    // Services/Products
    if (extractedData.services && extractedData.services.length > 0) {
      totalConfidence += 1;
      fieldCount++;
    }
    if (extractedData.products && extractedData.products.length > 0) {
      totalConfidence += 1;
      fieldCount++;
    }

    // Tone and personality
    if (extractedData.toneOfVoice) {
      totalConfidence += 1;
      fieldCount++;
    }
    if (extractedData.personalityTraits && extractedData.personalityTraits.length > 0) {
      totalConfidence += 1;
      fieldCount++;
    }

    return fieldCount > 0 ? totalConfidence / fieldCount : 0;
  }

  /**
   * Identifies missing critical information gaps
   * @param extractedData Current extracted data
   * @param niche Detected niche
   * @returns Array of missing information
   */
  identifyGaps(extractedData: ExtractedBusinessData, niche: string | null): string[] {
    const gaps: string[] = [];

    if (!extractedData.businessName) {
      gaps.push('Nome do negócio');
    }

    if (!extractedData.niche && !niche) {
      gaps.push('Tipo/nicho do negócio');
    }

    if (!extractedData.description || extractedData.description.length < 50) {
      gaps.push('Descrição detalhada do negócio');
    }

    if (!extractedData.toneOfVoice && (!extractedData.personalityTraits || extractedData.personalityTraits.length === 0)) {
      gaps.push('Tom de voz ou personalidade');
    }

    if ((!extractedData.services || extractedData.services.length === 0) && 
        (!extractedData.products || extractedData.products.length === 0)) {
      gaps.push('Serviços ou produtos oferecidos');
    }

    return gaps;
  }
}