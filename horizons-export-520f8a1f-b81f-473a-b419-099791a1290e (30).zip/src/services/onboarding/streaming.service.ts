/**
 * StreamingService - Manages real-time streaming responses from OpenAI (session-based)
 */
export class StreamingService {
  /**
   * Processes streaming response and yields formatted chunks
   * @param stream AsyncIterable stream from OpenAI
   * @yields Formatted text chunks
   */
  async* streamResponse(stream: AsyncIterable<any>): AsyncIterable<string> {
    try {
      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content;
        
        if (content) {
          yield content;
        }
      }
    } catch (error) {
      console.error('Streaming error:', error);
      throw new Error('Erro no streaming da resposta');
    }
  }

  /**
   * Formats streamed text for UI display
   * @param text Raw streamed text
   * @returns Formatted text
   */
  formatStreamedText(text: string): string {
    return text.replace(/\n{3,}/g, '\n\n').trim();
  }

  /**
   * Handles stream completion
   * @param accumulatedText Complete accumulated text
   * @returns Final formatted text
   */
  handleStreamComplete(accumulatedText: string): string {
    return this.formatStreamedText(accumulatedText);
  }

  /**
   * Stream onboarding chat (session-based, no assistant_id required)
   * @param payload Onboarding chat payload with session_id
   * @returns Streaming response with extracted data and progress
   */
  async streamOnboardingChat(payload: {
    message: string;
    session_id: string;
    onboarding_state?: any;
    extracted_data?: any;
    progress?: number;
    onboarding_completed?: boolean;
  }) {
    const { 
      message, 
      session_id, 
      onboarding_state = {}, 
      extracted_data = {}, 
      progress = 0,
      onboarding_completed = false 
    } = payload;

    if (!message || !session_id) {
      throw new Error('Missing required fields: message and session_id');
    }

    // This method is primarily for documentation
    // The actual streaming is handled by the edge function
    // Frontend should call supabase.functions.invoke() directly
    return {
      session_id,
      onboarding_state,
      extracted_data,
      progress,
      onboarding_completed,
    };
  }
}