import type { OnboardingContext } from '@/schemas/onboarding-extraction.schema';

/**
 * PromptBuilderService - Builds dynamic, context-aware prompts for OpenAI
 */
export class PromptBuilderService {
  /**
   * Builds comprehensive system prompt based on onboarding context
   * @param context Current onboarding context
   * @returns Dynamic system prompt
   */
  buildSystemPrompt(context: Partial<OnboardingContext>): string {
    const { extractedData, progress = 0, completedFields = [] } = context;

    const basePrompt = this.getBasePrompt();
    const contextSection = this.buildContextSection(extractedData);
    const progressSection = this.buildProgressSection(progress, completedFields);
    const guidanceSection = this.buildGuidanceSection(extractedData);

    return `${basePrompt}

${contextSection}

${progressSection}

${guidanceSection}

Seja conversacional, amigável e guie o usuário suavemente. Faça perguntas específicas baseadas no que ainda falta.`;
  }

  /**
   * Base prompt defining the AI's role
   */
  private getBasePrompt(): string {
    return `Você é um assistente especializado em onboarding de negócios. Seu objetivo é coletar informações sobre o negócio do usuário de forma natural e conversacional.

REGRAS FUNDAMENTAIS:
1. Seja amigável, empático e profissional
2. Faça UMA pergunta por vez
3. Valide e confirme informações importantes
4. Adapte suas perguntas ao nicho detectado
5. Não invente informações - apenas colete o que o usuário diz
6. Dê feedback positivo quando receber boas informações
7. Seja paciente se o usuário não souber algo

INFORMAÇÕES A COLETAR:
✓ Nome do negócio
✓ Tipo/nicho do negócio
✓ Descrição detalhada (o que faz, diferenciais)
✓ Serviços ou produtos oferecidos
✓ Tom de voz desejado (formal, descontraído, etc.)
✓ Personalidade do assistente
✓ Informações específicas do nicho`;
  }

  /**
   * Builds context section with current data
   */
  private buildContextSection(extractedData: any): string {
    if (!extractedData) {
      return 'CONTEXTO: Iniciando onboarding - nenhuma informação coletada ainda.';
    }

    const collected: string[] = [];

    if (extractedData.businessName) {
      collected.push(`Nome: ${extractedData.businessName}`);
    }
    if (extractedData.niche) {
      collected.push(`Nicho: ${extractedData.niche}`);
    }
    if (extractedData.description) {
      collected.push(`Descrição: ${extractedData.description.substring(0, 100)}...`);
    }
    if (extractedData.services && extractedData.services.length > 0) {
      collected.push(`Serviços: ${extractedData.services.map((s: any) => s.name).join(', ')}`);
    }
    if (extractedData.products && extractedData.products.length > 0) {
      collected.push(`Produtos: ${extractedData.products.map((p: any) => p.name).join(', ')}`);
    }
    if (extractedData.toneOfVoice) {
      collected.push(`Tom de voz: ${extractedData.toneOfVoice}`);
    }

    return `CONTEXTO - INFORMAÇÕES JÁ COLETADAS:
${collected.length > 0 ? collected.join('\n') : 'Nenhuma informação coletada ainda'}`;
  }

  /**
   * Builds progress section
   */
  private buildProgressSection(progress: number, completedFields: string[]): string {
    return `PROGRESSO: ${progress}% completo
Campos preenchidos: ${completedFields.join(', ') || 'nenhum'}`;
  }

  /**
   * Builds guidance section with next steps
   */
  private buildGuidanceSection(extractedData: any): string {
    const missing: string[] = [];

    if (!extractedData?.businessName) {
      missing.push('nome do negócio');
    }
    if (!extractedData?.niche) {
      missing.push('tipo/nicho do negócio');
    }
    if (!extractedData?.description || extractedData.description.length < 50) {
      missing.push('descrição detalhada');
    }
    if ((!extractedData?.services || extractedData.services.length === 0) && 
        (!extractedData?.products || extractedData.products.length === 0)) {
      missing.push('serviços ou produtos');
    }
    if (!extractedData?.toneOfVoice && (!extractedData?.personalityTraits || extractedData.personalityTraits.length === 0)) {
      missing.push('tom de voz/personalidade');
    }

    if (missing.length === 0) {
      return `PRÓXIMO PASSO: Todas as informações essenciais foram coletadas! Pergunte se o usuário quer adicionar mais detalhes ou finalizar.`;
    }

    return `PRÓXIMO PASSO: Priorize coletar: ${missing[0]}
Ainda faltam: ${missing.join(', ')}`;
  }

  /**
   * Builds prompt for specific niche
   */
  buildNicheSpecificPrompt(niche: string): string {
    const nichePrompts: Record<string, string> = {
      barbearia: `PERGUNTAS ESPECÍFICAS PARA BARBEARIA:
- Quais serviços oferece? (corte, barba, design, etc.)
- Quantos barbeiros trabalham?
- Qual o tempo médio de cada serviço?
- Tem agendamento online?`,
      
      loja: `PERGUNTAS ESPECÍFICAS PARA LOJA:
- Quais tipos de produtos vende?
- Faz entrega? Qual área de cobertura?
- Quais formas de pagamento aceita?
- Tem controle de estoque?`,
      
      clinica: `PERGUNTAS ESPECÍFICAS PARA CLÍNICA:
- Quais especialidades oferece?
- Quantos profissionais atendem?
- Aceita convênios? Quais?
- Como funciona o agendamento?`,
      
      restaurante: `PERGUNTAS ESPECÍFICAS PARA RESTAURANTE:
- Qual tipo de culinária?
- Tem delivery ou apenas retirada?
- Quais os horários de funcionamento?
- Tem opções vegetarianas/veganas?`,
    };

    return nichePrompts[niche.toLowerCase()] || '';
  }
}