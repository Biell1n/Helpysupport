import type { ExtractedBusinessData, ChecklistItem } from '@/schemas/onboarding-extraction.schema';
import { getContextualChecklist, formatChecklistWithStatus } from '@/lib/onboarding-utils';

/**
 * ProgressEngineService - Manages onboarding progress and dynamic checklist (no assistant_id required)
 */
export class ProgressEngineService {
  /**
   * Calculates onboarding progress based on extracted data
   * @param extractedData Current extracted data
   * @returns Progress object with percentage and completion status
   */
  calculateProgress(extractedData: any): {
    progress: number;
    onboarding_completed: boolean;
  } {
    const weights = {
      name: 20,
      description: 20,
      niche: 15,
      tone_of_voice: 15,
      personality: 10,
      products: 5,
      services: 5,
      contact: 5,
      rules: 5,
    };

    let totalProgress = 0;

    if (extractedData.name?.trim()) totalProgress += weights.name;
    if (extractedData.description?.trim()) totalProgress += weights.description;
    if (extractedData.niche?.trim()) totalProgress += weights.niche;
    if (extractedData.tone_of_voice?.trim()) totalProgress += weights.tone_of_voice;
    
    if (extractedData.personality && Object.keys(extractedData.personality).length > 0) {
      totalProgress += weights.personality;
    }
    
    if (extractedData.products && extractedData.products.length > 0) {
      totalProgress += weights.products;
    }
    
    if (extractedData.services && extractedData.services.length > 0) {
      totalProgress += weights.services;
    }
    
    if (extractedData.contact && Object.keys(extractedData.contact).length > 0) {
      totalProgress += weights.contact;
    }
    
    if (extractedData.rules && Object.keys(extractedData.rules).length > 0) {
      totalProgress += weights.rules;
    }

    const progress = Math.min(100, totalProgress);
    const isMinimalChecklistValid = this.validateMinimalChecklist(extractedData);
    const onboarding_completed = progress >= 80 && isMinimalChecklistValid;

    return {
      progress,
      onboarding_completed,
    };
  }

  /**
   * Validates minimal checklist requirements
   * @param extractedData Extracted data
   * @returns True if minimal requirements are met
   */
  validateMinimalChecklist(extractedData: any): boolean {
    return !!(
      extractedData.name?.trim() &&
      extractedData.description?.trim() &&
      extractedData.niche?.trim()
    );
  }

  /**
   * Updates progress based on extracted data (legacy method)
   * @param extractedData Current extracted data
   * @param niche Detected niche
   * @returns Progress percentage (0-100)
   */
  updateProgress(extractedData: ExtractedBusinessData, niche: string | null): number {
    const { progress } = this.calculateProgress(extractedData);
    return progress;
  }

  /**
   * Gets contextual checklist based on detected niche
   * @param niche Business niche
   * @param extractedData Current extracted data
   * @returns Array of checklist items with completion status
   */
  getContextualChecklist(niche: string | null, extractedData: ExtractedBusinessData): ChecklistItem[] {
    const baseChecklist = getContextualChecklist(niche || '');
    return formatChecklistWithStatus(baseChecklist, extractedData);
  }

  /**
   * Checks if onboarding is complete (legacy method)
   * @param extractedData Current extracted data
   * @returns True if minimum requirements met
   */
  isOnboardingComplete(extractedData: ExtractedBusinessData): boolean {
    return this.validateMinimalChecklist(extractedData);
  }

  /**
   * Gets completion percentage (legacy method)
   * @param extractedData Current extracted data
   * @param niche Detected niche
   * @returns Completion percentage (0-100)
   */
  getCompletionPercentage(extractedData: ExtractedBusinessData, niche: string | null): number {
    return this.updateProgress(extractedData, niche);
  }

  /**
   * Determines onboarding stage based on progress
   * @param percentage Completion percentage
   * @returns Current stage
   */
  getOnboardingStage(percentage: number): 'initial' | 'gathering' | 'refining' | 'completing' {
    if (percentage === 0) return 'initial';
    if (percentage < 50) return 'gathering';
    if (percentage < 90) return 'refining';
    return 'completing';
  }

  /**
   * Gets validation status for extracted data
   * @param extractedData Extracted data
   * @returns Validation status with missing fields
   */
  getValidationStatus(extractedData: any): {
    isValid: boolean;
    missingFields: string[];
  } {
    const missingFields: string[] = [];

    if (!extractedData.name?.trim()) missingFields.push('Nome do assistente');
    if (!extractedData.description?.trim()) missingFields.push('Descrição do negócio');
    if (!extractedData.niche?.trim()) missingFields.push('Nicho/Segmento');

    return {
      isValid: missingFields.length === 0,
      missingFields,
    };
  }
}