import { templates } from '@/lib/onboarding-templates';

function extractBusinessType(aiText) {
  const match = aiText.match(/"business_type":\s*"([^"]+)"/i) || aiText.match(/Nicho:\s*([^\n]+)/i);
  return match ? match[1].trim() : null;
}

function extractBusinessName(aiText) {
  const match = aiText.match(/"business_name":\s*"([^"]+)"/i) || aiText.match(/Nome do Negócio:\s*([^\n]+)/i);
  return match ? match[1].trim() : null;
}

function extractGoal(aiText) {
  const match = aiText.match(/"goal":\s*"([^"]+)"/i) || aiText.match(/Objetivo:\s*([^\n]+)/i);
  return match ? match[1].trim() : null;
}

function detectTemplate(businessType) {
  if (!businessType) return null;
  const lowerType = businessType.toLowerCase();
  if (lowerType.includes('venda') || lowerType.includes('loja')) return 'sales_template';
  if (lowerType.includes('consórcio') || lowerType.includes('imóvel')) return 'consortium_template';
  if (lowerType.includes('clínica') || lowerType.includes('médic') || lowerType.includes('dentista')) return 'clinic_template';
  if (lowerType.includes('restaurante') || lowerType.includes('delivery') || lowerType.includes('comida')) return 'restaurant_template';
  return null;
}

function extractFields(aiText, templateFields) {
  const fields = {};
  if (!templateFields) return fields;
  
  templateFields.forEach(field => {
    const regex = new RegExp(`"${field}":\\s*(?:"([^"]+)"|\\[([^\\]]+)\\]|{([^}]+)})`, 'i');
    const match = aiText.match(regex);
    if (match) {
      fields[field] = match[1] || match[2] || match[3];
    }
  });
  return fields;
}

export function extractOnboardingData(aiResponse, currentCollectedData) {
  let jsonExtracted = {};
  try {
    const jsonMatch = aiResponse.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      jsonExtracted = JSON.parse(jsonMatch[0]);
    }
  } catch (e) {
    // Fallback to manual extraction
  }

  const business_type = jsonExtracted.business_type || extractBusinessType(aiResponse) || currentCollectedData.business_type;
  const business_name = jsonExtracted.business_name || extractBusinessName(aiResponse) || currentCollectedData.business_name;
  const goal = jsonExtracted.goal || extractGoal(aiResponse) || currentCollectedData.goal;
  
  const template = detectTemplate(business_type) || currentCollectedData.template;
  const templateFields = template ? templates[template]?.fields : [];
  
  const fields = { ...currentCollectedData.fields, ...jsonExtracted.fields, ...extractFields(aiResponse, templateFields) };

  return {
    ...currentCollectedData,
    business_type,
    business_name,
    goal,
    template,
    fields
  };
}