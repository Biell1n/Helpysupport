import type { OnboardingContext, ExtractedBusinessData } from '@/schemas/onboarding-extraction.schema';
import { ExtractionService } from './extraction.service';
import { SemanticAnalysisService } from './semantic-analysis.service';
import { ProgressEngineService } from './progress-engine.service';
import { PromptBuilderService } from './prompt-builder.service';
import { mergeExtractedData } from '@/lib/onboarding-utils';

/**
 * OnboardingService - Orchestrates the entire onboarding flow
 */
export class OnboardingService {
  private extractionService: ExtractionService;
  private semanticService: SemanticAnalysisService;
  private progressService: ProgressEngineService;
  private promptService: PromptBuilderService;

  constructor(openaiApiKey: string) {
    this.extractionService = new ExtractionService(openaiApiKey);
    this.semanticService = new SemanticAnalysisService();
    this.progressService = new ProgressEngineService();
    this.promptService = new PromptBuilderService();
  }

  /**
   * Initializes onboarding context
   * @param assistantId Assistant ID
   * @param userId User ID
   * @returns Initial onboarding context
   */
  initializeOnboarding(assistantId: string, userId: string): Partial<OnboardingContext> {
    return {
      assistantId,
      userId,
      extractedData: {
        missingInformation: [],
        confidenceScore: 0,
        services: [],
        products: [],
        personalityTraits: [],
      },
      conversationHistory: [],
      progress: 0,
      completedFields: [],
      checklist: [],
      lastUpdated: new Date().toISOString(),
    };
  }

  /**
   * Processes user message and updates onboarding state
   * @param userMessage User's message
   * @param currentContext Current onboarding context
   * @returns Updated context and AI response
   */
  async processUserMessage(
    userMessage: string,
    currentContext: Partial<OnboardingContext>
  ): Promise<{
    context: Partial<OnboardingContext>;
    extractedData: ExtractedBusinessData;
    progress: number;
    isComplete: boolean;
  }> {
    // Extract data from user message
    const newExtractedData = await this.extractionService.extractBusinessData(
      userMessage,
      currentContext
    );

    // Merge with existing data
    const mergedData = mergeExtractedData(
      currentContext.extractedData || {},
      newExtractedData
    );

    // Detect niche
    const { niche } = this.semanticService.detectNiche(
      mergedData.description || '',
      mergedData.services,
      mergedData.products
    );

    // Update niche if detected with high confidence
    if (niche && !mergedData.niche) {
      mergedData.niche = niche;
    }

    // Calculate confidence
    const confidenceScore = this.semanticService.calculateConfidenceScore(mergedData);
    mergedData.confidenceScore = confidenceScore;

    // Identify gaps
    const gaps = this.semanticService.identifyGaps(mergedData, niche);
    mergedData.missingInformation = gaps;

    // Update progress
    const progress = this.progressService.updateProgress(mergedData, niche);

    // Get contextual checklist
    const checklist = this.progressService.getContextualChecklist(niche, mergedData);

    // Check if complete
    const isComplete = this.progressService.isOnboardingComplete(mergedData);

    // Get completed fields
    const completedFields = checklist
      .filter(item => item.completed)
      .map(item => item.id);

    // Update context
    const updatedContext: Partial<OnboardingContext> = {
      ...currentContext,
      extractedData: mergedData,
      progress,
      completedFields,
      checklist,
      lastUpdated: new Date().toISOString(),
    };

    return {
      context: updatedContext,
      extractedData: mergedData,
      progress,
      isComplete,
    };
  }

  /**
   * Gets current onboarding state
   * @param context Current context
   * @returns Onboarding state
   */
  getOnboardingState(context: Partial<OnboardingContext>) {
    const progress = context.progress || 0;
    const stage = this.progressService.getOnboardingStage(progress);
    const isComplete = this.progressService.isOnboardingComplete(
      context.extractedData || {}
    );

    return {
      stage,
      completionPercentage: progress,
      isComplete,
      contextualChecklist: context.checklist || [],
      extractedData: context.extractedData || {},
    };
  }

  /**
   * Completes onboarding
   * @param context Final context
   * @returns Completion result
   */
  completeOnboarding(context: Partial<OnboardingContext>) {
    const isValid = this.progressService.isOnboardingComplete(
      context.extractedData || {}
    );

    if (!isValid) {
      throw new Error('Onboarding incompleto - informações obrigatórias faltando');
    }

    return {
      success: true,
      finalData: context.extractedData,
      completionPercentage: 100,
    };
  }

  /**
   * Builds system prompt for current context
   * @param context Current context
   * @returns System prompt
   */
  buildSystemPrompt(context: Partial<OnboardingContext>): string {
    return this.promptService.buildSystemPrompt(context);
  }
}