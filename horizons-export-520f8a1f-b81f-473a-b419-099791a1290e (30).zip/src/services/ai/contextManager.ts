import { supabase } from '@/lib/supabase/client';
import type { Message } from '@/config/aiModels';

export async function saveConversationMessage(
  sessionId: string, 
  role: 'user' | 'assistant', 
  content: string,
  isChat: boolean = false
) {
  try {
    const newMessage = { role, content, timestamp: new Date().toISOString() };
    
    if (isChat) {
      const { data, error } = await supabase
        .from('conversation_messages')
        .insert({
          conversation_id: sessionId,
          role,
          content,
        });
      if (error) throw error;
      return true;
    } else {
      // Onboarding Sessions logic
      const { data: session, error: fetchError } = await supabase
        .from('onboarding_sessions')
        .select('messages')
        .eq('id', sessionId)
        .single();
        
      if (fetchError) throw fetchError;
      
      const messages = session.messages || [];
      messages.push(newMessage);
      
      const { error: updateError } = await supabase
        .from('onboarding_sessions')
        .update({ messages, updated_at: new Date().toISOString() })
        .eq('id', sessionId);
        
      if (updateError) throw updateError;
      return true;
    }
  } catch (error) {
    console.error('Error saving conversation message:', error);
    return false;
  }
}

export async function getConversationHistory(sessionId: string, limit: number = 20, isChat: boolean = false): Promise<Message[]> {
  try {
    if (isChat) {
      const { data, error } = await supabase
        .from('conversation_messages')
        .select('role, content, created_at')
        .eq('conversation_id', sessionId)
        .order('created_at', { ascending: false })
        .limit(limit);
        
      if (error) throw error;
      return (data || []).reverse().map(m => ({ role: m.role as any, content: m.content, timestamp: m.created_at }));
    } else {
      const { data: session, error } = await supabase
        .from('onboarding_sessions')
        .select('messages')
        .eq('id', sessionId)
        .single();
        
      if (error) throw error;
      const msgs = session?.messages || [];
      return msgs.slice(-limit);
    }
  } catch (error) {
    console.error('Error getting conversation history:', error);
    return [];
  }
}

export function buildContextualMessages(systemPrompt: string, conversationHistory: Message[], userMessage: string): Message[] {
  return [
    { role: 'system', content: systemPrompt },
    ...conversationHistory.map(m => ({ role: m.role, content: m.content })),
    { role: 'user', content: userMessage }
  ];
}