# HELPY Assistant Diagnostic Report
**Date:** 2026-06-05
**Focus:** HELPY Prompt Structure, Context Flow, Data Architecture, and Off-Topic Behavior Analysis

## 1. PROMPT LOCATION & STORAGE
**Locations:**
- **Base Prompt:** `src/lib/helpyConfig.js` exports `HELPY_SYSTEM_PROMPT`.
- **Dynamic Context Prompt:** `src/lib/intelligentPrompts.js` exports `buildContextAwarePrompt` and `buildAnalyzeAndRoutePrompt` which wrap the context dynamically based on the current business state and missing fields.
- **Storage:** The prompt is largely hardcoded in the frontend repository (`helpyConfig.js` and `intelligentPrompts.js`), but it is hydrated with dynamic variables (completion progress, missing fields, business type) before being sent to the Edge Function (`refine-assistant-chat`).

**References:**
- `src/lib/helpyConfig.js`
- `src/lib/intelligentPrompts.js`
- `src/components/RefinementAssistantChat.jsx`
- `supabase/functions/refine-assistant-chat/index.ts` (Edge Function execution)

## 2. CURRENT PROMPT ANALYSIS
**Extracted Base Prompt (`src/lib/helpyConfig.js`):**