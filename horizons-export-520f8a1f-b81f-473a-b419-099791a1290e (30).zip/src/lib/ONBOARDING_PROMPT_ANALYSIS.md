# HELPY Onboarding Prompt Architecture Analysis
**Date:** 2026-06-05

This document provides a comprehensive diagnostic analysis of the current HELPY onboarding prompt architecture, data extraction flow, and progress tracking logic based on the existing codebase.

---

## 1. Current Prompt Extraction

The current architecture actually contains **three different prompt definitions** scattered across the codebase, creating a fragmented context.

### A. Edge Function Active Prompt (`supabase/functions/onboarding-chat/index.ts`)
This is the prompt currently being executed by the Edge Function: