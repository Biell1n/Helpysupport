export function extractBusinessContext(messages: any[], collectedData: any) {
  const recentMessages = messages.slice(-5).map(m => m.content).join(' ');
  return {
    recent_context: recentMessages,
    known_data: collectedData
  };
}

export function detectBusinessType(description: string, context: any) {
  const text = (description + ' ' + JSON.stringify(context)).toLowerCase();
  if (text.includes('consórcio')) return 'consórcio';
  if (text.includes('clínica') || text.includes('paciente')) return 'clínica';
  if (text.includes('restaurante') || text.includes('comida')) return 'restaurante';
  if (text.includes('agência') || text.includes('marketing')) return 'agência';
  if (text.includes('loja') || text.includes('produto')) return 'loja';
  return 'genérico';
}

export function classifyFields(businessType: string, fields: string[]) {
  const required = ['nome_negocio', 'tipo_negocio', 'objetivo_principal'];
  const recommended = ['email', 'telefone', 'horario_funcionamento', 'localizacao'];
  return { required, recommended, optional: fields.filter(f => !required.includes(f) && !recommended.includes(f)) };
}

export function suggestNextQuestions(businessType: string, collectedData: any, confidence: number) {
  if (confidence < 40) return "Poderia me dar mais detalhes sobre como funciona a operação no dia a dia?";
  if (confidence < 70) return "Quais são as principais dúvidas que seus clientes costumam ter?";
  return "Excelente! Tem alguma regra específica de atendimento ou algo que o assistente NÃO deva falar?";
}

export function calculateConfidence(businessType: string, collectedData: any, requiredFields: string[]) {
  const reqFilled = requiredFields.filter(f => collectedData[f]).length;
  const reqTotal = requiredFields.length || 1;
  const baseConf = (reqFilled / reqTotal) * 60;
  
  const additionalKeys = Object.keys(collectedData).length - reqFilled;
  const bonusConf = Math.min(40, additionalKeys * 5);
  
  return Math.min(100, Math.round(baseConf + bonusConf));
}