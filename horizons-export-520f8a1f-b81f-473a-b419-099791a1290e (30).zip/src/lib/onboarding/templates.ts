export const SALES_TEMPLATE = () => ({
  fields: ['produtos', 'preços', 'processo_venda', 'follow_up'],
  flows: ['apresentacao', 'objecao', 'fechamento', 'follow_up'],
  automations: ['envio_proposta', 'lembrete_follow_up', 'confirmacao_venda']
});

export const CONSORTIUM_TEMPLATE = () => ({
  fields: ['membros', 'beneficios', 'estrutura', 'comunicacao'],
  flows: ['captacao', 'onboarding_membro', 'comunicacao', 'suporte'],
  automations: ['confirmacao_inscricao', 'envio_beneficios', 'lembrete_pagamento']
});

export const CLINIC_TEMPLATE = () => ({
  fields: ['especialidades', 'agendamento', 'pacientes', 'prontuarios'],
  flows: ['agendamento', 'confirmacao', 'atendimento', 'follow_up'],
  automations: ['confirmacao_consulta', 'lembrete_consulta', 'envio_prontuario']
});

export const RESTAURANT_TEMPLATE = () => ({
  fields: ['cardapio', 'reservas', 'pedidos', 'delivery'],
  flows: ['reserva', 'pedido', 'entrega', 'feedback'],
  automations: ['confirmacao_reserva', 'lembrete_reserva', 'confirmacao_pedido']
});

export const getTemplateForBusinessType = (type: string) => {
  const typeLower = (type || '').toLowerCase();
  if (typeLower.includes('consórcio') || typeLower.includes('consorcio')) return CONSORTIUM_TEMPLATE();
  if (typeLower.includes('clínica') || typeLower.includes('clinica') || typeLower.includes('médico')) return CLINIC_TEMPLATE();
  if (typeLower.includes('restaurante') || typeLower.includes('food')) return RESTAURANT_TEMPLATE();
  if (typeLower.includes('loja') || typeLower.includes('venda')) return SALES_TEMPLATE();
  
  return { fields: [], flows: [], automations: [] };
};