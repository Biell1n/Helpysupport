/**
 * Supabase admin client for Edge Functions
 * Uses service role key (NEVER expose in frontend)
 * 
 * This file should ONLY be imported in Edge Functions (supabase/functions/*)
 */

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import type { Database } from '../../types/database.types.ts';

/**
 * Create Supabase admin client with service role key
 * This bypasses Row Level Security - use with caution
 */
export function createAdminClient() {
  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

  if (!supabaseUrl || !supabaseServiceKey) {
    throw new Error('Missing Supabase environment variables in Edge Function');
  }

  return createClient<Database>(supabaseUrl, supabaseServiceKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });
}