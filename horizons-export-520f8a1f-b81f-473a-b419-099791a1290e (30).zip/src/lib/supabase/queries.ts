/**
 * Common database query helpers
 * Reusable functions for database operations
 * Updated to use user_id and auth.uid() (Fase 1 architecture)
 */

import { supabase } from './client';
import { isValidAssistantStatus } from '@/schemas/assistant.schema';
import { DEFAULT_ASSISTANT_STATUS } from '@/constants/assistantStatus';
import type { 
  Assistant, 
  AssistantProfile, 
  AssistantWithProfile 
} from '@/types/assistant.types';
import type { Database } from '@/types/database.types';

type ConversationMessage = Database['public']['Tables']['conversation_messages']['Row'];
type UsageLog = Database['public']['Tables']['usage_logs']['Insert'];

/**
 * Get assistant by ID
 */
export async function getAssistant(assistantId: string): Promise<Assistant | null> {
  try {
    const { data, error } = await supabase
      .from('assistants')
      .select('*')
      .eq('id', assistantId)
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error fetching assistant:', error);
    return null;
  }
}

/**
 * Get assistant with profile
 */
export async function getAssistantWithProfile(
  assistantId: string
): Promise<AssistantWithProfile | null> {
  try {
    const { data: assistant, error: assistantError } = await supabase
      .from('assistants')
      .select('*')
      .eq('id', assistantId)
      .single();

    if (assistantError) throw assistantError;

    const { data: profile, error: profileError } = await supabase
      .from('assistant_profiles')
      .select('*')
      .eq('assistant_id', assistantId)
      .single();

    // Profile might not exist yet, that's okay
    if (profileError && profileError.code !== 'PGRST116') {
      console.error('Error fetching profile:', profileError);
    }

    return {
      ...assistant,
      profile: profile || null,
    };
  } catch (error) {
    console.error('Error fetching assistant with profile:', error);
    return null;
  }
}

/**
 * Get assistant profile
 */
export async function getAssistantProfile(
  assistantId: string
): Promise<AssistantProfile | null> {
  try {
    const { data, error } = await supabase
      .from('assistant_profiles')
      .select('*')
      .eq('assistant_id', assistantId)
      .single();

    if (error && error.code !== 'PGRST116') throw error;
    return data || null;
  } catch (error) {
    console.error('Error fetching assistant profile:', error);
    return null;
  }
}

/**
 * Get conversation messages
 */
export async function getConversationMessages(
  assistantId: string,
  customerId: string
): Promise<ConversationMessage[]> {
  try {
    const { data, error } = await supabase
      .from('conversation_messages')
      .select('*')
      .eq('assistant_id', assistantId)
      .eq('customer_id', customerId)
      .order('created_at', { ascending: true });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching conversation messages:', error);
    return [];
  }
}

/**
 * Create usage log entry
 */
export async function createUsageLog(data: UsageLog): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('usage_logs')
      .insert(data);

    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error creating usage log:', error);
    return false;
  }
}

/**
 * Get user's assistants (using user_id and auth.uid())
 */
export async function getUserAssistants(userId: string): Promise<Assistant[]> {
  try {
    const { data, error } = await supabase
      .from('assistants')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching user assistants:', error);
    return [];
  }
}

/**
 * Get current user's assistants (uses auth.uid() automatically via RLS)
 */
export async function getCurrentUserAssistants(): Promise<Assistant[]> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data, error } = await supabase
      .from('assistants')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching current user assistants:', error);
    return [];
  }
}

/**
 * Validates assistant status before database operation
 * @param status Status value to validate
 * @returns Validated status or default status if invalid
 */
export function validateAssistantStatus(status: string | undefined): string {
  if (!status || !isValidAssistantStatus(status)) {
    console.warn(`Invalid assistant status: ${status}. Using default: ${DEFAULT_ASSISTANT_STATUS}`);
    return DEFAULT_ASSISTANT_STATUS;
  }
  return status;
}