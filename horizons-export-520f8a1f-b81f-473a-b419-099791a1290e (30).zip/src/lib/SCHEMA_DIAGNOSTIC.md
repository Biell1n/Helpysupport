# SCHEMA DIAGNOSTIC REPORT
*Extracted directly from the current database state.*

## PART 1 - TABLE: onboarding_sessions

**Schema Definition:**
- **id**: `uuid` NOT NULL (PRIMARY KEY)
- **user_id**: `uuid` NOT NULL
- **business_type**: `text`
- **business_description**: `text`
- **assistant_goal**: `text`
- **onboarding_progress**: `integer`
- **collected_data**: `jsonb`
- **status**: `text`
- **created_at**: `timestamp with time zone`
- **updated_at**: `timestamp with time zone`
- **extracted_data**: `jsonb`
- **missing_information**: `jsonb`
- **context_sufficiency**: `integer`
- **assistant_capabilities**: `jsonb`
- **conversation_history**: `jsonb`
- **next_objective**: `text`

**Constraints & Defaults:**
- Primary Key: `id`
- NOT NULL constraints: `id`, `user_id`
- Default values are standard PostgreSQL defaults (e.g., `gen_random_uuid()` for id, `now()` for timestamps) based on standard creation, though explicit defaults are hidden in the raw column output.

**Foreign Keys:**
- None detected directly on `onboarding_sessions` in the schema payload (expected `user_id -> users(id)` but it's not explicitly enforced via FK constraint in the current dump).

**RLS (Row Level Security):**
- Enabled: YES (inferred from policies existing)

**RLS Policies:**
1. `"Users can update their own sessions"`
   - Operation: `UPDATE`
   - USING condition: `((auth.uid() = user_id))`
2. `"Users can insert their own sessions"`
   - Operation: `INSERT`
   - USING condition: `(true)`
3. `"Users can delete their own sessions"`
   - Operation: `DELETE`
   - USING condition: `((auth.uid() = user_id))`
4. `"Users can view their own sessions"`
   - Operation: `SELECT`
   - USING condition: `((auth.uid() = user_id))`

**Triggers:**
- `update_onboarding_sessions_updated_at`
  - Condition: `BEFORE UPDATE ON onboarding_sessions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column()`

---

## PART 2 - TABLE: onboarding_messages

**Schema Definition:**
- **id**: `uuid` NOT NULL (PRIMARY KEY)
- **session_id**: `uuid` NOT NULL
- **user_id**: `uuid` NOT NULL
- **role**: `text` NOT NULL
- **content**: `text` NOT NULL
- **created_at**: `timestamp with time zone`

**Constraints & Defaults:**
- Primary Key: `id`
- NOT NULL constraints: `id`, `session_id`, `user_id`, `role`, `content`

**Foreign Keys:**
- `FOREIGN KEY (session_id) REFERENCES public.onboarding_sessions(id)`

**RLS (Row Level Security):**
- Enabled: YES

**RLS Policies:**
1. `"Users can view messages from their own sessions"`
   - Operation: `SELECT`
   - USING condition: `((auth.uid() = user_id))`
2. `"Users can insert their own messages"`
   - Operation: `INSERT`
   - USING condition: `(true)`

**Triggers:**
- None detected.

---

## PART 3 - STRUCTURED FIELDS VALIDATION

| Field Name | Exists in `onboarding_sessions`? | Exact Data Type | Nullable? |
| :--- | :--- | :--- | :--- |
| `extracted_data` | **YES** | `jsonb` | YES |
| `missing_information` | **YES** | `jsonb` | YES |
| `context_sufficiency` | **YES** | `integer` | YES |
| `assistant_capabilities` | **YES** | `jsonb` | YES |
| `next_objective` | **YES** | `text` | YES |
| `business_type_detected` | **NO** | N/A | N/A |
| `conversation_history` | **YES** | `jsonb` | YES |
| `business_type` | **YES** | `text` | YES |
| `business_description` | **YES** | `text` | YES |
| `assistant_goal` | **YES** | `text` | YES |
| `onboarding_progress` | **YES** | `integer` | YES |
| `collected_data` | **YES** | `jsonb` | YES |
| `status` | **YES** | `text` | YES |
| `created_at` | **YES** | `timestamp with time zone` | YES |
| `updated_at` | **YES** | `timestamp with time zone` | YES |

***CRITICAL FINDING:** `business_type_detected` DOES NOT EXIST in the `onboarding_sessions` table. The edge function relies on a fallback to `business_type` but any direct update to `business_type_detected` will fail if not accounted for.*

---

## PART 4 - COMPLETE SCHEMA SQL
*(Reconstructed from the active schema metadata)*