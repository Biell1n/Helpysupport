# BUG B AUDIT: .map() Calls in Onboarding Components

## 1. `src/components/OnboardingDataPanel.jsx`
- **Line 41**: `Object.entries(extractedData).map(...)`
  - **Issue**: `extractedData` could occasionally be an array or null depending on API edge cases, breaking `Object.entries`.
- **Line 57**: `missingInformation.map(...)`
  - **CRITICAL ISSUE FOUND**: The edge function returns `missingInformation` as an object: `{ critical: [], important: [], optional: [] }`. However, this panel expects an array of objects `[{priority, field, explanation}]`. The `useOnboardingChat.js` hook passed the object down directly, causing `missingInformation.map is not a function`. This is the exact cause of the ErrorBoundary crash.
- **Line 83**: `assistantCapabilities.map(...)`
  - **Issue**: No safety check. If undefined, `.map()` crashes.

## 2. `src/components/onboarding/OnboardingChat.jsx`
- **Line 54**: `messages.map((msg) => (...))`
  - **Issue**: Array check omitted. If `messages` falls back to `null`, it breaks.

## 3. `src/components/onboarding/OnboardingChat.tsx`
- **Line 47**: `messages.map((msg) => (...))`
  - **Issue**: Same missing array check as JSX counterpart.

## 4. `src/pages/OnboardingChatPage.jsx`
- **Line 106**: `history.map((msg, idx) => (...))`
  - **Issue**: `history` could be null prior to initial hydration.