# BUG A AUDIT: .insert() Calls to onboarding_sessions

## 1. `src/pages/OnboardingPage.jsx`
- **Line Number:** ~81
- **Function Name:** `handleStartOnboarding`
- **Payload Structure:** `{ user_id, business_type, business_description, assistant_goal, status, onboarding_progress, collected_data }`
- **When/How Called:** Triggered when the user submits the initial business setup form.
- **Checked Before Insert?** No, it relied on a separate `useEffect` check, which was causing race conditions if the user clicked too quickly.
- **Handles 409 Conflict?** No.

## 2. `src/pages/OnboardingChatPage.jsx`
- **Line Number:** ~31
- **Function Name:** `initSession`
- **Payload Structure:** `{ user_id, business_type, conversation_history, context_sufficiency, status }`
- **When/How Called:** Triggered on mount inside a `useEffect` if `!sessionId` exists.
- **Checked Before Insert?** No, it blindly called insert.
- **Handles 409 Conflict?** No.

## 3. `src/services/onboarding/onboardingService.js`
- **Line Number:** ~28
- **Function Name:** `createSession`
- **Payload Structure:** `{ user_id, business_type, business_name, goal, status, current_step, messages, collected_data }`
- **When/How Called:** Exported utility method for starting sessions manually in older/different flows.
- **Checked Before Insert?** No.
- **Handles 409 Conflict?** No.

## 4. `src/hooks/useGetOrCreateSession.js`
- **Line Number:** ~46
- **Function Name:** `getOrCreateSession`
- **Payload Structure:** `{ user_id, business_type, business_description, assistant_goal, status, onboarding_progress, extracted_data }`
- **When/How Called:** Used in `CreateAssistantOnboardingPage.jsx`.
- **Checked Before Insert?** Yes, checks `getActiveSession`.
- **Handles 409 Conflict?** Yes, handles `23505` correctly.