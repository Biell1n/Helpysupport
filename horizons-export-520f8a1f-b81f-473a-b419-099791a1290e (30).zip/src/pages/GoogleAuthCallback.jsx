// ============================================================
// HELPY — GoogleAuthCallback v3 — ARQUIVO COMPLETO
//
// Esta é a página para onde o Google devolve o usuário depois do
// consentimento. Ela precisa existir e precisa ter tempo: a URL chega
// com "?code=..." e esse código tem que ser trocado por uma sessão
// ANTES de qualquer navegação. Se a página redirecionar na hora, a URL
// é apagada com o código dentro, e o login se perde em silêncio.
// ============================================================

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { Loader2 } from 'lucide-react';

export default function GoogleAuthCallback() {
  const navigate = useNavigate();
  const [erro, setErro] = useState(null);
  const [etapa, setEtapa] = useState('recebendo resposta do Google');
  // O que realmente chegou na URL e no armazenamento. Sem isto é
  // impossível saber se o problema é o Google, o Supabase ou o site.
  const [pistas, setPistas] = useState(null);

  useEffect(() => {
    let cancelado = false;

    const finalizar = async () => {
      try {
        if (!supabase) throw new Error('Cliente Supabase não inicializado');

        const url = new URL(window.location.href);

        // --- 0. registrar o que chegou ---
        const naQuery = [...url.searchParams.keys()];
        const hash = window.location.hash || '';
        const noHash = hash
          ? [...new URLSearchParams(hash.replace(/^#/, '')).keys()]
          : [];

        // o fluxo PKCE guarda um "code verifier" no armazenamento antes
        // de mandar para o Google. Se ele sumiu, a troca não tem como dar certo.
        let temVerifier = false;
        try {
          for (let i = 0; i < window.localStorage.length; i++) {
            const k = window.localStorage.key(i) || '';
            if (k.includes('code-verifier') || k.includes('auth-token-code-verifier')) {
              temVerifier = true;
              break;
            }
          }
        } catch (_) {
          /* armazenamento bloqueado */
        }

        const diag = {
          query: naQuery.length ? naQuery.join(', ') : '(vazio)',
          hash: noHash.length ? noHash.join(', ') : '(vazio)',
          verifier: temVerifier ? 'sim' : 'NAO',
          origem: url.origin,
          caminho: url.pathname,
          trocaErro: null,
        };
        setPistas(diag);
        console.log('[GoogleCallback] pistas:', diag);

        // --- 1. o Google recusou? ---
        const recusa =
          url.searchParams.get('error_description') || url.searchParams.get('error');
        if (recusa) {
          setErro(`O Google recusou o login: ${recusa}`);
          return;
        }

        // --- 2. trocar o código por sessão (fluxo PKCE) ---
        const code = url.searchParams.get('code');
        if (code) {
          setEtapa('trocando o código por sessão');
          try {
            const { error: erroTroca } = await supabase.auth.exchangeCodeForSession(
              window.location.href
            );
            if (erroTroca) {
              diag.trocaErro = erroTroca.message;
              setPistas({ ...diag });
            }
          } catch (e) {
            // detectSessionInUrl pode ter consumido o código antes.
            diag.trocaErro = e?.message || String(e);
            setPistas({ ...diag });
            console.warn('[GoogleCallback] troca de código:', e?.message);
          }
        }

        // --- 3. esperar a sessão aparecer ---
        // Até 6 segundos. É aqui que a versão anterior falhava: ela
        // consultava uma vez só, na hora, e quase sempre vinha vazio.
        setEtapa('confirmando a sessão');
        let session = null;
        for (let i = 0; i < 20; i++) {
          if (cancelado) return;
          const { data } = await supabase.auth.getSession();
          if (data?.session) {
            session = data.session;
            break;
          }
          await new Promise((r) => setTimeout(r, 300));
        }

        if (!session?.user) {
          setErro('O Google autorizou, mas a sessão não foi criada.');
          return;
        }

        // --- 4. sair ---
        // Não decidimos aqui se falta completar o cadastro. Essa regra
        // já existe no ProtectedRoute:
        //
        //   if (isPending && pathname !== '/complete-cadastro')
        //       -> manda para /complete-cadastro
        //
        // com isPending = userProfile.user_type === 'pending'.
        //
        // Duplicar a decisão aqui criaria duas regras capazes de
        // discordar. Mandamos para o dashboard e quem decide continua
        // sendo um lugar só, igual para login com Google ou com senha.
        if (cancelado) return;

        // limpa o código da barra de endereço antes de sair
        window.history.replaceState({}, document.title, window.location.pathname);

        setEtapa('entrando');
        navigate('/dashboard', { replace: true });
      } catch (e) {
        console.error('[GoogleCallback] falhou:', e);
        if (!cancelado) setErro(e?.message || 'Erro desconhecido ao concluir o login.');
      }
    };

    finalizar();
    return () => {
      cancelado = true;
    };
  }, [navigate]);

  if (erro) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center px-6">
        <div className="max-w-sm w-full text-center">
          <h1 className="text-white text-lg font-semibold mb-3">
            Não foi possível concluir o login
          </h1>
          <p className="text-neutral-400 text-sm leading-relaxed mb-6 break-words">{erro}</p>

          {pistas && (
            <div className="text-[10px] font-mono text-neutral-600 text-left border border-neutral-800 p-3 mb-6 space-y-1 break-all">
              <p>na url: {pistas.query}</p>
              <p>no hash: {pistas.hash}</p>
              <p>code verifier: {pistas.verifier}</p>
              <p>origem: {pistas.origem}</p>
              <p>caminho: {pistas.caminho}</p>
              {pistas.trocaErro && <p>erro da troca: {pistas.trocaErro}</p>}
            </div>
          )}

          <button
            type="button"
            onClick={() => navigate('/auth', { replace: true })}
            className="text-xs text-neutral-300 border border-neutral-700 px-4 py-2 hover:text-white hover:border-neutral-400 transition-colors"
          >
            Voltar para o login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-6">
      <div className="flex flex-col items-center gap-4 text-center">
        <Loader2 className="w-8 h-8 text-white animate-spin" />
        <p className="text-neutral-400">Concluindo login com o Google...</p>
        <p className="text-[10px] font-mono text-neutral-600">{etapa}</p>
      </div>
    </div>
  );
}