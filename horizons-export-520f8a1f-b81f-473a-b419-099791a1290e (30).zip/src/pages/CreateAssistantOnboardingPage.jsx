import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ArrowLeft, Loader2, Sparkles, Terminal, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import InitialQuestionsModal from '@/components/InitialQuestionsModal';
import OnboardingChat from '@/components/onboarding/OnboardingChat';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useGetOrCreateSession } from '@/hooks/useGetOrCreateSession';

export default function CreateAssistantOnboardingPage() {
  const navigate = useNavigate();
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const { toast } = useToast();
  
  const [showModal, setShowModal] = useState(true);
  const [activeSessionId, setActiveSessionId] = useState(null);
  const [isNewSession, setIsNewSession] = useState(true);
  const [sessionInitialData, setSessionInitialData] = useState(null);
  
  const { getOrCreateSession, isLoading: isCreatingSession } = useGetOrCreateSession(user?.id);

  const handleModalSubmit = async (data) => {
    if (!user?.id) {
      toast({ title: 'Erro', description: 'Usuário não autenticado', variant: 'destructive' });
      return;
    }

    try {
      const result = await getOrCreateSession(user.id, data.businessType, data.description, data.goal);
      
      if (result?.sessionId) {
        setActiveSessionId(result.sessionId);
        setIsNewSession(result.isNew);
        setSessionInitialData(result.session);
        setShowModal(false);
        
        toast({ 
          title: result.isNew ? 'Sessão Iniciada' : 'Sessão Restaurada', 
          description: result.isNew ? 'Vamos configurar o seu assistente.' : 'Encontramos seu progresso anterior.'
        });
      }
    } catch (error) {
      console.error('[ONBOARDING INIT ERROR]', error);
      toast({ title: 'Erro', description: 'Falha ao iniciar a sessão. Tente novamente.', variant: 'destructive' });
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6">
        <div className="bg-neutral-900 border border-white/10 p-8 rounded-xl max-w-md w-full text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">Acesso Negado</h2>
          <p className="text-neutral-400 mb-6">Você precisa estar logado para acessar o onboarding consultivo.</p>
          <Button onClick={() => navigate('/auth')} className="w-full">Ir para Login</Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Onboarding Inteligente | Horizons</title>
      </Helmet>

      <InitialQuestionsModal 
        isOpen={showModal} 
        onSubmit={handleModalSubmit}
        isSubmitting={isCreatingSession}
      />

      {!showModal && activeSessionId && (
        <div className="min-h-screen bg-black flex flex-col">
          <header className="bg-neutral-900 border-b border-white/10 px-6 py-4 flex items-center justify-between z-10 relative shadow-md">
            <div className="flex items-center gap-4">
              <Button variant="ghost" onClick={() => navigate('/dashboard')} className="text-white hover:bg-white/10">
                <ArrowLeft className="w-4 h-4 mr-2" /> Voltar
              </Button>
              <h1 className="text-xl font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" /> Especialista em IA
              </h1>
            </div>
          </header>

          <div className="flex-1 flex overflow-hidden w-full mx-auto relative">
            <div className="absolute top-4 left-4 right-4 z-10 pointer-events-none hidden md:block">
              <Alert className="bg-neutral-900/80 border-primary/30 backdrop-blur-sm pointer-events-auto max-w-xl mx-auto">
                <Terminal className="h-4 w-4 text-primary" />
                <AlertTitle className="text-primary font-bold">Resumo da Sessão</AlertTitle>
                <AlertDescription className="text-neutral-300 text-xs mt-1">
                  Sessão ID: <span className="font-mono text-[10px]">{activeSessionId}</span> <br/>
                  Status: {isNewSession ? 'Nova Sessão' : 'Sessão Restaurada'}
                </AlertDescription>
              </Alert>
            </div>

            <div className="flex-1 flex flex-col p-4 md:p-6 lg:p-8 w-full max-w-6xl mx-auto">
               <OnboardingChat 
                 sessionId={activeSessionId} 
                 isNewSession={isNewSession} 
                 initialSessionData={sessionInitialData} 
               />
            </div>
          </div>
        </div>
      )}
    </>
  );
}