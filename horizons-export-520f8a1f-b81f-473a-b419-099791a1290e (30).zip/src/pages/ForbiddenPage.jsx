import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ForbiddenPage() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4">
      <div className="text-center max-w-md">
        <div className="bg-red-900/20 w-24 h-24 rounded-3xl flex items-center justify-center mx-auto mb-8 border border-red-500/30">
          <ShieldAlert className="w-12 h-12 text-red-500" />
        </div>
        
        <h1 className="text-4xl font-bold text-white mb-4">403 - Acesso Negado</h1>
        <p className="text-neutral-400 mb-8 text-lg">
          Você não tem permissão para acessar este recurso.
        </p>
        
        <Link to="/dashboard">
          <Button className="bg-neutral-800 hover:bg-neutral-700 text-white px-8 py-6">
            Voltar para Dashboard
          </Button>
        </Link>
      </div>
    </div>
  );
}