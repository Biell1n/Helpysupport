import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Send, Bot, User, Check, Loader2, RefreshCw, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useIntelligentOnboarding } from '@/hooks/useIntelligentOnboarding';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/AuthContext';
import { runIntelligentOnboardingMigration } from '@/utils/runIntelligentOnboardingMigration';
import { logger } from '@/utils/logger';
import OnboardingDataPanel from '@/components/OnboardingDataPanel';
import ErrorBoundary from '@/components/ErrorBoundary';

function ChatContent() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [inputMessage, setInputMessage] = useState('');
  const scrollRef = useRef(null);
  const [initError, setInitError] = useState(null);

  const {
    sessionId,
    setSessionId,
    loading,
    sessionState,
    history,
    sendMessage,
    getProgress,
    fetchSessionState
  } = useIntelligentOnboarding(location.state?.sessionId || null);

  // Run migration on mount
  useEffect(() => {
    runIntelligentOnboardingMigration().catch(e => logger.error('Migration', 'Failed', e));
  }, []);

  // Session Initialization Logic
  useEffect(() => {
    async function initSession() {
      if (!sessionId && user) {
        try {
          logger.info('initSession', 'Looking for active session...');
          const { data: existingData, error: existingError } = await supabase
            .from('onboarding_sessions')
            .select('id')
            .eq('user_id', user.id)
            .in('status', ['active', 'in_progress'])
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();

          if (existingError) throw existingError;

          if (existingData?.id) {
            logger.info('initSession', `Found existing session: ${existingData.id}`);
            setSessionId(existingData.id);
            return;
          }

          logger.info('initSession', 'Creating new session...');
          const { data, error } = await supabase
            .from('onboarding_sessions')
            .insert({
              user_id: user.id,
              status: 'active',
              business_type: null,
              critical_fields: [],
              important_fields: [],
              optional_fields: [],
              depth_analysis: {},
              extracted_data: {},
              missing_information: { critical: [], important: [], optional: [] }
            })
            .select()
            .single();
            
          if (error) throw error;
          setSessionId(data.id);
        } catch (err) {
          logger.error('initSession', 'Initialization failed', err);
          setInitError('Failed to initialize session. Please refresh.');
          toast({ title: "Error", description: "Could not start session.", variant: "destructive" });
        }
      }
    }
    initSession();
  }, [sessionId, user, setSessionId, toast]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollIntoView({ behavior: 'smooth' });
  }, [history, loading]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!inputMessage.trim() || loading || !user?.id) return;
    
    const messageToSend = inputMessage.trim();
    setInputMessage(''); // Clear immediately for better UX
    
    try {
      await sendMessage(messageToSend, user.id);
    } catch (e) {
      // Re-populate input if permanent failure
      setInputMessage(messageToSend);
      logger.error('handleSend', 'Failed to send message', e);
    }
  };

  const handleRecover = () => {
    setInitError(null);
    fetchSessionState();
  };

  const progress = getProgress();
  const isReady = progress.overall >= 85;

  if (initError) {
    return (
      <div className="flex flex-col min-h-screen items-center justify-center bg-black gap-4 text-white">
        <AlertCircle className="w-12 h-12 text-red-500" />
        <p>{initError}</p>
        <Button onClick={handleRecover} variant="outline" className="gap-2 border-white/20 text-white hover:bg-white/10">
          <RefreshCw className="w-4 h-4" /> Retry
        </Button>
      </div>
    );
  }

  if (!sessionId) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <Loader2 className="w-8 h-8 animate-spin text-white" />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-black overflow-hidden">
      <div className="flex-1 flex flex-col relative">
        <header className="h-16 border-b border-white/10 flex items-center justify-between px-6 bg-neutral-950/50 backdrop-blur-md z-10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
              <Bot className="w-4 h-4 text-primary" />
            </div>
            <div>
               <h1 className="font-semibold text-white">Setup Assistant</h1>
               <div className="text-xs text-neutral-400 flex items-center gap-2">
                 <span>{sessionState.business_type ? sessionState.business_type.toUpperCase() : 'Discovery Phase'}</span>
                 <span>• Progress: {progress.overall}%</span>
               </div>
            </div>
          </div>
          <Button 
            onClick={() => { if(isReady) navigate('/dashboard') }}
            disabled={!isReady}
            className={isReady ? "bg-green-600 hover:bg-green-700 text-white shadow-lg shadow-green-900/20" : "bg-neutral-800 text-neutral-400"}
          >
            {isReady && <Check className="w-4 h-4 mr-2" />}
            Build AI
          </Button>
        </header>

        <ScrollArea className="flex-1 p-4 md:p-6">
          <div className="max-w-3xl mx-auto space-y-6 pb-6">
            {!history || history.length === 0 ? (
              <div className="text-center py-20 text-neutral-400">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4 border border-primary/20">
                  <Bot className="w-8 h-8 text-primary" />
                </div>
                <h2 className="text-xl font-medium text-white mb-2">Welcome to Intelligent Setup</h2>
                <p className="text-sm max-w-md mx-auto">
                  I am here to learn about your business and configure your perfect AI assistant. 
                  Tell me a bit about what you do to get started!
                </p>
              </div>
            ) : (
              history.map((msg, idx) => (
                <div key={idx} className={`flex gap-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {msg.role === 'assistant' && (
                    <div className="w-8 h-8 shrink-0 rounded-full bg-neutral-800 flex items-center justify-center mt-1 border border-white/10">
                      <Bot className="w-4 h-4 text-primary" />
                    </div>
                  )}
                  
                  <div className={`max-w-[85%] md:max-w-[75%] rounded-2xl px-5 py-3.5 shadow-sm ${
                    msg.role === 'user' 
                      ? 'bg-primary text-primary-foreground rounded-br-sm' 
                      : 'bg-neutral-900 text-neutral-100 border border-white/5 rounded-bl-sm'
                  }`}>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                  </div>

                  {msg.role === 'user' && (
                    <div className="w-8 h-8 shrink-0 rounded-full bg-neutral-800 flex items-center justify-center mt-1 border border-white/10">
                      <User className="w-4 h-4 text-white" />
                    </div>
                  )}
                </div>
              ))
            )}
            
            {loading && (
              <div className="flex gap-4 justify-start">
                <div className="w-8 h-8 shrink-0 rounded-full bg-neutral-800 flex items-center justify-center mt-1 border border-white/10">
                  <Bot className="w-4 h-4 text-primary" />
                </div>
                <div className="bg-neutral-900 border border-white/5 rounded-2xl rounded-bl-sm px-5 py-4 flex items-center gap-2 shadow-sm">
                  <div className="w-2 h-2 rounded-full bg-primary/60 animate-bounce" />
                  <div className="w-2 h-2 rounded-full bg-primary/60 animate-bounce delay-75" />
                  <div className="w-2 h-2 rounded-full bg-primary/60 animate-bounce delay-150" />
                </div>
              </div>
            )}
            <div ref={scrollRef} />
          </div>
        </ScrollArea>

        <div className="p-4 bg-neutral-950 border-t border-white/10 shrink-0">
          <form onSubmit={handleSend} className="max-w-3xl mx-auto flex gap-3">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Type your answer here..."
              disabled={loading}
              className="flex-1 bg-neutral-900 border-neutral-800 text-white h-12 md:h-14 rounded-xl px-4 focus-visible:ring-1 focus-visible:ring-primary shadow-inner"
            />
            <Button type="submit" disabled={loading || !inputMessage.trim()} size="icon" className="h-12 w-12 md:h-14 md:w-14 rounded-xl bg-primary hover:bg-primary/90 shrink-0 shadow-lg shadow-primary/20">
              <Send className="w-5 h-5 text-primary-foreground ml-1" />
            </Button>
          </form>
        </div>
      </div>

      <div className="hidden lg:block shrink-0">
        <OnboardingDataPanel sessionState={sessionState} />
      </div>
    </div>
  );
}

export default function OnboardingChatPage() {
  return (
    <ErrorBoundary>
      <ChatContent />
    </ErrorBoundary>
  );
}