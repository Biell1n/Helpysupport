import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Bot, ArrowRight, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

export default function AssistantsListPage() {
  const [assistants, setAssistants] = useState([]);
  const [loadingAssistants, setLoadingAssistants] = useState(true);
  const { error, clearError, signOut } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (error) {
      toast({ 
        title: 'Aviso', 
        description: 'Sua sessão anterior expirou. Você está visualizando como anônimo.', 
        variant: 'destructive' 
      });
      clearError();
      signOut();
    }
  }, [error, toast, clearError, signOut]);

  useEffect(() => {
    async function loadAssistants() {
      try {
        const { data, error } = await supabase
          .from('assistants')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(20);
          
        if (error) throw error;
        setAssistants(data || []);
      } catch (error) {
        console.error('Error loading assistants:', error);
      } finally {
        setLoadingAssistants(false);
      }
    }
    loadAssistants();
  }, []);

  return (
    <>
      <Helmet><title>Assistentes Disponíveis - Helpy</title></Helmet>

      <div className="min-h-screen bg-black">
        <div className="bg-black/80 backdrop-blur-md border-b border-neutral-900 sticky top-0 z-10">
          <div className="container mx-auto px-4 py-4 flex justify-between items-center">
             <Link to="/" className="flex items-center gap-2">
                <div className="bg-white w-8 h-8 rounded-lg flex items-center justify-center">
                   <span className="font-black text-black text-sm">H</span>
                </div>
                <h1 className="text-xl font-bold text-white tracking-tight">Helpy</h1>
             </Link>
             <Link to="/login">
                <Button variant="ghost" className="text-neutral-300 hover:text-white font-medium">
                   Entrar
                </Button>
             </Link>
          </div>
        </div>

        <div className="container mx-auto px-4 py-20">
           <div className="max-w-2xl mx-auto text-center mb-16">
              <h2 className="text-4xl font-bold text-white mb-4">Catálogo de IA</h2>
              <p className="text-lg text-neutral-400 font-light">
                 Interaja com assistentes criados pela comunidade Helpy.
              </p>
           </div>

           {loadingAssistants ? (
             <div className="flex justify-center py-20">
                <Loader2 className="w-12 h-12 text-white animate-spin" />
             </div>
           ) : assistants.length === 0 ? (
             <div className="text-center py-24 bg-neutral-900/30 rounded-[2.5rem] border border-neutral-800">
                <Bot className="w-16 h-16 text-neutral-700 mx-auto mb-6" />
                <h3 className="text-2xl font-bold text-white mb-2">Nenhum assistente público</h3>
             </div>
           ) : (
             <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {assistants.map((assistant, index) => (
                   <motion.div
                      key={assistant.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="bg-neutral-900/40 border border-neutral-800 rounded-3xl overflow-hidden hover:border-white/50 transition-all hover:shadow-[0_10px_30px_rgba(255,255,255,0.05)] hover:-translate-y-1 group"
                   >
                      <div className="p-8">
                         <div className="flex items-start justify-between mb-6">
                            <div className="w-14 h-14 bg-black rounded-2xl flex items-center justify-center border border-neutral-800 group-hover:border-white/30 transition-colors overflow-hidden">
                               {assistant.photo_url ? (
                                  <img src={assistant.photo_url} alt="Avatar" className="w-full h-full object-cover" />
                               ) : (
                                  <Bot className="w-7 h-7 text-neutral-400 group-hover:text-white" />
                               )}
                            </div>
                            <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-neutral-800 text-neutral-300 border border-neutral-700">
                               {assistant.business_type || assistant.personality || 'Geral'}
                            </span>
                         </div>
                         <h3 className="text-2xl font-bold text-white mb-3 line-clamp-1">{assistant.title || assistant.name}</h3>
                         <p className="text-neutral-400 text-base line-clamp-2 mb-8 h-12 font-light">
                            {assistant.description || assistant.extended_description || 'Assistente de atendimento ao cliente.'}
                         </p>
                         <Link to={`/assistant/${assistant.id}`}>
                            <Button className="w-full bg-neutral-800 hover:bg-white hover:text-black text-white border-none rounded-xl py-6 font-bold transition-all">
                               Iniciar Chat <ArrowRight className="w-5 h-5 ml-2" />
                            </Button>
                         </Link>
                      </div>
                   </motion.div>
                ))}
             </div>
           )}
        </div>
      </div>
    </>
  );
}