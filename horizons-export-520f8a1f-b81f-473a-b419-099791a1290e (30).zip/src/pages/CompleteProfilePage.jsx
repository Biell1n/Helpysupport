import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Building2, Phone, FileText, UserCircle, MapPin } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

export default function CompleteProfilePage() {
  const { user, updateProfile, userProfile, completeGoogleSignup } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [videoUrl, setVideoUrl] = useState('');
  
  const isGoogleFlow = location.state?.googleAuth;
  const selectedType = location.state?.selectedType || userProfile?.user_type || 'business_owner';

  const [formData, setFormData] = useState({
    company_name: '',
    full_name: '',
    phone: '',
    description: '',
    address: ''
  });

  useEffect(() => {
    const { data } = supabase.storage.from('landing-videos').getPublicUrl('videofundo.mp4');
    if (data?.publicUrl) {
       setVideoUrl(data.publicUrl);
    }
  }, []);

  useEffect(() => {
    if (userProfile && !isGoogleFlow) {
       setFormData(prev => ({
          ...prev,
          company_name: userProfile.company_name || '',
          full_name: userProfile.full_name || '',
          phone: userProfile.phone || '',
          description: userProfile.description || '',
          address: userProfile.address || ''
       }));
    }
  }, [userProfile, isGoogleFlow]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'phone') {
       const numeric = value.replace(/\D/g, '');
       setFormData(prev => ({ ...prev, [name]: numeric }));
    } else {
       setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (selectedType === 'business' || selectedType === 'business_owner') {
      if (!formData.company_name.trim()) {
        toast({ title: "Campo obrigatório", description: "O nome da empresa é necessário.", variant: "destructive" });
        return;
      }
    } else {
      if (!formData.full_name.trim()) {
        toast({ title: "Campo obrigatório", description: "Seu nome é necessário.", variant: "destructive" });
        return;
      }
    }
    
    if (!acceptedTerms) {
      toast({ title: "Termos obrigatórios", description: "Você deve aceitar os Termos de Uso e Política de Privacidade.", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      
      const profileData = {
         phone: formData.phone,
         user_type: selectedType
      };

      if (selectedType === 'business' || selectedType === 'business_owner') {
         profileData.company_name = formData.company_name;
         profileData.description = formData.description;
      } else {
         profileData.full_name = formData.full_name;
         profileData.address = formData.address;
      }

      if (isGoogleFlow) {
         const result = await completeGoogleSignup(profileData);
         if (!result.success) throw new Error(result.error);
      } else {
         await updateProfile(profileData);
      }
      
      toast({ title: "Perfil completado!", description: "Bem-vindo ao seu dashboard." });
      navigate('/dashboard');
    } catch (error) {
      toast({ title: "Erro", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet><title>Complete seu Perfil - Helpy</title></Helmet>
      
      <div className="relative min-h-screen bg-black flex items-center justify-center p-4 overflow-hidden">
        {videoUrl && (
          <video 
            autoPlay 
            loop 
            muted 
            playsInline
            className="absolute inset-0 w-full h-full object-cover z-0 opacity-40"
          >
            <source src={videoUrl} type="video/mp4" />
          </video>
        )}
        <div className="absolute inset-0 bg-black/60 z-0" />

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }} 
          animate={{ opacity: 1, scale: 1 }} 
          className="w-full max-w-lg bg-neutral-900/80 backdrop-blur-xl border border-neutral-800 rounded-2xl shadow-2xl p-8 relative z-10"
        >
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/20">
               {selectedType === 'business' || selectedType === 'business_owner' ? (
                 <Building2 className="w-8 h-8 text-white" />
               ) : (
                 <UserCircle className="w-8 h-8 text-white" />
               )}
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Finalize seu Cadastro</h1>
            <p className="text-neutral-400">
              {selectedType === 'business' || selectedType === 'business_owner' 
                ? "Precisamos de algumas informações sobre sua empresa." 
                : "Precisamos de algumas informações para completar seu perfil."}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {(selectedType === 'business' || selectedType === 'business_owner') ? (
              <>
                <div className="space-y-2">
                  <Label htmlFor="company_name" className="text-neutral-300">Nome da Empresa <span className="text-neutral-500">*</span></Label>
                  <div className="relative">
                     <Building2 className="absolute left-3 top-3 w-5 h-5 text-neutral-500" />
                     <Input 
                       id="company_name" 
                       name="company_name" 
                       value={formData.company_name} 
                       onChange={handleChange} 
                       className="bg-neutral-950/50 border-neutral-800 pl-10 text-white focus:border-white focus:ring-1 focus:ring-white" 
                       placeholder="Ex: Tech Solutions Ltda"
                       required
                     />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-neutral-300">Telefone (Opcional)</Label>
                  <div className="relative">
                     <Phone className="absolute left-3 top-3 w-5 h-5 text-neutral-500" />
                     <Input 
                       id="phone" 
                       name="phone" 
                       type="tel"
                       value={formData.phone} 
                       onChange={handleChange} 
                       className="bg-neutral-950/50 border-neutral-800 pl-10 text-white focus:border-white focus:ring-1 focus:ring-white" 
                       placeholder="Apenas números"
                     />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description" className="text-neutral-300">Descrição da Empresa (Opcional)</Label>
                  <div className="relative">
                     <FileText className="absolute left-3 top-3 w-5 h-5 text-neutral-500" />
                     <Textarea 
                       id="description" 
                       name="description" 
                       value={formData.description} 
                       onChange={handleChange} 
                       className="bg-neutral-950/50 border-neutral-800 pl-10 min-h-[100px] text-white focus:border-white focus:ring-1 focus:ring-white" 
                       placeholder="O que sua empresa faz?"
                     />
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="space-y-2">
                  <Label htmlFor="full_name" className="text-neutral-300">Nome Completo <span className="text-neutral-500">*</span></Label>
                  <div className="relative">
                     <UserCircle className="absolute left-3 top-3 w-5 h-5 text-neutral-500" />
                     <Input 
                       id="full_name" 
                       name="full_name" 
                       value={formData.full_name} 
                       onChange={handleChange} 
                       className="bg-neutral-950/50 border-neutral-800 pl-10 text-white focus:border-white focus:ring-1 focus:ring-white" 
                       placeholder="Seu nome completo"
                       required
                     />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-neutral-300">Telefone (Opcional)</Label>
                  <div className="relative">
                     <Phone className="absolute left-3 top-3 w-5 h-5 text-neutral-500" />
                     <Input 
                       id="phone" 
                       name="phone" 
                       type="tel"
                       value={formData.phone} 
                       onChange={handleChange} 
                       className="bg-neutral-950/50 border-neutral-800 pl-10 text-white focus:border-white focus:ring-1 focus:ring-white" 
                       placeholder="Apenas números"
                     />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address" className="text-neutral-300">Endereço (Opcional)</Label>
                  <div className="relative">
                     <MapPin className="absolute left-3 top-3 w-5 h-5 text-neutral-500" />
                     <Input 
                       id="address" 
                       name="address" 
                       value={formData.address} 
                       onChange={handleChange} 
                       className="bg-neutral-950/50 border-neutral-800 pl-10 text-white focus:border-white focus:ring-1 focus:ring-white" 
                       placeholder="Seu endereço"
                     />
                  </div>
                </div>
              </>
            )}

            <div className="flex items-start space-x-3 pt-2">
              <input 
                type="checkbox" 
                id="terms" 
                checked={acceptedTerms} 
                onChange={(e) => setAcceptedTerms(e.target.checked)} 
                className="mt-1 w-4 h-4 rounded border-neutral-800 bg-neutral-950 text-white focus:ring-white focus:ring-offset-neutral-900 accent-white" 
              />
              <Label htmlFor="terms" className="text-sm text-neutral-400 font-normal leading-tight">
                Aceito os <Link to="/terms" className="text-white hover:underline font-medium">Termos de Uso</Link> e <Link to="/privacy" className="text-white hover:underline font-medium">Política de Privacidade</Link>
              </Label>
            </div>

            <Button type="submit" disabled={loading || !acceptedTerms} className="w-full bg-white hover:bg-neutral-200 text-black font-bold py-6 text-lg disabled:opacity-50 disabled:hover:bg-white">
               {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Concluir Cadastro"}
            </Button>
          </form>
        </motion.div>
      </div>
    </>
  );
}