import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Check, Shield, Users, Zap, ArrowRight, Loader2 } from 'lucide-react';
import Navigation from '@/components/Navigation';
import { useAuth } from '@/contexts/AuthContext';
import Footer from '@/components/Footer';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

export default function HomePage() {
  const navigate = useNavigate();
  const { isAuthenticated, isBusinessOwner, userProfile, error, signOut, clearError, loading } = useAuth();
  const [videoUrl, setVideoUrl] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const { data } = supabase.storage.from('landing-videos').getPublicUrl('videofundo.mp4');
    if (data?.publicUrl) {
       setVideoUrl(data.publicUrl);
    }
  }, []);

  useEffect(() => {
    if (error) {
      toast({ 
        title: 'Aviso', 
        description: 'Sua sessão anterior expirou.', 
        variant: 'destructive' 
      });
      clearError();
      signOut();
    }
  }, [error, toast, clearError, signOut]);

  const features = [
    {
      icon: <Shield className="w-8 h-8" />,
      title: 'Segurança Avançada',
      description: 'Seus dados protegidos com criptografia de ponta e autenticação em duas etapas.'
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: 'Gestão Completa',
      description: 'Painel de controle intuitivo para gerenciar todos os aspectos da sua conta.'
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'Performance Rápida',
      description: 'Infraestrutura otimizada para garantir velocidade e confiabilidade.'
    }
  ];

  const plans = [
    {
      name: 'Starter',
      price: 'Grátis',
      period: 'para sempre',
      features: [
        'Acesso ao dashboard',
        'Gerenciamento de perfil',
        'Suporte básico',
        'Armazenamento seguro'
      ],
      cta: 'Começar Agora',
      highlighted: false
    },
    {
      name: 'Premium',
      price: 'R$ 49,90',
      period: '/mês',
      features: [
        'Todos os recursos do Starter',
        'Recursos avançados',
        'Suporte prioritário',
        'Armazenamento ilimitado',
        'Análises detalhadas'
      ],
      cta: 'Assinar Premium',
      highlighted: true
    }
  ];

  const handleGetStarted = () => {
    if (!isAuthenticated) {
      navigate('/auth', { state: { view: 'signup' } });
    } else if (isBusinessOwner || userProfile?.user_type === 'business') {
      navigate('/dashboard');
    } else if (userProfile?.user_type === 'pending') {
      navigate('/complete-cadastro');
    } else {
      navigate('/dashboard');
    }
  };

  let mainButtonText = "Começar";
  if (isAuthenticated) {
    if (userProfile?.user_type === 'pending') {
      mainButtonText = "Completar Cadastro";
    } else {
      mainButtonText = "Acessar Dashboard";
    }
  }

  return (
    <>
      <Helmet>
        <title>Helpy - Plataforma de Gestão Empresarial</title>
        <meta name="description" content="A plataforma completa para gerenciar seu negócio com segurança, eficiência e controle total." />
      </Helmet>

      <div className="min-h-screen bg-black text-white">
        <Navigation />

        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
           {videoUrl && (
             <video 
               autoPlay 
               loop 
               muted 
               playsInline
               className="absolute inset-0 w-full h-full object-cover z-0"
             >
               <source src={videoUrl} type="video/mp4" />
             </video>
           )}
           
           <div className="absolute inset-0 bg-black/70 z-10" />
           <div className="absolute inset-0 bg-gradient-to-b from-black/90 via-transparent to-black z-10" />

           <motion.div 
             animate={{ rotate: 360 }} 
             transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
             className="absolute top-1/4 -right-20 w-96 h-96 border border-white/5 rounded-full z-10 pointer-events-none"
           />
           <motion.div 
             animate={{ rotate: -360 }} 
             transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
             className="absolute -bottom-20 -left-20 w-[500px] h-[500px] border border-neutral-500/10 rounded-full z-10 pointer-events-none"
           />

          <div className="container mx-auto px-4 relative z-20 pt-20">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="text-center max-w-5xl mx-auto"
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="inline-block mb-6"
              >
                <div className="bg-white/10 backdrop-blur-2xl rounded-full px-6 py-2 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
                  <span className="text-white font-medium flex items-center gap-2 text-sm uppercase tracking-widest">
                    <Shield className="w-4 h-4" />
                    Plataforma Empresarial
                  </span>
                </div>
              </motion.div>

              <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold mb-8 tracking-tighter leading-[1.1]">
                GESTÃO COMPLETA <br/>
                <span className="text-white">
                  PARA SEU NEGÓCIO
                </span>
              </h1>

              <p className="text-xl md:text-2xl text-neutral-400 mb-12 max-w-3xl mx-auto font-light leading-relaxed">
                A Helpy é a plataforma definitiva para gerenciar seu negócio. Segurança, eficiência e controle total em um único lugar.
              </p>

              <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
                {loading ? (
                  <Button
                    size="lg"
                    disabled
                    className="bg-white/20 text-white font-bold text-lg px-10 py-7 h-auto rounded-full border-none shadow-none"
                  >
                    <Loader2 className="w-5 h-5 mr-3 animate-spin" />
                    Carregando...
                  </Button>
                ) : (
                  <Button
                    size="lg"
                    onClick={handleGetStarted}
                    className="bg-white hover:bg-neutral-200 text-black font-bold text-lg px-10 py-7 h-auto rounded-full shadow-[0_0_40px_rgba(255,255,255,0.2)] hover:shadow-[0_0_60px_rgba(255,255,255,0.3)] transition-all hover:scale-105 border-none"
                  >
                    {mainButtonText}
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                )}
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-white/5 backdrop-blur-2xl border-none text-white hover:bg-white/10 hover:text-white text-lg px-10 py-7 h-auto rounded-full transition-all"
                >
                  Saiba Mais
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        <section id="features" className="py-32 px-4 bg-black relative">
          <div className="container mx-auto max-w-6xl relative z-10">
            <div className="text-center mb-20">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
                Recursos que Fazem a Diferença
              </h2>
              <p className="text-xl text-neutral-400 max-w-2xl mx-auto">
                Ferramentas profissionais para elevar o nível da sua gestão empresarial.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="group bg-white/5 backdrop-blur-2xl rounded-3xl p-10 hover:bg-white/10 transition-all duration-500 hover:shadow-[0_10px_40px_rgba(255,255,255,0.05)] hover:-translate-y-1"
                >
                  <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center mb-6 text-white group-hover:scale-110 transition-transform">
                    {feature.icon}
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-white transition-colors">{feature.title}</h3>
                  <p className="text-neutral-400 text-lg leading-relaxed">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section id="pricing" className="py-32 px-4 bg-black relative overflow-hidden">
           <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-white/5 blur-[150px] rounded-full pointer-events-none" />
           
          <div className="container mx-auto max-w-5xl relative z-10">
            <div className="text-center mb-20">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
                Planos Transparentes
              </h2>
              <p className="text-xl text-neutral-400">
                Escolha o plano ideal para o seu negócio.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-center">
              {plans.map((plan, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  className={`relative rounded-[2.5rem] p-10 md:p-12 transition-all duration-500 ${
                    plan.highlighted
                      ? 'bg-white/10 backdrop-blur-3xl shadow-[0_20px_50px_rgba(255,255,255,0.1)] md:scale-105 z-10'
                      : 'bg-white/5 backdrop-blur-2xl hover:bg-white/10'
                  }`}
                >
                  {plan.highlighted && (
                    <div className="absolute -top-5 left-1/2 -translate-x-1/2 bg-white text-black px-6 py-2 rounded-full text-sm font-bold tracking-wide uppercase shadow-lg">
                      Mais Escolhido
                    </div>
                  )}

                  <h3 className="text-3xl font-bold mb-2 text-white">{plan.name}</h3>
                  <div className="mb-8 pb-8 border-b border-white/10">
                    <span className="text-5xl font-bold text-white">{plan.price}</span>
                    <span className="text-neutral-500 ml-2">{plan.period}</span>
                  </div>

                  <ul className="space-y-5 mb-10">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-4 text-neutral-300">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${plan.highlighted ? 'bg-white/20 text-white' : 'bg-white/10 text-neutral-400'}`}>
                           <Check className="w-3.5 h-3.5" />
                        </div>
                        <span className="text-lg">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    onClick={handleGetStarted}
                    disabled={loading}
                    className={`w-full py-7 text-lg font-bold rounded-full transition-all border-none ${
                      plan.highlighted
                        ? 'bg-white hover:bg-neutral-200 text-black shadow-[0_0_20px_rgba(255,255,255,0.2)] disabled:bg-white/50 disabled:text-black/50'
                        : 'bg-white/10 hover:bg-white/20 text-white disabled:bg-white/5 disabled:text-white/50'
                    }`}
                  >
                    {loading ? (
                       <span className="flex items-center justify-center">
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Carregando...
                       </span>
                    ) : (
                       plan.cta
                    )}
                  </Button>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}