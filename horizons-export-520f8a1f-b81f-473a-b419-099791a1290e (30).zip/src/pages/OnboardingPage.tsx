// This file is deprecated in favor of OnboardingPage.jsx. 
// Do not use this file. All logic has been migrated to the .jsx version.
export default function DeprecatedOnboarding() {
  return null;
}