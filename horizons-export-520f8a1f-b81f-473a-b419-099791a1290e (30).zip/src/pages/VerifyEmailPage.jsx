// ============================================================
// HELPY — VerifyEmailPage v2 — ARQUIVO COMPLETO
// Toda a tela vive em TelaCodigo. Aqui só o que é específico.
// ============================================================

import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import TelaCodigo from '@/components/TelaCodigo';

export default function VerifyEmailPage() {
  const navigate = useNavigate();
  const { user, isEmailVerified, sendVerificationCode, verifyCode, logout } = useAuth();

  // Já verificado, ou sem sessão: não há o que fazer aqui.
  useEffect(() => {
    if (isEmailVerified) navigate('/dashboard', { replace: true });
    else if (!user) navigate('/auth', { replace: true });
  }, [isEmailVerified, user, navigate]);

  return (
    <TelaCodigo
      eyebrow="Confirmar e-mail"
      titulo="Confirme seu e-mail."
      descricao="Enviamos um código de seis dígitos para"
      destino={user?.email}
      onVerificar={async (codigo) => {
        const r = await verifyCode(codigo);
        if (r?.success !== false) navigate('/dashboard', { replace: true });
        return r;
      }}
      onReenviar={() => sendVerificationCode()}
      onVoltar={() => logout?.()}
      rotuloVoltar="sair"
      nota="Se não chegou em alguns minutos, confira a caixa de spam. O código vale por dez minutos."
    />
  );
}