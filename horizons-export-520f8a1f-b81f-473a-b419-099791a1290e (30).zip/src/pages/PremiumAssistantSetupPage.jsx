import React, { useState, useRef, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Bot, Send, ArrowRight, Sparkles, FileText } from 'lucide-react';
import Navigation from '@/components/Navigation';
import { useAuth } from '@/contexts/AuthContext';
import { db } from '@/lib/supabase';
import { getChatCompletion } from '@/lib/openai';
import { buildInterviewerPrompt, extractBusinessDataPrompt } from '@/lib/assistantPrompt';
import { useToast } from '@/components/ui/use-toast';

export default function PremiumAssistantSetupPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [phase, setPhase] = useState(1);
  const [loading, setLoading] = useState(false);
  const [chatLoading, setChatLoading] = useState(false);
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Olá! Vou ajudar você a configurar seu assistente Premium. Para começar, qual é o nome do seu negócio?' }
  ]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef(null);

  const [formData, setFormData] = useState({
    business_name: '',
    industry: '',
    humor_type: 'professional',
    description: '',
    pdf_url: null
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim() || chatLoading) return;

    const userMsg = { role: 'user', content: input };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setChatLoading(true);

    try {
      const systemPrompt = buildInterviewerPrompt(newMessages);
      const aiResponse = await getChatCompletion(newMessages, systemPrompt);
      
      setMessages([...newMessages, { role: 'assistant', content: aiResponse }]);
    } catch (error) {
      console.error(error);
      toast({ title: 'Erro', description: 'Falha ao obter resposta da IA', variant: 'destructive' });
    } finally {
      setChatLoading(false);
    }
  };

  const handleFinishChat = async () => {
    setLoading(true);
    try {
      const extractionPrompt = extractBusinessDataPrompt(messages);
      const extractionResponse = await getChatCompletion([], extractionPrompt);
      
      let extractedData = {};
      try {
        extractedData = JSON.parse(extractionResponse);
      } catch (e) {
        console.error("JSON parse failed", e);
      }

      setFormData(prev => ({
        ...prev,
        business_name: extractedData.business_name || '',
        industry: extractedData.industry || '',
        description: extractedData.description || ''
      }));

      setPhase(2);
    } catch (error) {
      console.error(error);
      setPhase(2); 
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const uniqueLink = crypto.randomUUID();
      
      const assistantData = {
        owner_id: user.id,
        business_name: formData.business_name,
        industry: formData.industry,
        plan_type: 'premium',
        humor_type: formData.humor_type,
        extended_description: formData.description,
        chat_history: messages,
        unique_link: uniqueLink,
      };

      await db.createAssistant(assistantData);
      
      toast({ title: 'Sucesso!', description: 'Seu assistente Premium foi criado.' });
      navigate(`/assistant/${uniqueLink}`);
    } catch (error) {
      toast({ title: 'Erro', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Setup Premium - ChatSupport AI</title>
      </Helmet>

      <div className="min-h-screen bg-black flex flex-col">
        <Navigation />

        <div className="flex-1 container mx-auto px-4 pt-24 pb-12 max-w-4xl">
          <AnimatePresence mode="wait">
            {phase === 1 ? (
              <motion.div
                key="chat"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="h-[600px] flex flex-col bg-neutral-900/50 rounded-2xl overflow-hidden shadow-2xl"
              >
                <div className="p-4 bg-neutral-900/80 backdrop-blur-md flex justify-between items-center shadow-md z-10">
                  <div className="flex items-center gap-3">
                    <div className="bg-white/10 p-2 rounded-lg">
                      <Sparkles className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h2 className="font-bold text-white">Coleta Inteligente</h2>
                      <p className="text-xs text-neutral-400">IA analisando seu negócio</p>
                    </div>
                  </div>
                  {messages.length > 3 && (
                    <Button onClick={handleFinishChat} disabled={loading} className="bg-white text-black font-bold hover:bg-neutral-200 border-none ring-0 outline-none">
                      {loading ? 'Processando...' : 'Continuar para Setup'} <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                  )}
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-neutral-950/30">
                  {messages.map((msg, idx) => (
                    <div key={idx} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                      {msg.role === 'assistant' && (
                        <div className="w-8 h-8 rounded-full bg-neutral-800 flex items-center justify-center flex-shrink-0 shadow-inner">
                          <Bot className="w-4 h-4 text-white" />
                        </div>
                      )}
                      <div className={`max-w-[80%] p-4 rounded-2xl shadow-md ${
                        msg.role === 'user' 
                          ? 'bg-white text-black font-medium rounded-tr-none' 
                          : 'bg-neutral-800 text-neutral-200 rounded-tl-none'
                      }`}>
                        {msg.content}
                      </div>
                    </div>
                  ))}
                  {chatLoading && (
                     <div className="flex gap-3">
                        <div className="w-8 h-8 rounded-full bg-neutral-800 flex items-center justify-center shadow-inner">
                          <Bot className="w-4 h-4 text-white" />
                        </div>
                        <div className="bg-neutral-800 p-4 rounded-2xl rounded-tl-none flex gap-1 items-center shadow-md">
                           <span className="w-2 h-2 bg-neutral-500 rounded-full animate-bounce"></span>
                           <span className="w-2 h-2 bg-neutral-500 rounded-full animate-bounce delay-100"></span>
                           <span className="w-2 h-2 bg-neutral-500 rounded-full animate-bounce delay-200"></span>
                        </div>
                     </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                <div className="p-4 bg-neutral-900/80 backdrop-blur-md shadow-[0_-10px_30px_rgba(0,0,0,0.5)] z-10">
                  <form onSubmit={handleSendMessage} className="flex gap-2">
                    <input
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder="Responda aqui..."
                      className="flex-1 bg-neutral-950 rounded-xl px-4 py-3 text-white border-none shadow-inner focus:outline-none focus:ring-0"
                    />
                    <Button type="submit" disabled={chatLoading} className="bg-white hover:bg-neutral-200 text-black font-bold h-auto border-none ring-0 outline-none">
                      <Send className="w-5 h-5" />
                    </Button>
                  </form>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="form"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-neutral-900/50 rounded-2xl p-8 shadow-2xl"
              >
                <h1 className="text-3xl font-bold text-white mb-6">Confirmar Detalhes</h1>
                
                <form onSubmit={handleCreate} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-neutral-300 mb-2">Nome do Negócio</label>
                      <input
                        value={formData.business_name}
                        onChange={(e) => setFormData({...formData, business_name: e.target.value})}
                        className="w-full px-4 py-3 bg-neutral-950 rounded-lg text-white border-none shadow-inner focus:outline-none focus:ring-0"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-neutral-300 mb-2">Indústria</label>
                      <input
                        value={formData.industry}
                        onChange={(e) => setFormData({...formData, industry: e.target.value})}
                        className="w-full px-4 py-3 bg-neutral-950 rounded-lg text-white border-none shadow-inner focus:outline-none focus:ring-0"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-2">Descrição do Negócio (Extraída do Chat)</label>
                    <textarea
                      rows={5}
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      className="w-full px-4 py-3 bg-neutral-950 rounded-lg text-white border-none shadow-inner focus:outline-none focus:ring-0"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-2">Personalidade</label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {['professional', 'friendly', 'casual', 'humorous'].map(type => (
                        <div
                          key={type}
                          onClick={() => setFormData({...formData, humor_type: type})}
                          className={`cursor-pointer p-4 rounded-xl text-center transition-all bg-neutral-950 shadow-md ${
                            formData.humor_type === type 
                              ? 'bg-white/10 text-white font-medium shadow-inner' 
                              : 'text-neutral-400 hover:bg-neutral-800'
                          }`}
                        >
                          <span className="capitalize">{type}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                   <div className="bg-neutral-950 rounded-xl p-8 text-center hover:bg-neutral-900 transition-colors shadow-inner cursor-pointer">
                    <div className="flex flex-col items-center gap-2 text-neutral-400">
                      <FileText className="w-8 h-8" />
                      <span className="font-medium text-white">Upload de PDF (Opcional)</span>
                      <span className="text-xs text-neutral-500">Documentação técnica, manuais, etc.</span>
                    </div>
                  </div>

                  <Button type="submit" disabled={loading} className="w-full bg-white hover:bg-neutral-200 text-black font-bold py-6 text-lg border-none shadow-lg ring-0 outline-none">
                    {loading ? 'Criando Assistente...' : 'Finalizar e Criar'}
                  </Button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </>
  );
}