import React, { useState, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Loader2, LogIn } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import ForgotPasswordModal from '@/components/ForgotPasswordModal';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = useCallback(async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const result = await login(email, password);
      
      if (result.success) {
         if (result.requiresVerification) {
            toast({ title: "Login realizado", description: "Redirecionando..." });
            navigate('/dashboard'); 
         } else {
            navigate('/dashboard');
         }
      } else {
         toast({ title: "Erro de login", description: "Verifique suas credenciais.", variant: "destructive" });
      }
    } catch (error) {
       console.error(error);
       toast({ title: "Erro inesperado", description: "Ocorreu um erro ao tentar fazer login.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [email, password, login, navigate, toast]);

  return (
    <>
      <Helmet><title>Login - ChatSupport AI</title></Helmet>
      
      <div className="min-h-screen bg-black flex items-center justify-center p-4 relative overflow-hidden">
        {/* Background blobs */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-purple-900/20 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-blue-900/10 rounded-full blur-[120px] pointer-events-none" />

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md bg-neutral-900/80 backdrop-blur-xl border border-neutral-800 rounded-2xl p-8 shadow-2xl relative z-10"
        >
          <Button 
            variant="ghost" 
            className="absolute top-4 left-4 p-2 text-neutral-400 hover:text-white"
            onClick={() => navigate('/auth')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>

          <div className="text-center mb-8 mt-6">
            <h1 className="text-2xl font-bold text-white mb-2">Bem-vindo</h1>
            <p className="text-neutral-400">Entre na sua conta para continuar</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-neutral-300">Email</Label>
              <Input 
                id="email" 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-neutral-950 border-neutral-800 text-white focus:border-purple-500 transition-colors"
                placeholder="seu@email.com"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-neutral-300">Senha</Label>
                <button 
                  type="button"
                  onClick={() => setIsForgotModalOpen(true)}
                  className="text-xs text-purple-400 hover:text-purple-300 bg-transparent border-none p-0 cursor-pointer"
                >
                  Esqueceu a senha?
                </button>
              </div>
              <Input 
                id="password" 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="bg-neutral-950 border-neutral-800 text-white focus:border-purple-500 transition-colors"
                placeholder="••••••••"
              />
            </div>

            <Button type="submit" disabled={loading} className="w-full bg-purple-600 hover:bg-purple-700 text-white py-6">
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Entrar"}
            </Button>
          </form>

          <div className="mt-8 text-center text-sm text-neutral-500">
            Não tem conta?{' '}
            <Link to="/signup" className="text-purple-400 hover:text-purple-300 font-medium">
              Cadastre-se
            </Link>
          </div>
        </motion.div>
      </div>

      <ForgotPasswordModal 
        isOpen={isForgotModalOpen} 
        onClose={() => setIsForgotModalOpen(false)} 
      />
    </>
  );
}