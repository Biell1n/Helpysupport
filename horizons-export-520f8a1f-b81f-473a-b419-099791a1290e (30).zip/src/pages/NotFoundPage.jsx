import React from 'react';
import { Link } from 'react-router-dom';
import { Ghost } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function NotFoundPage() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4">
      <div className="text-center max-w-md">
        <div className="bg-neutral-900 w-24 h-24 rounded-3xl flex items-center justify-center mx-auto mb-8 border border-neutral-800">
          <Ghost className="w-12 h-12 text-purple-500" />
        </div>
        
        <h1 className="text-4xl font-bold text-white mb-4">404 - Página Não Encontrada</h1>
        <p className="text-neutral-400 mb-8 text-lg">
          O link que você tentou acessar não existe ou foi movido.
        </p>
        
        <Link to="/">
          <Button className="bg-primary hover:bg-primary/90 text-white px-8 py-6">
            Voltar para Início
          </Button>
        </Link>
      </div>
    </div>
  );
}