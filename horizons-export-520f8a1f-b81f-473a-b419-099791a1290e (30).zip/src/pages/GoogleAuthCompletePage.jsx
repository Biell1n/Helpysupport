import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate, useLocation, Navigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { UserCircle, Building2, ArrowLeft } from 'lucide-react';
import GoogleAuthClientForm from '@/components/GoogleAuthClientForm';
import GoogleAuthCompanyForm from '@/components/GoogleAuthCompanyForm';

export default function GoogleAuthCompletePage() {
  const [selectedType, setSelectedType] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();

  const isGoogleAuth = location.state?.email && location.state?.userId;

  if (!isGoogleAuth) {
    return <Navigate to="/auth" replace />;
  }

  return (
    <>
      <Helmet>
        <title>Finalizar Cadastro - Helpy</title>
      </Helmet>

      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="w-full max-w-md mx-auto">
          <AnimatePresence mode="wait">
            {!selectedType ? (
              <motion.div
                key="selection"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <div className="text-center mb-10">
                  <h1 className="text-4xl font-bold text-white mb-4">Você é Cliente ou Empresa?</h1>
                  <p className="text-neutral-400 text-lg">
                    Selecione seu perfil para concluir o cadastro.
                  </p>
                </div>

                <div className="space-y-4">
                  <Button
                    onClick={() => setSelectedType('cliente')}
                    className="w-full py-8 text-lg font-bold bg-neutral-900 text-white hover:bg-neutral-800 transition-all rounded-xl border border-neutral-800 flex items-center justify-start px-6 gap-4 h-auto"
                  >
                    <UserCircle className="w-8 h-8 text-neutral-400 shrink-0" />
                    <div className="text-left">
                      <div className="text-white">Sou Cliente</div>
                      <div className="text-sm text-neutral-500 font-normal">Quero conversar com assistentes</div>
                    </div>
                  </Button>

                  <Button
                    onClick={() => setSelectedType('empresa')}
                    className="w-full py-8 text-lg font-bold bg-neutral-900 text-white hover:bg-neutral-800 transition-all rounded-xl border border-neutral-800 flex items-center justify-start px-6 gap-4 h-auto"
                  >
                    <Building2 className="w-8 h-8 text-neutral-400 shrink-0" />
                    <div className="text-left">
                      <div className="text-white">Sou Empresa</div>
                      <div className="text-sm text-neutral-500 font-normal">Quero criar e gerenciar assistentes</div>
                    </div>
                  </Button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="form"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedType(null)} 
                  className="mb-8 p-0 text-neutral-400 hover:text-white hover:bg-transparent flex items-center gap-2"
                >
                  <ArrowLeft className="w-5 h-5" /> Voltar
                </Button>
                
                <h1 className="text-3xl font-bold text-white mb-2">
                  {selectedType === 'cliente' ? 'Conta Cliente' : 'Conta Empresa'}
                </h1>
                <p className="text-neutral-400 mb-8">
                  Falta pouco! Preencha os dados abaixo.
                </p>

                {selectedType === 'cliente' ? (
                  <GoogleAuthClientForm />
                ) : (
                  <GoogleAuthCompanyForm />
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </>
  );
}