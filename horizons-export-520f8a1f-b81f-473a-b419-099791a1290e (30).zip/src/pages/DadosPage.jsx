// ============================================================
// HELPY — DadosPage v2 — ARQUIVO COMPLETO
// Rota: /dashboard/dados
//
// Reescrita. O que mudou:
//
//  1. Os estilos vivem DENTRO do componente. Na v1 dependiam de um CSS
//     colado à mão noutro arquivo — se não fosse colado, a grade perdia
//     o estilo e as células paravam de funcionar.
//  2. A grade virou grade de verdade: letra na coluna, número na linha,
//     célula selecionada, Tab e setas navegam, Enter desce.
//  3. O editor de coluna ganhou chave primária, única, valor padrão e
//     chave estrangeira, que é o que permite ligar tabelas.
// ============================================================

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import ConfirmDialog from '@/components/builder/ConfirmDialog';

const TIPOS = [
  { v: 'texto', r: 'Texto', d: 'Qualquer texto curto. Nome, categoria, cor.' },
  { v: 'texto_longo', r: 'Texto longo', d: 'Descrição, observação, um parágrafo.' },
  { v: 'numero', r: 'Número', d: 'Quantidade, estoque, peso.' },
  { v: 'moeda', r: 'Valor', d: 'Preço. Exibido com R$.' },
  { v: 'data', r: 'Data', d: 'Dia, mês e ano.' },
  { v: 'selecao', r: 'Escolha', d: 'Uma opção de uma lista que você define.' },
  { v: 'booleano', r: 'Sim ou não', d: 'Marcado ou desmarcado.' },
];

const LETRAS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const letraDe = (i) => (i < 26 ? LETRAS[i] : LETRAS[Math.floor(i / 26) - 1] + LETRAS[i % 26]);

const chavear = (s) =>
  String(s ?? '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 40);

// ============================================================
// Estilos. Ficam aqui de propósito: assim a tela não depende de
// nenhum CSS ser colado no lugar certo.
// ============================================================
const CSS = `
.dd { --l:#1A1A1E; --l2:#26262C; --ink:#F4F4F6; --ink2:#8E8E9A; --ink3:#57575F;
      --ac:#8A9BC4; --bg:#08080A; --head:#101014;
      font-family:'Manrope',system-ui,sans-serif; font-weight:300;
      background:var(--bg); color:var(--ink); min-height:100vh; }
.dd-lbl { font-size:.625rem; font-weight:500; letter-spacing:.18em; text-transform:uppercase; color:var(--ink3); }

.dd-bar { position:sticky; top:0; z-index:40; height:4.5rem; display:flex; align-items:center;
          justify-content:space-between; padding:0 3rem; background:var(--bg); border-bottom:1px solid var(--l); }
.dd-brand { font-size:1rem; font-weight:500; letter-spacing:.02em; }
.dd-brand b { font-weight:500; color:var(--ink3); }
.dd-bar-r { display:flex; align-items:center; gap:2rem; }
.dd-nav { font-size:.6875rem; font-weight:500; letter-spacing:.14em; text-transform:uppercase;
          background:none; border:none; padding:0; cursor:pointer; color:var(--ink2); transition:color .2s; }
.dd-nav:hover { color:var(--ink); }

.dd-btn { font-family:inherit; font-size:.6875rem; font-weight:500; letter-spacing:.12em; text-transform:uppercase;
          display:inline-flex; align-items:center; gap:.5rem; padding:.75rem 1.25rem;
          border:1px solid var(--l2); background:none; color:var(--ink2); cursor:pointer;
          transition:color .2s,border-color .2s,background .2s; white-space:nowrap; }
.dd-btn:hover:not(:disabled) { color:var(--ink); border-color:var(--ink3); }
.dd-btn:disabled { opacity:.35; cursor:not-allowed; }
.dd-btn--solid { background:var(--ink); border-color:var(--ink); color:var(--bg); }
.dd-btn--solid:hover:not(:disabled) { background:#fff; border-color:#fff; color:var(--bg); }
.dd-btn--sm { padding:.5rem .75rem; font-size:.625rem; letter-spacing:.1em; }
.dd-btn--kill:hover { color:#C96A6A; border-color:#C96A6A; }

.dd-wrap { padding:3rem; }
.dd-h1 { font-size:2.25rem; font-weight:200; letter-spacing:-.03em; margin:.75rem 0 0; line-height:1.05; }
.dd-h1 em { font-style:normal; color:var(--ink3); }
.dd-sub { font-size:.8125rem; color:var(--ink2); margin:1rem 0 0; max-width:38rem; line-height:1.6; }

.dd-split { display:grid; grid-template-columns:14rem 1fr; gap:0; margin-top:3.5rem; align-items:start; }
.dd-side { border-right:1px solid var(--l); padding-right:1.5rem; }
.dd-side-i { display:block; width:100%; text-align:left; font-family:inherit; background:none; border:none;
             border-bottom:1px solid var(--l); padding:1rem 0; cursor:pointer; color:var(--ink2); transition:color .2s; }
.dd-side-i:hover, .dd-side-i[data-on='true'] { color:var(--ink); }
.dd-side-n { font-size:.9375rem; font-weight:300; display:block; letter-spacing:-.01em; }
.dd-side-c { font-size:.625rem; letter-spacing:.14em; text-transform:uppercase; color:var(--ink3); margin-top:.3125rem; display:block; }
.dd-main { padding-left:2rem; min-width:0; }

.dd-tools { display:flex; align-items:center; gap:.5rem; flex-wrap:wrap; margin:1.5rem 0; }
.dd-in { font-family:inherit; font-size:.8125rem; font-weight:300; color:var(--ink); background:none;
         border:none; border-bottom:1px solid var(--l2); padding:.4375rem 0; outline:none; transition:border-color .2s; }
.dd-in:focus { border-bottom-color:var(--ink); }
.dd-in::placeholder { color:var(--ink3); }
.dd-sel { font-family:inherit; font-size:.8125rem; font-weight:300; color:var(--ink); background:none;
          border:none; border-bottom:1px solid var(--l2); padding:.4375rem 0; outline:none; cursor:pointer; }
.dd-sel option { background:#131318; }

/* ---------- a grade ---------- */
.dd-grid-wrap { overflow:auto; border:1px solid var(--l); max-height:64vh; }
.dd-grid { border-collapse:collapse; font-size:.8125rem; width:max-content; min-width:100%; }
.dd-grid th, .dd-grid td { border-right:1px solid var(--l); border-bottom:1px solid var(--l); padding:0; }

/* faixa das letras */
.dd-letra { background:var(--head); color:var(--ink3); font-size:.625rem; font-weight:500;
            letter-spacing:.1em; text-align:center; height:1.5rem; position:sticky; top:0; z-index:3; }
/* cabeçalho com o nome */
.dd-th { background:var(--head); position:sticky; top:1.5rem; z-index:3; min-width:9rem; }
.dd-th-b { width:100%; background:none; border:none; cursor:pointer; font-family:inherit; text-align:left;
           padding:.75rem .75rem; color:var(--ink2); transition:color .2s; }
.dd-th-b:hover { color:var(--ink); }
.dd-th-nome { font-size:.75rem; font-weight:500; display:block; }
.dd-th-tipo { font-size:.5625rem; letter-spacing:.1em; text-transform:uppercase; color:var(--ink3); margin-top:.1875rem; display:block; }
.dd-th-pk { color:var(--ac); }

/* coluna do número da linha */
.dd-num { background:var(--head); color:var(--ink3); font-size:.6875rem; text-align:center;
          width:3rem; min-width:3rem; position:sticky; left:0; z-index:2; font-variant-numeric:tabular-nums; }
.dd-canto { background:var(--head); position:sticky; left:0; top:0; z-index:4; width:3rem; }

.dd-cel { width:100%; background:none; border:none; outline:none; font-family:inherit;
          font-size:.8125rem; font-weight:300; color:var(--ink); padding:.625rem .75rem; }
.dd-cel:focus { background:rgba(138,155,196,.08); box-shadow:inset 0 0 0 1px var(--ac); }
.dd-cel::placeholder { color:#3A3A42; }
.dd-cel--num { text-align:right; font-variant-numeric:tabular-nums; }
.dd-grid tr:hover .dd-num { color:var(--ink2); }
.dd-kill { opacity:0; transition:opacity .15s; }
.dd-grid tr:hover .dd-kill { opacity:1; }

.dd-empty { padding:2.5rem; font-size:.8125rem; color:var(--ink3); text-align:center; }
.dd-alert { border-left:1px solid #C96A6A; padding:.25rem 0 .25rem 1rem; font-size:.8125rem; color:#D89A9A; }
.dd-skel { height:3rem; background:var(--l); opacity:.5; }

/* ---------- painel lateral ---------- */
.dd-drawer { position:fixed; inset:0; z-index:60; display:flex; justify-content:flex-end; background:rgba(6,6,8,.75); }
.dd-panel { width:min(27rem,100%); background:var(--bg); height:100%; border-left:1px solid var(--l2);
            overflow-y:auto; display:flex; flex-direction:column; }
.dd-panel-h { padding:2.5rem 2.5rem 1.75rem; border-bottom:1px solid var(--l); }
.dd-panel-b { padding:2rem 2.5rem; flex:1; }
.dd-panel-f { padding:1.5rem 2.5rem 2.5rem; border-top:1px solid var(--l); display:flex; gap:.5rem; }
.dd-campo { margin-bottom:2.25rem; }
.dd-campo > .dd-in, .dd-campo > .dd-sel { width:100%; margin-top:.75rem; font-size:.9375rem; }
.dd-dica { font-size:.75rem; color:var(--ink3); line-height:1.55; margin-top:.5rem; }
.dd-chk { display:flex; gap:.875rem; align-items:flex-start; cursor:pointer; padding:1rem 0;
          border-bottom:1px solid var(--l); }
.dd-chk input { margin-top:.1875rem; accent-color:var(--ac); }
.dd-chk-t { font-size:.875rem; font-weight:400; display:block; }
.dd-chk-d { font-size:.75rem; color:var(--ink3); line-height:1.5; display:block; margin-top:.25rem; }

@media (max-width:900px) {
  .dd-wrap { padding:2rem 1.25rem; }
  .dd-bar { padding:0 1.25rem; }
  .dd-split { grid-template-columns:1fr; }
  .dd-side { border-right:none; border-bottom:1px solid var(--l); padding-right:0; padding-bottom:1.5rem; }
  .dd-main { padding-left:0; padding-top:2rem; }
}
`;

export default function DadosPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const [tabelas, setTabelas] = useState(null);
  const [ativaId, setAtivaId] = useState(null);
  const [colunas, setColunas] = useState([]);
  const [linhas, setLinhas] = useState([]);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState(null);
  const [busca, setBusca] = useState('');

  const [editandoColuna, setEditandoColuna] = useState(null);
  const [aExcluir, setAExcluir] = useState(null);
  const [colando, setColando] = useState(false);
  const [textoColado, setTextoColado] = useState('');

  const timers = useRef({});
  const ativa = useMemo(() => (tabelas ?? []).find((t) => t.id === ativaId), [tabelas, ativaId]);

  // ---- carregar --------------------------------------------------------
  const carregarTabelas = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from('tabelas')
      .select('*, tabela_linhas(count)')
      .eq('owner_id', user.id)
      .order('alterada_em', { ascending: false });
    if (error) return setErro(error.message);
    setTabelas(data ?? []);
    setAtivaId((a) => a ?? data?.[0]?.id ?? null);
  }, [user]);

  useEffect(() => {
    carregarTabelas();
  }, [carregarTabelas]);

  const carregarConteudo = useCallback(async (id) => {
    if (!id) return;
    setCarregando(true);
    try {
      const [c, l] = await Promise.all([
        supabase.from('tabela_colunas').select('*').eq('tabela_id', id).order('ordem'),
        supabase.from('tabela_linhas').select('*').eq('tabela_id', id).order('criada_em').limit(2000),
      ]);
      if (c.error) throw c.error;
      if (l.error) throw l.error;
      setColunas(c.data ?? []);
      setLinhas(l.data ?? []);
      setErro(null);
    } catch (e) {
      setErro(e.message);
    } finally {
      setCarregando(false);
    }
  }, []);

  useEffect(() => {
    if (ativaId) carregarConteudo(ativaId);
  }, [ativaId, carregarConteudo]);

  // ---- tabela ----------------------------------------------------------
  const criarTabela = async () => {
    const nome = window.prompt('Nome da tabela', 'Produtos');
    if (!nome?.trim()) return;

    const { data, error } = await supabase
      .from('tabelas')
      .insert({ owner_id: user.id, nome: nome.trim(), proposito: '' })
      .select()
      .single();
    if (error) return toast({ variant: 'destructive', title: 'Não deu para criar', description: error.message });

    await supabase.from('tabela_colunas').insert([
      { tabela_id: data.id, chave: 'nome', rotulo: 'Nome', tipo: 'texto', ordem: 0, obrigatoria: true, identifica: true, chave_primaria: true },
      { tabela_id: data.id, chave: 'preco', rotulo: 'Preço', tipo: 'moeda', ordem: 1 },
    ]);

    await carregarTabelas();
    setAtivaId(data.id);
  };

  // ---- coluna ----------------------------------------------------------
  const salvarColuna = async (d) => {
    const chave = d.id ? d.chave : chavear(d.rotulo);
    if (!chave) return toast({ variant: 'destructive', title: 'Dê um nome à coluna' });

    const campos = {
      rotulo: d.rotulo,
      tipo: d.tipo,
      obrigatoria: !!d.obrigatoria,
      identifica: !!d.chave_primaria,
      chave_primaria: !!d.chave_primaria,
      unica: !!d.unica || !!d.chave_primaria,
      padrao: d.padrao || null,
      ref_tabela_id: d.ref_tabela_id || null,
      ref_coluna_chave: d.ref_tabela_id ? d.ref_coluna_chave || null : null,
      opcoes: d.tipo === 'selecao' && d.opcoes?.length ? d.opcoes : null,
    };

    // Uma chave primária por tabela: tira das outras antes de marcar esta.
    if (campos.chave_primaria) {
      await supabase
        .from('tabela_colunas')
        .update({ chave_primaria: false, identifica: false })
        .eq('tabela_id', ativaId)
        .neq('id', d.id ?? '00000000-0000-0000-0000-000000000000');
    }

    const r = d.id
      ? await supabase.from('tabela_colunas').update(campos).eq('id', d.id)
      : await supabase.from('tabela_colunas').insert({ ...campos, tabela_id: ativaId, chave, ordem: colunas.length });

    if (r.error) return toast({ variant: 'destructive', title: 'Não deu para salvar', description: r.error.message });

    setEditandoColuna(null);
    carregarConteudo(ativaId);
  };

  const moverColuna = async (col, dir) => {
    const i = colunas.findIndex((c) => c.id === col.id);
    const j = i + dir;
    if (j < 0 || j >= colunas.length) return;
    const a = colunas[i], b = colunas[j];
    await Promise.all([
      supabase.from('tabela_colunas').update({ ordem: b.ordem }).eq('id', a.id),
      supabase.from('tabela_colunas').update({ ordem: a.ordem }).eq('id', b.id),
    ]);
    carregarConteudo(ativaId);
  };

  // ---- linha -----------------------------------------------------------
  const novaLinha = async () => {
    const padroes = {};
    for (const c of colunas) if (c.padrao) padroes[c.chave] = c.padrao;

    const { data, error } = await supabase
      .from('tabela_linhas')
      .insert({ tabela_id: ativaId, dados: padroes })
      .select()
      .single();
    if (error) return toast({ variant: 'destructive', title: 'Não deu para adicionar', description: error.message });
    setLinhas((p) => [...p, data]);
  };

  /**
   * Edita a célula. O estado local muda na hora; a gravação espera
   * 700ms sem digitação — senão seria uma escrita por tecla.
   */
  const editarCelula = useCallback((linhaId, chave, valor) => {
    setLinhas((prev) => {
      const nova = prev.map((l) => (l.id === linhaId ? { ...l, dados: { ...l.dados, [chave]: valor } } : l));

      clearTimeout(timers.current[linhaId]);
      timers.current[linhaId] = setTimeout(async () => {
        const atual = nova.find((l) => l.id === linhaId);
        const { error } = await supabase
          .from('tabela_linhas')
          .update({ dados: atual?.dados ?? {} })
          .eq('id', linhaId);
        if (error) setErro(error.message);
      }, 700);

      return nova;
    });
  }, []);

  useEffect(() => () => Object.values(timers.current).forEach(clearTimeout), []);

  /** Tab, setas e Enter navegam entre as células, como numa planilha. */
  const navegarCelula = (e, li, ci) => {
    const ir = (l, c) => {
      const alvo = document.querySelector(`[data-cel="${l}-${c}"]`);
      if (alvo) {
        e.preventDefault();
        alvo.focus();
        alvo.select?.();
      }
    };
    if (e.key === 'Enter' || (e.key === 'ArrowDown' && e.ctrlKey)) ir(li + 1, ci);
    if (e.key === 'ArrowUp' && e.ctrlKey) ir(li - 1, ci);
    if (e.key === 'ArrowRight' && e.ctrlKey) ir(li, ci + 1);
    if (e.key === 'ArrowLeft' && e.ctrlKey) ir(li, ci - 1);
  };

  const excluir = async () => {
    const alvo = aExcluir;
    setAExcluir(null);
    if (!alvo) return;
    if (alvo.tipo === 'linha') {
      await supabase.from('tabela_linhas').delete().eq('id', alvo.id);
      setLinhas((p) => p.filter((l) => l.id !== alvo.id));
    }
    if (alvo.tipo === 'coluna') {
      await supabase.from('tabela_colunas').delete().eq('id', alvo.id);
      carregarConteudo(ativaId);
    }
    if (alvo.tipo === 'tabela') {
      await supabase.from('tabelas').delete().eq('id', alvo.id);
      setAtivaId(null);
      carregarTabelas();
    }
  };

  const importarColado = async () => {
    const texto = textoColado.trim();
    if (!texto) return;
    const sep = texto.includes('\t') ? '\t' : ';';
    const novas = texto
      .split(/\n/)
      .map((l) => l.trim())
      .filter(Boolean)
      .map((l) => {
        const partes = l.split(sep).map((p) => p.trim());
        const obj = {};
        colunas.forEach((c, i) => {
          if (partes[i]) obj[c.chave] = partes[i];
        });
        return { tabela_id: ativaId, dados: obj };
      })
      .filter((n) => Object.keys(n.dados).length);

    if (!novas.length) return toast({ variant: 'destructive', title: 'Não reconheci nenhuma linha' });

    const { error } = await supabase.from('tabela_linhas').insert(novas);
    if (error) return toast({ variant: 'destructive', title: 'Não deu para importar', description: error.message });

    setColando(false);
    setTextoColado('');
    carregarConteudo(ativaId);
    toast({ title: `${novas.length} linhas adicionadas` });
  };

  const visiveis = useMemo(() => {
    const q = busca.trim().toLowerCase();
    if (!q) return linhas;
    return linhas.filter((l) => Object.values(l.dados ?? {}).some((v) => String(v).toLowerCase().includes(q)));
  }, [linhas, busca]);

  return (
    <div className="dd">
      <style>{CSS}</style>

      <header className="dd-bar">
        <div className="dd-brand">
          Helpy<b> / dados</b>
        </div>
        <div className="dd-bar-r">
          <button type="button" className="dd-nav" onClick={() => navigate('/dashboard')}>
            Painel
          </button>
          <button type="button" className="dd-btn dd-btn--solid" onClick={criarTabela}>
            Nova tabela
          </button>
        </div>
      </header>

      <div className="dd-wrap">
        <span className="dd-lbl">Dados</span>
        <h1 className="dd-h1">
          Suas tabelas.
          <br />
          <em>
            {tabelas === null
              ? 'carregando'
              : tabelas.length === 0
                ? 'nenhuma ainda'
                : `${tabelas.length} ${tabelas.length === 1 ? 'tabela' : 'tabelas'}`}
          </em>
        </h1>

        {tabelas?.length === 0 && (
          <>
            <p className="dd-sub">
              Uma tabela serve para qualquer lista que cresce: produtos com estoque, procedimentos
              com duração, turmas, imóveis, clientes. Você define as colunas, e o assistente
              consulta na hora de responder.
            </p>
            <button type="button" className="dd-btn dd-btn--solid" style={{ marginTop: '2rem' }} onClick={criarTabela}>
              Criar a primeira
            </button>
          </>
        )}

        {erro && <div className="dd-alert" style={{ marginTop: '2rem' }}>{erro}</div>}

        {tabelas?.length > 0 && (
          <div className="dd-split">
            <aside className="dd-side">
              {tabelas.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  className="dd-side-i"
                  data-on={t.id === ativaId ? 'true' : 'false'}
                  onClick={() => setAtivaId(t.id)}
                >
                  <span className="dd-side-n">{t.nome}</span>
                  <span className="dd-side-c">{t.tabela_linhas?.[0]?.count ?? 0} linhas</span>
                </button>
              ))}
            </aside>

            <main className="dd-main">
              {ativa && (
                <>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: '1rem' }}>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: 300, margin: 0, letterSpacing: '-.02em' }}>
                      {ativa.nome}
                    </h2>
                    <button
                      type="button"
                      className="dd-nav"
                      onClick={() => setAExcluir({ tipo: 'tabela', id: ativa.id, nome: ativa.nome })}
                    >
                      Excluir tabela
                    </button>
                  </div>

                  <label style={{ display: 'block', marginTop: '1.5rem' }}>
                    <span className="dd-lbl">Para que serve — o assistente lê isto</span>
                    <input
                      className="dd-in"
                      defaultValue={ativa.proposito || ''}
                      placeholder="Ex: produtos à venda, com preço e estoque"
                      onBlur={async (e) => {
                        await supabase.from('tabelas').update({ proposito: e.target.value }).eq('id', ativa.id);
                        carregarTabelas();
                      }}
                      style={{ display: 'block', width: '100%', marginTop: '.5rem', fontSize: '.9375rem' }}
                    />
                  </label>

                  <div className="dd-tools">
                    <input
                      className="dd-in"
                      placeholder="Buscar"
                      value={busca}
                      onChange={(e) => setBusca(e.target.value)}
                      style={{ minWidth: '10rem' }}
                    />
                    <button type="button" className="dd-btn dd-btn--sm" onClick={() => setEditandoColuna('nova')}>
                      + Coluna
                    </button>
                    <button type="button" className="dd-btn dd-btn--sm" onClick={novaLinha}>
                      + Linha
                    </button>
                    <button type="button" className="dd-btn dd-btn--sm" onClick={() => setColando(true)}>
                      Colar lista
                    </button>
                    <span style={{ marginLeft: 'auto', fontSize: '.75rem', color: 'var(--ink3)' }}>
                      {visiveis.length} de {linhas.length}
                    </span>
                  </div>

                  {colando && (
                    <div style={{ border: '1px solid var(--l2)', padding: '1.5rem', marginBottom: '1.5rem' }}>
                      <span className="dd-lbl">Cole as linhas</span>
                      <p className="dd-dica">
                        Uma por linha, colunas separadas por tabulação — é o que sai ao copiar do
                        Excel. A ordem segue: {colunas.map((c) => c.rotulo).join(' · ')}
                      </p>
                      <textarea
                        value={textoColado}
                        onChange={(e) => setTextoColado(e.target.value)}
                        rows={6}
                        style={{
                          width: '100%', marginTop: '1rem', background: 'none',
                          border: '1px solid var(--l)', color: 'var(--ink)',
                          fontFamily: 'inherit', fontSize: '.8125rem', padding: '.75rem', outline: 'none',
                        }}
                      />
                      <div style={{ display: 'flex', gap: '.5rem', marginTop: '1rem' }}>
                        <button type="button" className="dd-btn dd-btn--solid dd-btn--sm" onClick={importarColado}>
                          Importar
                        </button>
                        <button type="button" className="dd-btn dd-btn--sm" onClick={() => setColando(false)}>
                          Cancelar
                        </button>
                      </div>
                    </div>
                  )}

                  {carregando && <div className="dd-skel" />}

                  {!carregando && colunas.length === 0 && (
                    <p className="dd-empty">Esta tabela ainda não tem colunas.</p>
                  )}

                  {!carregando && colunas.length > 0 && (
                    <div className="dd-grid-wrap">
                      <table className="dd-grid">
                        <thead>
                          {/* faixa das letras, como no Excel */}
                          <tr>
                            <th className="dd-canto" />
                            {colunas.map((c, i) => (
                              <th key={`L${c.id}`} className="dd-letra">
                                {letraDe(i)}
                              </th>
                            ))}
                            <th className="dd-letra" style={{ width: '2.5rem' }} />
                          </tr>
                          {/* nomes */}
                          <tr>
                            <th className="dd-canto" style={{ top: '1.5rem' }} />
                            {colunas.map((c) => (
                              <th key={c.id} className="dd-th">
                                <button
                                  type="button"
                                  className="dd-th-b"
                                  onClick={() => setEditandoColuna(c)}
                                  title="Editar coluna"
                                >
                                  <span className="dd-th-nome">
                                    {c.chave_primaria && <span className="dd-th-pk">◆ </span>}
                                    {c.rotulo}
                                    {c.obrigatoria && !c.chave_primaria && ' *'}
                                  </span>
                                  <span className="dd-th-tipo">
                                    {c.ref_tabela_id
                                      ? 'referência'
                                      : TIPOS.find((t) => t.v === c.tipo)?.r ?? c.tipo}
                                  </span>
                                </button>
                              </th>
                            ))}
                            <th className="dd-th" style={{ minWidth: '2.5rem' }} />
                          </tr>
                        </thead>
                        <tbody>
                          {visiveis.map((l, li) => (
                            <tr key={l.id}>
                              <td className="dd-num">{li + 1}</td>
                              {colunas.map((c, ci) => (
                                <td key={c.id}>
                                  {c.tipo === 'booleano' ? (
                                    <input
                                      type="checkbox"
                                      data-cel={`${li}-${ci}`}
                                      checked={l.dados?.[c.chave] === true || l.dados?.[c.chave] === 'true'}
                                      onChange={(e) => editarCelula(l.id, c.chave, e.target.checked)}
                                      style={{ margin: '.625rem .75rem', accentColor: 'var(--ac)' }}
                                    />
                                  ) : c.tipo === 'selecao' && c.opcoes?.length ? (
                                    <select
                                      className="dd-cel"
                                      data-cel={`${li}-${ci}`}
                                      value={l.dados?.[c.chave] ?? ''}
                                      onChange={(e) => editarCelula(l.id, c.chave, e.target.value)}
                                    >
                                      <option value="">—</option>
                                      {c.opcoes.map((o) => (
                                        <option key={o} value={o}>{o}</option>
                                      ))}
                                    </select>
                                  ) : (
                                    <input
                                      className={`dd-cel${c.tipo === 'numero' || c.tipo === 'moeda' ? ' dd-cel--num' : ''}`}
                                      data-cel={`${li}-${ci}`}
                                      type={c.tipo === 'data' ? 'date' : 'text'}
                                      value={l.dados?.[c.chave] ?? ''}
                                      placeholder=""
                                      onChange={(e) => editarCelula(l.id, c.chave, e.target.value)}
                                      onKeyDown={(e) => navegarCelula(e, li, ci)}
                                      onFocus={(e) => e.target.select()}
                                    />
                                  )}
                                </td>
                              ))}
                              <td>
                                <button
                                  type="button"
                                  className="dd-kill"
                                  onClick={() => setAExcluir({ tipo: 'linha', id: l.id })}
                                  title="Excluir linha"
                                  style={{
                                    background: 'none', border: 'none', color: 'var(--ink3)',
                                    cursor: 'pointer', padding: '.625rem .75rem',
                                  }}
                                >
                                  ✕
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>

                      {visiveis.length === 0 && (
                        <p className="dd-empty">{busca ? 'Nada encontrado.' : 'Nenhuma linha ainda.'}</p>
                      )}
                    </div>
                  )}

                  <p className="dd-dica" style={{ marginTop: '1rem' }}>
                    Clique numa célula para editar. Enter desce, Ctrl + setas navega. Tudo salva
                    sozinho.
                  </p>
                </>
              )}
            </main>
          </div>
        )}
      </div>

      {editandoColuna && (
        <PainelColuna
          coluna={editandoColuna === 'nova' ? null : editandoColuna}
          colunas={colunas}
          tabelas={(tabelas ?? []).filter((t) => t.id !== ativaId)}
          onSalvar={salvarColuna}
          onMover={moverColuna}
          onExcluir={(c) => {
            setEditandoColuna(null);
            setAExcluir({ tipo: 'coluna', id: c.id, nome: c.rotulo });
          }}
          onFechar={() => setEditandoColuna(null)}
        />
      )}

      <ConfirmDialog
        open={!!aExcluir}
        eyebrow="Excluir"
        title={
          aExcluir?.tipo === 'tabela'
            ? `Apagar a tabela ${aExcluir?.nome}?`
            : aExcluir?.tipo === 'coluna'
              ? `Apagar a coluna ${aExcluir?.nome}?`
              : 'Apagar esta linha?'
        }
        body={
          aExcluir?.tipo === 'tabela'
            ? 'Todas as colunas e linhas vão junto. Os assistentes ligados a ela param de consultá-la. Não dá para desfazer.'
            : aExcluir?.tipo === 'coluna'
              ? 'A coluna some da tabela. Os valores preenchidos nela param de aparecer.'
              : 'Esta linha some da tabela.'
        }
        confirmLabel="Apagar"
        cancelLabel="Manter"
        destructive
        onConfirm={excluir}
        onCancel={() => setAExcluir(null)}
      />
    </div>
  );
}

// ============================================================
// Painel da coluna
// ============================================================
function PainelColuna({ coluna, colunas, tabelas, onSalvar, onMover, onExcluir, onFechar }) {
  const [rotulo, setRotulo] = useState(coluna?.rotulo ?? '');
  const [tipo, setTipo] = useState(coluna?.tipo ?? 'texto');
  const [obrigatoria, setObrigatoria] = useState(!!coluna?.obrigatoria);
  const [pk, setPk] = useState(!!coluna?.chave_primaria);
  const [unica, setUnica] = useState(!!coluna?.unica);
  const [padrao, setPadrao] = useState(coluna?.padrao ?? '');
  const [refTabela, setRefTabela] = useState(coluna?.ref_tabela_id ?? '');
  const [opcoesTexto, setOpcoesTexto] = useState((coluna?.opcoes ?? []).join('\n'));

  useEffect(() => {
    const esc = (e) => e.key === 'Escape' && onFechar();
    document.addEventListener('keydown', esc);
    return () => document.removeEventListener('keydown', esc);
  }, [onFechar]);

  const tipoAtual = TIPOS.find((t) => t.v === tipo);
  const jaTemPk = colunas.some((c) => c.chave_primaria && c.id !== coluna?.id);

  return (
    <div className="dd-drawer" onMouseDown={(e) => e.target === e.currentTarget && onFechar()}>
      <div className="dd-panel" role="dialog" aria-modal="true">
        <div className="dd-panel-h">
          <span className="dd-lbl">{coluna ? 'Coluna' : 'Nova coluna'}</span>
          <h2 style={{ fontSize: '1.625rem', fontWeight: 200, margin: '.625rem 0 0', letterSpacing: '-.02em' }}>
            {rotulo || 'Sem nome'}
          </h2>
          {coluna && (
            <p className="dd-dica" style={{ marginTop: '.5rem', fontFamily: 'monospace', fontSize: '.6875rem' }}>
              {coluna.chave}
            </p>
          )}
        </div>

        <div className="dd-panel-b">
          <div className="dd-campo">
            <span className="dd-lbl">Nome</span>
            <input
              className="dd-in"
              autoFocus
              value={rotulo}
              onChange={(e) => setRotulo(e.target.value)}
              placeholder="Estoque"
            />
            {!coluna && rotulo && (
              <p className="dd-dica" style={{ fontFamily: 'monospace', fontSize: '.6875rem' }}>
                chave: {chavear(rotulo)}
              </p>
            )}
          </div>

          <div className="dd-campo">
            <span className="dd-lbl">Tipo</span>
            <select className="dd-sel" value={tipo} onChange={(e) => setTipo(e.target.value)}>
              {TIPOS.map((t) => (
                <option key={t.v} value={t.v}>{t.r}</option>
              ))}
            </select>
            <p className="dd-dica">{tipoAtual?.d}</p>
          </div>

          {tipo === 'selecao' && (
            <div className="dd-campo">
              <span className="dd-lbl">Opções — uma por linha</span>
              <textarea
                value={opcoesTexto}
                onChange={(e) => setOpcoesTexto(e.target.value)}
                rows={4}
                placeholder={'Disponível\nEsgotado\nSob encomenda'}
                style={{
                  width: '100%', marginTop: '.75rem', background: 'none',
                  border: '1px solid var(--l)', color: 'var(--ink)',
                  fontFamily: 'inherit', fontSize: '.875rem', padding: '.625rem', outline: 'none',
                }}
              />
            </div>
          )}

          <div className="dd-campo">
            <span className="dd-lbl">Valor padrão</span>
            <input
              className="dd-in"
              value={padrao}
              onChange={(e) => setPadrao(e.target.value)}
              placeholder="deixe vazio para nenhum"
            />
            <p className="dd-dica">Toda linha nova já nasce com este valor.</p>
          </div>

          <label className="dd-chk">
            <input
              type="checkbox"
              checked={pk}
              onChange={(e) => {
                setPk(e.target.checked);
                if (e.target.checked) setUnica(true);
              }}
            />
            <span>
              <span className="dd-chk-t">Chave primária ◆</span>
              <span className="dd-chk-d">
                Identifica a linha. É por ela que o assistente se refere ao item e que outras
                tabelas apontam para cá.
                {jaTemPk && ' Marcar aqui desmarca a coluna que é chave hoje.'}
              </span>
            </span>
          </label>

          <label className="dd-chk">
            <input
              type="checkbox"
              checked={unica || pk}
              disabled={pk}
              onChange={(e) => setUnica(e.target.checked)}
            />
            <span>
              <span className="dd-chk-t">Valor único</span>
              <span className="dd-chk-d">Duas linhas não podem repetir o mesmo valor aqui.</span>
            </span>
          </label>

          <label className="dd-chk">
            <input
              type="checkbox"
              checked={obrigatoria}
              onChange={(e) => setObrigatoria(e.target.checked)}
            />
            <span>
              <span className="dd-chk-t">Obrigatória</span>
              <span className="dd-chk-d">O assistente cobra este dado quando faltar.</span>
            </span>
          </label>

          {tabelas.length > 0 && (
            <div className="dd-campo" style={{ marginTop: '2.25rem' }}>
              <span className="dd-lbl">Aponta para outra tabela</span>
              <select className="dd-sel" value={refTabela} onChange={(e) => setRefTabela(e.target.value)}>
                <option value="">Não aponta para nenhuma</option>
                {tabelas.map((t) => (
                  <option key={t.id} value={t.id}>{t.nome}</option>
                ))}
              </select>
              <p className="dd-dica">
                Chave estrangeira. Esta coluna guarda a chave primária de uma linha da outra tabela —
                é assim que um serviço aponta para uma categoria, ou um agendamento para um cliente.
              </p>
            </div>
          )}

          {coluna && colunas.length > 1 && (
            <div style={{ display: 'flex', gap: '.5rem', marginTop: '2rem' }}>
              <button type="button" className="dd-btn dd-btn--sm" onClick={() => onMover(coluna, -1)}>
                ← Mover
              </button>
              <button type="button" className="dd-btn dd-btn--sm" onClick={() => onMover(coluna, 1)}>
                Mover →
              </button>
            </div>
          )}
        </div>

        <div className="dd-panel-f">
          <button
            type="button"
            className="dd-btn dd-btn--solid"
            onClick={() =>
              onSalvar({
                id: coluna?.id,
                chave: coluna?.chave,
                rotulo,
                tipo,
                obrigatoria,
                chave_primaria: pk,
                unica,
                padrao,
                ref_tabela_id: refTabela || null,
                opcoes: opcoesTexto.split('\n').map((o) => o.trim()).filter(Boolean),
              })
            }
          >
            Salvar
          </button>
          <button type="button" className="dd-btn" onClick={onFechar}>
            Cancelar
          </button>
          {coluna && (
            <button
              type="button"
              className="dd-btn dd-btn--kill"
              style={{ marginLeft: 'auto' }}
              onClick={() => onExcluir(coluna)}
            >
              Excluir
            </button>
          )}
        </div>
      </div>
    </div>
  );
}