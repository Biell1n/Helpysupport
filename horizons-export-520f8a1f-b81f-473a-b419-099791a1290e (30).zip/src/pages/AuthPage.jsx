import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';
import GoogleAuthButton from '@/components/GoogleAuthButton';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import ForgotPasswordModal from '@/components/ForgotPasswordModal';
import PasswordStrengthIndicator from '@/components/PasswordStrengthIndicator';
import PasswordRequirements from '@/components/PasswordRequirements';

export default function AuthPage() {
  const [view, setView] = useState('login'); 
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { login, register, isPending } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);

  useEffect(() => {
    if (location.state?.view) {
      setView(location.state.view);
    } else if (location.state?.message) {
      toast({ title: 'Aviso', description: location.state.message });
    }
  }, [location, toast]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      if (view === 'signup') {
        if (password !== confirmPassword) {
          toast({ title: "Erro", description: "As senhas não coincidem.", variant: "destructive" });
          setLoading(false);
          return;
        }
        
        const isStrong = password.length >= 8 && /[A-Z]/.test(password) && /[0-9]/.test(password) && /[^A-Za-z0-9]/.test(password);
        if (!isStrong) {
          toast({ title: "Erro", description: "A senha não atende aos requisitos mínimos.", variant: "destructive" });
          setLoading(false);
          return;
        }
        
        const result = await register(email, password, 'pending', 'free', null, null);
        if (result.success) {
          navigate('/complete-cadastro');
        }
      } else {
        const result = await login(email, password);
        if (result.success) {
           if (result.requiresVerification) {
              navigate('/verify-login');
           } else {
              // Redirect handled by ProtectedRoute wrapper logic in real scenario,
              // but we can check isPending state explicitly if available in result,
              // or rely on the route protection mechanism to bounce them.
              // To be safe, just navigate to dashboard and let ProtectedRoute bounce if pending.
              navigate('/dashboard'); 
           }
        }
      }
    } catch (error) {
       console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>{view === 'login' ? 'Login' : 'Cadastro'} - Helpy</title>
      </Helmet>

      <div className="h-screen flex bg-black overflow-hidden">
        <div className="w-full lg:w-[45%] xl:w-[40%] flex flex-col px-8 sm:px-12 lg:px-16 relative z-10 bg-black h-full overflow-y-auto custom-scrollbar">
          <div className="my-auto min-h-[calc(100vh-40px)] flex flex-col justify-center py-10">
            <motion.div 
              key={view}
              initial={{ opacity: 0, x: -20 }} 
              animate={{ opacity: 1, x: 0 }} 
              transition={{ duration: 0.3 }}
              className="w-full max-w-md mx-auto py-8"
            >
              <div className="flex items-center gap-2 mb-10 cursor-pointer" onClick={() => navigate('/')}>
                 <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                    <span className="text-black font-black text-xl">H</span>
                 </div>
                 <span className="text-2xl font-bold text-white tracking-tight">Helpy</span>
              </div>

              <h1 className="text-3xl font-bold text-white mb-2">
                {view === 'login' ? 'Bem-vindo de volta' : 'Crie sua conta'}
              </h1>
              <p className="text-neutral-400 mb-8">
                {view === 'login' ? 'Entre na sua conta para continuar' : 'Preencha seus dados para começar'}
              </p>

              <GoogleAuthButton className="mb-6" />

              <div className="relative flex py-4 items-center mb-6">
                <div className="flex-grow border-t border-neutral-800"></div>
                <span className="flex-shrink-0 mx-4 text-neutral-600 text-sm font-medium uppercase">OU</span>
                <div className="flex-grow border-t border-neutral-800"></div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-neutral-300">Email</Label>
                  <Input 
                    id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required
                    className="bg-neutral-900 border-none outline-none text-white h-14 rounded-xl px-4" placeholder="seu@email.com"
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password" className="text-neutral-300">Senha</Label>
                    {view === 'login' && (
                      <button type="button" onClick={() => setIsForgotModalOpen(true)} className="text-xs text-neutral-400 hover:text-white transition-colors">
                        Esqueceu a senha?
                      </button>
                    )}
                  </div>
                  <Input 
                    id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required
                    className="bg-neutral-900 border-none outline-none text-white h-14 rounded-xl px-4" placeholder="••••••••"
                  />
                  {view === 'signup' && (
                    <>
                      <PasswordStrengthIndicator password={password} />
                      <PasswordRequirements password={password} />
                    </>
                  )}
                </div>

                {view === 'signup' && (
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword" className="text-neutral-300">Confirmar Senha</Label>
                    <Input 
                      id="confirmPassword" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required
                      className="bg-neutral-900 border-none outline-none text-white h-14 rounded-xl px-4" placeholder="••••••••"
                    />
                  </div>
                )}

                <Button type="submit" disabled={loading} className="w-full bg-white hover:bg-neutral-200 text-black font-bold py-6 text-lg rounded-xl mt-4">
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (view === 'login' ? 'Entrar' : 'Cadastrar')}
                </Button>
              </form>

              <div className="text-center mt-8">
                {view === 'login' ? (
                  <button onClick={() => setView('signup')} className="text-neutral-400 hover:text-white transition-colors">
                    Não tem uma conta? <span className="font-bold text-white">Cadastre-se</span>
                  </button>
                ) : (
                  <button onClick={() => setView('login')} className="text-neutral-400 hover:text-white transition-colors">
                    Já tem uma conta? <span className="font-bold text-white">Faça login</span>
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        </div>

        <div className="hidden lg:block lg:w-[55%] xl:w-[60%] relative h-full bg-neutral-950 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-neutral-800/20 via-black to-white/10 z-10 pointer-events-none mix-blend-overlay" />
          <motion.img 
            initial={{ scale: 1.05, opacity: 0 }}
            animate={{ scale: 1, opacity: 0.6 }}
            transition={{ duration: 1.5 }}
            src="https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=2000&auto=format&fit=crop"
            alt="Abstract dark theme background with elegant waves" 
            className="w-full h-full object-cover grayscale opacity-50"
          />
        </div>
      </div>

      <ForgotPasswordModal isOpen={isForgotModalOpen} onClose={() => setIsForgotModalOpen(false)} />
    </>
  );
}