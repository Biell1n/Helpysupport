// ============================================================
// HELPY — InboxPage v5 — ARQUIVO COMPLETO
// Rota: /dashboard/atendimentos
//
// A caixa de entrada da empresa. Lista as conversas dos assistentes do
// usuário, com as escalonadas no topo, e permite responder.
//
// Lê e escreve direto pelo cliente Supabase: as policies da migration 07
// garantem que cada dono só enxerga o que é dele.
// ============================================================

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import '@/styles/builder.css';
import '@/styles/assistant.css';

const quando = (iso) => {
  if (!iso) return '';
  const d = new Date(iso);
  const min = Math.round((Date.now() - d.getTime()) / 60000);
  if (min < 1) return 'agora';
  if (min < 60) return `${min} min`;
  if (min < 1440) return `${Math.round(min / 60)} h`;
  return d.toLocaleDateString('pt-BR');
};

/**
 * Nome de quem está do outro lado.
 * Ordem: o que ele deu ao assistente, o do cadastro, e só então o
 * genérico. "Visitante" agora só aparece para quem realmente não tem
 * conta — antes aparecia até para quem tinha.
 */
const estrelas = (n) => '\u2605'.repeat(n) + '\u2606'.repeat(5 - n);

const nomeDoCliente = (c) =>
  c.lead_nome?.trim() ||
  c.visitor_name?.trim() ||
  (c.user_id ? 'Sem nome no cadastro' : 'Visitante');

export default function InboxPage() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const [conversas, setConversas] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState(null);
  const [filtro, setFiltro] = useState('escalated'); // escalated | todas

  const [aberta, setAberta] = useState(null);
  const [assistentes, setAssistentes] = useState({});
  const [mensagens, setMensagens] = useState([]);
  const [carregandoMsgs, setCarregandoMsgs] = useState(false);
  const [resposta, setResposta] = useState('');
  const [enviando, setEnviando] = useState(false);

  const fimRef = useRef(null);

  // ---- lista ----------------------------------------------------------
  const carregar = useCallback(async () => {
    if (!user) return;
    try {
      let q = supabase
        .from('assistant_conversations')
        .select('*')
        .eq('owner_id', user.id)
        .order('last_message_at', { ascending: false })
        .limit(100);

      if (filtro === 'escalated') q = q.eq('status', 'escalated');

      const { data, error } = await q;
      if (error) throw error;
      const lista = data ?? [];
      setConversas(lista);

      // Nomes reais em vez de "Cliente" e "Atendente". Quem lê o ticket
      // precisa saber com quem está falando e qual assistente atendeu.
      const ids = [...new Set(lista.map((c) => c.assistant_id).filter(Boolean))];
      if (ids.length) {
        const { data: asts } = await supabase.from('assistants').select('id, name').in('id', ids);
        const mapa = {};
        for (const a of asts ?? []) mapa[a.id] = a.name;
        setAssistentes(mapa);
      }
      setErro(null);
    } catch (e) {
      console.error('[Inbox]', e);
      setErro(e.message);
    } finally {
      setCarregando(false);
    }
  }, [user, filtro]);

  useEffect(() => {
    setCarregando(true);
    carregar();
    // atualiza sozinho: atendimento não pode depender de F5
    const t = setInterval(carregar, 20000);
    return () => clearInterval(t);
  }, [carregar]);

  // ---- conversa aberta -------------------------------------------------
  const abrir = useCallback(async (conversa) => {
    setAberta(conversa);
    setMensagens([]);
    setCarregandoMsgs(true);
    try {
      const { data, error } = await supabase
        .from('assistant_messages')
        .select('role, content, created_at')
        .eq('conversation_id', conversa.id)
        .order('created_at', { ascending: true })
        .limit(200);
      if (error) throw error;
      setMensagens(data ?? []);

      if (!conversa.lido_em) {
        await supabase
          .from('assistant_conversations')
          .update({ lido_em: new Date().toISOString() })
          .eq('id', conversa.id);
      }
    } catch (e) {
      console.error('[Inbox] mensagens:', e);
      setErro(e.message);
    } finally {
      setCarregandoMsgs(false);
    }
  }, []);

  useEffect(() => {
    if (fimRef.current) fimRef.current.scrollIntoView({ block: 'end' });
  }, [mensagens]);

  // recarrega a conversa aberta de tempos em tempos
  useEffect(() => {
    if (!aberta) return;
    const t = setInterval(async () => {
      const { data } = await supabase
        .from('assistant_messages')
        .select('role, content, created_at')
        .eq('conversation_id', aberta.id)
        .order('created_at', { ascending: true })
        .limit(200);
      if (data) setMensagens(data);
    }, 8000);
    return () => clearInterval(t);
  }, [aberta]);

  const responder = async () => {
    const texto = resposta.trim();
    if (!texto || !aberta || enviando) return;
    setEnviando(true);
    try {
      const { error } = await supabase.from('assistant_messages').insert({
        conversation_id: aberta.id,
        role: 'agent',
        content: texto,
      });
      if (error) throw error;

      if (!aberta.assumido_por) {
        // O nome vai gravado na conversa: a página pública não tem
        // permissão de ler a tabela de usuários, então é daqui que o
        // cliente descobre quem assumiu o chamado dele.
        await supabase
          .from('assistant_conversations')
          .update({
            assumido_por: user.id,
            assumido_nome: nomeDoAtendente,
            assumido_em: new Date().toISOString(),
          })
          .eq('id', aberta.id);
        setAberta((p) => ({ ...p, assumido_por: user.id, assumido_nome: nomeDoAtendente }));
      }

      setMensagens((prev) => [
        ...prev,
        { role: 'agent', content: texto, created_at: new Date().toISOString() },
      ]);
      setResposta('');
    } catch (e) {
      console.error('[Inbox] responder:', e);
      setErro(e.message);
    } finally {
      setEnviando(false);
    }
  };

  const fechar = async () => {
    if (!aberta) return;
    await supabase
      .from('assistant_conversations')
      .update({
        status: 'closed',
        fechado_em: new Date().toISOString(),
        encerrado_por: 'atendente',
        assumido_nome: aberta.assumido_nome || nomeDoAtendente,
      })
      .eq('id', aberta.id);
    setAberta(null);
    carregar();
  };

  const pendentes = conversas.filter((c) => c.status === 'escalated').length;

  // Nome de quem está atendendo, do cadastro da conta.
  const nomeDoAtendente =
    user?.user_metadata?.full_name ||
    user?.user_metadata?.name ||
    user?.email?.split('@')[0] ||
    'Atendente';

  return (
    <div className="hb hb-shell">
      <header className="hb-top">
        <div className="hb-top-left">
          <button type="button" className="hb-btn" onClick={() => navigate('/dashboard')}>
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M10 3L5 8l5 5" strokeLinecap="square" />
            </svg>
            Painel
          </button>
          <span className="hb-crumb">
            Helpy / <b>Atendimentos</b>
            {pendentes > 0 && ` · ${pendentes} aguardando`}
          </span>
        </div>

        <div className="hb-top-right">
          <button
            type="button"
            className={filtro === 'escalated' ? 'hb-btn hb-btn--edge' : 'hb-btn'}
            onClick={() => setFiltro('escalated')}
          >
            Aguardando
          </button>
          <button
            type="button"
            className={filtro === 'todas' ? 'hb-btn hb-btn--edge' : 'hb-btn'}
            onClick={() => setFiltro('todas')}
          >
            Todas
          </button>
        </div>
      </header>

      {erro && (
        <div
          role="alert"
          style={{
            flexShrink: 0,
            padding: '.625rem 1.25rem',
            borderBottom: '1px solid var(--hb-rule-lit)',
            background: 'var(--hb-raised)',
            fontSize: '.8125rem',
          }}
        >
          {erro}
        </div>
      )}

      <div className="hb-body">
        {/* ---------- lista ---------- */}
        <aside className="hb-aside" style={{ width: '360px' }}>
          <div className="hb-chat">
            <div className="hb-chat-scroll" style={{ padding: 0 }}>
              {carregando && <div className="hb-skel" style={{ margin: '1.5rem' }} />}

              {!carregando && conversas.length === 0 && (
                <div style={{ padding: '2rem 1.5rem' }}>
                  <p className="hb-none">
                    {filtro === 'escalated'
                      ? 'Nenhum atendimento aguardando uma pessoa.'
                      : 'Nenhuma conversa ainda.'}
                  </p>
                </div>
              )}

              {conversas.map((c) => {
                const ativa = aberta?.id === c.id;
                const novo = c.status === 'escalated' && !c.lido_em;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => abrir(c)}
                    style={{
                      display: 'block',
                      width: '100%',
                      textAlign: 'left',
                      padding: '1.125rem 1.5rem',
                      background: ativa ? 'var(--hb-raised)' : 'none',
                      border: 'none',
                      borderBottom: '1px solid var(--hb-rule)',
                      borderLeft: novo ? '2px solid var(--hb-ink)' : '2px solid transparent',
                      cursor: 'pointer',
                      color: 'inherit',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', gap: '.75rem' }}>
                      <span className="hb-label" style={{ color: 'var(--hb-ink-2)' }}>
                        {nomeDoCliente(c)}
                      </span>
                      <span className="hb-flag">{quando(c.last_message_at)}</span>
                    </div>

                    <div
                      style={{
                        fontSize: '.875rem',
                        color: 'var(--hb-ink)',
                        margin: '.4rem 0 .3rem',
                        lineHeight: 1.4,
                      }}
                    >
                      {c.titulo || c.escalonado_motivo || 'Conversa com o assistente'}
                    </div>

                    {c.resumo && (
                      <p
                        style={{
                          fontSize: '.75rem',
                          color: 'var(--hb-ink-3)',
                          lineHeight: 1.5,
                          margin: 0,
                          display: '-webkit-box',
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical',
                          overflow: 'hidden',
                        }}
                      >
                        {c.resumo}
                      </p>
                    )}

                    <div style={{ marginTop: '.5rem', display: 'flex', gap: '.75rem', flexWrap: 'wrap' }}>
                      <span className="hb-flag">
                        {c.status === 'escalated'
                          ? 'aguardando'
                          : c.status === 'closed'
                          ? 'encerrado'
                          : 'em andamento'}
                      </span>
                      <span className="hb-flag">{c.message_count} msgs</span>
                      {c.nota != null && (
                        <span className="hb-flag" style={{ color: 'var(--hb-ink)' }}>
                          {estrelas(c.nota)}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </aside>

        {/* ---------- conversa ---------- */}
        <main className="hb-main">
          {!aberta && (
            <div className="hbx-state">
              <h2>Nenhum atendimento aberto</h2>
              <p>
                Escolha uma conversa à esquerda. Você vê o histórico inteiro com o assistente e
                pode assumir de onde ele parou.
              </p>
            </div>
          )}

          {aberta && (
            <div style={{ maxWidth: '46rem', margin: '0 auto', padding: '2.5rem 2rem 8rem' }}>
              <div style={{ borderBottom: '1px solid var(--hb-rule)', paddingBottom: '1.5rem', marginBottom: '2rem' }}>
                <div className="hb-doc-eyebrow">{nomeDoCliente(aberta)}</div>
                <h1 className="hb-doc-title" style={{ fontSize: '1.875rem', margin: '.5rem 0 1rem' }}>
                  {aberta.titulo || 'Conversa com o assistente'}
                </h1>

                {aberta.escalonado_motivo && (
                  <div style={{ marginBottom: '.75rem' }}>
                    <span className="hb-label">O problema</span>
                    <p style={{ fontSize: '.875rem', color: 'var(--hb-ink)', lineHeight: 1.6, marginTop: '.25rem' }}>
                      {aberta.escalonado_motivo}
                    </p>
                  </div>
                )}

                {aberta.resumo && (
                  <div style={{ marginBottom: '.75rem' }}>
                    <span className="hb-label">Resumo</span>
                    <p style={{ fontSize: '.8125rem', color: 'var(--hb-ink-2)', lineHeight: 1.6, marginTop: '.25rem' }}>
                      {aberta.resumo}
                    </p>
                  </div>
                )}

                {aberta.nota != null && (
                  <div style={{ marginBottom: '.75rem' }}>
                    <span className="hb-label">Avaliação do cliente</span>
                    <p style={{ fontSize: '.9375rem', color: 'var(--hb-ink)', marginTop: '.25rem' }}>
                      {estrelas(aberta.nota)}
                      {aberta.feedback_texto ? ` — "${aberta.feedback_texto}"` : ''}
                    </p>
                  </div>
                )}

                {aberta.lead_contato && (
                  <div style={{ marginBottom: '.75rem' }}>
                    <span className="hb-label">Contato</span>
                    <p style={{ fontSize: '.875rem', color: 'var(--hb-ink)', marginTop: '.25rem' }}>
                      {aberta.lead_contato}
                    </p>
                  </div>
                )}

                {aberta.status === 'closed' && (
                  <div style={{ marginTop: '1.25rem' }}>
                    <span className="hb-flag">
                      encerrado
                      {aberta.encerrado_por ? ` pelo ${aberta.encerrado_por}` : ''}
                    </span>
                  </div>
                )}
              </div>

              {carregandoMsgs && <div className="hb-skel" />}

              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                {mensagens.map((m, i) => (
                  <div className="hbx-turn" data-role={m.role === 'user' ? 'user' : 'assistant'} key={i}>
                    <span className="hbx-who">
                      {m.role === 'user'
                        ? nomeDoCliente(aberta)
                        : m.role === 'agent'
                        ? nomeDoAtendente
                        : assistentes[aberta.assistant_id] || 'Assistente'}
                    </span>
                    <div className="hbx-text">{m.content}</div>
                  </div>
                ))}
                <div ref={fimRef} />
              </div>
            </div>
          )}

          {aberta && (
            <div className="hbx-foot" style={{ position: 'sticky', bottom: 0 }}>
              <div className="hbx-foot-in">
                <div className="hbx-row">
                  <textarea
                    rows={1}
                    value={resposta}
                    onChange={(e) => setResposta(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        responder();
                      }
                    }}
                    placeholder="Responder ao cliente..."
                    disabled={enviando}
                    aria-label="Resposta"
                  />
                  <button
                    type="button"
                    className="hb-icon-btn"
                    onClick={responder}
                    disabled={!resposta.trim() || enviando}
                    aria-label="Enviar"
                  >
                    <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4">
                      <path d="M8 13V3M8 3L4 7M8 3l4 4" strokeLinecap="square" />
                    </svg>
                  </button>
                </div>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: '1rem',
                    marginTop: '.75rem',
                    flexWrap: 'wrap',
                  }}
                >
                  <span className="hbx-note" style={{ marginTop: 0 }}>
                    Enter envia · o cliente vê como {nomeDoAtendente}
                  </span>

                  {/* Encerrar fica AQUI, onde a mão já está. No cabeçalho
                      passava despercebido. */}
                  {aberta.status !== 'closed' ? (
                    <button type="button" className="hb-btn hb-btn--edge" onClick={fechar}>
                      Encerrar atendimento
                    </button>
                  ) : (
                    <span className="hbx-note" style={{ marginTop: 0 }}>
                      {aberta.nota != null
                        ? `Encerrado · ${estrelas(aberta.nota)}`
                        : 'Encerrado · sem avaliação'}
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}