// ============================================================
// HELPY — AssistantChatPage v1 — ARQUIVO COMPLETO
// Rota: /assistant/:id
// ============================================================

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import '@/styles/builder.css';
import '@/styles/assistant.css';

async function invoke(body) {
  const { data, error } = await supabase.functions.invoke('assistant-chat', { body });
  if (error) {
    let detalhe = error.message || 'Erro na função';
    try {
      const ctx = error.context;
      if (ctx && typeof ctx.text === 'function') {
        const txt = await ctx.text();
        try {
          detalhe = JSON.parse(txt)?.error || txt || detalhe;
        } catch {
          detalhe = txt || detalhe;
        }
      }
    } catch (_) {
      /* mantém a genérica */
    }
    throw new Error(detalhe);
  }
  if (data?.error) throw new Error(data.error);
  return data;
}

const IconSend = () => (
  <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4">
    <path d="M8 13V3M8 3L4 7M8 3l4 4" strokeLinecap="square" />
  </svg>
);

export default function AssistantChatPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [fatal, setFatal] = useState(null);

  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);

  const scrollRef = useRef(null);
  const areaRef = useRef(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const data = await invoke({ assistant_id: id, action: 'info' });
        if (!cancelled) setInfo(data);
      } catch (err) {
        if (!cancelled) setFatal(err.message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [id]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, thinking]);

  useEffect(() => {
    const el = areaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 112)}px`;
  }, [input]);

  const send = useCallback(
    async (text) => {
      const content = String(text || '').trim();
      if (!content || thinking) return;

      const next = [...messages, { role: 'user', content }];
      setMessages(next);
      setInput('');
      setThinking(true);

      try {
        const data = await invoke({ assistant_id: id, messages: next });
        setMessages([...next, { role: 'assistant', content: data.message }]);
      } catch (err) {
        setMessages([...next, { role: 'assistant', content: `[erro] ${err.message}` }]);
      } finally {
        setThinking(false);
      }
    },
    [id, messages, thinking]
  );

  const onKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send(input);
    }
  };

  // perguntas de partida, montadas a partir da ficha do próprio negócio
  const seeds = (() => {
    if (!info) return [];
    const cfg = info.configuration ?? {};
    const out = [];
    const cols = cfg.collections ?? {};

    const catalogo = Object.keys(cols).find(
      (k) => !['contatos', 'faq'].includes(k) && (cols[k] || []).length > 0
    );
    if (catalogo) {
      const primeiro = cols[catalogo][0] ?? {};
      const nome = primeiro.nome || primeiro.modelo || primeiro.titulo || primeiro.plano;
      out.push('O que vocês vendem?');
      if (nome) out.push(`Quanto custa o ${nome}?`);
    }
    if (cfg.fields?.formas_pagamento?.value) out.push('Quais as formas de pagamento?');
    if (cfg.fields?.entrega?.value) out.push('Como funciona a entrega?');
    if (cfg.fields?.horario?.value) out.push('Qual o horário de vocês?');
    return out.slice(0, 4);
  })();

  const nome = info?.name || 'Assistente';

  if (loading) {
    return (
      <div className="hb hbx-shell">
        <div className="hbx-state">
          <p>Carregando o assistente…</p>
        </div>
      </div>
    );
  }

  if (fatal) {
    return (
      <div className="hb hbx-shell">
        <div className="hbx-state">
          <h2>Não deu para abrir</h2>
          <p>{fatal}</p>
          <button type="button" className="hb-btn hb-btn--edge" onClick={() => navigate('/dashboard')}>
            Voltar ao painel
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="hb hbx-shell">
      <header className="hbx-top">
        <div className="hbx-id">
          <button type="button" className="hb-btn" onClick={() => navigate('/dashboard')}>
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M10 3L5 8l5 5" strokeLinecap="square" />
            </svg>
            Painel
          </button>
          <span className="hbx-name">{nome}</span>
          <span className="hbx-badge">{info?.business_type || 'no ar'}</span>
        </div>

        <div className="hb-top-right">
          <button
            type="button"
            className="hb-btn"
            onClick={() => setMessages([])}
            disabled={messages.length === 0 || thinking}
          >
            Limpar
          </button>
          <button
            type="button"
            className="hb-btn hb-btn--edge"
            onClick={() => navigate(`/assistant/${id}/edit`)}
          >
            Editar
          </button>
        </div>
      </header>

      <div className="hbx-scroll" ref={scrollRef}>
        <div className="hbx-inner">
          {messages.length === 0 && (
            <div className="hbx-hero">
              <h1>
                Converse com o {nome}
                <br />
                <em>como se fosse um cliente.</em>
              </h1>
              <p>
                Ele responde só com o que está no briefing. Se você perguntar algo que não foi
                configurado, ele vai dizer que não sabe e oferecer o contato humano — é assim que
                deve ser. Se isso acontecer com algo importante, volte e complete a ficha.
              </p>

              {seeds.length > 0 && (
                <div className="hbx-seeds">
                  {seeds.map((s) => (
                    <button
                      key={s}
                      type="button"
                      className="hbx-seed"
                      onClick={() => send(s)}
                      disabled={thinking}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {messages.map((m, i) => (
            <div className="hbx-turn" data-role={m.role} key={i}>
              <span className="hbx-who">{m.role === 'user' ? 'Cliente' : nome}</span>
              <div className="hbx-text">{m.content}</div>
            </div>
          ))}

          {thinking && (
            <div className="hbx-turn" data-role="assistant">
              <span className="hbx-who">{nome}</span>
              <div className="hbx-dots">
                <i />
                <i />
                <i />
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="hbx-foot">
        <div className="hbx-foot-in">
          <div className="hbx-row">
            <textarea
              ref={areaRef}
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onKeyDown}
              placeholder="Pergunte como um cliente perguntaria..."
              disabled={thinking}
              aria-label="Mensagem"
            />
            <button
              type="button"
              className="hb-icon-btn"
              onClick={() => send(input)}
              disabled={!input.trim() || thinking}
              aria-label="Enviar"
            >
              <IconSend />
            </button>
          </div>
          <span className="hbx-note">
            Enter envia · esta conversa não fica salva
          </span>
        </div>
      </div>
    </div>
  );
}