import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { UserPlus, User, Loader2, AlertCircle, Shield, Building2, ArrowRight } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { db } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import PasswordRequirements from '@/components/PasswordRequirements';
import PasswordStrengthIndicator from '@/components/PasswordStrengthIndicator';

export default function RegisterPage() {
  const [activeTab, setActiveTab] = useState('business');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [isAnonymousSelected, setIsAnonymousSelected] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const { register, registerBusiness, createAnonymousSession, clearAnonymousSession, isAuthenticated, isAnonymous } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    if (isAuthenticated) {
        navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  const validateForm = () => {
    if (activeTab === 'customer' && isAnonymousSelected) return true;

    if (!email || !email.includes('@')) {
      toast({ title: "Erro", description: "Por favor, insira um email válido.", variant: "destructive" });
      return false;
    }

    if (activeTab === 'business' && !companyName.trim()) {
      toast({ title: "Erro", description: "O nome da empresa é obrigatório.", variant: "destructive" });
      return false;
    }

    const pwCheck = db.validatePassword(password);
    if (!pwCheck.isValid) {
      toast({ title: "Senha Fraca", description: "A senha não atende aos requisitos de segurança.", variant: "destructive" });
      return false;
    }

    if (password !== confirmPassword) {
      toast({ title: "Erro", description: "As senhas não coincidem.", variant: "destructive" });
      return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setLoading(true);
    
    try {
      if (isAnonymous) clearAnonymousSession();

      // Anonymous Customer
      if (activeTab === 'customer' && isAnonymousSelected) {
        setTimeout(() => {
          createAnonymousSession();
          navigate('/assistants');
          setLoading(false);
        }, 800);
        return;
      }

      // Business Registration
      if (activeTab === 'business') {
         const result = await registerBusiness(email, password, companyName);
         if (result.success) {
           navigate('/verify-registration', { state: { userId: result.userId, companyName, email } });
         }
      } 
      // Customer Registration
      else {
         const success = await register(email, password, 'end_customer', 'free', null);
         if (success) {
           navigate('/login'); // Customers usually just login or verifying depending on flow
         }
      }

    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet><title>Criar Conta - ChatSupport AI</title></Helmet>
      <div className="min-h-screen bg-black flex items-center justify-center px-4 py-12 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-900/20 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-violet-900/20 rounded-full blur-3xl translate-x-1/2 translate-y-1/2"></div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-2xl z-10">
          <div className="bg-neutral-900/80 backdrop-blur-xl border border-neutral-800 rounded-2xl p-8 shadow-2xl">
            <div className="text-center mb-8">
              <div className="bg-gradient-to-br from-purple-600 to-violet-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/20">
                <UserPlus className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-white mb-2">
                {isAnonymousSelected ? 'Modo Anônimo' : 'Comece Agora'}
              </h1>
              <p className="text-neutral-400">
                {isAnonymousSelected ? 'Acesse os assistentes sem criar conta' : 'Crie sua conta para todos os recursos'}
              </p>
            </div>

            {/* Type Selector */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-neutral-950 rounded-xl mb-8 border border-neutral-800">
              <button onClick={() => { setActiveTab('business'); setIsAnonymousSelected(false); }} className={`flex items-center justify-center gap-2 py-3 rounded-lg text-sm font-medium transition-all ${activeTab === 'business' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-500 hover:text-neutral-300'}`}>
                <Building2 className="w-4 h-4" /> Sou Empresa
              </button>
              <button onClick={() => setActiveTab('customer')} className={`flex items-center justify-center gap-2 py-3 rounded-lg text-sm font-medium transition-all ${activeTab === 'customer' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-500 hover:text-neutral-300'}`}>
                <User className="w-4 h-4" /> Sou Cliente
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {activeTab === 'customer' && (
                <div className={`p-4 rounded-xl border flex items-start gap-3 transition-colors ${isAnonymousSelected ? 'bg-violet-900/20 border-violet-500/50' : 'bg-neutral-950/50 border-neutral-800'}`}>
                   <div className="pt-0.5">
                     <input type="checkbox" id="anon-check" checked={isAnonymousSelected} onChange={(e) => setIsAnonymousSelected(e.target.checked)} className="w-4 h-4 rounded border-neutral-700 bg-neutral-900 text-violet-600 focus:ring-violet-600 focus:ring-offset-neutral-900" />
                   </div>
                   <label htmlFor="anon-check" className="text-sm cursor-pointer select-none">
                      <span className="block font-medium text-white flex items-center gap-2"><Shield className="w-3 h-3 text-violet-400" /> Não quero me identificar</span>
                      <span className="block text-neutral-500 mt-1">Você poderá usar o chat sem criar conta, mas seu histórico não será salvo na nuvem.</span>
                   </label>
                </div>
              )}

              <AnimatePresence>
                {(!isAnonymousSelected || activeTab === 'business') ? (
                  <motion.div key="form" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="space-y-6">
                    {activeTab === 'business' && (
                      <div>
                        <label className="block text-sm font-medium text-neutral-300 mb-2">Nome da Empresa</label>
                        <input type="text" value={companyName} onChange={(e) => setCompanyName(e.target.value)} className="w-full px-4 py-3 bg-neutral-950 border border-neutral-800 rounded-lg text-white focus:ring-2 focus:ring-violet-500 focus:outline-none" placeholder="Sua Empresa Ltda" />
                      </div>
                    )}
                    <div>
                      <label className="block text-sm font-medium text-neutral-300 mb-2">Email</label>
                      <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-4 py-3 bg-neutral-950 border border-neutral-800 rounded-lg text-white focus:ring-2 focus:ring-violet-500 focus:outline-none" placeholder="seu@email.com" />
                    </div>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-neutral-300 mb-2">Senha</label>
                        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-4 py-3 bg-neutral-950 border border-neutral-800 rounded-lg text-white focus:ring-2 focus:ring-violet-500 focus:outline-none" placeholder="••••••••" />
                        <PasswordStrengthIndicator password={password} />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-neutral-300 mb-2">Confirmar Senha</label>
                        <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="w-full px-4 py-3 bg-neutral-950 border border-neutral-800 rounded-lg text-white focus:ring-2 focus:ring-violet-500 focus:outline-none" placeholder="••••••••" />
                      </div>
                    </div>
                    <PasswordRequirements password={password} />
                  </motion.div>
                ) : null}
              </AnimatePresence>

              <Button type="submit" disabled={loading} className="w-full bg-violet-600 hover:bg-violet-700 text-white py-6 text-lg font-semibold shadow-lg shadow-violet-900/20">
                {loading ? <span className="flex items-center gap-2"><Loader2 className="w-5 h-5 animate-spin" /> Processando...</span> : (isAnonymousSelected ? <span className="flex items-center gap-2">Entrar como Anônimo <ArrowRight className="w-5 h-5" /></span> : 'Criar Conta')}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-neutral-400">Já tem uma conta? <Link to="/login" className="text-violet-400 hover:text-violet-300 font-medium">Fazer login</Link></p>
            </div>
          </div>
        </motion.div>
      </div>
    </>
  );
}