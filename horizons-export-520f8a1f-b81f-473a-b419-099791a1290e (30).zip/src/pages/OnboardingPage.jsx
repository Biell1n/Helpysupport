import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase/client';
import { useOnboardingChat } from '@/hooks/useOnboardingChat';
import OnboardingChat from '@/components/onboarding/OnboardingChat';
import { useNavigate, Link } from 'react-router-dom';
import { Loader2, AlertCircle, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { getActiveSession } from '@/lib/getActiveSession';

export default function OnboardingPage() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [sessionId, setSessionId] = useState(null);
  const [businessContext, setBusinessContext] = useState(null);
  
  const [businessType, setBusinessType] = useState('');
  const [businessDescription, setBusinessDescription] = useState('');
  const [assistantGoal, setAssistantGoal] = useState('');
  const [formError, setFormError] = useState('');
  const [isCreatingSession, setIsCreatingSession] = useState(false);
  const [isCheckingSession, setIsCheckingSession] = useState(true);

  const { 
    messages, 
    loading: chatLoading, 
    error: chatError, 
    sendMessage,
    loadHistory
  } = useOnboardingChat();

  useEffect(() => {
    const checkActiveSession = async () => {
      if (!user) {
        setIsCheckingSession(false);
        return;
      }
      try {
        const existingSession = await getActiveSession(user.id);
        if (existingSession) {
          setSessionId(existingSession.id);
          setBusinessContext({
            businessType: existingSession.business_type,
            businessDescription: existingSession.business_description,
            assistantGoal: existingSession.assistant_goal
          });
        }
      } catch (err) {
        console.error("Error checking session:", err);
      } finally {
        setIsCheckingSession(false);
      }
    };
    checkActiveSession();
  }, [user]);

  useEffect(() => {
    if (sessionId) {
      loadHistory(sessionId);
    }
  }, [sessionId, loadHistory]);

  const handleStartOnboarding = async (e) => {
    e.preventDefault();
    setFormError('');

    if (!businessType.trim() || !businessDescription.trim() || !assistantGoal.trim()) {
      setFormError('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    if (!user) return;

    setIsCreatingSession(true);
    
    try {
      // FIX BUG A: Explicitly check for existing session right before insert
      let existingSession = await getActiveSession(user.id);
      
      if (existingSession) {
        setSessionId(existingSession.id);
        setBusinessContext({ 
          businessType: existingSession.business_type, 
          businessDescription: existingSession.business_description, 
          assistantGoal: existingSession.assistant_goal 
        });
        setIsCreatingSession(false);
        return;
      }

      const { data, error } = await supabase
        .from('onboarding_sessions')
        .insert({
          user_id: user.id,
          business_type: businessType,
          business_description: businessDescription,
          assistant_goal: assistantGoal,
          status: 'active',
          onboarding_progress: 0,
          collected_data: {}
        })
        .select('id')
        .single();

      if (error) {
        // FIX BUG A: Handle 409 Unique Violation Gracefully
        if (error.code === '23505') {
          existingSession = await getActiveSession(user.id);
          if (existingSession) {
            setSessionId(existingSession.id);
            setBusinessContext({ businessType, businessDescription, assistantGoal });
            setIsCreatingSession(false);
            return;
          }
        }
        throw error;
      }
      
      if (data?.id) {
        setSessionId(data.id);
        setBusinessContext({ businessType, businessDescription, assistantGoal });
        toast({
          title: "Sessão iniciada",
          description: "Vamos configurar seu assistente!",
        });
      }
    } catch (err) {
      const errorMessage = err.message || 'Erro ao criar sessão de onboarding.';
      setFormError(errorMessage);
      toast({
        variant: "destructive",
        title: "Erro no setup",
        description: errorMessage,
      });
    } finally {
      setIsCreatingSession(false);
    }
  };

  const handleSendMessage = async (text, context) => {
    if (!sessionId || !user) return;
    await sendMessage(text, sessionId, user.id, context || businessContext);
  };

  if (authLoading || isCheckingSession) {
    return (
      <div className="min-h-screen bg-neutral-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-neutral-950 pt-24 pb-12 px-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-neutral-900 border border-white/10 rounded-2xl p-8 shadow-xl text-center">
          <div className="w-16 h-16 bg-red-500/10 border border-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-8 h-8 text-red-500" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-3">Acesso Negado</h1>
          <p className="text-neutral-400 mb-6">Você precisa estar logado para iniciar o onboarding do assistente.</p>
          <Link to="/auth">
            <Button className="w-full bg-primary text-primary-foreground font-bold h-12 rounded-xl">
              <LogIn className="w-4 h-4 mr-2" />
              Fazer Login
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  if (!sessionId) {
    return (
      <div className="min-h-screen bg-neutral-950 pt-24 pb-12 px-4 flex items-center justify-center">
        <div className="max-w-2xl w-full bg-neutral-900 border border-white/10 rounded-2xl p-8 shadow-xl">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold text-white mb-3">Configuração Inicial</h1>
            <p className="text-neutral-400">Conte-nos um pouco sobre o seu negócio para que a IA possa personalizar seu assistente.</p>
          </div>

          {formError && (
            <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3 text-red-400">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p className="text-sm">{formError}</p>
            </div>
          )}

          <form onSubmit={handleStartOnboarding} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-2">Tipo de Negócio *</label>
              <select 
                value={businessType}
                onChange={(e) => setBusinessType(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-xl px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent outline-none appearance-none"
              >
                <option value="" disabled>Selecione uma opção...</option>
                <option value="Restaurante">Restaurante / Delivery</option>
                <option value="Clinica">Clínica / Consultório</option>
                <option value="Ecommerce">E-commerce</option>
                <option value="Servicos">Prestação de Serviços</option>
                <option value="Imobiliaria">Imobiliária</option>
                <option value="Outro">Outro</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-2">Descrição do Negócio *</label>
              <textarea 
                value={businessDescription}
                onChange={(e) => setBusinessDescription(e.target.value)}
                placeholder="Descreva o que sua empresa faz, principais produtos/serviços..."
                className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-xl px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent outline-none min-h-[120px] resize-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-2">Qual o objetivo principal do assistente? *</label>
              <textarea 
                value={assistantGoal}
                onChange={(e) => setAssistantGoal(e.target.value)}
                placeholder="Ex: Agendar consultas, tirar dúvidas sobre produtos, qualificar leads..."
                className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-xl px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent outline-none min-h-[100px] resize-none"
              />
            </div>

            <Button 
              type="submit" 
              disabled={isCreatingSession}
              className="w-full h-12 bg-primary text-primary-foreground font-bold text-lg rounded-xl hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20"
            >
              {isCreatingSession ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Iniciando Setup...
                </>
              ) : (
                'Começar Conversa'
              )}
            </Button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-950 pt-20 pb-4 px-4 flex flex-col">
      <div className="container max-w-4xl mx-auto flex-1 h-[calc(100vh-6rem)]">
        {chatError && (
          <div className="mb-4 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3 text-red-400">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p className="text-sm font-medium">Erro de chat: {chatError}</p>
          </div>
        )}
        <OnboardingChat 
          messages={messages} 
          loading={chatLoading}
          onSendMessage={handleSendMessage} 
          context={businessContext}
        />
      </div>
    </div>
  );
}