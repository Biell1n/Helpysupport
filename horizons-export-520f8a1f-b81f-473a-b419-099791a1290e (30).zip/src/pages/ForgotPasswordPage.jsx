import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { KeyRound, ArrowLeft, Loader2, Mail, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');
    
    try {
      const { data, error } = await supabase.functions.invoke('send-reset-email', {
        body: { email }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setSent(true);
      toast({
        title: "Sucesso!",
        description: "Email de recuperação enviado.",
      });
    } catch (error) {
      console.error("Reset password error:", error);
      setErrorMsg(error.message || "Ocorreu um erro ao enviar o email de recuperação. Pode haver restrições na API de envio.");
      toast({
        variant: "destructive",
        title: "Erro ao enviar",
        description: "Falha ao processar solicitação de recuperação."
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Recuperar Senha - ChatSupport AI</title>
      </Helmet>

      <div className="min-h-screen bg-black flex items-center justify-center px-4 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-white/5 rounded-full blur-[120px] pointer-events-none"></div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          className="w-full max-w-md relative z-10"
        >
          <div className="bg-neutral-900/80 backdrop-blur-xl border border-neutral-800 rounded-2xl p-8 shadow-2xl">
            {sent ? (
              <div className="text-center py-4">
                <div className="w-16 h-16 bg-neutral-800 rounded-full flex items-center justify-center mx-auto mb-6 border border-neutral-700">
                  <Mail className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Check your email for reset link</h2>
                <p className="text-neutral-400 mb-8">
                  Enviamos as instruções de recuperação para <strong>{email}</strong>.
                </p>
                <Link to="/login">
                  <Button variant="outline" className="w-full border-neutral-700 text-white hover:bg-neutral-800 hover:text-white">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Voltar para Login
                  </Button>
                </Link>
              </div>
            ) : (
              <>
                <div className="text-center mb-8">
                  <div className="bg-neutral-800 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-neutral-700">
                    <KeyRound className="w-8 h-8 text-white" />
                  </div>
                  <h1 className="text-2xl font-bold text-white mb-2">Esqueceu a senha?</h1>
                  <p className="text-neutral-400">
                    Digite seu email e enviaremos um link para você redefinir sua senha.
                  </p>
                </div>

                {errorMsg && (
                   <div className="mb-6 bg-red-500/10 border border-red-500/50 rounded-lg p-4 flex items-start gap-3">
                     <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                     <div className="text-sm text-red-200">{errorMsg}</div>
                   </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-2">Email</label>
                    <input 
                      type="email" 
                      required 
                      value={email} 
                      onChange={(e) => setEmail(e.target.value)} 
                      className="w-full px-4 py-3 bg-neutral-950 border border-neutral-800 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-white placeholder-neutral-600" 
                      placeholder="seu@email.com" 
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={loading || !email} 
                    className="w-full bg-white hover:bg-neutral-200 text-black py-6 text-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <span className="flex items-center gap-2">
                        <Loader2 className="w-5 h-5 animate-spin" /> Enviando...
                      </span>
                    ) : errorMsg ? (
                      'Tentar Novamente'
                    ) : (
                      'Enviar Link de Recuperação'
                    )}
                  </Button>
                </form>

                <div className="mt-6 text-center">
                  <Link to="/login" className="text-sm text-neutral-500 hover:text-white flex items-center justify-center gap-2 transition-colors">
                    <ArrowLeft className="w-4 h-4" />
                    Voltar para Login
                  </Link>
                </div>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </>
  );
}