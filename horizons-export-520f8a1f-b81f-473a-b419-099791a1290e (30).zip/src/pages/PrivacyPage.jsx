import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Footer from '@/components/Footer';

export default function PrivacyPage() {
  return (
    <>
      <Helmet>
        <title>Política de Privacidade - Helpy</title>
        <meta name="description" content="Política de privacidade e proteção de dados da plataforma Helpy." />
      </Helmet>

      <div className="min-h-screen bg-black text-white selection:bg-white/30">
        <header className="fixed top-0 w-full bg-black/90 backdrop-blur-md border-b border-white/5 z-50">
          <div className="container mx-auto px-6 h-20 flex items-center max-w-4xl">
            <Link to="/" className="flex items-center gap-2 text-neutral-400 hover:text-white transition-colors text-sm font-medium">
              <ArrowLeft className="w-4 h-4" />
              Voltar para o app
            </Link>
          </div>
        </header>

        <main className="pt-32 pb-32 px-6">
          <div className="container mx-auto max-w-3xl">
            <div className="mb-16">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight">Política de Privacidade</h1>
              <p className="text-lg text-neutral-400">
                Última atualização: 21 de Março de 2026
              </p>
            </div>

            <div className="space-y-12 text-neutral-300">
              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-white">1. Coleta de Informações</h2>
                <p className="leading-relaxed">
                  Coletamos apenas as informações estritamente necessárias para o funcionamento e melhoria dos nossos serviços. Isso inclui:
                </p>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Dados da conta (nome, e-mail) fornecidos no registro.</li>
                  <li>Informações inseridas para o treinamento dos assistentes (descrições, FAQ).</li>
                  <li>Histórico de interações entre usuários finais e os assistentes criados.</li>
                </ul>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-white">2. Uso dos Dados</h2>
                <p className="leading-relaxed">
                  As informações coletadas são utilizadas exclusivamente para:
                </p>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Fornecer, operar e manter a plataforma Helpy.</li>
                  <li>Processar as respostas da inteligência artificial através de provedores parceiros (como OpenAI).</li>
                  <li>Melhorar a segurança e a usabilidade do serviço.</li>
                  <li>Enviar comunicações essenciais sobre sua conta.</li>
                </ul>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-white">3. Proteção de Dados</h2>
                <p className="leading-relaxed">
                  Implementamos medidas de segurança técnicas e organizacionais para proteger suas informações contra acesso, alteração, divulgação ou destruição não autorizada. Nossos bancos de dados são criptografados em repouso e em trânsito, utilizando infraestrutura moderna e segura.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-white">4. Direitos do Usuário</h2>
                <p className="leading-relaxed">
                  Você tem o direito de acessar, corrigir ou excluir seus dados pessoais a qualquer momento. Você pode gerenciar suas informações diretamente nas configurações da sua conta ou excluir seus assistentes e dados associados de forma permanente.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-white">5. Informações de Contato</h2>
                <p className="leading-relaxed">
                  Se você tiver dúvidas ou preocupações sobre esta Política de Privacidade ou sobre nossas práticas de manuseio de dados, entre em contato conosco através do suporte na plataforma ou pelo e-mail de contato disponível no seu painel.
                </p>
              </section>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    </>
  );
}