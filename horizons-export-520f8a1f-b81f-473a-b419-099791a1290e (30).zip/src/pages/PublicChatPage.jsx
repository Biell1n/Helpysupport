// ============================================================
// HELPY — PublicChatPage v8 — ARQUIVO COMPLETO
// Rota: /c/:token  — PÚBLICA, sem login.
//
// É a tela que o cliente do seu cliente vê. Fala com a edge function
// public-chat, que valida o token, aplica os tetos e GRAVA a conversa.
//
// v2: a conversa é retomada ao voltar. O visitante ganha um id no
// próprio navegador, e o id da conversa fica guardado por token — assim
// quem fecha a aba e volta continua de onde parou.
// ============================================================

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import '@/styles/builder.css';
import '@/styles/assistant.css';

async function chamar(body) {
  const { data, error } = await supabase.functions.invoke('public-chat', { body });
  if (error) {
    let detalhe = error.message || 'Erro na conexão';
    try {
      const ctx = error.context;
      if (ctx && typeof ctx.text === 'function') {
        const txt = await ctx.text();
        try {
          detalhe = JSON.parse(txt)?.error || txt || detalhe;
        } catch {
          detalhe = txt || detalhe;
        }
      }
    } catch (_) {
      /* mantém a genérica */
    }
    throw new Error(detalhe);
  }
  if (data?.error) throw new Error(data.error);
  return data;
}

const IconSend = () => (
  <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4">
    <path d="M8 13V3M8 3L4 7M8 3l4 4" strokeLinecap="square" />
  </svg>
);

/** Id do visitante, criado uma vez e guardado no navegador. */
function obterVisitorId() {
  const CHAVE = 'helpy_visitor_id';
  try {
    let v = window.localStorage.getItem(CHAVE);
    if (!v) {
      v =
        typeof crypto !== 'undefined' && crypto.randomUUID
          ? crypto.randomUUID()
          : `v${Date.now()}${Math.random().toString(36).slice(2)}`;
      window.localStorage.setItem(CHAVE, v);
    }
    return v;
  } catch (_) {
    // navegador sem armazenamento: id só desta aba
    if (!window.__helpyVisitor) {
      window.__helpyVisitor = `t${Date.now()}${Math.random().toString(36).slice(2)}`;
    }
    return window.__helpyVisitor;
  }
}

const chaveConversa = (token) => `helpy_conv_${token}`;

export default function PublicChatPage() {
  const { token } = useParams();
  const visitorId = useRef(obterVisitorId()).current;
  const [conversaId, setConversaId] = useState(() => {
    try {
      return window.localStorage.getItem(chaveConversa(token)) || null;
    } catch (_) {
      return null;
    }
  });
  const [precisaLogin, setPrecisaLogin] = useState(false);
  // marca d'água do último "agent" já recebido, para pedir só o que é novo
  const ultimoAgente = useRef(null);
  // quando um humano assume, a IA sai de cena e a tela muda de cara
  const [modoHumano, setModoHumano] = useState(false);
  const [conta, setConta] = useState(null);
  // Ciclo do atendimento, para o cliente saber o que está acontecendo:
  // encaminhado -> alguém assumiu -> encerrado -> avaliação.
  const [statusConv, setStatusConv] = useState(null);
  const [atendente, setAtendente] = useState(null);
  const [assumido, setAssumido] = useState(false);
  const [jaAvaliou, setJaAvaliou] = useState(false);
  const [nota, setNota] = useState(0);
  const [comentario, setComentario] = useState('');
  const [enviandoNota, setEnviandoNota] = useState(false);

  const [info, setInfo] = useState(null);
  const [carregando, setCarregando] = useState(true);
  const [fatal, setFatal] = useState(null);

  const [mensagens, setMensagens] = useState([]);
  const [texto, setTexto] = useState('');
  const [pensando, setPensando] = useState(false);

  const scrollRef = useRef(null);
  const areaRef = useRef(null);

  useEffect(() => {
    let cancelado = false;
    (async () => {
      setCarregando(true);
      try {
        const data = await chamar({ token, action: 'info' });
        if (cancelado) return;
        setInfo(data);

        // retoma a conversa anterior, se houver
        const salva = (() => {
          try {
            return window.localStorage.getItem(chaveConversa(token));
          } catch (_) {
            return null;
          }
        })();

        if (salva) {
          const hist = await chamar({
            token,
            action: 'history',
            conversation_id: salva,
            visitor_id: visitorId,
          });
          if (cancelado) return;
          if (hist?.status) setStatusConv(hist.status);
          if (hist?.assumido_nome) setAtendente(hist.assumido_nome);
          if (hist?.assumido) setAssumido(true);
          if (hist?.ja_avaliou) setJaAvaliou(true);
          if (hist?.status === 'escalated') setModoHumano(true);

          if (hist?.messages?.length) {
            setMensagens(hist.messages.map((m) => ({ role: m.role, content: m.content })));
            setConversaId(salva);
            const ultimoDoAgente = [...hist.messages].reverse().find((m) => m.role === 'agent');
            if (ultimoDoAgente) ultimoAgente.current = ultimoDoAgente.created_at;
          } else {
            try {
              window.localStorage.removeItem(chaveConversa(token));
            } catch (_) {}
            setConversaId(null);
          }
        }
      } catch (err) {
        if (!cancelado) setFatal(err.message);
      } finally {
        if (!cancelado) setCarregando(false);
      }
    })();
    return () => {
      cancelado = true;
    };
  }, [token, visitorId]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [mensagens, pensando]);

  // O visitante entra numa aba separada. Quando volta para esta, a sessão
  // já está no armazenamento — só precisamos perceber. Abrir noutra aba
  // evita mexer no fluxo de login e não perde a conversa em andamento.
  useEffect(() => {
    let vivo = true;

    const conferir = async () => {
      try {
        const { data } = await supabase.auth.getSession();
        if (!vivo) return;
        const u = data?.session?.user ?? null;
        setConta(u ? u.email || u.user_metadata?.full_name || 'sua conta' : null);
        if (u) setPrecisaLogin(false);
      } catch (_) {
        /* sem sessão */
      }
    };

    conferir();
    const { data: sub } = supabase.auth.onAuthStateChange(() => conferir());
    window.addEventListener('focus', conferir);
    document.addEventListener('visibilitychange', conferir);

    return () => {
      vivo = false;
      sub?.subscription?.unsubscribe?.();
      window.removeEventListener('focus', conferir);
      document.removeEventListener('visibilitychange', conferir);
    };
  }, []);

  // Quando o atendimento é assumido por uma pessoa, a resposta dela nasce
  // no banco, não nesta aba. Sem esta consulta periódica o cliente nunca
  // veria o humano falando.
  useEffect(() => {
    if (!conversaId) return;

    const buscar = async () => {
      try {
        const data = await chamar({
          token,
          action: 'poll',
          conversation_id: conversaId,
          visitor_id: visitorId,
          desde: ultimoAgente.current,
        });
        if (data?.status) setStatusConv(data.status);
        if (data?.status === 'escalated') setModoHumano(true);
        if (data?.assumido_nome) setAtendente(data.assumido_nome);
        if (typeof data?.assumido === 'boolean') setAssumido(data.assumido);
        if (data?.ja_avaliou) setJaAvaliou(true);
        const novas = data?.messages ?? [];
        if (novas.length) {
          ultimoAgente.current = novas[novas.length - 1].created_at;
          setMensagens((prev) => [
            ...prev,
            ...novas.map((m) => ({ role: 'agent', content: m.content })),
          ]);
        }
      } catch (_) {
        // silencioso: é uma consulta de fundo, não pode poluir a conversa
      }
    };

    const t = setInterval(buscar, 10000);
    return () => clearInterval(t);
  }, [conversaId, token, visitorId]);

  useEffect(() => {
    const el = areaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 112)}px`;
  }, [texto]);

  const enviar = useCallback(
    async (bruto) => {
      const content = String(bruto || '').trim();
      if (!content || pensando) return;

      const proximas = [...mensagens, { role: 'user', content }];
      setMensagens(proximas);
      setTexto('');
      setPensando(true);

      try {
        const data = await chamar({
          token,
          messages: proximas,
          visitor_id: visitorId,
          conversation_id: conversaId,
        });

        if (data.modo === 'humano') setModoHumano(true);

        if (data.conversation_id && data.conversation_id !== conversaId) {
          setConversaId(data.conversation_id);
          try {
            window.localStorage.setItem(chaveConversa(token), data.conversation_id);
          } catch (_) {}
        }

        if (data.message) {
          setMensagens([...proximas, { role: 'assistant', content: data.message }]);
        }
        // sem data.message significa turno do humano: nada a acrescentar,
        // a resposta dele chega pela consulta periódica
      } catch (err) {
        // o servidor sinaliza quando o limite de anônimo acabou
        if (/limite de mensagens para visitantes/i.test(err.message)) setPrecisaLogin(true);
        // Papel "sistema", não "assistant". Antes o aviso de limite
        // aparecia como se a atendente tivesse dito, o que fazia ela
        // parecer quebrada.
        setMensagens([...proximas, { role: 'sistema', content: err.message }]);
      } finally {
        setPensando(false);
      }
    },
    [token, mensagens, pensando, visitorId, conversaId]
  );

  const enviarNota = async () => {
    if (!nota || !conversaId || enviandoNota) return;
    setEnviandoNota(true);
    try {
      await chamar({
        token,
        action: 'feedback',
        conversation_id: conversaId,
        visitor_id: visitorId,
        nota,
        texto: comentario,
      });
      setJaAvaliou(true);
    } catch (_) {
      setJaAvaliou(true); // não vale travar o cliente por causa disso
    } finally {
      setEnviandoNota(false);
    }
  };

  const reabrirConversa = async () => {
    if (!conversaId) return;
    try {
      const d = await chamar({
        token,
        action: 'reabrir',
        conversation_id: conversaId,
        visitor_id: visitorId,
      });
      setStatusConv(d?.status ?? 'open');
      setJaAvaliou(false);
      setNota(0);
      setComentario('');
    } catch (_) {
      /* silencioso */
    }
  };

  const encerrarConversa = async () => {
    if (!conversaId) return;
    try {
      await chamar({ token, action: 'encerrar', conversation_id: conversaId, visitor_id: visitorId });
      setStatusConv('closed');
    } catch (_) {
      /* silencioso */
    }
  };

  const onKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      enviar(texto);
    }
  };

  const nome = info?.name || 'Atendimento';

  if (carregando) {
    return (
      <div className="hb hbx-shell">
        <div className="hbx-state">
          <p>Abrindo o atendimento…</p>
        </div>
      </div>
    );
  }

  if (fatal) {
    return (
      <div className="hb hbx-shell">
        <div className="hbx-state">
          <h2>Atendimento indisponível</h2>
          <p>{fatal}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="hb hbx-shell">
      <header className="hbx-top">
        <div className="hbx-id">
          <span className="hbx-name">{nome}</span>
          {info?.negocio && <span className="hbx-badge">{info.negocio}</span>}
        </div>

        <div className="hb-top-right">
          {conta ? (
            <span className="hbx-badge" title={conta}>
              conectado
            </span>
          ) : (
            <>
              <a
                className="hb-btn"
                href="/auth"
                target="_blank"
                rel="noreferrer"
                title="Abre numa aba nova para você não perder esta conversa"
              >
                Entrar
              </a>
              <a className="hb-btn hb-btn--edge" href="/auth" target="_blank" rel="noreferrer">
                Criar conta
              </a>
            </>
          )}
        </div>
      </header>

      <div className="hbx-scroll" ref={scrollRef}>
        <div className="hbx-inner">
          {mensagens.length === 0 && (
            <div className="hbx-hero">
              <h1>
                Olá.
                <br />
                <em>Como posso ajudar?</em>
              </h1>
              <p>
                {info?.negocio
                  ? `Você está falando com o atendimento de ${info.negocio}.`
                  : 'Mande sua dúvida que eu respondo por aqui.'}
              </p>
            </div>
          )}

          {mensagens.map((m, i) =>
            m.role === 'sistema' ? (
              <div
                key={i}
                style={{
                  border: '1px solid var(--hb-rule-lit)',
                  padding: '.875rem 1rem',
                  fontSize: '.8125rem',
                  lineHeight: 1.6,
                  color: 'var(--hb-ink-2)',
                }}
              >
                {m.content}
              </div>
            ) : (
              <div className="hbx-turn" data-role={m.role} key={i}>
                <span className="hbx-who">
                  {m.role === 'user' ? 'Você' : m.role === 'agent' ? 'Atendente' : nome}
                </span>
                <div className="hbx-text">{m.content}</div>
              </div>
            )
          )}

          {/* Ciclo do atendimento, contado ao cliente passo a passo. */}
          {statusConv === 'escalated' && !assumido && (
            <div className="hbx-aviso">
              Seu chamado foi aberto. <b>Alguém da equipe vai assumir</b> em breve — pode deixar
              esta janela aberta ou voltar por este mesmo link depois.
            </div>
          )}

          {statusConv === 'escalated' && assumido && (
            <div className="hbx-aviso hbx-aviso--bom">
              <b>{atendente || 'Um atendente'}</b> assumiu seu chamado. As próximas respostas são de
              uma pessoa, e podem levar alguns minutos.
            </div>
          )}

          {statusConv === 'closed' && !jaAvaliou && (
            <div className="hbx-fb">
              <p className="hbx-fb-t">Atendimento concluído.</p>
              <p className="hbx-fb-p">
                {atendente
                  ? `${atendente} encerrou este chamado. Como foi para você?`
                  : 'O assunto foi resolvido. Como foi este atendimento para você?'}
              </p>

              <div className="hbx-stars">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    className="hbx-star"
                    data-on={nota >= n ? 'true' : 'false'}
                    onClick={() => setNota(n)}
                    aria-label={`${n} de 5`}
                  >
                    {nota >= n ? '\u2605' : '\u2606'}
                  </button>
                ))}
              </div>

              <textarea
                rows={2}
                value={comentario}
                onChange={(e) => setComentario(e.target.value)}
                placeholder="Quer contar algo? (opcional)"
              />

              <div className="hbx-fb-f">
                <button
                  type="button"
                  className="hb-btn hb-btn--solid"
                  onClick={enviarNota}
                  disabled={!nota || enviandoNota}
                >
                  {enviandoNota ? 'Enviando' : 'Enviar avaliação'}
                </button>
                <button type="button" className="hb-btn" onClick={() => setJaAvaliou(true)}>
                  Não avaliar
                </button>
                <button type="button" className="hb-btn" onClick={reabrirConversa}>
                  Ainda preciso de ajuda
                </button>
              </div>
            </div>
          )}

          {statusConv === 'closed' && jaAvaliou && (
            <div className="hbx-aviso">
              <p className="hbx-obrigado">
                Atendimento encerrado. Esta conversa fica disponível por sete dias neste mesmo link.{' '}
                <button
                  type="button"
                  onClick={reabrirConversa}
                  style={{
                    background: 'none', border: 'none', padding: 0, cursor: 'pointer',
                    color: 'var(--hb-ink)', borderBottom: '1px solid currentColor', font: 'inherit',
                  }}
                >
                  Reabrir
                </button>{' '}
                se surgir outra dúvida.
              </p>
            </div>
          )}

          {pensando && !modoHumano && (
            <div className="hbx-turn" data-role="assistant">
              <span className="hbx-who">{nome}</span>
              <div className="hbx-dots">
                <i />
                <i />
                <i />
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="hbx-foot">
        <div className="hbx-foot-in">
          <div className="hbx-row">
            <textarea
              ref={areaRef}
              rows={1}
              value={texto}
              onChange={(e) => setTexto(e.target.value)}
              onKeyDown={onKeyDown}
              placeholder={
                statusConv === 'closed'
                  ? 'Atendimento encerrado'
                  : modoHumano
                  ? 'Escreva para o atendente...'
                  : precisaLogin
                  ? 'Entre com uma conta para continuar'
                  : 'Escreva sua mensagem...'
              }
              disabled={pensando || statusConv === 'closed' || (precisaLogin && !modoHumano)}
              aria-label="Mensagem"
            />
            <button
              type="button"
              className="hb-icon-btn"
              onClick={() => enviar(texto)}
              disabled={!texto.trim() || pensando || statusConv === 'closed' || (precisaLogin && !modoHumano)}
              aria-label="Enviar"
            >
              <IconSend />
            </button>
          </div>
          {statusConv === 'closed' ? (
            <span className="hbx-note">
              Conversa encerrada ·{' '}
              <button
                type="button"
                onClick={reabrirConversa}
                style={{
                  background: 'none', border: 'none', padding: 0, cursor: 'pointer',
                  color: 'var(--hb-ink-2)', borderBottom: '1px solid currentColor', font: 'inherit',
                }}
              >
                reabrir
              </button>
            </span>
          ) : modoHumano ? (
            <span className="hbx-note">Enter envia · você está falando com um atendente</span>
          ) : mensagens.length >= 2 ? (
            <span className="hbx-note">
              Enter envia ·{' '}
              <button
                type="button"
                onClick={encerrarConversa}
                style={{
                  background: 'none', border: 'none', padding: 0, cursor: 'pointer',
                  color: 'var(--hb-ink-2)', borderBottom: '1px solid currentColor',
                  font: 'inherit',
                }}
              >
                encerrar conversa
              </button>
            </span>
          ) : precisaLogin ? (
            <span className="hbx-note">
              Limite de visitante atingido ·{' '}
              <a
                href="/auth"
                target="_blank"
                rel="noreferrer"
                style={{ color: 'var(--hb-ink)', borderBottom: '1px solid currentColor' }}
              >
                entre ou crie uma conta
              </a>{' '}
              · a conversa continua aqui
            </span>
          ) : (
            <span className="hbx-note">Enter envia · atendimento automatizado</span>
          )}
        </div>
      </div>
    </div>
  );
}