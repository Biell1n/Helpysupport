import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Sparkles } from 'lucide-react';
import Navigation from '@/components/Navigation';
import { useAuth } from '@/contexts/AuthContext';
import { db } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

export default function FreeAssistantSetupPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    business_name: '',
    industry: '',
    hours: '',
    phone: '',
    address: '',
    products: ''
  });

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const uniqueLink = crypto.randomUUID();
      
      const assistantData = {
        owner_id: user.id,
        business_name: formData.business_name,
        industry: formData.industry,
        plan_type: 'free',
        humor_type: 'professional',
        unique_link: uniqueLink,
        pre_set_answers: {
          hours: formData.hours,
          phone: formData.phone,
          address: formData.address,
          products: formData.products
        }
      };

      await db.createAssistant(assistantData);

      toast({
        title: 'Assistente Criado!',
        description: 'Seu assistente gratuito já está disponível.'
      });
      
      navigate(`/assistant/${uniqueLink}`);
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: 'Erro ao criar',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Criar Assistente (Free) - ChatSupport AI</title>
      </Helmet>

      <div className="min-h-screen bg-black">
        <Navigation />

        <div className="container mx-auto px-4 pt-24 pb-12 max-w-2xl">
          <Button
            variant="ghost"
            onClick={() => navigate('/dashboard')}
            className="mb-6 text-neutral-400 hover:text-white pl-0 border-none ring-0 outline-none"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Cancelar
          </Button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-neutral-900/50 rounded-2xl p-8 shadow-2xl"
          >
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-white mb-2">Configuração Básica</h1>
              <p className="text-neutral-400">Preencha as informações essenciais para seu assistente.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-neutral-300 mb-2">
                    Nome do Negócio *
                  </label>
                  <input
                    name="business_name"
                    required
                    value={formData.business_name}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-neutral-950 rounded-lg text-white border-none shadow-inner focus:outline-none focus:ring-0"
                    placeholder="Ex: Café Central"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-neutral-300 mb-2">
                    Ramo/Indústria *
                  </label>
                  <input
                    name="industry"
                    required
                    value={formData.industry}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-neutral-950 rounded-lg text-white border-none shadow-inner focus:outline-none focus:ring-0"
                    placeholder="Ex: Alimentação"
                  />
                </div>
              </div>

              <div className="space-y-4 pt-4 mt-4">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-white" />
                  Perguntas Frequentes
                </h3>
                
                <div>
                  <label className="block text-sm font-medium text-neutral-300 mb-2">
                    Qual o seu horário de funcionamento?
                  </label>
                  <input
                    name="hours"
                    required
                    value={formData.hours}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-neutral-950 rounded-lg text-white border-none shadow-inner focus:outline-none focus:ring-0"
                    placeholder="Ex: Seg-Sex 9h às 18h"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-neutral-300 mb-2">
                    Qual o telefone de contato?
                  </label>
                  <input
                    name="phone"
                    required
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-neutral-950 rounded-lg text-white border-none shadow-inner focus:outline-none focus:ring-0"
                    placeholder="(00) 0000-0000"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-neutral-300 mb-2">
                    Qual o endereço?
                  </label>
                  <input
                    name="address"
                    required
                    value={formData.address}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-neutral-950 rounded-lg text-white border-none shadow-inner focus:outline-none focus:ring-0"
                    placeholder="Rua Exemplo, 123 - Centro"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-neutral-300 mb-2">
                    Quais os principais produtos/serviços?
                  </label>
                  <textarea
                    name="products"
                    required
                    rows={3}
                    value={formData.products}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-neutral-950 rounded-lg text-white border-none shadow-inner focus:outline-none focus:ring-0"
                    placeholder="Liste seus principais produtos..."
                  />
                </div>
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-white text-black hover:bg-neutral-200 py-6 text-lg font-bold border-none ring-0 outline-none shadow-lg"
              >
                {loading ? 'Criando...' : 'Criar Assistente'}
              </Button>
            </form>
          </motion.div>
        </div>
      </div>
    </>
  );
}