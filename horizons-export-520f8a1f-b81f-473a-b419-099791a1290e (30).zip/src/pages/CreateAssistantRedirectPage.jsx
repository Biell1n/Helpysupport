import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { DEFAULT_ASSISTANT_STATUS } from '@/constants/assistantStatus';

export default function CreateAssistantRedirectPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [creating, setCreating] = useState(true);

  useEffect(() => {
    if (!user?.id) {
      navigate('/auth', { state: { view: 'login' }, replace: true });
      return;
    }

    createNewAssistant();
  }, [user?.id]);

  async function createNewAssistant() {
    try {
      setCreating(true);

      // Create a new assistant with minimal data (will be filled during onboarding)
      const { data: newAssistant, error } = await supabase
        .from('assistants')
        .insert({
          user_id: user.id,
          professional_id: user.id, // Temporary - will be updated
          name: 'Novo Assistente',
          niche: 'Geral',
          status: DEFAULT_ASSISTANT_STATUS, // Use constant: 'draft'
          onboarding_completed: false,
          onboarding_progress: 0,
          metadata: {
            onboarding_status: 'in_progress',
            created_via: 'onboarding_flow'
          }
        })
        .select()
        .single();

      if (error) throw error;

      // Create default assistant profile
      await supabase
        .from('assistant_profiles')
        .insert({
          assistant_id: newAssistant.id,
          onboarding_state: {
            currentStep: 'welcome',
            completedSteps: [],
            data: {},
            lastUpdated: new Date().toISOString(),
          },
        });

      // Create default assistant memory
      await supabase
        .from('assistant_memory')
        .insert({
          assistant_id: newAssistant.id,
          tipo_negocio: 'VENDAS',
          descricao_negocio: '',
          produtos: [],
          regras_fala: [],
          contato: {},
          personalidade: {},
          refused_fields: {},
          completion_percentage: 0,
          mandatory_fields_complete: false
        });

      // Redirect to onboarding page with assistantId
      navigate(`/dashboard/create-assistant/${newAssistant.id}`, { replace: true });

    } catch (error) {
      console.error('Error creating assistant:', error);
      toast({
        title: 'Erro ao criar assistente',
        description: error.message || 'Ocorreu um erro ao criar o assistente. Tente novamente.',
        variant: 'destructive'
      });
      navigate('/dashboard', { replace: true });
    } finally {
      setCreating(false);
    }
  }

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center text-white">
      <Loader2 className="w-12 h-12 animate-spin text-blue-500 mb-4" />
      <p className="text-neutral-400 font-medium">Criando novo assistente...</p>
      <p className="text-xs text-neutral-600 mt-2">Preparando o onboarding conversacional</p>
    </div>
  );
}