import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Building2, User } from 'lucide-react';
import ClientCompletionForm from '@/components/ClientCompletionForm';
import BusinessCompletionForm from '@/components/BusinessCompletionForm';
import { useAuth } from '@/contexts/AuthContext';
import { Navigate } from 'react-router-dom';

export default function CompleteCadastroPage() {
  const [selectedType, setSelectedType] = useState(null);
  const { isPending, loading, isAuthenticated } = useAuth();

  if (loading) return null;

  if (!isAuthenticated) {
     return <Navigate to="/auth" replace />;
  }

  if (!isPending) {
    return <Navigate to="/dashboard" replace />;
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.4
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { 
      opacity: 1, 
      y: 0, 
      transition: { duration: 0.5, ease: "easeOut" } 
    }
  };

  return (
    <>
      <Helmet>
        <title>Completar Cadastro - Helpy</title>
      </Helmet>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6 }}
        className="min-h-screen relative flex items-center justify-center p-4 overflow-hidden bg-black"
      >
        {/* Background Video with fade-in */}
        <motion.video 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          autoPlay 
          loop 
          muted 
          playsInline
          className="absolute inset-0 w-full h-full object-cover z-0"
        >
          <source src="https://cdscurcwcyzeagincjdv.supabase.co/storage/v1/object/public/landing-videos/videofundo2.mp4.mp4" type="video/mp4" />
        </motion.video>
        
        {/* Overlays to ensure text readability */}
        <div className="absolute inset-0 bg-black/70 z-10" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/90 via-transparent to-black z-10" />

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
          className="max-w-md w-full bg-neutral-900/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl relative z-20"
        >
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-center mb-8"
          >
            <h1 className="text-3xl font-bold text-white mb-2">Quase lá!</h1>
            <p className="text-neutral-400">Como você deseja usar a plataforma?</p>
          </motion.div>

          {!selectedType ? (
            <motion.div 
              variants={containerVariants}
              initial="hidden"
              animate="show"
              className="grid gap-4"
            >
              <motion.div variants={itemVariants}>
                <Button
                  variant="outline"
                  className="w-full h-auto py-8 flex flex-col items-center gap-4 border-none bg-neutral-950 hover:bg-neutral-800 hover:text-white rounded-2xl transition-all shadow-lg"
                  onClick={() => setSelectedType('business')}
                >
                  <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center">
                    <Building2 className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-center">
                    <div className="font-bold text-xl text-white mb-1">Sou Empresa</div>
                    <div className="text-sm text-neutral-400 font-normal">Quero criar e gerenciar assistentes de IA</div>
                  </div>
                </Button>
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <Button
                  variant="outline"
                  className="w-full h-auto py-8 flex flex-col items-center gap-4 border-none bg-neutral-950 hover:bg-neutral-800 hover:text-white rounded-2xl transition-all shadow-lg"
                  onClick={() => setSelectedType('client')}
                >
                  <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center">
                    <User className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-center">
                    <div className="font-bold text-xl text-white mb-1">Sou Cliente</div>
                    <div className="text-sm text-neutral-400 font-normal">Quero interagir com empresas</div>
                  </div>
                </Button>
              </motion.div>
            </motion.div>
          ) : (
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedType}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.4, ease: "easeOut" }}
              >
                <button 
                  onClick={() => setSelectedType(null)}
                  className="text-sm text-neutral-400 hover:text-white mb-4 transition-colors font-medium flex items-center"
                >
                  ← Voltar e alterar tipo de conta
                </button>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.1 }}
                >
                  {selectedType === 'client' ? <ClientCompletionForm /> : <BusinessCompletionForm />}
                </motion.div>
              </motion.div>
            </AnimatePresence>
          )}
        </motion.div>
      </motion.div>
    </>
  );
}