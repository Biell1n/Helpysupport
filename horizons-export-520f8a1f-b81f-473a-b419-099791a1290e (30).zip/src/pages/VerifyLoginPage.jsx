// ============================================================
// HELPY — VerifyLoginPage v3 — ARQUIVO COMPLETO
//
// Além da tela, esta página tem uma responsabilidade própria: marcar
// ESTE aparelho como confiável por 30 dias. A confiança é do aparelho,
// não da conta — antes ficava na linha do usuário, o que liberava a
// senha sozinha em qualquer lugar.
// ============================================================

import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, obterDeviceId, rotuloDoAparelho } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import TelaCodigo from '@/components/TelaCodigo';

const DIAS_DE_CONFIANCA = 30;

export default function VerifyLoginPage() {
  const navigate = useNavigate();
  const {
    verifyTwoFactorCode,
    resendTwoFactorCode,
    pendingUserId,
    pendingTwoFactor,
    logout,
  } = useAuth();

  // Ninguém deveria chegar aqui sem um login pendente.
  useEffect(() => {
    if (!pendingTwoFactor && !pendingUserId) navigate('/auth', { replace: true });
  }, [pendingTwoFactor, pendingUserId, navigate]);

  const confiarNesteAparelho = async () => {
    const deviceId = obterDeviceId();
    if (!deviceId || !pendingUserId) return; // sem armazenamento, pede código sempre

    const expira = new Date(Date.now() + DIAS_DE_CONFIANCA * 864e5).toISOString();
    try {
      await supabase.from('trusted_devices').upsert(
        {
          user_id: pendingUserId,
          device_id: deviceId,
          rotulo: rotuloDoAparelho(),
          expira_em: expira,
          usado_em: new Date().toISOString(),
        },
        { onConflict: 'user_id,device_id' }
      );
    } catch (e) {
      // Falhar aqui só significa pedir código na próxima. Não trava o login.
      console.error('Não deu para marcar o aparelho como confiável:', e);
    }
  };

  return (
    <TelaCodigo
      eyebrow="Verificação em duas etapas"
      titulo="Confirme que é você."
      descricao="Enviamos um código de seis dígitos para o seu e-mail."
      onVerificar={async (codigo) => {
        const r = await verifyTwoFactorCode(codigo);
        if (r?.success !== false) {
          await confiarNesteAparelho();
          navigate('/dashboard', { replace: true });
        }
        return r;
      }}
      onReenviar={() => resendTwoFactorCode()}
      onVoltar={() => logout?.()}
      rotuloVoltar="usar outra conta"
      nota={`Neste aparelho, o código não será pedido de novo pelos próximos ${DIAS_DE_CONFIANCA} dias. Em qualquer outro, sim.`}
    />
  );
}