// ============================================================
// HELPY — EditAssistantPage v2 — ARQUIVO COMPLETO
//
// Editar é a MESMA tela de criar. O que muda é o assistantId: com ele,
// a sessão nasce carregada com a configuração do assistente e o botão
// salva por cima em vez de criar outro.
// ============================================================

import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { BuilderProvider } from '@/contexts/BuilderContext';
import BuilderShell from '@/components/builder/BuilderShell';
import '@/styles/builder.css';

export default function EditAssistantPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  if (!id) {
    return (
      <div className="hb" style={{ minHeight: '100vh', background: '#000', display: 'grid', placeItems: 'center', padding: '2rem' }}>
        <div style={{ textAlign: 'center' }}>
          <p style={{ color: '#A8A8A8', fontSize: '.875rem', marginBottom: '1.25rem' }}>
            Assistente não informado.
          </p>
          <button type="button" className="hb-btn hb-btn--edge" onClick={() => navigate('/dashboard')}>
            Voltar ao painel
          </button>
        </div>
      </div>
    );
  }

  return (
    <BuilderProvider assistantId={id}>
      <BuilderShell />
    </BuilderProvider>
  );
}