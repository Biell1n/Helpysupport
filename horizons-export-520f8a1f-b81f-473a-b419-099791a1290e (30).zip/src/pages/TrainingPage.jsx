import React from 'react';
import { Helmet } from 'react-helmet';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import ColorLegend from '@/components/ColorLegend';
import DynamicTrainingForm from '@/components/DynamicTrainingForm';
import { motion } from 'framer-motion';
import { BrainCircuit } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';

export default function TrainingPage() {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleContinue = (data) => {
    // Navigate to next step or dashboard, passing the trained data if needed
    toast({
      title: "Treinamento Concluído!",
      description: "As informações da sua IA estão com excelente qualidade.",
    });
    // For now, redirect to dashboard as a placeholder next step
    setTimeout(() => navigate('/dashboard'), 1500);
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <Helmet>
        <title>Treinamento Dinâmico da IA - Helpy</title>
        <meta name="description" content="Treine sua Inteligência Artificial com dados específicos do seu negócio." />
      </Helmet>
      
      <Navigation />

      <main className="flex-grow pt-28 pb-16">
        <div className="container mx-auto px-4 max-w-4xl">
          
          {/* Header Section */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center border border-white/10">
                <BrainCircuit className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-3xl font-bold tracking-tight">Treinamento Dinâmico da IA</h1>
            </div>
            <p className="text-neutral-400 text-lg max-w-2xl mt-4">
              Forneça as informações cruciais sobre o seu negócio. Nosso sistema inteligente analisa o que você digita em tempo real para garantir que a IA tenha o melhor contexto possível para atender seus clientes.
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <ColorLegend />
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <DynamicTrainingForm onContinue={handleContinue} />
          </motion.div>

        </div>
      </main>

      <Footer />
    </div>
  );
}