import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import DashboardBusiness from '@/components/DashboardBusiness';
import DashboardClient from '@/components/DashboardClient';
import { Loader2 } from 'lucide-react';

export default function DashboardPage() {
  const { user, userProfile, loading, error, signOut, clearError } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth', { state: { view: 'login' }, replace: true });
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (error) {
      toast({ 
        title: 'Sessão Expirada', 
        description: 'Sua sessão expirou. Por favor, faça login novamente.', 
        variant: 'destructive' 
      });
      clearError();
      signOut();
      navigate('/auth', { state: { view: 'login' }, replace: true });
    }
  }, [error, toast, clearError, signOut, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center">
        <Loader2 className="w-12 h-12 text-white animate-spin mb-4" />
        <p className="text-neutral-400">Carregando painel...</p>
      </div>
    );
  }

  if (!userProfile) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center text-white">
        <p>Erro ao carregar perfil do usuário.</p>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Dashboard - Helpy</title>
      </Helmet>
      
      {userProfile.user_type === 'business_owner' ? (
        <DashboardBusiness />
      ) : (
        <DashboardClient />
      )}
    </>
  );
}