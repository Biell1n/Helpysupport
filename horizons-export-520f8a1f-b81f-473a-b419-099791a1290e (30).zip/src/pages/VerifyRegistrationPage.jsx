// ============================================================
// HELPY — VerifyRegistrationPage v2 — ARQUIVO COMPLETO
// ============================================================

import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import TelaCodigo from '@/components/TelaCodigo';

export default function VerifyRegistrationPage() {
  const navigate = useNavigate();
  const { verifyRegistration, resendRegistrationCode, user, userProfile, logout } = useAuth();

  useEffect(() => {
    if (!user) navigate('/auth', { replace: true });
  }, [user, navigate]);

  const userId = user?.id;

  return (
    <TelaCodigo
      eyebrow="Concluir cadastro"
      titulo="Falta confirmar a empresa."
      descricao="Mandamos um código de seis dígitos para"
      destino={userProfile?.email || user?.email}
      onVerificar={async (codigo) => {
        const r = await verifyRegistration(userId, codigo);
        if (r?.success !== false) navigate('/dashboard', { replace: true });
        return r;
      }}
      onReenviar={() => resendRegistrationCode(userId)}
      onVoltar={() => logout?.()}
      rotuloVoltar="sair"
      nota="Esta confirmação acontece uma vez só. Depois dela você entra direto no painel."
    />
  );
}