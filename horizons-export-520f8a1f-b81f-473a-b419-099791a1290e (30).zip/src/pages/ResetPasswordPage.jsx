import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Lock, Loader2, CheckCircle, AlertOctagon, ArrowLeft } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import PasswordStrengthIndicator from '@/components/PasswordStrengthIndicator';

export default function ResetPasswordPage() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const navigate = useNavigate();
  const { toast } = useToast();

  const [pageState, setPageState] = useState('validating'); 
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (!token) {
      setPageState('invalid');
      setErrorMsg('Token não fornecido.');
      return;
    }

    const validateToken = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('validate-reset-token', {
          body: { token }
        });

        if (error) throw error;
        if (data?.error) throw new Error(data.error);
        if (data?.valid === false) throw new Error(data.error || 'Token expirado ou inválido');

        setPageState('valid');
      } catch (err) {
        console.error(err);
        setPageState('invalid');
        setErrorMsg(err.message || 'Token expirado ou inválido');
      }
    };

    validateToken();
  }, [token]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast({ title: 'Erro', description: 'As senhas não coincidem.', variant: 'destructive' });
      return;
    }
    if (newPassword.length < 8) {
        toast({ title: 'Erro', description: 'A senha deve ter no mínimo 8 caracteres.', variant: 'destructive' });
        return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('reset-password', {
        body: { token, newPassword }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setPageState('success');
      toast({ title: 'Sucesso', description: 'Sua senha foi alterada com sucesso.' });
      
      setTimeout(() => {
        navigate('/auth');
      }, 2000);
      
    } catch (err) {
      console.error(err);
      toast({ title: 'Erro', description: err.message || 'Erro ao redefinir senha.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet><title>Redefinir Senha - Helpy</title></Helmet>
      
      <div className="min-h-screen bg-black flex items-center justify-center p-4 relative overflow-hidden">
        {/* Minimalist Background Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-white/5 rounded-full blur-[120px] pointer-events-none" />

        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="w-full max-w-md relative z-10"
        >
          
          {pageState === 'validating' && (
             <div className="text-center">
                <Loader2 className="w-10 h-10 animate-spin mx-auto mb-6 text-white" />
                <p className="text-neutral-400 text-lg font-light">Validando link de segurança...</p>
             </div>
          )}

          {pageState === 'invalid' && (
            <div className="text-center">
               <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <AlertOctagon className="w-8 h-8 text-white" />
               </div>
               <h2 className="text-3xl font-bold text-white mb-3 tracking-tight">Link Inválido</h2>
               <p className="text-neutral-400 mb-8 font-light">{errorMsg}</p>
               
               <Button 
                 onClick={() => navigate('/auth')} 
                 className="w-full bg-white text-black font-bold hover:bg-neutral-200 py-6 text-lg rounded-xl mb-4 transition-all"
               >
                  Ir para o Login
               </Button>
            </div>
          )}

          {pageState === 'success' && (
            <div className="text-center">
               <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="w-8 h-8 text-white" />
               </div>
               <h2 className="text-3xl font-bold text-white mb-3 tracking-tight">Senha Atualizada</h2>
               <p className="text-neutral-400 mb-8 font-light">Sua senha foi redefinida com sucesso. Redirecionando...</p>
               <Loader2 className="w-6 h-6 animate-spin mx-auto text-neutral-500" />
            </div>
          )}

          {pageState === 'valid' && (
             <div>
                <Button 
                  variant="ghost" 
                  className="mb-8 p-0 text-neutral-400 hover:text-white hover:bg-transparent flex items-center gap-2 transition-colors"
                  onClick={() => navigate('/auth')}
                >
                  <ArrowLeft className="w-5 h-5" /> Voltar ao Login
                </Button>

                <div className="mb-10">
                    <h1 className="text-3xl md:text-4xl font-bold text-white mb-3 tracking-tight">Nova Senha</h1>
                    <p className="text-neutral-400 font-light">Crie uma senha forte para proteger sua conta.</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-2">
                        <label className="block text-sm font-medium text-neutral-300">Nova Senha</label>
                        <input 
                            type="password" 
                            required 
                            disabled={loading}
                            value={newPassword} 
                            onChange={(e) => setNewPassword(e.target.value)} 
                            className="w-full px-4 py-3 h-14 bg-neutral-900 border border-neutral-800 rounded-xl text-white focus:outline-none focus:border-white focus:ring-1 focus:ring-white transition-colors placeholder:text-neutral-600 mb-2" 
                            placeholder="••••••••" 
                        />
                        <PasswordStrengthIndicator password={newPassword} />
                    </div>

                    <div className="space-y-2">
                        <label className="block text-sm font-medium text-neutral-300">Confirmar Senha</label>
                        <input 
                            type="password" 
                            required 
                            disabled={loading}
                            value={confirmPassword} 
                            onChange={(e) => setConfirmPassword(e.target.value)} 
                            className="w-full px-4 py-3 h-14 bg-neutral-900 border border-neutral-800 rounded-xl text-white focus:outline-none focus:border-white focus:ring-1 focus:ring-white transition-colors placeholder:text-neutral-600" 
                            placeholder="••••••••" 
                        />
                    </div>

                    <div className="pt-4">
                      <Button 
                        type="submit" 
                        disabled={loading} 
                        className="w-full bg-white hover:bg-neutral-200 text-black font-bold py-6 text-lg rounded-xl shadow-[0_0_20px_rgba(255,255,255,0.1)] transition-all"
                      >
                          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Atualizar Senha'}
                      </Button>
                    </div>
                </form>
             </div>
          )}

        </motion.div>
      </div>
    </>
  );
}