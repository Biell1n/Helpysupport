import React from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Check, Zap, Crown, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import Navigation from '@/components/Navigation';

export default function PlanSelectionPage() {
  const { updatePlan } = useAuth();
  const navigate = useNavigate();

  const handleSelectPlan = async (plan) => {
    await updatePlan(plan);
    navigate('/create-assistant');
  };

  return (
    <>
      <Helmet>
        <title>Selecionar Plano - ChatSupport AI</title>
      </Helmet>

      <div className="min-h-screen bg-black">
        <Navigation />

        <div className="container mx-auto px-4 pt-24 pb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Escolha seu Plano
            </h1>
            <p className="text-xl text-neutral-400">
              Comece a automatizar seu atendimento hoje mesmo
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Free Plan */}
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="bg-neutral-900/50 rounded-3xl p-8 flex flex-col shadow-lg"
            >
              <div className="mb-6">
                <div className="bg-neutral-800 w-12 h-12 rounded-xl flex items-center justify-center mb-4 shadow-inner">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Free</h2>
                <p className="text-3xl font-bold text-white">R$ 0<span className="text-sm font-normal text-neutral-400">/mês</span></p>
              </div>

              <ul className="space-y-4 mb-8 flex-1">
                <li className="flex items-center gap-3 text-neutral-300">
                  <Check className="w-5 h-5 text-neutral-500" />
                  <span>1 Assistente Virtual</span>
                </li>
                <li className="flex items-center gap-3 text-neutral-300">
                  <Check className="w-5 h-5 text-neutral-500" />
                  <span>Chat Básico</span>
                </li>
                <li className="flex items-center gap-3 text-neutral-300">
                  <Check className="w-5 h-5 text-neutral-500" />
                  <span>Perguntas Pré-definidas</span>
                </li>
              </ul>

              <Button
                variant="ghost"
                onClick={() => handleSelectPlan('free')}
                className="w-full py-6 bg-neutral-800 text-white hover:bg-neutral-700 shadow-sm border-none ring-0 outline-none"
              >
                Selecionar Free
              </Button>
            </motion.div>

            {/* Premium Plan */}
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="bg-neutral-800/80 rounded-3xl p-8 flex flex-col relative shadow-[0_0_40px_rgba(255,255,255,0.05)]"
            >
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-white text-black px-4 py-1 rounded-full text-sm font-bold shadow-lg">
                Recomendado
              </div>

              <div className="mb-6">
                <div className="bg-white/20 w-12 h-12 rounded-xl flex items-center justify-center mb-4 shadow-inner">
                  <Crown className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Premium</h2>
                <p className="text-3xl font-bold text-white">R$ 39,90<span className="text-sm font-normal text-neutral-400">/mês</span></p>
              </div>

              <ul className="space-y-4 mb-8 flex-1">
                <li className="flex items-center gap-3 text-white font-medium">
                  <Check className="w-5 h-5 text-white" />
                  <span>Assistentes Ilimitados</span>
                </li>
                <li className="flex items-center gap-3 text-white font-medium">
                  <Check className="w-5 h-5 text-white" />
                  <span>Configuração via IA</span>
                </li>
                <li className="flex items-center gap-3 text-white font-medium">
                  <Check className="w-5 h-5 text-white" />
                  <span>Upload de PDF</span>
                </li>
                <li className="flex items-center gap-3 text-white font-medium">
                  <Check className="w-5 h-5 text-white" />
                  <span>Sistema de Tickets</span>
                </li>
              </ul>

              <Button
                onClick={() => handleSelectPlan('premium')}
                className="w-full py-6 bg-white hover:bg-neutral-200 text-black font-bold shadow-lg border-none ring-0 outline-none"
              >
                Selecionar Premium <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
}