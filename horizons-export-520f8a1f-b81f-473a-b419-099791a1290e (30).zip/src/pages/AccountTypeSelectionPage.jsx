import React from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate, useLocation, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { UserCircle, Building2 } from 'lucide-react';

export default function AccountTypeSelectionPage() {
  const navigate = useNavigate();
  const location = useLocation();

  const isGoogleAuth = location.state?.googleAuth;

  if (!isGoogleAuth) {
    return <Navigate to="/auth" replace />;
  }

  const handleSelection = (type) => {
    navigate('/complete-profile', { state: { googleAuth: true, selectedType: type } });
  };

  return (
    <>
      <Helmet>
        <title>Tipo de Conta - Helpy</title>
      </Helmet>

      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="w-full max-w-md mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="text-center mb-10">
              <h1 className="text-4xl font-bold text-white mb-4">Escolha seu Perfil</h1>
              <p className="text-neutral-400 text-lg">
                Como você deseja usar a Helpy?
              </p>
            </div>

            <div className="space-y-4">
              <Button
                onClick={() => handleSelection('end_customer')}
                className="w-full py-8 text-lg font-bold bg-neutral-900 text-white hover:bg-neutral-800 transition-all rounded-xl border border-neutral-800 flex items-center justify-start px-6 gap-4 h-auto"
              >
                <UserCircle className="w-8 h-8 text-neutral-400 shrink-0" />
                <div className="text-left">
                  <div className="text-white">Para Mim (Cliente)</div>
                  <div className="text-sm text-neutral-500 font-normal">Quero conversar com assistentes</div>
                </div>
              </Button>

              <Button
                onClick={() => handleSelection('business')}
                className="w-full py-8 text-lg font-bold bg-neutral-900 text-white hover:bg-neutral-800 transition-all rounded-xl border border-neutral-800 flex items-center justify-start px-6 gap-4 h-auto"
              >
                <Building2 className="w-8 h-8 text-neutral-400 shrink-0" />
                <div className="text-left">
                  <div className="text-white">Para Minha Empresa</div>
                  <div className="text-sm text-neutral-500 font-normal">Quero criar e gerenciar assistentes</div>
                </div>
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
}