import React, { useState, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Loader2, Check, X } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import PasswordStrengthIndicator from '@/components/PasswordStrengthIndicator';

export default function SignupPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { register } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = useCallback(async (e) => {
    e.preventDefault();
    
    if (password !== confirmPassword) {
      toast({ title: "Erro", description: "As senhas não coincidem.", variant: "destructive" });
      return;
    }

    if (password.length < 8) {
       toast({ title: "Senha fraca", description: "A senha deve ter pelo menos 8 caracteres.", variant: "destructive" });
       return;
    }

    setLoading(true);
    try {
      const result = await register(email, password, 'business_owner');
      if (result.success) {
         navigate('/complete-profile');
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [email, password, confirmPassword, register, navigate, toast]);

  return (
    <>
      <Helmet><title>Criar Conta - Higgsfield</title></Helmet>
      
      <div className="min-h-screen bg-black flex items-center justify-center p-4 relative overflow-hidden">
        {/* Background blobs */}
        <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-purple-900/20 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-blue-900/10 rounded-full blur-[120px] pointer-events-none" />

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md bg-neutral-900/80 backdrop-blur-xl border border-neutral-800 rounded-2xl p-8 shadow-2xl relative z-10"
        >
          <Button 
            variant="ghost" 
            className="absolute top-4 left-4 p-2 text-neutral-400 hover:text-white"
            onClick={() => navigate('/auth')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>

          <div className="text-center mb-8 mt-6">
            <h1 className="text-2xl font-bold text-white mb-2">Criar conta</h1>
            <p className="text-neutral-400">Preencha os dados para se cadastrar</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-neutral-300">Email</Label>
              <Input 
                id="email" 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-neutral-950 border-neutral-800 text-white focus:border-purple-500 transition-colors"
                placeholder="seu@email.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-neutral-300">Senha</Label>
              <Input 
                id="password" 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="bg-neutral-950 border-neutral-800 text-white focus:border-purple-500 transition-colors"
                placeholder="••••••••"
              />
              <PasswordStrengthIndicator password={password} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-neutral-300">Confirmar Senha</Label>
              <Input 
                id="confirmPassword" 
                type="password" 
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                className={`bg-neutral-950 border-neutral-800 text-white transition-colors ${
                  confirmPassword && password !== confirmPassword ? 'border-red-500 focus:border-red-500' : 'focus:border-purple-500'
                }`}
                placeholder="••••••••"
              />
              {confirmPassword && password !== confirmPassword && (
                 <p className="text-xs text-red-400 flex items-center gap-1 mt-1">
                    <X className="w-3 h-3" /> As senhas não coincidem
                 </p>
              )}
            </div>

            <Button type="submit" disabled={loading} className="w-full bg-purple-600 hover:bg-purple-700 text-white py-6">
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Cadastrar"}
            </Button>
          </form>

          <div className="mt-8 text-center text-sm text-neutral-500">
            Já tem conta?{' '}
            <Link to="/login" className="text-purple-400 hover:text-purple-300 font-medium">
              Faça login
            </Link>
          </div>
        </motion.div>
      </div>
    </>
  );
}