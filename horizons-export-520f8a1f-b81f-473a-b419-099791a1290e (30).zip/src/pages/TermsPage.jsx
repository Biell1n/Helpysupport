import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Footer from '@/components/Footer';

export default function TermsPage() {
  return (
    <>
      <Helmet>
        <title>Termos de Serviço - Helpy</title>
        <meta name="description" content="Termos de Serviço e condições de uso da plataforma Helpy." />
      </Helmet>

      <div className="min-h-screen bg-black text-white selection:bg-white/30">
        <header className="fixed top-0 w-full bg-black/90 backdrop-blur-md border-b border-white/5 z-50">
          <div className="container mx-auto px-6 h-20 flex items-center max-w-4xl">
            <Link to="/" className="flex items-center gap-2 text-neutral-400 hover:text-white transition-colors text-sm font-medium">
              <ArrowLeft className="w-4 h-4" />
              Voltar para o app
            </Link>
          </div>
        </header>

        <main className="pt-32 pb-32 px-6">
          <div className="container mx-auto max-w-3xl">
            <div className="mb-16">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight">Termos de Serviço</h1>
              <p className="text-lg text-neutral-400">
                Última atualização: 21 de Março de 2026
              </p>
            </div>

            <div className="space-y-12 text-neutral-300">
              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-white">1. Termos de Serviço</h2>
                <p className="leading-relaxed">
                  Ao acessar e utilizar a plataforma Helpy, você concorda em cumprir estes Termos de Serviço, todas as leis e regulamentos aplicáveis, e concorda que é responsável pelo cumprimento de quaisquer leis locais aplicáveis. Se você não concordar com algum destes termos, está proibido de usar ou acessar este site.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-white">2. Responsabilidades do Usuário</h2>
                <p className="leading-relaxed">
                  Ao criar e gerenciar assistentes virtuais na plataforma Helpy, você concorda que:
                </p>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Não utilizará o serviço para gerar conteúdo ilegal, difamatório, ameaçador ou discriminatório.</li>
                  <li>Não tentará violar a segurança ou integridade da plataforma.</li>
                  <li>É o único responsável pelo conteúdo (prompts, base de conhecimento) fornecido aos assistentes.</li>
                  <li>Garantirá que as interações do seu assistente com terceiros respeitem as leis de proteção de dados.</li>
                </ul>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-white">3. Propriedade Intelectual</h2>
                <p className="leading-relaxed">
                  A plataforma Helpy, seus recursos originais, funcionalidades e design são de propriedade exclusiva da Helpy e estão protegidos por direitos autorais internacionais, marcas registradas e outras leis de propriedade intelectual. Você mantém todos os direitos sobre os dados e informações específicas que insere na plataforma para treinar seus assistentes.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-white">4. Limitação de Responsabilidade</h2>
                <p className="leading-relaxed">
                  Em nenhum caso a Helpy ou seus fornecedores serão responsáveis por quaisquer danos (incluindo, sem limitação, danos por perda de dados ou lucros, ou devido a interrupção dos negócios) decorrentes do uso ou da incapacidade de usar os materiais na plataforma Helpy. A inteligência artificial pode ocasionalmente gerar respostas imprecisas ou indesejadas, e é sua responsabilidade monitorar e ajustar o comportamento do seu assistente.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-white">5. Rescisão</h2>
                <p className="leading-relaxed">
                  Podemos encerrar ou suspender o acesso ao nosso Serviço imediatamente, sem aviso prévio ou responsabilidade, por qualquer motivo, inclusive, sem limitação, se você violar os Termos. Todas as disposições dos Termos que, por sua natureza, devam sobreviver à rescisão, sobreviverão à rescisão.
                </p>
              </section>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    </>
  );
}