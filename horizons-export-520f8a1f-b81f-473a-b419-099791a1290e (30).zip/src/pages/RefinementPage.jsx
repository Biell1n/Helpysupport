import React, { useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Navigation from '@/components/Navigation';
import { Button } from '@/components/ui/button';
import { AssistantMemoryProvider, useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';
import RefinementAssistantChat from '@/components/RefinementAssistantChat';
import ProgressSidebar from '@/components/ProgressSidebar';
import { ArrowLeft, Save, Loader2, CheckCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useState } from 'react';
import { supabase } from '@/lib/supabase';

function RefinementLayout() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const assistantIdParam = searchParams.get('id');
  const assistantNameParam = searchParams.get('name') || 'Novo Assistente';
  const businessTypeParam = searchParams.get('type') || 'VENDAS';
  
  const { 
    initMemory, 
    getProgress,
    getCompletionStatus,
    assistantName,
    setAssistantName,
    setBusinessType,
    state,
    assistantId
  } = useAssistantMemoryContext();
  
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (assistantIdParam) {
      initMemory(assistantIdParam, businessTypeParam, {});
    } else {
      setAssistantName(assistantNameParam);
      setBusinessType(businessTypeParam);
    }
  }, [assistantIdParam, assistantNameParam, businessTypeParam, initMemory, setAssistantName, setBusinessType]);

  const handleSave = async () => {
    const completionStatus = getCompletionStatus();
    
    if (!completionStatus.mandatoryComplete) {
      toast({
        title: 'Atenção',
        description: `Complete os campos obrigatórios antes de finalizar: ${completionStatus.missingMandatory.join(', ')}`,
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);
    try {
      // Create or update assistant
      if (assistantId) {
        await supabase
          .from('assistants')
          .update({
            description: state.descricao,
            name: assistantName,
            updated_at: new Date().toISOString()
          })
          .eq('id', assistantId);
      }

      toast({
        title: 'Sucesso',
        description: 'Assistente configurado com sucesso!'
      });
      
      navigate('/dashboard');
    } catch (err) {
      console.error('[RefinementPage] Save error:', err);
      toast({
        title: 'Erro',
        description: 'Falha ao salvar assistente.',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  const progress = getProgress();
  const completionStatus = getCompletionStatus();

  return (
    <div className="min-h-screen bg-black">
      <Helmet><title>Configurar Assistente - Helpy</title></Helmet>
      <Navigation />
      
      <main className="max-w-[1600px] mx-auto px-6 py-8 mt-20">
        <div className="flex items-center justify-between mb-8">
          <div>
            <button 
              onClick={() => navigate(-1)} 
              className="flex items-center gap-2 text-neutral-400 hover:text-white transition-colors mb-3"
            >
              <ArrowLeft className="w-4 h-4" /> Voltar
            </button>
            <h1 className="text-3xl font-bold text-white mb-2">
              {assistantName}
            </h1>
            <p className="text-neutral-400">
              {progress}% completo • {completionStatus.missingMandatory?.length || 0} campos obrigatórios faltando
            </p>
          </div>
          
          <Button 
            onClick={handleSave} 
            disabled={saving || !completionStatus.mandatoryComplete} 
            className={`font-bold rounded-xl h-12 px-8 ${
              completionStatus.mandatoryComplete 
                ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white'
                : 'bg-white text-black hover:bg-neutral-200'
            }`}
          >
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Salvando...
              </>
            ) : completionStatus.mandatoryComplete ? (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Finalizar
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Salvar Progresso
              </>
            )}
          </Button>
        </div>

        <div className="grid lg:grid-cols-[1fr_320px] xl:grid-cols-[1fr_350px] gap-6">
          <div className="h-[calc(100vh-240px)]">
            <RefinementAssistantChat />
          </div>
          
          <div className="h-[calc(100vh-240px)]">
            <ProgressSidebar />
          </div>
        </div>
      </main>
    </div>
  );
}

export default function RefinementPage() {
  return (
    <AssistantMemoryProvider>
      <RefinementLayout />
    </AssistantMemoryProvider>
  );
}