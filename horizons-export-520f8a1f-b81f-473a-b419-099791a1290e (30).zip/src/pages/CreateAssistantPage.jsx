// ============================================================
// HELPY — CreateAssistantPage v9 — ARQUIVO COMPLETO
// Só embrulha o BuilderShell. Toda a tela vive em BuilderShell.jsx.
// ============================================================

import React from 'react';
import { BuilderProvider } from '@/contexts/BuilderContext';
import BuilderShell from '@/components/builder/BuilderShell';

export default function CreateAssistantPage() {
  return (
    <BuilderProvider>
      <BuilderShell />
    </BuilderProvider>
  );
}