// ============================================================
// HELPY — ProfilePage v3 — ARQUIVO COMPLETO
//
// Mesma linguagem do painel: Manrope leve, sem caixa arredondada,
// agrupamento por filete. Todas as funções da versão anterior estão
// aqui: foto, dados, 2FA, sons, animações e encerrar conta.
//
// A ordem mudou de propósito. Antes o "Deletar Conta" ficava no fim de
// um cartão vermelho grande, do mesmo tamanho visual do resto. Agora é
// a última linha, discreta, e exige digitar uma palavra.
// ============================================================

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import '@/styles/painel.css';

export default function ProfilePage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const {
    user,
    userProfile,
    updateProfile,
    uploadProfilePhoto,
    deleteAccount,
    toggleTwoFactor,
    signOut,
  } = useAuth();

  const [salvando, setSalvando] = useState(false);
  const [enviandoFoto, setEnviandoFoto] = useState(false);
  const [carregando2fa, setCarregando2fa] = useState(false);
  const [confirmaExclusao, setConfirmaExclusao] = useState('');
  const [excluindo, setExcluindo] = useState(false);

  const [dados, setDados] = useState({
    full_name: '',
    phone: '',
    birth_date: '',
    address: '',
    gender: 'prefer_not_to_say',
    profile_photo_url: '',
  });

  useEffect(() => {
    if (!userProfile) return;
    setDados({
      full_name: userProfile.full_name || '',
      phone: userProfile.phone || '',
      birth_date: userProfile.birth_date || '',
      address: userProfile.address || '',
      gender: userProfile.gender || 'prefer_not_to_say',
      profile_photo_url: userProfile.profile_photo_url || '',
    });
  }, [userProfile]);

  const mudar = (e) => setDados((p) => ({ ...p, [e.target.name]: e.target.value }));

  const salvar = async (e) => {
    e?.preventDefault();
    setSalvando(true);
    try {
      const r = await updateProfile(dados);
      if (r?.success === false) throw new Error(r.error || 'Falha ao salvar');
      toast({ title: 'Perfil salvo' });
    } catch (err) {
      toast({ variant: 'destructive', title: 'Não deu para salvar', description: err.message });
    } finally {
      setSalvando(false);
    }
  };

  const trocarFoto = async (e) => {
    const arquivo = e.target.files?.[0];
    if (!arquivo) return;
    setEnviandoFoto(true);
    try {
      const r = await uploadProfilePhoto(arquivo);
      const url = r?.url || r?.publicUrl || r?.data?.publicUrl;
      if (url) setDados((p) => ({ ...p, profile_photo_url: url }));
      toast({ title: 'Foto atualizada' });
    } catch (err) {
      toast({ variant: 'destructive', title: 'Não deu para enviar', description: err.message });
    } finally {
      setEnviandoFoto(false);
    }
  };

  const alternar2fa = async (ligado) => {
    setCarregando2fa(true);
    try {
      await toggleTwoFactor(ligado);
      toast({
        title: ligado ? 'Verificação em duas etapas ativada' : 'Verificação desativada',
      });
    } catch (err) {
      toast({ variant: 'destructive', title: 'Não deu para alterar', description: err.message });
    } finally {
      setCarregando2fa(false);
    }
  };

  const excluir = async () => {
    setExcluindo(true);
    try {
      await deleteAccount();
      navigate('/', { replace: true });
    } catch (err) {
      toast({ variant: 'destructive', title: 'Não deu para excluir', description: err.message });
      setExcluindo(false);
    }
  };

  const inicial = (dados.full_name || user?.email || '?').trim().charAt(0).toUpperCase();

  const Campo = ({ rotulo, nome, tipo = 'text', nota, ...resto }) => (
    <label style={{ display: 'block' }}>
      <span className="hd-lbl">{rotulo}</span>
      <input
        className="hd-in"
        type={tipo}
        name={nome}
        value={dados[nome] ?? ''}
        onChange={mudar}
        style={{ display: 'block', width: '100%', marginTop: '.625rem', fontSize: '.9375rem' }}
        {...resto}
      />
      {nota && <span className="hd-kpi-n" style={{ display: 'block' }}>{nota}</span>}
    </label>
  );

  return (
    <div className="hd">
      <header className="hd-bar">
        <div className="hd-brand">
          Helpy<b style={{ color: 'var(--hd-ink-3)' }}> / conta</b>
        </div>
        <div className="hd-bar-r">
          <button type="button" className="hd-nav" onClick={() => navigate('/dashboard')}>
            Painel
          </button>
          <button type="button" className="hd-nav" onClick={() => signOut()}>
            Sair
          </button>
        </div>
      </header>

      <div className="hd-wrap" style={{ maxWidth: '860px' }}>
        <div className="hd-head">
          <span className="hd-lbl">Conta</span>
          <h1 className="hd-h1">
            {dados.full_name || 'Sua conta'}
            <br />
            <em>{user?.email}</em>
          </h1>
        </div>

        {/* ---------- identidade ---------- */}
        <section className="hd-sec" style={{ marginTop: '3rem' }}>
          <div className="hd-sec-head">
            <h2 className="hd-h2">Seus dados</h2>
            <button
              type="button"
              className="hd-btn hd-btn--solid hd-btn--sm"
              onClick={salvar}
              disabled={salvando}
            >
              {salvando ? 'Salvando' : 'Salvar'}
            </button>
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'auto 1fr',
              gap: '3rem',
              alignItems: 'start',
            }}
          >
            {/* foto */}
            <label
              htmlFor="foto"
              style={{
                width: '6rem',
                height: '6rem',
                display: 'grid',
                placeItems: 'center',
                border: '1px solid var(--hd-line-2)',
                cursor: 'pointer',
                position: 'relative',
                overflow: 'hidden',
                background: 'none',
              }}
              title="Trocar foto"
            >
              {dados.profile_photo_url ? (
                <img
                  src={dados.profile_photo_url}
                  alt=""
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
              ) : (
                <span style={{ fontSize: '2rem', fontWeight: 200, color: 'var(--hd-ink-3)' }}>
                  {inicial}
                </span>
              )}
              <span
                className="hd-lbl"
                style={{
                  position: 'absolute',
                  inset: 0,
                  display: 'grid',
                  placeItems: 'center',
                  background: 'rgba(8,8,10,.82)',
                  opacity: 0,
                  transition: 'opacity .2s',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.opacity = 1)}
                onMouseLeave={(e) => (e.currentTarget.style.opacity = 0)}
              >
                {enviandoFoto ? 'enviando' : 'trocar'}
              </span>
              <input
                id="foto"
                type="file"
                accept="image/*"
                onChange={trocarFoto}
                disabled={enviandoFoto}
                style={{ display: 'none' }}
              />
            </label>

            {/* campos */}
            <form
              onSubmit={salvar}
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                gap: '2rem 2.5rem',
              }}
            >
              <Campo rotulo="Nome completo" nome="full_name" autoComplete="name" />

              <label style={{ display: 'block' }}>
                <span className="hd-lbl">E-mail</span>
                <input
                  className="hd-in"
                  value={user?.email || ''}
                  disabled
                  style={{
                    display: 'block',
                    width: '100%',
                    marginTop: '.625rem',
                    fontSize: '.9375rem',
                    color: 'var(--hd-ink-3)',
                  }}
                />
                <span className="hd-kpi-n" style={{ display: 'block' }}>
                  não dá para alterar por aqui
                </span>
              </label>

              <Campo rotulo="Telefone" nome="phone" autoComplete="tel" />
              <Campo rotulo="Data de nascimento" nome="birth_date" tipo="date" />
              <Campo rotulo="Endereço" nome="address" autoComplete="street-address" />

              <label style={{ display: 'block' }}>
                <span className="hd-lbl">Gênero</span>
                <select
                  className="hd-sel"
                  name="gender"
                  value={dados.gender}
                  onChange={mudar}
                  style={{ display: 'block', width: '100%', marginTop: '.625rem', fontSize: '.9375rem' }}
                >
                  <option value="prefer_not_to_say">Prefiro não informar</option>
                  <option value="male">Masculino</option>
                  <option value="female">Feminino</option>
                  <option value="other">Outro</option>
                </select>
              </label>

              <button type="submit" style={{ display: 'none' }} aria-hidden="true" />
            </form>
          </div>
        </section>

        {/* ---------- preferências ---------- */}
        {/*
          Antes aqui vivia um bloco de "Preferências de Interface" com
          card próprio e um controle de volume. O volume saiu: ninguém
          ajusta, e ele ocupava mais espaço que os dois interruptores
          juntos. As duas preferências ficam porque são lidas de verdade
          — useSound consulta soundsEnabled, e animations.css consulta as
          classes no body.
        */}
        <section className="hd-sec">
          <div className="hd-sec-head">
            <h2 className="hd-h2">Preferências</h2>
          </div>

          <Preferencia
            titulo="Sons de mensagem"
            descricao="Um som curto ao receber resposta. Útil com a aba em segundo plano."
            chave="soundsEnabled"
          />

          <Preferencia
            titulo="Animações"
            descricao="Transições ao abrir telas. Desligue se preferir a interface parada."
            chave="animationsEnabled"
            aoMudar={(ligado) => {
              document.body.classList.toggle('animate-enabled', ligado);
              document.body.classList.toggle('animate-disabled', !ligado);
            }}
          />
        </section>

        {/* ---------- segurança ---------- */}
        <section className="hd-sec">
          <div className="hd-sec-head">
            <h2 className="hd-h2">Segurança</h2>
          </div>

          <div
            style={{
              display: 'flex',
              alignItems: 'baseline',
              justifyContent: 'space-between',
              gap: '2rem',
              paddingBottom: '2rem',
              borderBottom: '1px solid var(--hd-line)',
            }}
          >
            <div>
              <p style={{ fontSize: '.9375rem', fontWeight: 400, margin: 0 }}>
                Verificação em duas etapas
              </p>
              <p className="hd-kpi-n" style={{ marginTop: '.5rem', maxWidth: '30rem' }}>
                A cada login, um código chega no seu e-mail. Protege a conta mesmo se a senha
                vazar — e o custo é um passo a mais para entrar.
              </p>
            </div>

            <button
              type="button"
              className="hd-btn"
              onClick={() => alternar2fa(!userProfile?.two_factor_enabled)}
              disabled={carregando2fa}
              style={{ flexShrink: 0 }}
            >
              {carregando2fa
                ? '...'
                : userProfile?.two_factor_enabled
                  ? 'Desativar'
                  : 'Ativar'}
            </button>
          </div>
        </section>

        {/* ---------- encerrar conta ---------- */}
        <section className="hd-sec">
          <div className="hd-sec-head">
            <h2 className="hd-h2" style={{ color: 'var(--hd-ink-3)' }}>
              Encerrar conta
            </h2>
          </div>

          <p className="hd-kpi-n" style={{ maxWidth: '38rem', marginTop: 0 }}>
            Apaga a conta, os assistentes, os briefings e o histórico de atendimentos. Os links
            públicos param de funcionar na hora. Não existe desfazer e não guardamos cópia.
          </p>

          <div
            style={{
              display: 'flex',
              alignItems: 'flex-end',
              gap: '1rem',
              marginTop: '2rem',
              flexWrap: 'wrap',
            }}
          >
            <label style={{ display: 'block' }}>
              <span className="hd-lbl">Digite EXCLUIR para confirmar</span>
              <input
                className="hd-in"
                value={confirmaExclusao}
                onChange={(e) => setConfirmaExclusao(e.target.value)}
                placeholder="EXCLUIR"
                style={{ display: 'block', width: '12rem', marginTop: '.625rem' }}
              />
            </label>

            <button
              type="button"
              className="hd-btn"
              onClick={excluir}
              disabled={confirmaExclusao.trim().toUpperCase() !== 'EXCLUIR' || excluindo}
              style={{
                borderColor:
                  confirmaExclusao.trim().toUpperCase() === 'EXCLUIR' ? '#C96A6A' : undefined,
                color: confirmaExclusao.trim().toUpperCase() === 'EXCLUIR' ? '#D89A9A' : undefined,
              }}
            >
              {excluindo ? 'Excluindo' : 'Excluir minha conta'}
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}

/**
 * Um interruptor ligado a uma chave do localStorage.
 *
 * Não é enfeite: o useSound lê soundsEnabled antes de tocar, e o
 * animations.css depende das classes no body. Tirar daqui deixaria a
 * pessoa sem como desligar o som.
 */
function Preferencia({ titulo, descricao, chave, aoMudar }) {
  const [ligado, setLigado] = useState(true);

  useEffect(() => {
    const v = localStorage.getItem(chave);
    if (v !== null) setLigado(v === 'true');
  }, [chave]);

  const alternar = () => {
    const novo = !ligado;
    setLigado(novo);
    localStorage.setItem(chave, novo);
    aoMudar?.(novo);
  };

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: '1fr auto',
        gap: '2rem',
        alignItems: 'center',
        padding: '1.5rem 0',
        borderBottom: '1px solid var(--hd-line)',
      }}
    >
      <div>
        <p style={{ fontSize: '.9375rem', fontWeight: 400, margin: 0 }}>{titulo}</p>
        <p className="hd-kpi-n" style={{ marginTop: '.4375rem', maxWidth: '30rem' }}>
          {descricao}
        </p>
      </div>

      <button
        type="button"
        role="switch"
        aria-checked={ligado}
        aria-label={titulo}
        onClick={alternar}
        style={{
          width: '2.75rem',
          height: '1.5rem',
          border: `1px solid ${ligado ? 'var(--hd-ink)' : 'var(--hd-line-2)'}`,
          background: 'none',
          cursor: 'pointer',
          padding: 0,
          position: 'relative',
          flexShrink: 0,
          transition: 'border-color .2s',
        }}
      >
        <span
          style={{
            position: 'absolute',
            top: '.1875rem',
            left: '.1875rem',
            width: '1.0625rem',
            height: '1.0625rem',
            background: ligado ? 'var(--hd-ink)' : 'var(--hd-ink-3)',
            transform: ligado ? 'translateX(1.1875rem)' : 'none',
            transition: 'transform .2s, background .2s',
          }}
        />
      </button>
    </div>
  );
}