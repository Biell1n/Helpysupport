-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Enable Row Level Security on all tables
ALTER TABLE IF EXISTS assistants ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS assistant_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS assistant_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS services ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS products ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS faqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS onboarding_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS conversation_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS professionals ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS uploaded_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS embeddings ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS usage_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS memory_versions ENABLE ROW LEVEL SECURITY;

-- Assistants table
CREATE TABLE IF NOT EXISTS assistants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  logo_url TEXT,
  niche TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'archived')),
  onboarding_completed BOOLEAN DEFAULT FALSE,
  onboarding_progress INTEGER DEFAULT 0 CHECK (onboarding_progress >= 0 AND onboarding_progress <= 100),
  timezone TEXT DEFAULT 'America/Sao_Paulo',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Assistant profiles table
CREATE TABLE IF NOT EXISTS assistant_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  company_description TEXT,
  tone_of_voice TEXT,
  personality TEXT,
  behavior_style TEXT,
  onboarding_state JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(assistant_id)
);

-- Assistant rules table
CREATE TABLE IF NOT EXISTS assistant_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  rule_type TEXT NOT NULL CHECK (rule_type IN ('behavior', 'restriction', 'guideline', 'custom')),
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Services table
CREATE TABLE IF NOT EXISTS services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  duration_minutes INTEGER NOT NULL,
  price NUMERIC(10, 2) NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10, 2) NOT NULL,
  stock INTEGER,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- FAQs table
CREATE TABLE IF NOT EXISTS faqs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Onboarding messages table
CREATE TABLE IF NOT EXISTS onboarding_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  message TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Conversation messages table
CREATE TABLE IF NOT EXISTS conversation_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  customer_id TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  message TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Appointments table (all times in UTC)
CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  customer_name TEXT NOT NULL,
  customer_contact TEXT NOT NULL,
  professional_id UUID REFERENCES professionals(id) ON DELETE SET NULL,
  start_time TIMESTAMPTZ NOT NULL,
  end_time TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Professionals table
CREATE TABLE IF NOT EXISTS professionals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role TEXT,
  availability JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Uploaded files table
CREATE TABLE IF NOT EXISTS uploaded_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_url TEXT NOT NULL,
  extracted_text TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Embeddings table (using JSONB instead of vector type)
CREATE TABLE IF NOT EXISTS embeddings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  embedding JSONB NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Usage logs table
CREATE TABLE IF NOT EXISTS usage_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  model_used TEXT NOT NULL,
  tokens_input INTEGER NOT NULL,
  tokens_output INTEGER NOT NULL,
  estimated_cost NUMERIC(10, 6) NOT NULL,
  feature_type TEXT NOT NULL CHECK (feature_type IN ('onboarding', 'chat', 'embedding', 'scheduling', 'upload')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Memory versions table
CREATE TABLE IF NOT EXISTS memory_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  snapshot JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_assistants_user_id ON assistants(user_id);
CREATE INDEX IF NOT EXISTS idx_assistant_profiles_assistant_id ON assistant_profiles(assistant_id);
CREATE INDEX IF NOT EXISTS idx_assistant_rules_assistant_id ON assistant_rules(assistant_id);
CREATE INDEX IF NOT EXISTS idx_services_assistant_id ON services(assistant_id);
CREATE INDEX IF NOT EXISTS idx_products_assistant_id ON products(assistant_id);
CREATE INDEX IF NOT EXISTS idx_faqs_assistant_id ON faqs(assistant_id);
CREATE INDEX IF NOT EXISTS idx_onboarding_messages_assistant_id ON onboarding_messages(assistant_id);
CREATE INDEX IF NOT EXISTS idx_conversation_messages_assistant_id ON conversation_messages(assistant_id);
CREATE INDEX IF NOT EXISTS idx_conversation_messages_customer_id ON conversation_messages(customer_id);
CREATE INDEX IF NOT EXISTS idx_appointments_assistant_id ON appointments(assistant_id);
CREATE INDEX IF NOT EXISTS idx_appointments_start_time ON appointments(start_time);
CREATE INDEX IF NOT EXISTS idx_professionals_assistant_id ON professionals(assistant_id);
CREATE INDEX IF NOT EXISTS idx_uploaded_files_assistant_id ON uploaded_files(assistant_id);
CREATE INDEX IF NOT EXISTS idx_embeddings_assistant_id ON embeddings(assistant_id);
CREATE INDEX IF NOT EXISTS idx_usage_logs_assistant_id ON usage_logs(assistant_id);
CREATE INDEX IF NOT EXISTS idx_memory_versions_assistant_id ON memory_versions(assistant_id);

-- Row Level Security Policies

-- Assistants policies
DROP POLICY IF EXISTS assistants_select_policy ON assistants;
CREATE POLICY assistants_select_policy ON assistants
  FOR SELECT USING (
    auth.uid() = user_id
  );

DROP POLICY IF EXISTS assistants_insert_policy ON assistants;
CREATE POLICY assistants_insert_policy ON assistants
  FOR INSERT WITH CHECK (
    auth.uid() = user_id
  );

DROP POLICY IF EXISTS assistants_update_policy ON assistants;
CREATE POLICY assistants_update_policy ON assistants
  FOR UPDATE USING (
    auth.uid() = user_id
  ) WITH CHECK (
    auth.uid() = user_id
  );

DROP POLICY IF EXISTS assistants_delete_policy ON assistants;
CREATE POLICY assistants_delete_policy ON assistants
  FOR DELETE USING (
    auth.uid() = user_id
  );

-- Assistant profiles policies
DROP POLICY IF EXISTS assistant_profiles_select_policy ON assistant_profiles;
CREATE POLICY assistant_profiles_select_policy ON assistant_profiles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_profiles.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS assistant_profiles_insert_policy ON assistant_profiles;
CREATE POLICY assistant_profiles_insert_policy ON assistant_profiles
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_profiles.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS assistant_profiles_update_policy ON assistant_profiles;
CREATE POLICY assistant_profiles_update_policy ON assistant_profiles
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_profiles.assistant_id
      AND assistants.user_id = auth.uid()
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_profiles.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS assistant_profiles_delete_policy ON assistant_profiles;
CREATE POLICY assistant_profiles_delete_policy ON assistant_profiles
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_profiles.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- Assistant rules policies
DROP POLICY IF EXISTS assistant_rules_select_policy ON assistant_rules;
CREATE POLICY assistant_rules_select_policy ON assistant_rules
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_rules.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS assistant_rules_insert_policy ON assistant_rules;
CREATE POLICY assistant_rules_insert_policy ON assistant_rules
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_rules.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS assistant_rules_update_policy ON assistant_rules;
CREATE POLICY assistant_rules_update_policy ON assistant_rules
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_rules.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS assistant_rules_delete_policy ON assistant_rules;
CREATE POLICY assistant_rules_delete_policy ON assistant_rules
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_rules.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- Services policies (same pattern as assistant_rules)
DROP POLICY IF EXISTS services_select_policy ON services;
CREATE POLICY services_select_policy ON services
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = services.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS services_insert_policy ON services;
CREATE POLICY services_insert_policy ON services
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = services.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS services_update_policy ON services;
CREATE POLICY services_update_policy ON services
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = services.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS services_delete_policy ON services;
CREATE POLICY services_delete_policy ON services
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = services.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- Products policies
DROP POLICY IF EXISTS products_select_policy ON products;
CREATE POLICY products_select_policy ON products
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = products.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS products_insert_policy ON products;
CREATE POLICY products_insert_policy ON products
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = products.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS products_update_policy ON products;
CREATE POLICY products_update_policy ON products
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = products.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS products_delete_policy ON products;
CREATE POLICY products_delete_policy ON products
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = products.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- FAQs policies
DROP POLICY IF EXISTS faqs_select_policy ON faqs;
CREATE POLICY faqs_select_policy ON faqs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = faqs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS faqs_insert_policy ON faqs;
CREATE POLICY faqs_insert_policy ON faqs
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = faqs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS faqs_update_policy ON faqs;
CREATE POLICY faqs_update_policy ON faqs
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = faqs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS faqs_delete_policy ON faqs;
CREATE POLICY faqs_delete_policy ON faqs
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = faqs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- Onboarding messages policies
DROP POLICY IF EXISTS onboarding_messages_select_policy ON onboarding_messages;
CREATE POLICY onboarding_messages_select_policy ON onboarding_messages
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = onboarding_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS onboarding_messages_insert_policy ON onboarding_messages;
CREATE POLICY onboarding_messages_insert_policy ON onboarding_messages
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = onboarding_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS onboarding_messages_update_policy ON onboarding_messages;
CREATE POLICY onboarding_messages_update_policy ON onboarding_messages
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = onboarding_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS onboarding_messages_delete_policy ON onboarding_messages;
CREATE POLICY onboarding_messages_delete_policy ON onboarding_messages
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = onboarding_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- Conversation messages policies
DROP POLICY IF EXISTS conversation_messages_select_policy ON conversation_messages;
CREATE POLICY conversation_messages_select_policy ON conversation_messages
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = conversation_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS conversation_messages_insert_policy ON conversation_messages;
CREATE POLICY conversation_messages_insert_policy ON conversation_messages
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = conversation_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS conversation_messages_update_policy ON conversation_messages;
CREATE POLICY conversation_messages_update_policy ON conversation_messages
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = conversation_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS conversation_messages_delete_policy ON conversation_messages;
CREATE POLICY conversation_messages_delete_policy ON conversation_messages
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = conversation_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- Appointments policies
DROP POLICY IF EXISTS appointments_select_policy ON appointments;
CREATE POLICY appointments_select_policy ON appointments
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = appointments.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS appointments_insert_policy ON appointments;
CREATE POLICY appointments_insert_policy ON appointments
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = appointments.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS appointments_update_policy ON appointments;
CREATE POLICY appointments_update_policy ON appointments
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = appointments.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS appointments_delete_policy ON appointments;
CREATE POLICY appointments_delete_policy ON appointments
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = appointments.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- Professionals policies
DROP POLICY IF EXISTS professionals_select_policy ON professionals;
CREATE POLICY professionals_select_policy ON professionals
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = professionals.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS professionals_insert_policy ON professionals;
CREATE POLICY professionals_insert_policy ON professionals
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = professionals.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS professionals_update_policy ON professionals;
CREATE POLICY professionals_update_policy ON professionals
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = professionals.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS professionals_delete_policy ON professionals;
CREATE POLICY professionals_delete_policy ON professionals
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = professionals.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- Uploaded files policies
DROP POLICY IF EXISTS uploaded_files_select_policy ON uploaded_files;
CREATE POLICY uploaded_files_select_policy ON uploaded_files
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = uploaded_files.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS uploaded_files_insert_policy ON uploaded_files;
CREATE POLICY uploaded_files_insert_policy ON uploaded_files
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = uploaded_files.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS uploaded_files_update_policy ON uploaded_files;
CREATE POLICY uploaded_files_update_policy ON uploaded_files
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = uploaded_files.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS uploaded_files_delete_policy ON uploaded_files;
CREATE POLICY uploaded_files_delete_policy ON uploaded_files
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = uploaded_files.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- Embeddings policies
DROP POLICY IF EXISTS embeddings_select_policy ON embeddings;
CREATE POLICY embeddings_select_policy ON embeddings
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = embeddings.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS embeddings_insert_policy ON embeddings;
CREATE POLICY embeddings_insert_policy ON embeddings
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = embeddings.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS embeddings_update_policy ON embeddings;
CREATE POLICY embeddings_update_policy ON embeddings
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = embeddings.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS embeddings_delete_policy ON embeddings;
CREATE POLICY embeddings_delete_policy ON embeddings
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = embeddings.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- Usage logs policies
DROP POLICY IF EXISTS usage_logs_select_policy ON usage_logs;
CREATE POLICY usage_logs_select_policy ON usage_logs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = usage_logs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS usage_logs_insert_policy ON usage_logs;
CREATE POLICY usage_logs_insert_policy ON usage_logs
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = usage_logs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS usage_logs_update_policy ON usage_logs;
CREATE POLICY usage_logs_update_policy ON usage_logs
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = usage_logs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS usage_logs_delete_policy ON usage_logs;
CREATE POLICY usage_logs_delete_policy ON usage_logs
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = usage_logs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- Memory versions policies
DROP POLICY IF EXISTS memory_versions_select_policy ON memory_versions;
CREATE POLICY memory_versions_select_policy ON memory_versions
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = memory_versions.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS memory_versions_insert_policy ON memory_versions;
CREATE POLICY memory_versions_insert_policy ON memory_versions
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = memory_versions.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS memory_versions_update_policy ON memory_versions;
CREATE POLICY memory_versions_update_policy ON memory_versions
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = memory_versions.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS memory_versions_delete_policy ON memory_versions;
CREATE POLICY memory_versions_delete_policy ON memory_versions
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = memory_versions.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );