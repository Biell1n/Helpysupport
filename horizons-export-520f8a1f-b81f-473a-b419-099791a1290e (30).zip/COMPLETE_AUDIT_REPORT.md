# HELPY - COMPLETE CODEBASE AUDIT REPORT

**Date:** June 21, 2026
**Scope:** Frontend (React/Vite), Backend (Supabase Edge Functions), Database Schema, Integrations (OpenAI).

---

## 1. COMPLETE PROJECT MAPPING

### Overview
The Helpy codebase is currently in a transitional state (Phase 1 MVP). There is a significant mix of Javascript (`.js`/`.jsx`) and TypeScript (`.ts`/`.tsx`) files, indicating a partial migration or multiple architectural directions taken over time.

### Key Directories
*   `src/components/`: Extensive library of UI components. High quality, utilizing shadcn/ui.
*   `src/pages/`: Well-structured page routes.
*   `src/hooks/`: Contains business logic, but suffers from severe duplication.
*   `src/lib/`: Core utilities and integrations. Contains redundant Supabase clients and unsafe API implementations.
*   `src/services/`: Mostly obsolete or duplicated by `hooks` and `lib`.
*   `src/schemas/` & `src/types/`: Typescript types and Zod schemas that partially match the current SQL schema.
*   `supabase/functions/`: Deno edge functions. Some use raw `fetch`, others use a wrapper.

---

## 2. DUPLICATION AUDIT

**🚨 CRITICAL DUPLICATIONS:**

1.  **Onboarding Chat Hooks:**
    *   `src/hooks/useOnboardingChat.js` (Uses Edge Function, expects synchronous JSON return)
    *   `src/hooks/useOnboardingChat.ts` (Uses Edge Function, slightly different TS implementation)
    *   *Impact:* Components might import the wrong one, causing inconsistent state management.

2.  **Supabase Clients:**
    *   `src/lib/supabase.js` (Highly customized wrapper with 60s timeout, custom interceptors)
    *   `src/lib/supabaseClient.js` (Standard initialize)
    *   `src/lib/customSupabaseClient.js` (Standard initialize)
    *   `src/lib/supabase/client.js` / `.ts` (Subfolder structure)
    *   *Impact:* Extremely confusing. Some components use the wrapper (which intercepts timeouts and forces logouts), while others bypass it.

3.  **Onboarding Services:**
    *   `src/services/onboardingService.js`
    *   `src/services/onboardingService.ts` (Currently `export {};` - Dead code)
    *   `src/services/onboarding/onboarding.service.ts`
    *   *Impact:* Code bloat.

---

## 3. DEAD CODE AUDIT

*   `src/services/onboarding/onboardingService.ts`: Completely empty (`export {};`).
*   `src/lib/openai.js`: Contains `shouldSuggestTicket` which is exported but largely unused in the current flow.
*   `src/types/assistant.types.ts`: Contains references to `assistant_profiles` and `assistant_rules` which were replaced in the Phase 1 MVP schema (they are now JSONB columns in `assistants` or legacy tables).
*   **Various Markdown/SQL Files:** `cleanup_old_architecture.sql`, `database-schema.sql`, multiple `AUDIT_*.md` files from previous diagnostics polluting the `docs/` and `src/lib/` directories.

---

## 4. IMPORT VALIDATION

*   ✅ **Path Aliasing:** `@/` resolves correctly to `src/` via `vite.config.js`.
*   ✅ **Dependencies:** Standard UI libraries (`lucide-react`, `framer-motion`, `radix-ui`) are present and working.
*   ⚠️ **Mixed Extensions:** Importing `.ts` services into `.jsx` components works via Vite, but breaks IDE intellisense in some places due to missing generic bounds.

---

## 5. EDGE FUNCTIONS AUDIT

### `supabase/functions/onboarding-chat/index.ts`
*   **Purpose:** Handles the onboarding conversation and extracts structured data.
*   **Status:** ⚠️ **PARTIAL (Performance Risk)**
*   **Issue:** It performs TWO sequential, synchronous calls to OpenAI's API. First for conversation (`gpt-4o`, temp 0.7), second for JSON extraction (`gpt-4o`, temp 0.1). This easily exceeds 15-20 seconds, risking HTTP 504 Gateway Timeouts on slower connections.

### `supabase/functions/chat/index.ts`
*   **Purpose:** General conversation endpoint for end-users talking to assistants.
*   **Status:** ✅ **WORKING**
*   **Details:** Uses an internal `callOpenAI` helper. Correctly fetches assistant settings and system prompt from the database.

### `supabase/functions/refine-assistant-chat/index.ts`
*   **Purpose:** Advanced editor chatbot for refining the assistant.
*   **Status:** ✅ **WORKING**
*   **Details:** Called by `IntelligentAssistantChat.jsx` and `RefinementAssistantChat.jsx`. Utilizes Server-Sent Events (SSE) for streaming, preventing timeouts.

---

## 6. OPENAI INTEGRATION AUDIT

**🚨 CRITICAL SECURITY VULNERABILITY:**
*   **File:** `src/lib/openai.js` and `src/services/onboarding/extraction.service.ts`
*   **Issue:** Both files initialize the OpenAI SDK directly in the browser using `dangerouslyAllowBrowser: true` and read from `import.meta.env.VITE_OPENAI_API_KEY`.
*   **Impact:** The OpenAI API key is exposed in the frontend bundle. Any user can steal the key and abuse the OpenAI billing account.
*   **Recommendation:** Remove these files immediately. Move all OpenAI SDK calls (like `generateTicketTitle`) to Supabase Edge Functions.

**Backend Integrations:**
*   `onboarding-chat`: Uses direct `fetch` to `https://api.openai.com/v1/chat/completions`.
*   `chat`: Uses abstracted `callOpenAI`.
*   All backend calls securely read the key from `Deno.env.get('OPENAI_API_KEY')`.

---

## 7. FRONTEND AUDIT

### Key Pages (`src/pages/`)
*   `HomePage.jsx`: ✅ Beautifully implemented, uses video background and Framer Motion.
*   `DashboardPage.jsx`: ✅ Implemented. Correctly branches into `DashboardBusiness` or `DashboardClient` based on user type.
*   `OnboardingChatPage.jsx`: ✅ Functioning chat UI for new onboarding flow.
*   `OnboardingPage.jsx`: ⚠️ Legacy form-based onboarding. Should probably be deprecated in favor of `OnboardingChatPage`.
*   `EditAssistantPage.jsx`: ✅ Loads `RefinementAssistantChat` and memory providers.

### Key Components (`src/components/`)
*   `IntelligentAssistantChat.jsx`: ✅ Uses SSE streaming perfectly. Well-designed UI.
*   `RefinementAssistantChat.jsx`: ✅ Integrates with `AssistantMemoryProvider`.
*   `TicketChat.jsx`: ✅ Validates policy enforcement via `usePolicyEnforcement`.

---

## 8. ROUTING AUDIT

*   **File:** `src/App.jsx`
*   ✅ **Configuration:** Uses `react-router-dom`. All main routes are wrapped in a custom `<ConfigCheck>` and `<ErrorBoundary>`.
*   ✅ **Protected Routes:** `ProtectedRoute` component correctly guards dashboard and onboarding routes.
*   ⚠️ **Redundancy:** `/dashboard/create-assistant` automatically redirects to `/onboarding-chat`, but there are files like `CreateAssistantPage.jsx` and `CreateAssistantOnboardingPage.jsx` still existing.

---

## 9. FLOW TRACING

### Flow 1: Onboarding Chat (New Flow)
1.  User accesses `/onboarding-chat`.
2.  `OnboardingChatPage.jsx` renders.
3.  If no session, creates a new `onboarding_sessions` record via Supabase client.
4.  User types a message -> `sendMessage` from `useOnboardingChat.js`.
5.  Calls `onboarding-chat` Edge Function.
6.  Edge Function calls OpenAI twice (Chat + Extraction), updates DB, returns JSON.
7.  React state updates history and `OnboardingDataPanel` renders the extracted info.
8.  User clicks "Create Assistant" -> Routes to `/dashboard` (⚠️ **Gap:** Doesn't actually insert into `assistants` table here; relies on incomplete logic or expects dashboard to handle it).

### Flow 2: Assistant Editing
1.  User accesses `/assistant/:id/edit`.
2.  `EditAssistantPage.jsx` loads assistant data and `assistant_memory`.
3.  Renders `RefinementAssistantChat.jsx`.
4.  User sends message -> invokes `refine-assistant-chat` edge function.
5.  Returns streaming response -> updates UI instantly.
6.  Parses structured data from response -> merges into `AssistantMemoryProvider` -> saves to DB.

### Flow 3: End-User Chat
1.  User accesses a public assistant widget.
2.  Sends message -> invokes `chat` edge function.
3.  Edge function inserts message into `conversation_messages`.
4.  **🚨 FAILURE POINT:** The RLS policy on `conversation_messages` requires `auth.uid()` to match the assistant owner. Anonymous users cannot insert messages unless the edge function bypasses RLS using the Service Role Key.

---

## 10. CONSISTENCY AUDIT

*   **Database vs Types:** `src/types/assistant.types.ts` defines `AssistantProfile` and `AssistantRule`. However, the current SQL schema for MVP Phase 1 flattened many settings into the `assistants` table directly (e.g., `model_name`, `temperature`, `niche`, `tone_of_voice`). The TypeScript types are out of sync with the database.
*   **Database Schema vs Service:** The legacy `src/lib/assistantService.js` attempts to insert `{ model: config.model, identity: config.identity }` which will crash because those JSON columns were dropped in favor of flat columns in the latest migration.

---

## 11. RUNTIME AUDIT

*   **Compilation:** Vite compiles successfully (it ignores `.ts` type mismatches).
*   **Network Timeouts:** The `src/lib/supabase.js` wrapper intercepts timeouts. If an OpenAI Edge Function takes longer than the timeout, the frontend forcibly deletes the auth token and logs the user out (`handleDbAuthError`). This is a terrible UX bug for long-running AI queries.
*   **Crash Risk:** Trying to save an assistant using the old `assistantService.js` logic will result in a 400 Bad Request from PostgREST due to missing columns.

---

## 12. PERFORMANCE AUDIT

*   **Bottleneck:** `supabase/functions/onboarding-chat/index.ts` running sequential GPT-4o queries.
*   **Fix:** Descouple the JSON extraction. Return the conversational response immediately, and run the extraction asynchronously (or stream it).

---

## 13. SECURITY AUDIT

1.  **VITE_OPENAI_API_KEY in Frontend:** As mentioned, critical exposure.
2.  **RLS Policies:** 
    *   `conversation_messages`: Too strict. Prevents public interaction.
    *   `assistants`: Correctly allows public read if `is_public = true`.

---

## 14. FINAL DIAGNOSIS

*   `src/App.jsx` & Routing: ✅ **WORKS AND IS CONNECTED**
*   `src/contexts/AuthContext.jsx`: ✅ **WORKS AND IS CONNECTED**
*   `src/components/IntelligentAssistantChat.jsx`: ✅ **WORKS AND IS CONNECTED**
*   `supabase/functions/refine-assistant-chat`: ✅ **WORKS AND IS CONNECTED**
*   `supabase/functions/onboarding-chat`: ⚠️ **EXISTS BUT PARTIALLY CONNECTED** (High latency, sync issues).
*   `src/hooks/useOnboardingChat.js/ts`: ⚠️ **EXISTS BUT PARTIALLY CONNECTED** (Duplicated).
*   `src/lib/openai.js`: ❌ **EXISTS BUT DANGEROUS** (Security risk, must be moved to backend).
*   `src/lib/assistantService.js`: ❌ **BROKEN** (Schema mismatch).

---

## 15. RECOMMENDATIONS & NEXT STEPS

1.  **IMMEDIATE SECURITY FIX:** Delete `src/lib/openai.js` and remove `VITE_OPENAI_API_KEY` from `.env.local` / Supabase Secrets exposed to Vite. Move all generation logic to Deno Edge Functions.
2.  **SCHEMA RECONCILIATION:** Rewrite `src/lib/assistantService.js` to insert/update data using the flat columns (`niche`, `model_name`, `temperature`, `system_prompt`) defined in the `20260621_phase1_mvp_schema.sql` migration.
3.  **CLEANUP DUPLICATES:** Delete the `.ts` versions of duplicated hooks (`useOnboardingChat.ts`) and unify all Supabase client imports to use exactly one instance (`src/lib/customSupabaseClient.js`).
4.  **FIX RLS:** Modify the `conversation_messages` RLS policy to allow anonymous inserts if the `conversation_id` is valid, OR ensure the `chat` Edge Function uses the `SUPABASE_SERVICE_ROLE_KEY` to insert messages on behalf of users.
5.  **REMOVE AUTH TIMEOUT TRAP:** Remove the aggressive `handleDbAuthError` logic in `src/lib/supabase.js` that logs users out on timeouts, as AI responses are naturally slow.