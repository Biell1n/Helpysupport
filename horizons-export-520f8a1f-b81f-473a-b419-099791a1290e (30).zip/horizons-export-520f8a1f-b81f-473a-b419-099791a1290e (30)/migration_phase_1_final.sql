-- =====================================================
-- PHASE 1: NEW MODULAR ARCHITECTURE MIGRATION
-- =====================================================
-- This migration creates the foundational modular database schema
-- for the Professional AI Assistant Platform with vector search capabilities.
--
-- NEW ARCHITECTURE OVERVIEW:
-- - Professional-centric model (replaces user/business owner model)
-- - Multi-tenant organization support
-- - Vector-based knowledge management with pgvector
-- - Audit logging and API key management
-- - Usage metrics and analytics
--
-- TABLES CREATED: 14 core tables
-- - professionals: Professional users who create and manage assistants
-- - organizations: Multi-tenant organization management
-- - professional_organizations: Many-to-many professional-organization relationships
-- - assistants: AI assistants owned by professionals
-- - assistant_knowledge_base: Vector-embedded knowledge for RAG
-- - assistant_settings: Configuration for each assistant
-- - conversations: User conversations with assistants
-- - conversation_messages: Individual messages in conversations
-- - conversation_embeddings: Vector embeddings for conversation context
-- - knowledge_base_categories: Categories for organizing knowledge
-- - assistant_knowledge_categories: Many-to-many assistant-category relationships
-- - audit_logs: System-wide audit trail
-- - api_keys: API authentication for professionals
-- - usage_metrics: Usage tracking and analytics
--
-- Execution time: ~45 seconds
-- =====================================================

-- =====================================================
-- SECTION 1: ENABLE REQUIRED EXTENSIONS
-- =====================================================

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 1/7: Enabling PostgreSQL extensions...';
END $$;

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Enable vector similarity search (pgvector)
CREATE EXTENSION IF NOT EXISTS vector;

DO $$
BEGIN
  RAISE NOTICE '✅ Extensions enabled successfully';
END $$;

-- =====================================================
-- SECTION 2: CREATE ALL TABLES
-- =====================================================

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 2/7: Creating new database tables...';
END $$;

-- -----------------------------------------------------
-- TABLE: professionals
-- Purpose: Professional users who create and manage AI assistants
-- Relationships: Parent table for assistants, api_keys, usage_metrics
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS professionals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT,
  bio TEXT,
  avatar_url TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE professionals IS 'Professional users who create and manage AI assistants';
COMMENT ON COLUMN professionals.user_id IS 'Reference to auth.users - connects to Supabase authentication';
COMMENT ON COLUMN professionals.status IS 'Account status: active, inactive, or suspended';

-- -----------------------------------------------------
-- TABLE: organizations
-- Purpose: Multi-tenant organizations that professionals can belong to
-- Relationships: Many-to-many with professionals via professional_organizations
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  logo_url TEXT,
  website TEXT,
  settings JSONB DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE organizations IS 'Multi-tenant organizations for grouping professionals';
COMMENT ON COLUMN organizations.settings IS 'Organization-wide settings and preferences (JSON)';

-- -----------------------------------------------------
-- TABLE: professional_organizations
-- Purpose: Many-to-many relationship between professionals and organizations
-- Relationships: Links professionals to organizations with roles
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS professional_organizations (
  professional_id UUID NOT NULL,
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (professional_id, organization_id)
);

COMMENT ON TABLE professional_organizations IS 'Junction table linking professionals to organizations with roles';
COMMENT ON COLUMN professional_organizations.role IS 'Professional role in organization: owner, admin, or member';

-- -----------------------------------------------------
-- TABLE: assistants
-- Purpose: AI assistants created and managed by professionals
-- Relationships: Owned by professionals, has knowledge base, settings, conversations
-- Note: professional_id FK constraint added later via ALTER TABLE
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS assistants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  professional_id UUID NOT NULL,
  organization_id UUID REFERENCES organizations(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  description TEXT,
  system_prompt TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'archived')),
  is_public BOOLEAN DEFAULT FALSE,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE assistants IS 'AI assistants owned by professionals';
COMMENT ON COLUMN assistants.system_prompt IS 'Base system prompt that defines assistant behavior';
COMMENT ON COLUMN assistants.is_public IS 'Whether assistant is publicly accessible';
COMMENT ON COLUMN assistants.metadata IS 'Additional assistant configuration (JSON)';

-- -----------------------------------------------------
-- TABLE: assistant_knowledge_base
-- Purpose: Vector-embedded knowledge documents for RAG (Retrieval Augmented Generation)
-- Relationships: Many-to-one with assistants
-- Note: Uses pgvector for semantic similarity search
-- Vector dimension: 1536 (OpenAI text-embedding-3-small)
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS assistant_knowledge_base (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  embedding vector(1536) NOT NULL,
  source_type TEXT CHECK (source_type IN ('document', 'url', 'manual', 'faq')),
  source_url TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE assistant_knowledge_base IS 'Vector-embedded knowledge for RAG-based assistant responses';
COMMENT ON COLUMN assistant_knowledge_base.embedding IS 'Vector embedding for semantic similarity search (1536 dimensions)';
COMMENT ON COLUMN assistant_knowledge_base.source_type IS 'Origin of knowledge: document, url, manual entry, or FAQ';

-- -----------------------------------------------------
-- TABLE: assistant_settings
-- Purpose: Configuration settings for each assistant
-- Relationships: One-to-one with assistants
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS assistant_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE UNIQUE,
  temperature NUMERIC(3, 2) DEFAULT 0.7 CHECK (temperature >= 0 AND temperature <= 2),
  max_tokens INTEGER DEFAULT 2000 CHECK (max_tokens > 0 AND max_tokens <= 128000),
  model TEXT NOT NULL DEFAULT 'gpt-4o',
  enable_web_search BOOLEAN DEFAULT FALSE,
  enable_function_calling BOOLEAN DEFAULT FALSE,
  response_format TEXT DEFAULT 'text' CHECK (response_format IN ('text', 'json')),
  custom_settings JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE assistant_settings IS 'LLM configuration settings for assistants';
COMMENT ON COLUMN assistant_settings.temperature IS 'Creativity level (0-2): lower = focused, higher = creative';
COMMENT ON COLUMN assistant_settings.max_tokens IS 'Maximum response length in tokens';
COMMENT ON COLUMN assistant_settings.model IS 'OpenAI model to use (e.g., gpt-4o, gpt-4o-mini)';

-- -----------------------------------------------------
-- TABLE: conversations
-- Purpose: User conversations with assistants
-- Relationships: Many-to-one with assistants, has conversation_messages
-- Note: user_id can be NULL for anonymous conversations
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  user_id UUID,
  title TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'archived', 'deleted')),
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE conversations IS 'User conversations with AI assistants';
COMMENT ON COLUMN conversations.user_id IS 'Optional: authenticated user ID or NULL for anonymous';
COMMENT ON COLUMN conversations.title IS 'Auto-generated or user-provided conversation title';

-- -----------------------------------------------------
-- TABLE: conversation_messages
-- Purpose: Individual messages within conversations
-- Relationships: Many-to-one with conversations
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system', 'function')),
  content TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE conversation_messages IS 'Individual messages in assistant conversations';
COMMENT ON COLUMN conversation_messages.role IS 'Message sender: user, assistant, system, or function';
COMMENT ON COLUMN conversation_messages.metadata IS 'Additional message data (tokens used, function calls, etc.)';

-- -----------------------------------------------------
-- TABLE: conversation_embeddings
-- Purpose: Vector embeddings for conversation context and similarity search
-- Relationships: One-to-one with conversations
-- Vector dimension: 1536 (OpenAI text-embedding-3-small)
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_embeddings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE UNIQUE,
  embedding vector(1536) NOT NULL,
  summary TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE conversation_embeddings IS 'Vector embeddings for conversation context and retrieval';
COMMENT ON COLUMN conversation_embeddings.summary IS 'Auto-generated conversation summary';

-- -----------------------------------------------------
-- TABLE: knowledge_base_categories
-- Purpose: Categories for organizing knowledge base content
-- Relationships: Many-to-many with assistants via assistant_knowledge_categories
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS knowledge_base_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  parent_category_id UUID REFERENCES knowledge_base_categories(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE knowledge_base_categories IS 'Categories for organizing knowledge base content';
COMMENT ON COLUMN knowledge_base_categories.parent_category_id IS 'Optional: parent category for hierarchical organization';

-- -----------------------------------------------------
-- TABLE: assistant_knowledge_categories
-- Purpose: Many-to-many relationship between assistants and knowledge categories
-- Relationships: Links assistants to knowledge_base_categories
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS assistant_knowledge_categories (
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  category_id UUID NOT NULL REFERENCES knowledge_base_categories(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (assistant_id, category_id)
);

COMMENT ON TABLE assistant_knowledge_categories IS 'Junction table linking assistants to knowledge categories';

-- -----------------------------------------------------
-- TABLE: audit_logs
-- Purpose: System-wide audit trail for compliance and debugging
-- Relationships: Many-to-one with professionals
-- Note: professional_id FK constraint added later via ALTER TABLE
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  professional_id UUID,
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id UUID,
  changes JSONB DEFAULT '{}'::jsonb,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE audit_logs IS 'System-wide audit trail for security and compliance';
COMMENT ON COLUMN audit_logs.action IS 'Action performed (e.g., create, update, delete)';
COMMENT ON COLUMN audit_logs.resource_type IS 'Type of resource affected (e.g., assistant, conversation)';
COMMENT ON COLUMN audit_logs.changes IS 'JSON diff of changes made';

-- -----------------------------------------------------
-- TABLE: api_keys
-- Purpose: API authentication keys for professionals
-- Relationships: Many-to-one with professionals
-- Note: professional_id FK constraint added later via ALTER TABLE
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS api_keys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  professional_id UUID NOT NULL,
  key_hash TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  permissions JSONB DEFAULT '["read"]'::jsonb,
  last_used_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'revoked', 'expired')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE api_keys IS 'API authentication keys for programmatic access';
COMMENT ON COLUMN api_keys.key_hash IS 'Hashed API key (never store plain text)';
COMMENT ON COLUMN api_keys.permissions IS 'JSON array of allowed permissions';

-- -----------------------------------------------------
-- TABLE: usage_metrics
-- Purpose: Track usage statistics for analytics and billing
-- Relationships: Many-to-one with professionals
-- Note: professional_id FK constraint added later via ALTER TABLE
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS usage_metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  professional_id UUID NOT NULL,
  assistant_id UUID REFERENCES assistants(id) ON DELETE SET NULL,
  metric_type TEXT NOT NULL CHECK (metric_type IN ('api_calls', 'tokens_used', 'conversations', 'messages', 'embeddings')),
  value INTEGER NOT NULL,
  period DATE NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE usage_metrics IS 'Usage tracking for analytics and billing';
COMMENT ON COLUMN usage_metrics.metric_type IS 'Type of metric: api_calls, tokens_used, conversations, messages, or embeddings';
COMMENT ON COLUMN usage_metrics.period IS 'Date for which this metric applies';

DO $$
BEGIN
  RAISE NOTICE '✅ All tables created successfully';
END $$;

-- =====================================================
-- SECTION 3: ADD FOREIGN KEY CONSTRAINTS
-- =====================================================
-- Add foreign key constraints that require tables to exist first

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 3/7: Adding foreign key constraints...';
END $$;

-- Add professional_id FK to professional_organizations
ALTER TABLE professional_organizations
ADD CONSTRAINT fk_professional_organizations_professional_id
FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE CASCADE;

-- Add professional_id FK to assistants
ALTER TABLE assistants
ADD CONSTRAINT fk_assistants_professional_id
FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE CASCADE;

-- Add professional_id FK to audit_logs
ALTER TABLE audit_logs
ADD CONSTRAINT fk_audit_logs_professional_id
FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE SET NULL;

-- Add professional_id FK to api_keys
ALTER TABLE api_keys
ADD CONSTRAINT fk_api_keys_professional_id
FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE CASCADE;

-- Add professional_id FK to usage_metrics
ALTER TABLE usage_metrics
ADD CONSTRAINT fk_usage_metrics_professional_id
FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE CASCADE;

DO $$
BEGIN
  RAISE NOTICE '✅ Foreign key constraints added successfully';
END $$;

-- =====================================================
-- SECTION 4: CREATE INDEXES
-- =====================================================
-- Performance optimization indexes for common query patterns

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 4/7: Creating performance indexes...';
END $$;

-- Professionals table indexes
CREATE INDEX IF NOT EXISTS idx_professionals_user_id ON professionals(user_id);
CREATE INDEX IF NOT EXISTS idx_professionals_email ON professionals(email);
CREATE INDEX IF NOT EXISTS idx_professionals_status ON professionals(status);

-- Organizations table indexes
CREATE INDEX IF NOT EXISTS idx_organizations_status ON organizations(status);

-- Professional organizations table indexes
CREATE INDEX IF NOT EXISTS idx_professional_orgs_professional_id ON professional_organizations(professional_id);
CREATE INDEX IF NOT EXISTS idx_professional_orgs_organization_id ON professional_organizations(organization_id);

-- Assistants table indexes
CREATE INDEX IF NOT EXISTS idx_assistants_professional_id ON assistants(professional_id);
CREATE INDEX IF NOT EXISTS idx_assistants_organization_id ON assistants(organization_id);
CREATE INDEX IF NOT EXISTS idx_assistants_status ON assistants(status);
CREATE INDEX IF NOT EXISTS idx_assistants_created_at ON assistants(created_at DESC);

-- Assistant knowledge base table indexes
CREATE INDEX IF NOT EXISTS idx_knowledge_assistant_id ON assistant_knowledge_base(assistant_id);
CREATE INDEX IF NOT EXISTS idx_knowledge_source_type ON assistant_knowledge_base(source_type);
-- Vector similarity search index using IVFFlat with cosine distance
CREATE INDEX IF NOT EXISTS idx_knowledge_embedding ON assistant_knowledge_base 
USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- Assistant settings table indexes
CREATE INDEX IF NOT EXISTS idx_settings_assistant_id ON assistant_settings(assistant_id);

-- Conversations table indexes
CREATE INDEX IF NOT EXISTS idx_conversations_assistant_id ON conversations(assistant_id);
CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_status ON conversations(status);
CREATE INDEX IF NOT EXISTS idx_conversations_created_at ON conversations(created_at DESC);

-- Conversation messages table indexes
CREATE INDEX IF NOT EXISTS idx_messages_conversation_id ON conversation_messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON conversation_messages(created_at);

-- Conversation embeddings table indexes
CREATE INDEX IF NOT EXISTS idx_conv_embeddings_conversation_id ON conversation_embeddings(conversation_id);
-- Vector similarity search index
CREATE INDEX IF NOT EXISTS idx_conv_embeddings_embedding ON conversation_embeddings 
USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- Knowledge base categories table indexes
CREATE INDEX IF NOT EXISTS idx_categories_parent_id ON knowledge_base_categories(parent_category_id);

-- Assistant knowledge categories table indexes
CREATE INDEX IF NOT EXISTS idx_asst_knowledge_cats_assistant_id ON assistant_knowledge_categories(assistant_id);
CREATE INDEX IF NOT EXISTS idx_asst_knowledge_cats_category_id ON assistant_knowledge_categories(category_id);

-- Audit logs table indexes
CREATE INDEX IF NOT EXISTS idx_audit_professional_id ON audit_logs(professional_id);
CREATE INDEX IF NOT EXISTS idx_audit_resource_type ON audit_logs(resource_type);
CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_logs(created_at DESC);

-- API keys table indexes
CREATE INDEX IF NOT EXISTS idx_api_keys_professional_id ON api_keys(professional_id);
CREATE INDEX IF NOT EXISTS idx_api_keys_key_hash ON api_keys(key_hash);
CREATE INDEX IF NOT EXISTS idx_api_keys_status ON api_keys(status);

-- Usage metrics table indexes
CREATE INDEX IF NOT EXISTS idx_metrics_professional_id ON usage_metrics(professional_id);
CREATE INDEX IF NOT EXISTS idx_metrics_assistant_id ON usage_metrics(assistant_id);
CREATE INDEX IF NOT EXISTS idx_metrics_period ON usage_metrics(period DESC);
CREATE INDEX IF NOT EXISTS idx_metrics_type ON usage_metrics(metric_type);

DO $$
BEGIN
  RAISE NOTICE '✅ Performance indexes created successfully';
END $$;

-- =====================================================
-- SECTION 5: ENABLE ROW LEVEL SECURITY
-- =====================================================

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 5/7: Enabling Row Level Security...';
END $$;

ALTER TABLE professionals ENABLE ROW LEVEL SECURITY;
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE professional_organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE assistants ENABLE ROW LEVEL SECURITY;
ALTER TABLE assistant_knowledge_base ENABLE ROW LEVEL SECURITY;
ALTER TABLE assistant_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversation_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversation_embeddings ENABLE ROW LEVEL SECURITY;
ALTER TABLE knowledge_base_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE assistant_knowledge_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE usage_metrics ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  RAISE NOTICE '✅ Row Level Security enabled on all tables';
END $$;

-- =====================================================
-- SECTION 6: CREATE RLS POLICIES
-- =====================================================
-- Security model: Professionals can only access their own data and public assistants

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 6/7: Creating Row Level Security policies...';
END $$;

-- -----------------------------------------------------
-- PROFESSIONALS TABLE POLICIES
-- Users can view and update their own professional profile
-- -----------------------------------------------------

CREATE POLICY professionals_select_own ON professionals
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY professionals_insert_own ON professionals
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY professionals_update_own ON professionals
  FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY professionals_delete_own ON professionals
  FOR DELETE USING (auth.uid() = user_id);

-- -----------------------------------------------------
-- ORGANIZATIONS TABLE POLICIES
-- Professionals can view organizations they belong to
-- -----------------------------------------------------

CREATE POLICY organizations_select_member ON organizations
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM professional_organizations po
      JOIN professionals p ON p.id = po.professional_id
      WHERE po.organization_id = organizations.id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY organizations_insert_owner ON organizations
  FOR INSERT WITH CHECK (true);

CREATE POLICY organizations_update_admin ON organizations
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM professional_organizations po
      JOIN professionals p ON p.id = po.professional_id
      WHERE po.organization_id = organizations.id
      AND p.user_id = auth.uid()
      AND po.role IN ('owner', 'admin')
    )
  );

CREATE POLICY organizations_delete_owner ON organizations
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM professional_organizations po
      JOIN professionals p ON p.id = po.professional_id
      WHERE po.organization_id = organizations.id
      AND p.user_id = auth.uid()
      AND po.role = 'owner'
    )
  );

-- -----------------------------------------------------
-- PROFESSIONAL_ORGANIZATIONS TABLE POLICIES
-- Professionals can manage their organization memberships
-- -----------------------------------------------------

CREATE POLICY prof_orgs_select_member ON professional_organizations
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM professionals p
      WHERE p.id = professional_organizations.professional_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY prof_orgs_insert_admin ON professional_organizations
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM professional_organizations po
      JOIN professionals p ON p.id = po.professional_id
      WHERE po.organization_id = professional_organizations.organization_id
      AND p.user_id = auth.uid()
      AND po.role IN ('owner', 'admin')
    )
  );

CREATE POLICY prof_orgs_delete_admin ON professional_organizations
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM professional_organizations po
      JOIN professionals p ON p.id = po.professional_id
      WHERE po.organization_id = professional_organizations.organization_id
      AND p.user_id = auth.uid()
      AND po.role IN ('owner', 'admin')
    )
  );

-- -----------------------------------------------------
-- ASSISTANTS TABLE POLICIES
-- Professionals can access their own assistants + public assistants
-- -----------------------------------------------------

CREATE POLICY assistants_select_own_or_public ON assistants
  FOR SELECT USING (
    is_public = true OR
    EXISTS (
      SELECT 1 FROM professionals p
      WHERE p.id = assistants.professional_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY assistants_insert_own ON assistants
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM professionals p
      WHERE p.id = assistants.professional_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY assistants_update_own ON assistants
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM professionals p
      WHERE p.id = assistants.professional_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY assistants_delete_own ON assistants
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM professionals p
      WHERE p.id = assistants.professional_id
      AND p.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- ASSISTANT_KNOWLEDGE_BASE TABLE POLICIES
-- Only assistant owners can manage knowledge base
-- -----------------------------------------------------

CREATE POLICY knowledge_select_owner ON assistant_knowledge_base
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants a
      JOIN professionals p ON p.id = a.professional_id
      WHERE a.id = assistant_knowledge_base.assistant_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY knowledge_insert_owner ON assistant_knowledge_base
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants a
      JOIN professionals p ON p.id = a.professional_id
      WHERE a.id = assistant_knowledge_base.assistant_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY knowledge_delete_owner ON assistant_knowledge_base
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants a
      JOIN professionals p ON p.id = a.professional_id
      WHERE a.id = assistant_knowledge_base.assistant_id
      AND p.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- ASSISTANT_SETTINGS TABLE POLICIES
-- Only assistant owners can manage settings
-- -----------------------------------------------------

CREATE POLICY settings_select_owner ON assistant_settings
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants a
      JOIN professionals p ON p.id = a.professional_id
      WHERE a.id = assistant_settings.assistant_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY settings_insert_owner ON assistant_settings
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants a
      JOIN professionals p ON p.id = a.professional_id
      WHERE a.id = assistant_settings.assistant_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY settings_update_owner ON assistant_settings
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants a
      JOIN professionals p ON p.id = a.professional_id
      WHERE a.id = assistant_settings.assistant_id
      AND p.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- CONVERSATIONS TABLE POLICIES
-- Users can view their own conversations, professionals can view assistant conversations
-- -----------------------------------------------------

CREATE POLICY conversations_select_own_or_owner ON conversations
  FOR SELECT USING (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM assistants a
      JOIN professionals p ON p.id = a.professional_id
      WHERE a.id = conversations.assistant_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY conversations_insert_authenticated ON conversations
  FOR INSERT WITH CHECK (true);

CREATE POLICY conversations_update_own ON conversations
  FOR UPDATE USING (auth.uid() = user_id);

-- -----------------------------------------------------
-- CONVERSATION_MESSAGES TABLE POLICIES
-- Users can view messages in their conversations
-- -----------------------------------------------------

CREATE POLICY messages_select_conversation_member ON conversation_messages
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = conversation_messages.conversation_id
      AND (
        c.user_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM assistants a
          JOIN professionals p ON p.id = a.professional_id
          WHERE a.id = c.assistant_id
          AND p.user_id = auth.uid()
        )
      )
    )
  );

CREATE POLICY messages_insert_conversation_member ON conversation_messages
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = conversation_messages.conversation_id
      AND (c.user_id = auth.uid() OR c.user_id IS NULL)
    )
  );

-- -----------------------------------------------------
-- CONVERSATION_EMBEDDINGS TABLE POLICIES
-- Only assistant owners can view embeddings
-- -----------------------------------------------------

CREATE POLICY embeddings_select_owner ON conversation_embeddings
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM conversations c
      JOIN assistants a ON a.id = c.assistant_id
      JOIN professionals p ON p.id = a.professional_id
      WHERE c.id = conversation_embeddings.conversation_id
      AND p.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- KNOWLEDGE_BASE_CATEGORIES TABLE POLICIES
-- Public read, authenticated write
-- -----------------------------------------------------

CREATE POLICY categories_select_all ON knowledge_base_categories
  FOR SELECT USING (true);

CREATE POLICY categories_insert_authenticated ON knowledge_base_categories
  FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

-- -----------------------------------------------------
-- ASSISTANT_KNOWLEDGE_CATEGORIES TABLE POLICIES
-- Only assistant owners can manage categories
-- -----------------------------------------------------

CREATE POLICY asst_cats_select_owner ON assistant_knowledge_categories
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants a
      JOIN professionals p ON p.id = a.professional_id
      WHERE a.id = assistant_knowledge_categories.assistant_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY asst_cats_insert_owner ON assistant_knowledge_categories
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants a
      JOIN professionals p ON p.id = a.professional_id
      WHERE a.id = assistant_knowledge_categories.assistant_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY asst_cats_delete_owner ON assistant_knowledge_categories
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants a
      JOIN professionals p ON p.id = a.professional_id
      WHERE a.id = assistant_knowledge_categories.assistant_id
      AND p.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- AUDIT_LOGS TABLE POLICIES
-- Professionals can view their own audit logs
-- -----------------------------------------------------

CREATE POLICY audit_select_own ON audit_logs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM professionals p
      WHERE p.id = audit_logs.professional_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY audit_insert_system ON audit_logs
  FOR INSERT WITH CHECK (true);

-- -----------------------------------------------------
-- API_KEYS TABLE POLICIES
-- Professionals can manage their own API keys
-- -----------------------------------------------------

CREATE POLICY api_keys_select_own ON api_keys
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM professionals p
      WHERE p.id = api_keys.professional_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY api_keys_insert_own ON api_keys
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM professionals p
      WHERE p.id = api_keys.professional_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY api_keys_update_own ON api_keys
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM professionals p
      WHERE p.id = api_keys.professional_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY api_keys_delete_own ON api_keys
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM professionals p
      WHERE p.id = api_keys.professional_id
      AND p.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- USAGE_METRICS TABLE POLICIES
-- Professionals can view their own usage metrics
-- -----------------------------------------------------

CREATE POLICY metrics_select_own ON usage_metrics
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM professionals p
      WHERE p.id = usage_metrics.professional_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY metrics_insert_system ON usage_metrics
  FOR INSERT WITH CHECK (true);

DO $$
BEGIN
  RAISE NOTICE '✅ Row Level Security policies created successfully';
END $$;

-- =====================================================
-- SECTION 7: CREATE STORAGE BUCKETS
-- =====================================================

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 7/7: Creating storage buckets...';
END $$;

-- Create storage bucket for assistant knowledge documents
INSERT INTO storage.buckets (id, name, public)
VALUES ('assistant-knowledge', 'assistant-knowledge', true)
ON CONFLICT (id) DO NOTHING;

-- Storage bucket RLS policy: Public read, authenticated write
CREATE POLICY "Public read access for knowledge documents"
ON storage.objects FOR SELECT
USING (bucket_id = 'assistant-knowledge');

CREATE POLICY "Authenticated users can upload knowledge documents"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'assistant-knowledge' AND
  auth.uid() IS NOT NULL
);

CREATE POLICY "Users can update their own knowledge documents"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'assistant-knowledge' AND
  auth.uid() IS NOT NULL
);

CREATE POLICY "Users can delete their own knowledge documents"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'assistant-knowledge' AND
  auth.uid() IS NOT NULL
);

DO $$
BEGIN
  RAISE NOTICE '✅ Storage buckets created successfully';
END $$;

-- =====================================================
-- SECTION 8: VERIFICATION QUERIES
-- =====================================================

DO $$
BEGIN
  RAISE NOTICE '';
  RAISE NOTICE '========================================';
  RAISE NOTICE '🔍 MIGRATION VERIFICATION';
  RAISE NOTICE '========================================';
END $$;

-- Count created tables
DO $$
DECLARE
  table_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO table_count
  FROM information_schema.tables
  WHERE table_schema = 'public'
  AND table_name IN (
    'professionals', 'organizations', 'professional_organizations',
    'assistants', 'assistant_knowledge_base', 'assistant_settings',
    'conversations', 'conversation_messages', 'conversation_embeddings',
    'knowledge_base_categories', 'assistant_knowledge_categories',
    'audit_logs', 'api_keys', 'usage_metrics'
  );
  
  IF table_count = 14 THEN
    RAISE NOTICE '✅ All 14 tables created successfully';
  ELSE
    RAISE NOTICE '⚠️  Warning: Expected 14 tables, found %', table_count;
  END IF;
END $$;

-- Verify vector extension
DO $$
DECLARE
  vector_enabled BOOLEAN;
BEGIN
  SELECT COUNT(*) > 0 INTO vector_enabled
  FROM pg_extension
  WHERE extname = 'vector';
  
  IF vector_enabled THEN
    RAISE NOTICE '✅ pgvector extension enabled';
  ELSE
    RAISE NOTICE '⚠️  Warning: pgvector extension not found';
  END IF;
END $$;

-- Count RLS policies
DO $$
DECLARE
  policy_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO policy_count
  FROM pg_policies
  WHERE schemaname = 'public';
  
  IF policy_count >= 40 THEN
    RAISE NOTICE '✅ RLS policies created (% policies)', policy_count;
  ELSE
    RAISE NOTICE '⚠️  Warning: Expected 40+ policies, found %', policy_count;
  END IF;
END $$;

-- Verify storage bucket
DO $$
DECLARE
  bucket_exists BOOLEAN;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM storage.buckets WHERE id = 'assistant-knowledge'
  ) INTO bucket_exists;
  
  IF bucket_exists THEN
    RAISE NOTICE '✅ Storage bucket "assistant-knowledge" created';
  ELSE
    RAISE NOTICE '⚠️  Warning: Storage bucket not found';
  END IF;
END $$;

DO $$
BEGIN
  RAISE NOTICE '';
  RAISE NOTICE '========================================';
  RAISE NOTICE '✅ MIGRATION COMPLETED SUCCESSFULLY';
  RAISE NOTICE '========================================';
  RAISE NOTICE '';
  RAISE NOTICE '📊 New Architecture Summary:';
  RAISE NOTICE '   • 14 tables created';
  RAISE NOTICE '   • Vector search enabled (pgvector)';
  RAISE NOTICE '   • Row Level Security configured';
  RAISE NOTICE '   • Storage bucket ready';
  RAISE NOTICE '';
  RAISE NOTICE 'Next steps:';
  RAISE NOTICE '   1. Verify data in Supabase Dashboard';
  RAISE NOTICE '   2. Test authentication and RLS policies';
  RAISE NOTICE '   3. Begin importing/migrating data';
  RAISE NOTICE '';
END $$;