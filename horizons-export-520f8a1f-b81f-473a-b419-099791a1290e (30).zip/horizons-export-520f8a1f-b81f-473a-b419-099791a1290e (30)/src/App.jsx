import React, { useEffect, useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { Toaster } from '@/components/ui/toaster';
import ToastContainer from '@/components/ui/ToastContainer';
import ProtectedRoute from '@/components/ProtectedRoute';
import ErrorBoundary from '@/components/ErrorBoundary';
import { validateEnv } from '@/lib/supabase';

import HomePage from '@/pages/HomePage';
import ResetPasswordPage from '@/pages/ResetPasswordPage';
import DashboardPage from '@/pages/DashboardPage';
import VerifyEmailPage from '@/pages/VerifyEmailPage';
import VerifyRegistrationPage from '@/pages/VerifyRegistrationPage';
import VerifyLoginPage from '@/pages/VerifyLoginPage';
import ProfilePage from '@/pages/ProfilePage';
import AuthPage from '@/pages/AuthPage';
import CompleteCadastroPage from '@/pages/CompleteCadastroPage';
import ForbiddenPage from '@/pages/ForbiddenPage';
import NotFoundPage from '@/pages/NotFoundPage';
import TermsPage from '@/pages/TermsPage';
import PrivacyPage from '@/pages/PrivacyPage';
import EditAssistantPage from '@/pages/EditAssistantPage';
import CreateAssistantPage from '@/pages/CreateAssistantPage';
import { AlertTriangle } from 'lucide-react';
import AssistantChatPage from '@/pages/AssistantChatPage';
import GoogleAuthCallback from '@/pages/GoogleAuthCallback';
import PublicChatPage from '@/pages/PublicChatPage';
import InboxPage from '@/pages/InboxPage';
import DadosPage from '@/pages/DadosPage';

function ConfigCheck({ children }) {
  const [isConfigured, setIsConfigured] = useState(null);
  const [configErrors, setConfigErrors] = useState([]);

  useEffect(() => {
    const { isValid, errors } = validateEnv();
    setIsConfigured(isValid);
    setConfigErrors(errors);
  }, []);

  if (isConfigured === null) return null;

  if (!isConfigured) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-neutral-900 border border-red-900/50 rounded-2xl p-8">
          <div className="flex items-center gap-3 mb-4 text-red-500">
            <AlertTriangle className="w-6 h-6" />
            <h1 className="text-xl font-bold">Configuration Error</h1>
          </div>
          <p className="text-neutral-300 mb-4">
            The application is missing required environment variables.
          </p>
          <ul className="list-disc list-inside text-red-400 text-sm space-y-1 bg-red-950/30 p-4 rounded-lg border border-red-900/30">
            {configErrors.map((err, i) => (
              <li key={i}>{err}</li>
            ))}
          </ul>
        </div>
      </div>
    );
  }

  return children;
}

function App() {
  return (
    <ErrorBoundary>
      <ConfigCheck>
        <AuthProvider>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<HomePage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/privacy" element={<PrivacyPage />} />
            <Route path="/c/:token" element={<PublicChatPage />} />
            
            <Route path="/auth" element={<AuthPage />} />
            <Route path="/auth/callback" element={<GoogleAuthCallback />} />
            <Route path="/reset-password" element={<ResetPasswordPage />} />
            <Route path="/forbidden" element={<ForbiddenPage />} />
            
            {/* Verification Routes */}
            <Route path="/verify-email" element={<VerifyEmailPage />} />
            <Route path="/verify-registration" element={<ProtectedRoute><VerifyRegistrationPage /></ProtectedRoute>} />
            <Route path="/verify-login" element={<VerifyLoginPage />} />
            <Route path="/complete-cadastro" element={<ProtectedRoute><CompleteCadastroPage /></ProtectedRoute>} />

            {/* Protected Dashboard Routes */}
            <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
            <Route path="/dashboard/atendimentos" element={<ProtectedRoute><InboxPage /></ProtectedRoute>} />
            <Route path="/dashboard/dados" element={<ProtectedRoute><DadosPage /></ProtectedRoute>} />
            
            {/* Assistants Creation and Editing */}
            <Route path="/dashboard/create-assistant" element={<ProtectedRoute><CreateAssistantPage /></ProtectedRoute>} />
            <Route path="/assistant/:id" element={<ProtectedRoute><AssistantChatPage /></ProtectedRoute>} />
            <Route path="/assistant/:id/edit" element={<ProtectedRoute><EditAssistantPage /></ProtectedRoute>} />
            
            {/* Profile */}
            <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
            
            {/* Fallback */}
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
          <Toaster />
          <ToastContainer />
        </AuthProvider>
      </ConfigCheck>
    </ErrorBoundary>
  );
}

export default App;