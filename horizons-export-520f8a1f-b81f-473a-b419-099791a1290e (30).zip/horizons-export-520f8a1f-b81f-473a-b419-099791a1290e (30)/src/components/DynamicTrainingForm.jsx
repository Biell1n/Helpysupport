import React, { useState } from 'react';
import { useDynamicTraining } from '@/hooks/useDynamicTraining';
import { BUSINESS_TYPES, BUSINESS_TYPE_LABELS } from '@/lib/businessTypeFields';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { Save, ArrowRight, AlertCircle, CheckCircle2, Loader2, FileSearch } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import FrameworkGuidance from './FrameworkGuidance';

export default function DynamicTrainingForm({ onContinue }) {
  const { 
    businessType, 
    setBusinessType, 
    fields, 
    formData, 
    fieldStatuses, 
    updateField, 
    saveProgress,
    getValidationStatus 
  } = useDynamicTraining();

  const { toast } = useToast();
  const { counts, totalFields, isReadyToContinue } = getValidationStatus();
  
  const [descriptionAnalysis, setDescriptionAnalysis] = useState(null);
  const [analyzingDescription, setAnalyzingDescription] = useState(false);
  const [showFramework, setShowFramework] = useState(false);

  const handleSave = () => {
    saveProgress();
    toast({
      title: "Progresso Salvo",
      description: "Suas informações foram salvas no navegador com sucesso.",
    });
  };

  const analyzeDescription = async () => {
    const description = formData.descricao_negocio || formData.description;
    if (!description || description.length < 30) {
      toast({
        title: 'Descrição muito curta',
        description: 'Adicione mais detalhes antes de analisar.',
        variant: 'destructive'
      });
      return;
    }

    setAnalyzingDescription(true);
    try {
      const { data, error } = await supabase.functions.invoke('analyze-description-quality', {
        body: { description, businessType }
      });

      if (error) throw error;
      
      setDescriptionAnalysis(data);
      setShowFramework(true);
      
      toast({
        title: 'Análise Concluída',
        description: `Seu framework está ${data.completionRate}% completo.`,
      });
    } catch (err) {
      console.error('Analysis error:', err);
      toast({
        title: 'Erro na Análise',
        description: 'Não foi possível analisar a descrição. Tente novamente.',
        variant: 'destructive'
      });
    } finally {
      setAnalyzingDescription(false);
    }
  };

  const handleFrameworkElementClick = (element, category) => {
    toast({
      title: element.label,
      description: `Adicione: ${element.examples[0]}`,
    });
  };

  const getCategoryTitle = (category) => {
    switch(category) {
      case 'core': return 'Informações Principais';
      case 'contact': return 'Contato e Canais';
      case 'personality': return 'Comportamento da IA';
      case 'rules': return 'Regras e Restrições';
      default: return 'Outros';
    }
  };

  const groupedFields = fields.reduce((acc, field) => {
    if (!acc[field.category]) acc[field.category] = [];
    acc[field.category].push(field);
    return acc;
  }, {});

  return (
    <div className="space-y-8">
      {/* Business Type Selector */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-white mb-4">Selecione o Perfil do seu Negócio</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {Object.values(BUSINESS_TYPES).map((type) => (
            <div 
              key={type}
              onClick={() => setBusinessType(type)}
              className={`p-4 rounded-xl cursor-pointer border transition-all duration-200 flex flex-col items-center justify-center text-center gap-2
                ${businessType === type 
                  ? 'bg-white/10 border-white/30 text-white shadow-md' 
                  : 'bg-black border-neutral-800 text-neutral-400 hover:border-neutral-600 hover:bg-neutral-950'
                }`}
            >
              <div className={`w-3 h-3 rounded-full ${businessType === type ? 'bg-white' : 'bg-neutral-700'}`} />
              <span className="font-medium text-sm">{BUSINESS_TYPE_LABELS[type]}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Dynamic Fields */}
      <div className="space-y-6">
        {Object.entries(groupedFields).map(([category, categoryFields]) => (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            key={category} 
            className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-sm"
          >
            <h3 className="text-md font-medium text-white mb-5 pb-2 border-b border-neutral-800">
              {getCategoryTitle(category)}
            </h3>
            
            <div className="space-y-6">
              {categoryFields.map((field) => {
                const statusInfo = fieldStatuses[field.name] || { status: field.required ? 'empty' : 'optional', reason: '' };
                const value = formData[field.name] || '';
                const isDescriptionField = field.name === 'descricao_negocio' || field.name === 'description';
                
                return (
                  <div key={field.name} className="flex flex-col gap-2 relative">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium text-neutral-200 flex items-center gap-2">
                        {field.label}
                        {!field.required && <span className="text-[10px] uppercase bg-neutral-800 text-neutral-400 px-2 py-0.5 rounded-full">Opcional</span>}
                      </Label>
                      
                      <div className="flex items-center gap-2">
                        {isDescriptionField && value.length > 30 && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={analyzeDescription}
                            disabled={analyzingDescription}
                            className="h-7 text-xs border-blue-500/30 text-blue-400 hover:bg-blue-950/20"
                          >
                            {analyzingDescription ? (
                              <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                            ) : (
                              <FileSearch className="w-3 h-3 mr-1" />
                            )}
                            Analisar Framework
                          </Button>
                        )}
                        
                        <div className={`status-badge status-bg-${statusInfo.status} bg-opacity-20 status-text-${statusInfo.status}`}>
                          <span className={`w-2 h-2 rounded-full status-bg-${statusInfo.status}`}></span>
                          {statusInfo.status === 'valid' ? 'Perfeito' : 
                           statusInfo.status === 'empty' ? 'Vazio' :
                           statusInfo.status === 'incomplete' ? 'Incompleto' :
                           statusInfo.status === 'invalid' ? 'Incompatível' : 'Opcional'}
                        </div>
                      </div>
                    </div>
                    
                    <Textarea 
                      value={value}
                      onChange={(e) => updateField(field.name, e.target.value)}
                      placeholder={field.placeholder}
                      className={`min-h-[100px] resize-y transition-colors border-neutral-800 bg-black focus-visible:ring-1 focus-visible:ring-white text-white
                        ${statusInfo.status === 'empty' && field.required ? 'border-red-900/50' : ''}
                        ${statusInfo.status === 'valid' ? 'border-green-900/50' : ''}
                        ${statusInfo.status === 'incomplete' ? 'border-orange-900/50' : ''}
                        ${statusInfo.status === 'invalid' ? 'border-purple-900/50' : ''}
                      `}
                    />
                    
                    <div className="flex items-start justify-between min-h-[20px]">
                      <span className="text-xs text-neutral-500">{field.helpText}</span>
                      
                      <AnimatePresence mode="wait">
                        {statusInfo.reason && statusInfo.status !== 'empty' && statusInfo.status !== 'optional' && (
                          <motion.span 
                            initial={{ opacity: 0, x: 10 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 10 }}
                            className={`text-xs flex items-center gap-1 font-medium text-right max-w-[60%] status-text-${statusInfo.status}`}
                          >
                            {statusInfo.status === 'valid' ? <CheckCircle2 className="w-3 h-3 shrink-0" /> : <AlertCircle className="w-3 h-3 shrink-0" />}
                            {statusInfo.reason}
                          </motion.span>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Framework Analysis Panel */}
                    {isDescriptionField && showFramework && descriptionAnalysis && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="mt-4"
                      >
                        <FrameworkGuidance
                          businessType={businessType}
                          analysis={descriptionAnalysis}
                          onElementClick={handleFrameworkElementClick}
                        />
                      </motion.div>
                    )}
                  </div>
                );
              })}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Footer / Actions */}
      <div className="bg-black border border-neutral-800 p-6 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4 sticky bottom-4 z-20 shadow-2xl">
        <div className="flex flex-col">
          <span className="text-sm font-medium text-white">Progresso do Treinamento</span>
          <span className="text-xs text-neutral-400">
            {counts.valid} de {totalFields} campos perfeitos. 
            {counts.incomplete > 0 && ` (${counts.incomplete} precisam de detalhes)`}
          </span>
        </div>
        
        <div className="flex w-full md:w-auto gap-3">
          <Button variant="outline" onClick={handleSave} className="flex-1 md:flex-none border-neutral-700 text-neutral-300 hover:text-white hover:bg-neutral-800">
            <Save className="w-4 h-4 mr-2" /> Salvar
          </Button>
          <Button 
            onClick={() => onContinue && onContinue(formData)} 
            disabled={!isReadyToContinue}
            className="flex-1 md:flex-none bg-white text-black hover:bg-neutral-200 font-bold transition-all disabled:opacity-50"
          >
            Continuar <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}