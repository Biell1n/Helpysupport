import React from 'react';

export default function FormFieldHint({ children }) {
  return (
    <p className="text-xs text-neutral-400 mt-1.5 font-medium">
      {children}
    </p>
  );
}