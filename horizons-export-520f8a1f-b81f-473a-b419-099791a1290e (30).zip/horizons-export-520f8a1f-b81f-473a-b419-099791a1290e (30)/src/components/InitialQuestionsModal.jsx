import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';

export default function InitialQuestionsModal({ isOpen, onSubmit, isSubmitting }) {
  const [formData, setFormData] = useState({
    businessType: '',
    description: '',
    goal: ''
  });

  const isFormValid = formData.businessType.trim() && formData.description.trim() && formData.goal.trim();

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('🖱️ [Modal] Botão "Começar Conversa" clicado');
    
    if (!isFormValid) {
      console.warn('❌ [Modal] Validação falhou. Campos ausentes.');
      return;
    }
    
    console.log('✅ [Modal] Formulário válido. Enviando dados:', formData);
    onSubmit(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-[500px] bg-neutral-900 border-white/10 text-white" hideCloseButton>
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Vamos configurar seu Assistente!</DialogTitle>
          <DialogDescription className="text-neutral-400">
            Para que nossa IA possa conduzir a entrevista corretamente, precisamos de um contexto inicial.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          <div className="space-y-2">
            <Label htmlFor="businessType" className="text-white">Qual o tipo do seu negócio?</Label>
            <Input
              id="businessType"
              placeholder="Ex: Clínica Odontológica, Loja de Roupas, Consórcio..."
              className="bg-black border-white/20 text-white placeholder:text-neutral-600 focus:border-primary focus:ring-primary"
              value={formData.businessType}
              onChange={(e) => setFormData(prev => ({ ...prev, businessType: e.target.value }))}
              disabled={isSubmitting}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-white">Uma breve descrição (nome e o que faz)</Label>
            <Textarea
              id="description"
              placeholder="Ex: Somos a Clínica Sorriso. Fazemos implantes e clareamento."
              className="bg-black border-white/20 text-white placeholder:text-neutral-600 min-h-[80px] focus:border-primary focus:ring-primary"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              disabled={isSubmitting}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="goal" className="text-white">Qual o principal objetivo deste assistente?</Label>
            <Input
              id="goal"
              placeholder="Ex: Agendar consultas e tirar dúvidas sobre convênios."
              className="bg-black border-white/20 text-white placeholder:text-neutral-600 focus:border-primary focus:ring-primary"
              value={formData.goal}
              onChange={(e) => setFormData(prev => ({ ...prev, goal: e.target.value }))}
              disabled={isSubmitting}
            />
          </div>

          <Button 
            type="submit" 
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
            disabled={!isFormValid || isSubmitting}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Iniciando Sessão...
              </>
            ) : (
              'Começar Conversa'
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}