// ============================================================
// HELPY — DashboardClient v2 — ARQUIVO COMPLETO
//
// A versão anterior consultava `assistants(title, ...)`. Essa coluna não
// existe — a tabela tem `name`. O PostgREST recusava a consulta e o
// resultado era o toast vermelho de "Erro de conexão" no login.
//
// E consultava as tabelas antigas `chats` e `support_tickets`, então
// mesmo sem o erro não mostraria nada: os atendimentos vivem em
// assistant_conversations desde a etapa 1.
// ============================================================

import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import '@/styles/builder.css';
import '@/styles/assistant.css';

const quando = (iso) => {
  if (!iso) return '';
  const d = new Date(iso);
  const min = Math.round((Date.now() - d.getTime()) / 60000);
  if (min < 1) return 'agora';
  if (min < 60) return `${min} min`;
  if (min < 1440) return `${Math.round(min / 60)} h`;
  return d.toLocaleDateString('pt-BR');
};

const ROTULO = {
  escalated: 'aguardando atendente',
  open: 'com o assistente',
  closed: 'encerrado',
};

export default function DashboardClient() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const [conversas, setConversas] = useState([]);
  const [assistentes, setAssistentes] = useState({});
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState(null);

  const carregar = useCallback(async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('assistant_conversations')
        .select('*')
        .eq('user_id', user.id)
        .order('last_message_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      const lista = data ?? [];
      setConversas(lista);

      // nomes dos assistentes, numa consulta só
      const ids = [...new Set(lista.map((c) => c.assistant_id).filter(Boolean))];
      if (ids.length) {
        const { data: asts } = await supabase
          .from('assistants')
          .select('id, name, public_token')
          .in('id', ids);
        const mapa = {};
        for (const a of asts ?? []) mapa[a.id] = a;
        setAssistentes(mapa);
      }
      setErro(null);
    } catch (e) {
      console.error('[DashboardClient]', e);
      setErro(e.message);
    } finally {
      setCarregando(false);
    }
  }, [user]);

  useEffect(() => {
    carregar();
    const t = setInterval(carregar, 30000);
    return () => clearInterval(t);
  }, [carregar]);

  const chamados = conversas.filter((c) => c.status === 'escalated');
  const ativas = conversas.filter((c) => c.status !== 'escalated');

  const Cartao = ({ c }) => {
    const a = assistentes[c.assistant_id];
    const link = a?.public_token ? `/c/${a.public_token}` : null;

    return (
      <button
        type="button"
        onClick={() => link && navigate(link)}
        disabled={!link}
        style={{
          display: 'block',
          width: '100%',
          textAlign: 'left',
          padding: '1.25rem 0',
          background: 'none',
          border: 'none',
          borderBottom: '1px solid var(--hb-rule)',
          cursor: link ? 'pointer' : 'default',
          color: 'inherit',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: '1rem' }}>
          <span className="hb-label" style={{ color: 'var(--hb-ink-2)' }}>
            {a?.name || 'Assistente'}
          </span>
          <span className="hb-flag">{quando(c.last_message_at)}</span>
        </div>

        <div style={{ fontSize: '.9375rem', color: 'var(--hb-ink)', margin: '.4rem 0 .35rem', lineHeight: 1.4 }}>
          {c.titulo || c.escalonado_motivo || 'Conversa em andamento'}
        </div>

        {c.resumo && (
          <p
            style={{
              fontSize: '.75rem',
              color: 'var(--hb-ink-3)',
              lineHeight: 1.5,
              margin: 0,
              display: '-webkit-box',
              WebkitLineClamp: 2,
              WebkitBoxOrient: 'vertical',
              overflow: 'hidden',
            }}
          >
            {c.resumo}
          </p>
        )}

        <div style={{ marginTop: '.5rem', display: 'flex', gap: '.75rem' }}>
          <span className="hb-flag">{ROTULO[c.status] ?? c.status}</span>
          <span className="hb-flag">{c.message_count} msgs</span>
        </div>
      </button>
    );
  };

  const Secao = ({ titulo, nota, itens, vazio }) => (
    <section style={{ marginBottom: '4rem' }}>
      <h2 className="hb-sec-title" style={{ marginBottom: '.25rem' }}>{titulo}</h2>
      <p className="hb-sec-note">{nota}</p>
      {carregando ? (
        <div className="hb-skel" />
      ) : itens.length === 0 ? (
        <p className="hb-none">{vazio}</p>
      ) : (
        <div>{itens.map((c) => <Cartao key={c.id} c={c} />)}</div>
      )}
    </section>
  );

  return (
    <div className="hb" style={{ minHeight: '100vh', background: 'var(--hb-page)' }}>
      <div style={{ maxWidth: '46rem', margin: '0 auto', padding: '5rem 2rem 8rem' }}>
        <div className="hb-doc-eyebrow">Seus atendimentos</div>
        <h1 className="hb-doc-title" style={{ fontSize: '2.5rem', margin: '.75rem 0 3rem' }}>
          Olá, {user?.user_metadata?.full_name?.split(' ')[0] || 'tudo bem'}.
        </h1>

        {erro && (
          <div
            role="alert"
            style={{
              border: '1px solid var(--hb-rule-lit)',
              padding: '.875rem 1rem',
              marginBottom: '2.5rem',
              fontSize: '.8125rem',
              color: 'var(--hb-ink-2)',
            }}
          >
            {erro}
          </div>
        )}

        <Secao
          titulo="Aguardando atendente"
          nota="Chamados que já foram encaminhados para uma pessoa."
          itens={chamados}
          vazio="Nenhum chamado aberto."
        />

        <Secao
          titulo="Conversas"
          nota="Atendimentos com assistentes, ativos ou encerrados."
          itens={ativas}
          vazio="Você ainda não conversou com nenhum assistente."
        />
      </div>
    </div>
  );
}