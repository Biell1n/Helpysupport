import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { Link } from 'react-router-dom';

export default function ClientCompletionForm() {
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const navigate = useNavigate();
  const { toast } = useToast();
  const { updateProfile } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!termsAccepted) {
      toast({ title: 'Termos obrigatórios', description: 'Você precisa aceitar os Termos de Uso.', variant: 'destructive' });
      return;
    }
    if (!fullName.trim()) {
      toast({ title: 'Nome obrigatório', description: 'Por favor, informe seu nome completo.', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      await updateProfile({
        full_name: fullName,
        phone: phone || null,
        user_type: 'end_customer'
      });
      
      toast({ title: 'Conta configurada!', description: 'Bem-vindo!' });
      navigate('/dashboard');
    } catch (error) {
      console.error(error);
      toast({ title: 'Erro', description: 'Ocorreu um erro ao configurar sua conta.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5 w-full mt-6">
      <div className="space-y-2">
        <Label htmlFor="full_name" className="text-neutral-300">Nome Completo *</Label>
        <Input id="full_name" value={fullName} onChange={(e) => setFullName(e.target.value)} required className="bg-neutral-900 border-none outline-none text-white h-14 rounded-xl px-4" placeholder="Seu nome completo" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="phone" className="text-neutral-300">Telefone (opcional)</Label>
        <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} className="bg-neutral-900 border-none outline-none text-white h-14 rounded-xl px-4" placeholder="(00) 00000-0000" />
      </div>
      <div className="flex items-start space-x-3 py-3">
        <Checkbox id="client-terms" checked={termsAccepted} onCheckedChange={setTermsAccepted} className="mt-1 data-[state=checked]:bg-white data-[state=checked]:border-none data-[state=checked]:text-black border-neutral-600 outline-none focus:ring-0" />
        <Label htmlFor="client-terms" className="text-sm text-neutral-400 leading-tight font-normal cursor-pointer select-none">
          Aceito os <Link to="/terms" target="_blank" className="text-white hover:underline">Termos de Uso</Link> e a <Link to="/privacy" target="_blank" className="text-white hover:underline">Política de Privacidade</Link>. *
        </Label>
      </div>
      <Button type="submit" disabled={loading} className="w-full bg-white hover:bg-neutral-200 text-black font-bold py-6 text-lg rounded-xl shadow-lg border-none">
        {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Concluir Cadastro"}
      </Button>
    </form>
  );
}