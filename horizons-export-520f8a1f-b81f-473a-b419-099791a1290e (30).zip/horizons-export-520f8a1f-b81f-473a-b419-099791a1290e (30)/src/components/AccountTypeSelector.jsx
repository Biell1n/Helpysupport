import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, User, Building2, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

export default function AccountTypeSelector({ isOpen, onClose, onSelect }) {
  const [selectedType, setSelectedType] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!isOpen) {
      setSelectedType(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleProceed = () => {
    if (selectedType) {
      onClose(); // Close the modal immediately
      onSelect(selectedType); // Proceed with the selected type
    }
  };

  const handleBack = () => {
    setSelectedType(null);
    if (onClose) onClose();
    navigate('/auth');
  };

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
        style={{ fontFamily: "'Montserrat', sans-serif" }}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="bg-black w-full max-w-md relative p-8 shadow-2xl shadow-white/5 border-none outline-none ring-0"
        >
          <button 
            onClick={handleBack} 
            className="absolute top-6 left-6 text-neutral-400 hover:text-white transition-colors bg-transparent border-none outline-none ring-0 focus:ring-0 flex items-center gap-2 text-sm font-medium"
          >
            <ArrowLeft className="w-5 h-5" /> Voltar
          </button>
          
          <div className="text-center mb-8 pt-8">
            <h2 className="text-2xl font-bold text-white mb-3">Tipo de Conta</h2>
            <p className="text-neutral-400 text-sm">Como você deseja usar a plataforma?</p>
          </div>
          
          <div className="space-y-4">
            <button
              onClick={() => setSelectedType('end_customer')}
              className={`w-full flex items-center justify-between p-6 transition-all outline-none border-none ring-0 focus:ring-0 group ${
                selectedType === 'end_customer' 
                  ? 'bg-white text-black' 
                  : 'bg-neutral-900 text-white hover:bg-neutral-800'
              }`}
            >
              <div className="flex items-center gap-5">
                <User className="w-8 h-8 flex-shrink-0" />
                <div className="text-left">
                  <h3 className="font-bold text-lg leading-tight mb-1">Sou Cliente</h3>
                  <p className={`text-sm font-medium ${selectedType === 'end_customer' ? 'text-neutral-700' : 'text-neutral-400'}`}>
                    Buscando suporte ou atendimento
                  </p>
                </div>
              </div>
              {selectedType === 'end_customer' && (
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                  <CheckCircle2 className="w-6 h-6 text-black" />
                </motion.div>
              )}
            </button>
            
            <button
              onClick={() => setSelectedType('business_owner')}
              className={`w-full flex items-center justify-between p-6 transition-all outline-none border-none ring-0 focus:ring-0 group ${
                selectedType === 'business_owner' 
                  ? 'bg-white text-black' 
                  : 'bg-neutral-900 text-white hover:bg-neutral-800'
              }`}
            >
              <div className="flex items-center gap-5">
                <Building2 className="w-8 h-8 flex-shrink-0" />
                <div className="text-left">
                  <h3 className="font-bold text-lg leading-tight mb-1">Sou Empresa</h3>
                  <p className={`text-sm font-medium ${selectedType === 'business_owner' ? 'text-neutral-700' : 'text-neutral-400'}`}>
                    Quero criar assistentes IA
                  </p>
                </div>
              </div>
              {selectedType === 'business_owner' && (
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                  <CheckCircle2 className="w-6 h-6 text-black" />
                </motion.div>
              )}
            </button>
          </div>

          <AnimatePresence>
            {selectedType && (
              <motion.div
                initial={{ opacity: 0, height: 0, marginTop: 0 }}
                animate={{ opacity: 1, height: 'auto', marginTop: 24 }}
                exit={{ opacity: 0, height: 0, marginTop: 0 }}
                className="overflow-hidden"
              >
                <Button
                  onClick={handleProceed}
                  className="w-full py-6 text-lg font-bold bg-white text-black hover:bg-neutral-200 border-none outline-none ring-0 focus:ring-0 rounded-none shadow-lg"
                >
                  Prosseguir
                </Button>
              </motion.div>
            )}
          </AnimatePresence>

        </motion.div>
      </div>
    </AnimatePresence>
  );
}