import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Clock } from 'lucide-react';
import TicketChat from '@/components/TicketChat';
import { supabase } from '@/lib/supabase';
import { handleAuthError } from '@/lib/authUtils';
import { useToast } from '@/components/ui/use-toast';

export default function KanbanBoard({ tickets, onUpdate }) {
  const [selectedTicket, setSelectedTicket] = useState(null);
  const { toast } = useToast();

  const columns = [
    { id: 'analyzing', title: 'Em Análise', color: 'orange' },
    { id: 'responded', title: 'Respondido', color: 'white' },
    { id: 'resolved', title: 'Resolvido', color: 'green' }
  ];

  const getTicketsByStatus = (status) => {
    return tickets.filter(t => t.status === status);
  };

  const handleDragStart = (e, ticket) => {
    e.dataTransfer.setData('ticketId', ticket.id);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = async (e, newStatus) => {
    e.preventDefault();
    const ticketId = e.dataTransfer.getData('ticketId');
    const ticket = tickets.find(t => t.id === ticketId);

    if (ticket && ticket.status !== newStatus) {
      try {
        const { error } = await supabase.from('support_tickets').update({ status: newStatus }).eq('id', ticketId);
        if (error) throw error;
        
        toast({
          title: 'Status atualizado',
          description: `Ticket movido para ${columns.find(c => c.id === newStatus).title}`
        });
        if (onUpdate) onUpdate();
      } catch (error) {
        if (await handleAuthError(error)) return;
        toast({
          title: 'Erro ao atualizar status',
          description: error.message,
          variant: 'destructive'
        });
      }
    }
  };

  const colorClasses = {
    orange: {
      bg: 'bg-amber-500/10',
      text: 'text-amber-500'
    },
    white: {
      bg: 'bg-white/10',
      text: 'text-white'
    },
    green: {
      bg: 'bg-emerald-500/10',
      text: 'text-emerald-400'
    }
  };

  if (tickets.length === 0) {
    return (
      <div className="bg-neutral-900/50 backdrop-blur-sm rounded-2xl p-12 text-center shadow-lg">
        <div className="bg-neutral-800 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-md">
          <MessageSquare className="w-8 h-8 text-neutral-500" />
        </div>
        <h3 className="text-xl font-semibold text-white mb-2">
          Nenhum ticket ainda
        </h3>
        <p className="text-neutral-400">
          Os tickets de suporte aparecerão aqui
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="grid md:grid-cols-3 gap-6">
        {columns.map((column) => {
          const columnTickets = getTicketsByStatus(column.id);
          const colors = colorClasses[column.color];

          return (
            <div key={column.id}>
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white">{column.title}</h3>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${colors.bg} ${colors.text}`}>
                  {columnTickets.length}
                </span>
              </div>

              <div
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, column.id)}
                className="space-y-3 min-h-[400px] bg-neutral-900/30 rounded-xl p-4 shadow-inner"
              >
                {columnTickets.map((ticket, index) => (
                  <motion.div
                    key={ticket.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    draggable
                    onDragStart={(e) => handleDragStart(e, ticket)}
                    onClick={() => setSelectedTicket(ticket)}
                    className="bg-neutral-900 rounded-xl p-4 cursor-move transition-all duration-300 group hover:bg-neutral-800 shadow-md hover:shadow-xl hover:shadow-white/5"
                  >
                    <h4 className="font-semibold text-white mb-2 line-clamp-1 group-hover:text-white transition-colors">
                      {ticket.title}
                    </h4>
                    <p className="text-sm text-neutral-400 mb-3 line-clamp-2">
                      {ticket.description}
                    </p>
                    
                    <div className="flex items-center gap-2 text-xs text-neutral-500 pt-3">
                      <Clock className="w-3 h-3" />
                      {new Date(ticket.created_at).toLocaleDateString('pt-BR')}
                    </div>
                  </motion.div>
                ))}

                {columnTickets.length === 0 && (
                  <div className="text-center py-12">
                    <p className="text-neutral-600 text-sm">
                      Arraste tickets para cá
                    </p>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {selectedTicket && (
        <TicketChat
          ticket={selectedTicket}
          onClose={() => setSelectedTicket(null)}
          onUpdate={onUpdate}
        />
      )}
    </>
  );
}