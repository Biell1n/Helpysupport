import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, RotateCcw, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ExistingSessionModal({ isOpen, onResume, onStartFresh, isLoading }) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          />
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="w-full max-w-md bg-neutral-900 border border-white/10 rounded-2xl shadow-xl overflow-hidden"
            >
              <div className="p-6 text-center">
                <div className="w-16 h-16 bg-primary/10 border border-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <RotateCcw className="w-8 h-8 text-primary" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Você já possui uma sessão de criação</h2>
                <p className="text-neutral-400 mb-8">
                  Deseja voltar para a sessão anterior ou começar do zero?
                </p>

                <div className="space-y-3">
                  <Button
                    onClick={onResume}
                    disabled={isLoading}
                    className="w-full h-12 bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl font-medium"
                  >
                    {isLoading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                    Voltar para sessão anterior
                  </Button>
                  
                  <Button
                    onClick={onStartFresh}
                    disabled={isLoading}
                    variant="outline"
                    className="w-full h-12 bg-transparent border border-white/10 text-white hover:bg-white/5 rounded-xl font-medium"
                  >
                    {isLoading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <RotateCcw className="w-4 h-4 mr-2" />}
                    Começar do zero
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}