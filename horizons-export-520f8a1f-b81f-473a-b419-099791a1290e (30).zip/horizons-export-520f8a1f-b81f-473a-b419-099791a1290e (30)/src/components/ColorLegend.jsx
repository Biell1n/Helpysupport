import React from 'react';
import { Info, CheckCircle2, AlertTriangle, XCircle, HelpCircle } from 'lucide-react';

export default function ColorLegend() {
  const legends = [
    { status: 'red', colorClass: 'bg-red-500', textClass: 'text-red-400', label: 'Sem Informação', desc: '(Campo vazio)', icon: <XCircle className="w-3 h-3 text-white" /> },
    { status: 'orange', colorClass: 'bg-orange-500', textClass: 'text-orange-400', label: 'Incompleto / Vago', desc: '(Falta detalhes)', icon: <AlertTriangle className="w-3 h-3 text-white" /> },
    { status: 'green', colorClass: 'bg-green-500', textClass: 'text-green-400', label: 'Completo', desc: '(Conteúdo adequado)', icon: <CheckCircle2 className="w-3 h-3 text-white" /> },
    { status: 'purple', colorClass: 'bg-purple-500', textClass: 'text-purple-400', label: 'Inválido', desc: '(Não condiz)', icon: <XCircle className="w-3 h-3 text-white" /> },
    { status: 'gray', colorClass: 'bg-neutral-500', textClass: 'text-neutral-400', label: 'Opcional', desc: '(Regras)', icon: <HelpCircle className="w-3 h-3 text-white" /> },
  ];

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-4 shadow-sm mb-6 sticky top-20 z-20 backdrop-blur-md bg-opacity-95">
      <div className="flex items-center gap-2 mb-3">
        <Info className="w-4 h-4 text-blue-400" />
        <h3 className="text-sm font-bold text-white">Qualidade do Treinamento</h3>
      </div>
      <div className="flex flex-wrap gap-x-6 gap-y-3">
        {legends.map((item) => (
          <div key={item.status} className="flex items-center gap-2 group cursor-default">
            <div className={`w-6 h-6 rounded-lg flex items-center justify-center shadow-sm ${item.colorClass}`}>
               {item.icon}
            </div>
            <div className="flex flex-col leading-tight">
              <span className={`text-xs font-bold ${item.textClass}`}>{item.label}</span>
              <span className="text-[10px] text-neutral-500">{item.desc}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}