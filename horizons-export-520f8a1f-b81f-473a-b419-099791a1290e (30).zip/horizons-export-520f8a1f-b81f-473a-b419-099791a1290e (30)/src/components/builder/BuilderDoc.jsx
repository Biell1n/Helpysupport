// ============================================================
// HELPY BUILDER v4 — ARQUIVO COMPLETO
// Usa apenas as classes hb-* que já existem em builder.css.
// ============================================================

import React, { useState } from 'react';
import { useBuilder } from '@/contexts/BuilderContext';

const pad = (n) => String(n).padStart(2, '0');

const IconX = () => (
  <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4">
    <path d="M4 4l8 8M12 4l-8 8" strokeLinecap="square" />
  </svg>
);

const IconUndo = () => (
  <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4">
    <path d="M3 8a5 5 0 105-5" strokeLinecap="square" />
    <path d="M3 4v4h4" strokeLinecap="square" />
  </svg>
);

function Control({ def, value, onChange, id }) {
  if (def.type === 'select' && def.options?.length) {
    return (
      <select id={id} className="hb-select" value={value || ''} onChange={(e) => onChange(e.target.value)}>
        <option value="">—</option>
        {def.options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
    );
  }
  if (def.type === 'textarea') {
    return (
      <textarea
        id={id}
        className="hb-textarea"
        value={value || ''}
        placeholder={def.hint || ''}
        onChange={(e) => onChange(e.target.value)}
      />
    );
  }
  return (
    <input
      id={id}
      className="hb-input"
      value={value || ''}
      placeholder={def.hint || ''}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}

function Field({ def, entry, fresh, missing, onChange, onSkip, onRestore }) {
  const skipped = entry?.status === 'ignorado';
  return (
    <div className="hb-field" data-fresh={fresh ? 'true' : 'false'}>
      <div className="hb-field-top">
        <label className="hb-label" htmlFor={`f-${def.key}`}>
          {def.label}
          {def.importance === 'critical' && <span className="hb-req">*</span>}
        </label>
        {missing && !skipped && <span className="hb-flag">falta</span>}
        {skipped && <span className="hb-flag">dispensado</span>}
      </div>

      <div className="hb-input-row">
        {skipped ? (
          <div className="hb-skipped">Você preferiu não informar. Dá para adicionar depois.</div>
        ) : (
          <Control def={def} id={`f-${def.key}`} value={entry?.value} onChange={onChange} />
        )}
        <button
          type="button"
          className="hb-icon-btn"
          onClick={skipped ? onRestore : onSkip}
          title={skipped ? 'Voltar a preencher' : 'Não quero informar'}
          aria-label={skipped ? 'Voltar a preencher' : 'Dispensar campo'}
        >
          {skipped ? <IconUndo /> : <IconX />}
        </button>
      </div>
    </div>
  );
}

function Collection({
  def,
  items,
  declined,
  declinedFields,
  incompleteBy,
  fresh,
  missing,
  onAdd,
  onSet,
  onRemove,
  onSkipAll,
  onRestoreAll,
  onSkipField,
  onRestoreField,
}) {
  // atributos que o usuário dispensou informar para esta coleção inteira
  const visibleFields = (def.item_fields || []).filter((f) => !declinedFields.includes(f.key));

  return (
    <div className="hb-field" data-fresh={fresh ? 'true' : 'false'}>
      <div className="hb-field-top">
        <span className="hb-label">
          {def.label}
          {def.importance === 'critical' && <span className="hb-req">*</span>}
        </span>

        {/* Mesmo lugar e mesmo ícone dos campos simples. Antes a única
            forma de dispensar uma lista era um botão lá embaixo, e
            ninguém procurava ali. */}
        <span style={{ display: 'flex', alignItems: 'center', gap: '.5rem' }}>
          {declined ? (
            <span className="hb-flag">dispensado</span>
          ) : (
            missing && <span className="hb-flag">falta</span>
          )}
          <button
            type="button"
            className="hb-icon-btn"
            onClick={declined ? onRestoreAll : onSkipAll}
            title={declined ? 'Voltar a listar' : 'Não quero listar isto'}
            aria-label={declined ? `Voltar a listar ${def.label}` : `Dispensar ${def.label}`}
          >
            {declined ? <IconUndo /> : <IconX />}
          </button>
        </span>
      </div>

      {declined ? (
        <div className="hb-input-row">
          <div className="hb-skipped">Você preferiu não listar isto. Dá para adicionar depois.</div>
          <button
            type="button"
            className="hb-icon-btn"
            onClick={onRestoreAll}
            title="Voltar a listar"
            aria-label="Voltar a listar"
          >
            <IconUndo />
          </button>
        </div>
      ) : (
        <>
          {items.length === 0 ? (
            <p className="hb-none">Nada listado ainda.</p>
          ) : (
            <div className="hb-items">
              {items.map((item, idx) => {
                const faltando = incompleteBy[`${def.key}:${idx}`] || [];
                return (
                  <div className="hb-item" key={idx}>
                    <div className="hb-field-top">
                      <span className="hb-item-no">{pad(idx + 1)}</span>
                      {faltando.length > 0 && (
                        <span className="hb-flag">
                          falta {faltando.map((f) => f.label.toLowerCase()).join(', ')}
                        </span>
                      )}
                    </div>

                    <div className="hb-item-kill">
                      <button
                        type="button"
                        className="hb-icon-btn"
                        onClick={() => onRemove(idx)}
                        title="Remover"
                        aria-label={`Remover item ${idx + 1}`}
                      >
                        <IconX />
                      </button>
                    </div>

                    <div className="hb-item-fields">
                      {visibleFields.map((f) => (
                        <div className="hb-field" key={f.key}>
                          <div className="hb-field-top">
                            <label className="hb-label" htmlFor={`i-${def.key}-${idx}-${f.key}`}>
                              {f.label}
                              {f.required && <span className="hb-req">*</span>}
                            </label>
                          </div>
                          <div className="hb-input-row">
                            <Control
                              def={f}
                              id={`i-${def.key}-${idx}-${f.key}`}
                              value={item[f.key]}
                              onChange={(v) => onSet(idx, f.key, v)}
                            />
                            <button
                              type="button"
                              className="hb-icon-btn"
                              onClick={() => onSkipField(f.key)}
                              title={`Não quero informar ${f.label.toLowerCase()} em nenhum item`}
                              aria-label={`Dispensar ${f.label}`}
                            >
                              <IconX />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {declinedFields.length > 0 && (
            <div style={{ marginTop: '1.5rem' }}>
              {declinedFields.map((fk) => {
                const label = (def.item_fields || []).find((f) => f.key === fk)?.label || fk;
                return (
                  <div className="hb-input-row" key={fk} style={{ marginTop: '.5rem' }}>
                    <div className="hb-skipped">{label} — dispensado nesta lista</div>
                    <button
                      type="button"
                      className="hb-icon-btn"
                      onClick={() => onRestoreField(fk)}
                      title={`Voltar a pedir ${label.toLowerCase()}`}
                      aria-label={`Voltar a pedir ${label}`}
                    >
                      <IconUndo />
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          <button type="button" className="hb-add" onClick={onAdd}>
            <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6">
              <path d="M8 3v10M3 8h10" strokeLinecap="square" />
            </svg>
            Adicionar
          </button>

          {/* Continua aqui embaixo também: quem está preenchendo a lista
              e desiste no meio encontra o botão perto de onde está. */}
          <button type="button" className="hb-add" onClick={onSkipAll} style={{ borderTop: 'none' }}>
            <IconX />
            Não quero listar isto
          </button>
        </>
      )}
    </div>
  );
}

/**
 * Criar um campo que não existe.
 * Nem tudo que um negócio precisa cabe no que o modelo previu, e não dá
 * para esperar a IA adivinhar. Aqui a pessoa escreve o que falta.
 */
function NovoCampo({ secao, onCriar }) {
  const [aberto, setAberto] = useState(false);
  const [rotulo, setRotulo] = useState('');
  const [tipo, setTipo] = useState('text');
  const [erro, setErro] = useState(null);
  const [salvando, setSalvando] = useState(false);

  const criar = async () => {
    const nome = rotulo.trim();
    if (!nome) return;
    setSalvando(true);
    setErro(null);
    try {
      await onCriar({ section: secao, label: nome, type: tipo });
      setRotulo('');
      setAberto(false);
    } catch (e) {
      setErro(e.message);
    } finally {
      setSalvando(false);
    }
  };

  if (!aberto) {
    return (
      <button type="button" className="hb-add" onClick={() => setAberto(true)}>
        <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M8 3v10M3 8h10" strokeLinecap="square" />
        </svg>
        Adicionar campo
      </button>
    );
  }

  return (
    <div style={{ borderTop: '1px solid var(--hb-rule)', paddingTop: '1.25rem', marginTop: '1.5rem' }}>
      <div className="hb-field-top">
        <span className="hb-label">Nome do campo novo</span>
      </div>
      <div className="hb-input-row">
        <input
          className="hb-input"
          autoFocus
          value={rotulo}
          placeholder="Ex: Convênios aceitos"
          onChange={(e) => setRotulo(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') criar();
            if (e.key === 'Escape') setAberto(false);
          }}
        />
        <select className="hb-select" value={tipo} onChange={(e) => setTipo(e.target.value)} style={{ maxWidth: '8rem' }}>
          <option value="text">Curto</option>
          <option value="textarea">Longo</option>
        </select>
      </div>

      {erro && (
        <p style={{ fontSize: '.6875rem', color: 'var(--hb-ink)', marginTop: '.5rem' }}>{erro}</p>
      )}

      <div style={{ display: 'flex', gap: '.5rem', marginTop: '1rem' }}>
        <button type="button" className="hb-btn hb-btn--solid" onClick={criar} disabled={!rotulo.trim() || salvando}>
          {salvando ? 'Criando' : 'Criar'}
        </button>
        <button type="button" className="hb-btn" onClick={() => setAberto(false)}>
          Cancelar
        </button>
      </div>
    </div>
  );
}

export default function BuilderDoc() {
  const {
    schema,
    config,
    progress,
    missing,
    incompleteBy,
    exhausted,
    freshKeys,
    loading,
    setField,
    skipField,
    addItem,
    setItemField,
    removeItem,
    skipCollection,
    skipItemField,
    adicionarCampo,
    restoreCollection,
    restoreItemField,
  } = useBuilder();

  const sections = schema.sections || [];
  const isFresh = (k) => freshKeys.includes(k);
  const inMissing = (k) =>
    missing.critical?.includes(k) || missing.important?.includes(k) || missing.optional?.includes(k);

  const openCritical = missing.critical?.length || 0;
  const openTotal =
    openCritical +
    (missing.important?.length || 0) +
    (missing.optional?.length || 0) +
    Object.keys(incompleteBy).length;

  const sectionDone = (sec) => {
    const fieldsOk = (sec.fields || []).every((f) => {
      const e = config.fields?.[f.key];
      return e && (e.status === 'ignorado' || String(e.value || '').trim());
    });
    const colsOk = (sec.collections || []).every((c) => {
      if (config.declined?.collections?.includes(c.key)) return true;
      const list = config.collections?.[c.key] || [];
      if (list.length < (c.min ?? 1)) return false;
      return list.every((_, idx) => !incompleteBy[`${c.key}:${idx}`]);
    });
    return fieldsOk && colsOk;
  };

  let statusLine;
  if (loading) statusLine = 'Carregando o briefing.';
  else if (exhausted) statusLine = 'Não sobrou nada a perguntar.';
  else if (openCritical > 0)
    statusLine = `${openCritical} ${openCritical === 1 ? 'item obrigatório' : 'itens obrigatórios'} em aberto, ${openTotal} no total.`;
  else statusLine = `Obrigatórios completos. ${openTotal} ${openTotal === 1 ? 'detalhe' : 'detalhes'} deixariam o assistente mais rico.`;

  return (
    <>
      <header className="hb-doc-head">
        <div className="hb-doc-eyebrow">Briefing</div>
        <h1 className="hb-doc-title">
          As instruções que
          <br />o seu assistente <em>vai seguir.</em>
        </h1>
        <div className="hb-meter">
          <span className="hb-meter-num">{progress}%</span>
          <span className="hb-meter-txt">{statusLine}</span>
        </div>
      </header>

      {loading && (
        <div className="hb-sec">
          <div className="hb-skel" />
          <div className="hb-skel" />
          <div className="hb-skel" />
        </div>
      )}

      {!loading &&
        sections.map((sec, i) => (
          <section className="hb-sec" key={sec.key} data-done={sectionDone(sec) ? 'true' : 'false'}>
            <div className="hb-sec-mark" aria-hidden="true">
              <span className="hb-sec-no">{pad(i + 1)}</span>
              <span className="hb-sec-rule" />
            </div>

            <h2 className="hb-sec-title">{sec.label}</h2>
            {sec.note && <p className="hb-sec-note">{sec.note}</p>}

            <div className="hb-sec-fields">
              {(sec.fields || []).map((def) => (
                <Field
                  key={def.key}
                  def={def}
                  entry={config.fields?.[def.key]}
                  fresh={isFresh(def.key)}
                  missing={inMissing(def.key)}
                  onChange={(v) => setField(def.key, v)}
                  onSkip={() => skipField(def.key)}
                  onRestore={() => setField(def.key, '')}
                />
              ))}

              {(sec.collections || []).map((def) => (
                <Collection
                  key={def.key}
                  def={def}
                  items={config.collections?.[def.key] || []}
                  declined={config.declined?.collections?.includes(def.key)}
                  declinedFields={config.declined?.item_fields?.[def.key] || []}
                  incompleteBy={incompleteBy}
                  fresh={isFresh(def.key)}
                  missing={inMissing(def.key)}
                  onAdd={() => addItem(def.key)}
                  onSet={(idx, k, v) => setItemField(def.key, idx, k, v)}
                  onRemove={(idx) => removeItem(def.key, idx)}
                  onSkipAll={() => skipCollection(def.key)}
                  onRestoreAll={() => restoreCollection(def.key)}
                  onSkipField={(f) => skipItemField(def.key, f)}
                  onRestoreField={(f) => restoreItemField(def.key, f)}
                />
              ))}

              {!sec.dynamic && typeof adicionarCampo === 'function' && (
                <NovoCampo secao={sec.key} onCriar={adicionarCampo} />
              )}
            </div>
          </section>
        ))}

      {!loading && sections.length > 0 && sections.every((s) => !s.dynamic) && (
        <section className="hb-sec" data-done="false">
          <div className="hb-sec-mark" aria-hidden="true">
            <span className="hb-sec-no">{pad(sections.length + 1)}</span>
            <span className="hb-sec-rule" />
          </div>
          <h2 className="hb-sec-title">Catálogo</h2>
          <p className="hb-sec-note">
            Esta seção ainda não existe. Assim que você contar de que ramo é o negócio, o Helpy monta
            aqui os campos específicos dele — uma loja de lubrificantes recebe viscosidade e
            aplicação; uma revenda de consórcio recebe carta de crédito e parcela.
          </p>
        </section>
      )}
    </>
  );
}