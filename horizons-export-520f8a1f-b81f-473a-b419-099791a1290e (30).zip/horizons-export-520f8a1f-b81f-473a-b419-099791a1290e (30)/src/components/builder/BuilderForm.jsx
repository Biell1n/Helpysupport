import React from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, Trash2, X, RotateCcw, MessageSquare } from 'lucide-react';
import { useBuilder } from '@/contexts/BuilderContext';

/**
 * Não existe campo hardcoded aqui. Tudo vem do field_schema que a IA
 * gerou pro nicho: loja de lubrificante recebe viscosidade, consórcio
 * recebe valor da carta. Este componente só desenha o que chegou.
 */

function FieldInput({ def, value, onChange }) {
  const common = {
    value: value ?? '',
    onChange: (e) => onChange(e.target.value),
    placeholder: def.hint || def.label,
    className: 'bg-neutral-950 border-neutral-700 text-white placeholder-neutral-600',
  };

  if (def.type === 'select' && def.options?.length) {
    return (
      <Select value={value ?? ''} onValueChange={onChange}>
        <SelectTrigger className="w-full bg-neutral-950 border-neutral-700 text-white">
          <SelectValue placeholder="Selecione..." />
        </SelectTrigger>
        <SelectContent>
          {def.options.map((opt) => (
            <SelectItem key={opt} value={opt}>
              {opt}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    );
  }

  if (def.type === 'textarea') {
    return <Textarea {...common} className={`${common.className} min-h-[90px]`} />;
  }

  return <Input {...common} />;
}

export default function BuilderForm() {
  const {
    schema,
    config,
    recentKeys,
    missing,
    setField,
    skipField,
    addItem,
    setItemField,
    removeItem,
  } = useBuilder();

  const hasSchema = schema.fields?.length || schema.collections?.length;

  if (!hasSchema) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-center px-8 bg-neutral-900/40 border border-dashed border-neutral-800 rounded-3xl">
        <MessageSquare className="w-10 h-10 text-neutral-700 mb-4" />
        <h3 className="text-white font-semibold mb-2">Nada por aqui ainda</h3>
        <p className="text-sm text-neutral-500 max-w-xs">
          Conte no chat o que o seu negócio faz. Os campos aparecem aqui
          conforme o Helpy entende o seu ramo.
        </p>
      </div>
    );
  }

  const isRecent = (key) => recentKeys.includes(key);
  const isMissing = (key) => missing.critical?.includes(key);

  return (
    <div className="space-y-5">
      {/* ---- campos simples ---- */}
      {schema.fields?.length > 0 && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 space-y-4">
          <h3 className="text-lg font-bold text-white">Sobre o negócio</h3>

          {schema.fields.map((def) => {
            const entry = config.fields?.[def.key];
            const ignored = entry?.status === 'ignorado';

            return (
              <div
                key={def.key}
                className={`rounded-lg transition-all duration-500 ${isRecent(def.key) ? 'ring-2 ring-blue-500/70 bg-blue-500/5 p-2 -m-2' : ''
                  }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs text-neutral-400">
                    {def.label}
                    {def.importance === 'critical' && (
                      <span className="text-red-400 ml-1">*</span>
                    )}
                  </label>
                  {isMissing(def.key) && (
                    <span className="text-[10px] uppercase tracking-wide text-amber-500">
                      falta
                    </span>
                  )}
                </div>

                <div className="flex gap-2 items-start">
                  <div className="flex-1">
                    {ignored ? (
                      <div className="h-10 px-3 flex items-center border border-neutral-800 bg-neutral-950/50 text-neutral-500 rounded-md text-sm">
                        Não se aplica
                      </div>
                    ) : (
                      <FieldInput
                        def={def}
                        value={entry?.value}
                        onChange={(v) => setField(def.key, v)}
                      />
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-neutral-500 hover:text-white shrink-0"
                    onClick={() =>
                      ignored ? setField(def.key, '') : skipField(def.key)
                    }
                    title={ignored ? 'Voltar a preencher' : 'Não se aplica ao meu negócio'}
                  >
                    {ignored ? <RotateCcw className="w-4 h-4" /> : <X className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ---- coleções (produtos, contatos, planos...) ---- */}
      {schema.collections?.map((col) => {
        const items = config.collections?.[col.key] ?? [];

        return (
          <div
            key={col.key}
            className={`bg-neutral-900 border rounded-xl p-5 space-y-4 transition-all duration-500 ${isRecent(col.key)
                ? 'border-blue-500/70 ring-2 ring-blue-500/30'
                : 'border-neutral-800'
              }`}
          >
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-white">
                {col.label}
                {col.importance === 'critical' && (
                  <span className="text-red-400 ml-1">*</span>
                )}
              </h3>
              <span className="text-xs text-neutral-500">{items.length}</span>
            </div>

            {items.length === 0 && (
              <p className="text-sm text-neutral-600">
                Nenhum item ainda. Fale no chat ou adicione aqui.
              </p>
            )}

            {items.map((item, idx) => (
              <div
                key={idx}
                className="bg-neutral-950 p-4 rounded-lg border border-neutral-800 relative space-y-3"
              >
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 text-neutral-600 hover:text-red-400"
                  onClick={() => removeItem(col.key, idx)}
                  title="Remover"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>

                {col.item_fields?.map((def) => (
                  <div key={def.key}>
                    <label className="text-xs text-neutral-400 mb-1 block">
                      {def.label}
                    </label>
                    <FieldInput
                      def={def}
                      value={item[def.key]}
                      onChange={(v) => setItemField(col.key, idx, def.key, v)}
                    />
                  </div>
                ))}
              </div>
            ))}

            <Button
              variant="outline"
              className="w-full border-neutral-700 text-neutral-300 hover:bg-neutral-800 hover:text-white"
              onClick={() => addItem(col.key)}
            >
              <Plus className="w-4 h-4 mr-2" />
              Adicionar
            </Button>
          </div>
        );
      })}
    </div>
  );
}