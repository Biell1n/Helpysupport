// ============================================================
// HELPY BUILDER v3 — ARQUIVO COMPLETO
// ============================================================

import React, { useState, useRef, useEffect } from 'react';
import { useBuilder } from '@/contexts/BuilderContext';

export default function BuilderChat() {
  const { messages, sending, loading, sendMessage, generateIdeas, businessType } =
    useBuilder();

  const [input, setInput] = useState('');
  const scrollRef = useRef(null);
  const areaRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, sending]);

  // textarea que cresce sozinho
  useEffect(() => {
    const el = areaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 112)}px`;
  }, [input]);

  const blocked = loading || sending;

  const submit = () => {
    const text = input.trim();
    if (!text || blocked) return;
    setInput('');
    sendMessage(text);
  };

  const onKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  return (
    <div className="hb-chat">
      <div className="hb-chat-head">
        <div className="hb-chat-title">Conversa</div>
        <div className="hb-chat-sub">
          {businessType || 'Vamos entender seu negócio'}
        </div>
      </div>

      <div className="hb-chat-scroll" ref={scrollRef}>
        {loading && (
          <div className="hb-empty">
            <div className="hb-skel" />
            <div className="hb-skel" />
          </div>
        )}

        {!loading && messages.length === 0 && (
          <div className="hb-empty">
            <div className="hb-empty-h">
              Conte o que
              <br />
              seu negócio faz.
            </div>
            <p className="hb-empty-p">
              Escreva como você explicaria a um funcionário no primeiro dia. O
              briefing ao lado vai se preenchendo sozinho.
            </p>
          </div>
        )}

        {messages.map((msg, i) => (
          <div key={i} className="hb-msg" data-role={msg.role}>
            <span className="hb-msg-who">
              {msg.role === 'user' ? 'Você' : 'Helpy'}
            </span>
            <div className="hb-msg-text">{msg.content}</div>
          </div>
        ))}

        {sending && (
          <div className="hb-msg" data-role="assistant">
            <span className="hb-msg-who">Helpy</span>
            <div className="hb-typing">
              <i />
              <i />
              <i />
            </div>
          </div>
        )}
      </div>

      <div className="hb-compose">
        <div className="hb-compose-row">
          <textarea
            ref={areaRef}
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Escreva aqui..."
            disabled={blocked}
            aria-label="Mensagem"
          />
          <button
            type="button"
            className="hb-icon-btn"
            onClick={submit}
            disabled={!input.trim() || blocked}
            aria-label="Enviar"
            title="Enviar"
          >
            <svg
              width="15"
              height="15"
              viewBox="0 0 16 16"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.4"
            >
              <path d="M8 13V3M8 3L4 7M8 3l4 4" strokeLinecap="square" />
            </svg>
          </button>
        </div>

        <div className="hb-compose-foot">
          <span className="hb-hint">Enter envia</span>
          <button
            type="button"
            className="hb-link"
            onClick={generateIdeas}
            disabled={blocked}
          >
            Sugerir
          </button>
        </div>
      </div>
    </div>
  );
}