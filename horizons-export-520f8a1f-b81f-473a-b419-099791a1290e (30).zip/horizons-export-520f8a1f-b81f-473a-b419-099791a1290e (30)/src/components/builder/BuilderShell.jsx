// ============================================================
// HELPY — BuilderShell v2 — ARQUIVO COMPLETO
//
// A tela do builder, usada tanto para CRIAR quanto para EDITAR.
// Quem decide é a página que a renderiza, passando (ou não) o
// assistantId para o BuilderProvider.
// ============================================================

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useBuilder } from '@/contexts/BuilderContext';
import BuilderChat from '@/components/builder/BuilderChat';
import BuilderDoc from '@/components/builder/BuilderDoc';
import ConfirmDialog from '@/components/builder/ConfirmDialog';
import '@/styles/builder.css';

function SaveState() {
  const { saveState } = useBuilder();
  if (saveState === 'idle') return null;
  const text =
    saveState === 'saving' ? 'Salvando' : saveState === 'saved' ? 'Salvo' : 'Não salvou';
  return (
    <span className="hb-save" data-state={saveState}>
      <span className="hb-save-dot" />
      {text}
    </span>
  );
}

function Shell() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const {
    loading, ready, missing, schema, saveDraft, publish, resetSession, loadError,
    editando, publico, gerarLink, limites, assistantId,
  } = useBuilder();

  const [open, setOpen] = useState(true);
  const [publishing, setPublishing] = useState(false);
  const [error, setError] = useState(null);
  const [askReset, setAskReset] = useState(false);
  const [linkAberto, setLinkAberto] = useState(false);
  const [gerando, setGerando] = useState(false);

  const doReset = async () => {
    setAskReset(false);
    setError(null);

    // Guarda contra versão antiga do BuilderContext. Sem isto o erro que
    // aparece é "f is not a function", que não ajuda ninguém.
    if (typeof resetSession !== 'function') {
      setError(
        'O arquivo src/contexts/BuilderContext.jsx está numa versão antiga e não tem a função de recomeçar. Confira a primeira linha dele: precisa dizer HELPY BUILDER v6.'
      );
      return;
    }

    try {
      await resetSession();
      toast({ title: 'Recomeçado', description: 'Sessão nova. Pode contar do início.' });
    } catch (err) {
      setError(err.message);
    }
  };

  const labelOf = (key) => {
    for (const sec of schema.sections || []) {
      const f = (sec.fields || []).find((x) => x.key === key);
      if (f) return f.label;
      const c = (sec.collections || []).find((x) => x.key === key);
      if (c) return c.label;
    }
    return key;
  };

  const faltam = missing.critical?.length || 0;

  const handleDraft = async () => {
    await saveDraft();
    toast({ title: 'Rascunho salvo', description: 'Pode fechar a página, está guardado.' });
  };

  const handlePublish = async () => {
    setError(null);

    // O botão continua clicável de propósito: se faltar algo, você recebe
    // o motivo com nome e sobrenome em vez de um botão morto.
    if (!ready) {
      const nomes = (missing.critical || []).map(labelOf).join(', ');
      setError(`Faltam campos obrigatórios: ${nomes || 'verifique o briefing'}.`);
      toast({
        variant: 'destructive',
        title: 'Ainda não dá para publicar',
        description: `Faltam: ${nomes}`,
      });
      return;
    }

    setPublishing(true);
    try {
      const assistant = await publish();
      if (editando) {
        toast({ title: 'Alterações salvas', description: `${assistant.name} foi atualizado.` });
        navigate(`/assistant/${assistant.id}`);
      } else {
        toast({
          title: 'Assistente publicado',
          description: `${assistant.name} está no ar. Abrindo a conversa.`,
        });
        navigate(`/assistant/${assistant.id}`);
      }
    } catch (err) {
      console.error('[Builder] erro ao publicar:', err);
      const msg = err?.message || 'Erro desconhecido ao publicar.';
      setError(msg);
      toast({ variant: 'destructive', title: 'Não foi possível publicar', description: msg });
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div className="hb hb-shell">
      <header className="hb-top">
        <div className="hb-top-left">
          <button type="button" className="hb-btn" onClick={() => navigate('/dashboard')}>
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M10 3L5 8l5 5" strokeLinecap="square" />
            </svg>
            Voltar
          </button>
          <span className="hb-crumb">
            Helpy / <b>Novo assistente</b>
          </span>
        </div>

        <div className="hb-top-right">
          <SaveState />
          {!editando && (
            <button type="button" className="hb-btn" onClick={() => setAskReset(true)} disabled={loading}>
              Recomeçar
            </button>
          )}
          {editando && (
            <button
              type="button"
              className="hb-btn"
              onClick={() => setLinkAberto(true)}
              disabled={loading}
            >
              Link e limites
            </button>
          )}
          <button type="button" className="hb-btn" onClick={handleDraft} disabled={loading}>
            Salvar rascunho
          </button>
          <button
            type="button"
            className={ready ? 'hb-btn hb-btn--solid' : 'hb-btn hb-btn--edge'}
            onClick={handlePublish}
            disabled={publishing || loading}
            title={
              ready
                ? 'Publicar o assistente'
                : `Faltam ${faltam} ${faltam === 1 ? 'campo obrigatório' : 'campos obrigatórios'}`
            }
            style={ready ? undefined : { color: 'var(--hb-ink-3)', borderColor: 'var(--hb-rule)' }}
          >
            {publishing
              ? 'Salvando'
              : ready
              ? editando ? 'Salvar alterações' : 'Publicar'
              : `${editando ? 'Salvar' : 'Publicar'} · faltam ${faltam}`}
          </button>
        </div>
      </header>

      {(error || loadError) && (
        <div
          role="alert"
          style={{
            flexShrink: 0,
            padding: '.625rem 1.25rem',
            borderBottom: '1px solid var(--hb-rule-lit)',
            background: 'var(--hb-raised)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '1rem',
            fontSize: '.8125rem',
            color: 'var(--hb-ink)',
          }}
        >
          <span style={{ lineHeight: 1.5 }}>{error || loadError}</span>
          <button
            type="button"
            className="hb-icon-btn"
            onClick={() => setError(null)}
            aria-label="Fechar aviso"
          >
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4">
              <path d="M4 4l8 8M12 4l-8 8" strokeLinecap="square" />
            </svg>
          </button>
        </div>
      )}

      <ConfirmDialog
        open={askReset}
        eyebrow="Recomeçar"
        title="Descartar este briefing?"
        body="A conversa e tudo que já foi preenchido serão apagados, e o ramo do negócio volta a ser detectado do zero. Não dá para desfazer."
        confirmLabel="Descartar"
        cancelLabel="Manter"
        destructive
        onConfirm={doReset}
        onCancel={() => setAskReset(false)}
      />

      {linkAberto && (
        <PainelLink
          publico={publico}
          gerando={gerando}
          onLimites={limites}
          onGerar={async (opcoes) => {
            setGerando(true);
            try {
              await gerarLink(opcoes);
              toast({ title: 'Link pronto', description: 'Já pode mandar para os seus clientes.' });
            } catch (err) {
              setError(err.message);
            } finally {
              setGerando(false);
            }
          }}
          onFechar={() => setLinkAberto(false)}
        />
      )}

      <div className="hb-body">
        <aside className="hb-aside" data-collapsed={open ? 'false' : 'true'}>
          <BuilderChat />
        </aside>

        <button
          type="button"
          className="hb-handle"
          style={{ left: open ? '400px' : '0px' }}
          onClick={() => setOpen(!open)}
          aria-label={open ? 'Recolher conversa' : 'Abrir conversa'}
          title={open ? 'Recolher conversa' : 'Abrir conversa'}
        >
          <svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6">
            <path d={open ? 'M10 3L5 8l5 5' : 'M6 3l5 5-5 5'} strokeLinecap="square" />
          </svg>
        </button>

        <main className="hb-main">
          <div className="hb-main-inner">
            <BuilderDoc />
          </div>
        </main>
      </div>
    </div>
  );
}

/**
 * Painel do link público. O endereço leva um token de 32 caracteres:
 * sem ele, qualquer um adivinharia um id e conversaria com o assistente
 * dos outros gastando a cota de OpenAI do dono.
 */
function PainelLink({ publico, gerando, onGerar, onLimites, onFechar }) {
  const token = publico?.token;
  const url = token ? `${window.location.origin}/c/${token}` : null;
  const [copiado, setCopiado] = useState(false);

  const copiar = async () => {
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      setCopiado(true);
      setTimeout(() => setCopiado(false), 2000);
    } catch (_) {
      /* navegador sem permissão: o campo abaixo permite copiar à mão */
    }
  };

  return (
    <div
      style={{
        flexShrink: 0,
        borderBottom: '1px solid var(--hb-rule-lit)',
        background: 'var(--hb-panel)',
        padding: '1.25rem',
      }}
    >
      <div style={{ maxWidth: '46rem', margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: '1rem' }}>
          <span className="hb-chat-title">Link e limites</span>
          <button type="button" className="hb-btn" onClick={onFechar}>Fechar</button>
        </div>

        {!url && (
          <>
            <p style={{ fontSize: '.8125rem', color: 'var(--hb-ink-3)', lineHeight: 1.6, margin: '.75rem 0 1.25rem' }}>
              Gere um endereço público para mandar aos seus clientes. Eles conversam com o
              assistente sem precisar de conta. O endereço tem um código secreto — quem não o
              tiver, não entra.
            </p>
            <button type="button" className="hb-btn hb-btn--solid" onClick={() => onGerar({})} disabled={gerando}>
              {gerando ? 'Gerando' : 'Gerar link'}
            </button>
          </>
        )}

        {url && (
          <>
            <input
              className="hb-input"
              readOnly
              value={url}
              onFocus={(e) => e.target.select()}
              style={{ margin: '.75rem 0 1rem' }}
            />
            <div style={{ display: 'flex', gap: '.5rem', flexWrap: 'wrap' }}>
              <button type="button" className="hb-btn hb-btn--solid" onClick={copiar}>
                {copiado ? 'Copiado' : 'Copiar link'}
              </button>
              <a className="hb-btn hb-btn--edge" href={url} target="_blank" rel="noreferrer">
                Abrir
              </a>
              <button
                type="button"
                className="hb-btn"
                onClick={() => onGerar({ regenerar: true })}
                disabled={gerando}
                title="Invalida o endereço atual e cria outro"
              >
                Gerar novo
              </button>
              {publico?.is_public !== false && (
                <button
                  type="button"
                  className="hb-btn"
                  onClick={() => onGerar({ ligado: false })}
                  disabled={gerando}
                  title="Desativa o link sem apagá-lo"
                >
                  Desativar
                </button>
              )}
              {publico?.is_public === false && (
                <button type="button" className="hb-btn" onClick={() => onGerar({ ligado: true })} disabled={gerando}>
                  Reativar
                </button>
              )}
            </div>
            {publico?.is_public === false && (
              <p style={{ fontSize: '.6875rem', color: 'var(--hb-ink-3)', marginTop: '.75rem' }}>
                Este link está desativado. Quem abrir verá um aviso.
              </p>
            )}
          </>
        )}

        <BlocoLimites limites={publico?.limites} onSalvar={onLimites} />
      </div>
    </div>
  );
}

/**
 * Teto de mensagens. São três, e cada um protege de uma coisa diferente:
 * visitante contém curioso, com conta libera cliente de verdade, e o
 * teto do assistente é o que segura a sua conta de OpenAI se algo
 * escapar dos dois primeiros.
 */
function BlocoLimites({ limites, onSalvar }) {
  const [aberto, setAberto] = useState(false);
  const [v, setV] = useState(null);
  const [salvando, setSalvando] = useState(false);
  const [ok, setOk] = useState(false);

  useEffect(() => {
    if (limites) setV(limites);
  }, [limites]);

  if (!limites) return null;

  const campo = (chave, rotulo, ajuda) => (
    <div style={{ marginBottom: '1.25rem' }}>
      <div className="hb-field-top">
        <span className="hb-label">{rotulo}</span>
      </div>
      <input
        className="hb-input"
        type="number"
        min="0"
        value={v?.[chave] ?? ''}
        onChange={(e) => setV({ ...v, [chave]: e.target.value })}
        style={{ maxWidth: '9rem' }}
      />
      <p style={{ fontSize: '.6875rem', color: 'var(--hb-ink-3)', marginTop: '.35rem', lineHeight: 1.5 }}>
        {ajuda}
      </p>
    </div>
  );

  return (
    <div style={{ marginTop: '2rem', borderTop: '1px solid var(--hb-rule)', paddingTop: '1.25rem' }}>
      <button
        type="button"
        className="hb-link"
        onClick={() => setAberto(!aberto)}
        style={{ border: 'none' }}
      >
        {aberto ? '− Limites de mensagem' : '+ Limites de mensagem'}
      </button>

      {aberto && (
        <div style={{ marginTop: '1.25rem' }}>
          {campo('anon_msg_limit', 'Visitante sem conta', 'Por dia, por pessoa. Baixo o bastante para conter curioso, alto o bastante para tirar uma dúvida.')}
          {campo('user_msg_limit', 'Visitante com conta', 'Por dia, por pessoa. Quem se identificou merece mais espaço.')}
          {campo('public_msg_limit', 'Teto do assistente', 'Por dia, somando todo mundo. É esta que protege a sua conta de OpenAI.')}

          <div style={{ display: 'flex', gap: '.5rem', alignItems: 'center' }}>
            <button
              type="button"
              className="hb-btn hb-btn--solid"
              disabled={salvando}
              onClick={async () => {
                setSalvando(true);
                setOk(false);
                try {
                  await onSalvar(v);
                  setOk(true);
                  setTimeout(() => setOk(false), 2500);
                } finally {
                  setSalvando(false);
                }
              }}
            >
              {salvando ? 'Salvando' : 'Salvar limites'}
            </button>
            {ok && <span className="hb-flag">salvo</span>}
          </div>

          <p style={{ fontSize: '.6875rem', color: 'var(--hb-ink-3)', marginTop: '1rem', lineHeight: 1.6 }}>
            Quando um atendente humano assume a conversa, nenhum destes limites vale — a IA sai de
            cena e não há custo por mensagem.
          </p>
        </div>
      )}
    </div>
  );
}

export default Shell;