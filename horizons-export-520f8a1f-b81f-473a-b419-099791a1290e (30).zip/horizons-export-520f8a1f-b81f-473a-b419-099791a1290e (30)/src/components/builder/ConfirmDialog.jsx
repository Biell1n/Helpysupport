// ============================================================
// HELPY — ConfirmDialog v1 — ARQUIVO COMPLETO
//
// Substitui o window.confirm() do navegador.
//
// Os estilos estão embutidos num <style> dentro do próprio componente,
// de propósito: assim o arquivo é autossuficiente e não depende de mais
// nenhum CSS ser colado no lugar certo.
// ============================================================

import React, { useEffect, useRef } from 'react';

export default function ConfirmDialog({
  open,
  eyebrow = 'Confirmação',
  title,
  body,
  confirmLabel = 'Confirmar',
  cancelLabel = 'Cancelar',
  destructive = false,
  onConfirm,
  onCancel,
}) {
  const confirmRef = useRef(null);

  useEffect(() => {
    if (!open) return;

    // foca o botão de confirmar ao abrir
    const t = setTimeout(() => confirmRef.current?.focus(), 40);

    const onKey = (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onCancel?.();
      }
      if (e.key === 'Enter') {
        e.preventDefault();
        onConfirm?.();
      }
    };

    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    return () => {
      clearTimeout(t);
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onConfirm, onCancel]);

  if (!open) return null;

  return (
    <>
      <style>{`
        .hbd-veil {
          position: fixed; inset: 0; z-index: 90;
          background: rgba(0,0,0,.78);
          backdrop-filter: blur(3px);
          display: flex; align-items: center; justify-content: center;
          padding: 1.5rem;
          animation: hbd-in .16s ease-out;
        }
        .hbd-panel {
          width: 100%; max-width: 27rem;
          background: #070707;
          border: 1px solid #3A3A3A;
          padding: 2rem;
          animation: hbd-rise .2s cubic-bezier(.2,.8,.3,1);
        }
        .hbd-eyebrow {
          font-family: 'JetBrains Mono', ui-monospace, monospace;
          font-size: .5625rem; letter-spacing: .18em; text-transform: uppercase;
          color: #6A6A6A; display: block; margin-bottom: .875rem;
        }
        .hbd-title {
          font-family: 'Instrument Serif', Georgia, serif;
          font-size: 1.625rem; line-height: 1.15; color: #fff;
          margin: 0 0 .875rem; letter-spacing: -.01em;
        }
        .hbd-body {
          font-family: 'Inter', system-ui, sans-serif;
          font-size: .8125rem; line-height: 1.65; color: #A8A8A8;
          margin: 0 0 2rem;
        }
        .hbd-actions {
          display: flex; justify-content: flex-end; gap: .5rem;
          padding-top: 1.25rem; border-top: 1px solid #1F1F1F;
        }
        .hbd-btn {
          font-family: 'JetBrains Mono', ui-monospace, monospace;
          font-size: .6875rem; letter-spacing: .1em; text-transform: uppercase;
          padding: .625rem 1.125rem; cursor: pointer;
          background: none; border: 1px solid transparent; color: #A8A8A8;
          transition: color .15s, border-color .15s, background .15s;
        }
        .hbd-btn:hover { color: #fff; }
        .hbd-btn:focus-visible { outline: 1px solid #fff; outline-offset: 2px; }
        .hbd-btn--go { background: #fff; color: #000; border-color: #fff; font-weight: 500; }
        .hbd-btn--go:hover { background: #A8A8A8; border-color: #A8A8A8; color: #000; }
        .hbd-btn--danger { background: none; color: #fff; border-color: #fff; }
        .hbd-btn--danger:hover { background: #fff; color: #000; }
        @keyframes hbd-in { from { opacity: 0 } to { opacity: 1 } }
        @keyframes hbd-rise { from { opacity: 0; transform: translateY(8px) } to { opacity: 1; transform: none } }
        @media (prefers-reduced-motion: reduce) {
          .hbd-veil, .hbd-panel { animation: none }
        }
      `}</style>

      <div
        className="hbd-veil"
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) onCancel?.();
        }}
      >
        <div
          className="hbd-panel"
          role="dialog"
          aria-modal="true"
          aria-labelledby="hbd-title"
          aria-describedby="hbd-body"
        >
          <span className="hbd-eyebrow">{eyebrow}</span>
          <h2 className="hbd-title" id="hbd-title">
            {title}
          </h2>
          <p className="hbd-body" id="hbd-body">
            {body}
          </p>

          <div className="hbd-actions">
            <button type="button" className="hbd-btn" onClick={onCancel}>
              {cancelLabel}
            </button>
            <button
              ref={confirmRef}
              type="button"
              className={`hbd-btn ${destructive ? 'hbd-btn--danger' : 'hbd-btn--go'}`}
              onClick={onConfirm}
            >
              {confirmLabel}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}