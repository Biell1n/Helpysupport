import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("=== ERROR BOUNDARY CAUGHT ERROR ===");
    console.error("ERROR MESSAGE:", error.message);
    console.error("ERROR STACK:", error.stack);
    console.error("ERROR INFO:", errorInfo);
    console.error("===================================");
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4 text-white">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 max-w-md w-full text-center shadow-2xl">
            <div className="bg-red-500/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="w-8 h-8 text-red-500" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Ops! Algo deu errado.</h2>
            <p className="text-neutral-400 mb-6 text-sm">
              Encontramos um erro inesperado: {this.state.error?.message}
            </p>
            <button
              onClick={() => window.location.reload()}
              className="bg-white text-black font-bold py-3 px-6 rounded-xl hover:bg-neutral-200 transition-colors w-full flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4" /> Recarregar Página
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}