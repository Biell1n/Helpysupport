import React from 'react';
import { AlertCircle } from 'lucide-react';

export default function FormFieldError({ error, charCount, maxChars }) {
  if (!error && !charCount) return null;

  return (
    <div className="flex justify-between items-start mt-1.5 text-xs">
      <div className="flex-1">
        {error && (
          <span className="flex items-center gap-1 text-red-500 font-medium animate-fade-in">
            <AlertCircle className="w-3.5 h-3.5" />
            {error}
          </span>
        )}
      </div>
      {maxChars && (
        <span className={`shrink-0 ml-4 ${charCount > maxChars ? 'text-red-500 font-bold' : 'text-neutral-500'}`}>
          {charCount}/{maxChars}
        </span>
      )}
    </div>
  );
}