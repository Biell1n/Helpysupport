import React, { useState, useEffect, useRef } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import RefinementAssistantChat from '@/components/RefinementAssistantChat';
import ProgressSidebar from '@/components/ProgressSidebar';
import EditableDataPanel from '@/components/EditableDataPanel';
import { Button } from '@/components/ui/button';
import { Save, Loader2, FileText, MessageSquare, Database } from 'lucide-react';
import { useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export default function EditAssistantTabPage({ assistantId, assistantData, initialMemory }) {
  const [activeTab, setActiveTab] = useState('chat');
  const [saving, setSaving] = useState(false);
  const [showFinalize, setShowFinalize] = useState(false);
  
  const { 
    initMemory,
    state,
    assistantName,
    setAssistantName,
    getCompletionStatus,
    getProgress
  } = useAssistantMemoryContext();
  
  const { toast } = useToast();
  const initialized = useRef(false);

  useEffect(() => {
    if (!initialized.current && assistantData && assistantId) {
      // Migrate old contact structure if needed
      let migratedMemory = { ...initialMemory };
      if (initialMemory?.contato && !Array.isArray(initialMemory.contato)) {
        const oldContato = initialMemory.contato;
        const newContato = [];
        if (oldContato.email) newContato.push({ type: 'Email', value: oldContato.email });
        if (oldContato.telefone) newContato.push({ type: 'Telefone', value: oldContato.telefone });
        if (oldContato.whatsapp) newContato.push({ type: 'WhatsApp', value: oldContato.whatsapp });
        if (oldContato.site) newContato.push({ type: 'Site', value: oldContato.site });
        migratedMemory.contato = newContato;
      }
      
      initMemory(assistantId, assistantData.business_type || 'VENDAS', migratedMemory);
      setAssistantName(assistantData.name || assistantData.title || '');
      
      initialized.current = true;
    }
  }, [assistantData, initialMemory, initMemory, assistantId, setAssistantName]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const memoryPayload = {
        assistant_id: assistantId,
        tipo_negocio: state.businessType,
        descricao_negocio: state.descricao,
        produtos: state.catalogo.map(p => ({
          nome: p.name,
          preco: p.priceMin,
          priceMax: p.priceMax
        })),
        contato: state.contato,
        personalidade: state.personalidade,
        regras_fala: state.regras,
        updated_at: new Date().toISOString()
      };

      // Update assistant_memory
      const { data: existingMemory } = await supabase
        .from('assistant_memory')
        .select('id')
        .eq('assistant_id', assistantId)
        .maybeSingle();

      if (existingMemory) {
        await supabase
          .from('assistant_memory')
          .update(memoryPayload)
          .eq('id', existingMemory.id);
      } else {
        await supabase
          .from('assistant_memory')
          .insert([memoryPayload]);
      }

      // Update assistants table
      await supabase
        .from('assistants')
        .update({
          description: state.descricao,
          name: assistantName,
          title: assistantName,
          updated_at: new Date().toISOString()
        })
        .eq('id', assistantId);

      toast({
        title: 'Sucesso',
        description: 'Alterações salvas com sucesso!'
      });
    } catch (err) {
      console.error('[EditAssistantTabPage] Save error:', err);
      toast({
        title: 'Erro ao Salvar',
        description: 'Não foi possível salvar as alterações.',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  const handleFinalize = () => {
    const completionStatus = getCompletionStatus();
    
    if (!completionStatus.mandatoryComplete) {
      toast({
        title: 'Atenção',
        description: 'Complete todos os campos obrigatórios antes de finalizar.',
        variant: 'destructive'
      });
      return;
    }

    setShowFinalize(true);
  };

  const confirmFinalize = async () => {
    await handleSave();
    setShowFinalize(false);
    
    toast({
      title: 'Assistente Finalizado!',
      description: 'Seu assistente está pronto para usar.',
    });
  };

  const progress = getProgress();
  const completionStatus = getCompletionStatus();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-neutral-900/30 p-4 rounded-2xl border border-white/5">
        <div>
          <h2 className="text-xl font-bold text-white">{assistantName}</h2>
          <p className="text-sm text-neutral-400">
            {progress}% completo • {completionStatus.missingMandatory?.length || 0} campos obrigatórios faltando
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            onClick={handleSave} 
            disabled={saving}
            variant="outline"
            className="border-white/10 hover:border-white/20"
          >
            {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
            Salvar
          </Button>
          
          {completionStatus.mandatoryComplete && (
            <Button 
              onClick={handleFinalize}
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold"
            >
              Finalizar Configuração
            </Button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full sm:w-[500px] grid-cols-3 bg-neutral-950 border border-white/10 p-1.5 rounded-xl h-12">
          <TabsTrigger 
            value="chat" 
            className="rounded-lg data-[state=active]:bg-white data-[state=active]:text-black transition-all font-semibold"
          >
            <MessageSquare className="w-4 h-4 mr-2" /> Conversa
          </TabsTrigger>
          <TabsTrigger 
            value="data" 
            className="rounded-lg data-[state=active]:bg-white data-[state=active]:text-black transition-all font-semibold"
          >
            <Database className="w-4 h-4 mr-2" /> Dados
          </TabsTrigger>
          <TabsTrigger 
            value="progress" 
            className="rounded-lg data-[state=active]:bg-white data-[state=active]:text-black transition-all font-semibold"
          >
            <FileText className="w-4 h-4 mr-2" /> Progresso
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="mt-6">
          <div className="grid lg:grid-cols-[1fr_320px] xl:grid-cols-[1fr_350px] gap-6">
            <div className="h-[calc(100vh-300px)]">
              <RefinementAssistantChat />
            </div>
            <div className="h-[calc(100vh-300px)]">
              <ProgressSidebar onAdvancedOptionsClick={() => setActiveTab('data')} />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="data" className="mt-6">
          <div className="max-w-4xl mx-auto">
            <EditableDataPanel />
          </div>
        </TabsContent>

        <TabsContent value="progress" className="mt-6">
          <div className="max-w-4xl mx-auto">
            <ProgressSidebar onAdvancedOptionsClick={() => setActiveTab('data')} />
          </div>
        </TabsContent>
      </Tabs>

      {/* Finalize Confirmation */}
      <AlertDialog open={showFinalize} onOpenChange={setShowFinalize}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Finalizar Configuração?</AlertDialogTitle>
            <AlertDialogDescription>
              Seu assistente está completo e pronto para uso. Deseja finalizar a configuração?
              Você ainda poderá fazer edições depois.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Continuar Editando</AlertDialogCancel>
            <AlertDialogAction onClick={confirmFinalize} className="bg-green-600 hover:bg-green-700">
              Finalizar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}