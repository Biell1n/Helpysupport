import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Edit2, Save, X } from 'lucide-react';
import { useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';
import EditableFieldModal from './EditableFieldModal';

export default function AdvancedOptionsModal({ isOpen, onClose }) {
  const { memory } = useAssistantMemoryContext();
  const [editingField, setEditingField] = useState(null);

  const fields = [
    { id: 'descricao_negocio', label: 'Descrição', type: 'textarea' },
    { id: 'produtos', label: 'Catálogo', type: 'array' },
    { id: 'contato', label: 'Contato', type: 'object' },
    { id: 'personalidade', label: 'Personalidade', type: 'object' },
    { id: 'regras_fala', label: 'Regras', type: 'array' }
  ];

  const handleEditField = (field) => {
    setEditingField(field);
  };

  const renderFieldContent = (fieldId) => {
    const content = memory[fieldId];
    
    if (!content || (typeof content === 'string' && !content.trim()) || 
        (Array.isArray(content) && content.length === 0) || 
        (typeof content === 'object' && Object.keys(content).length === 0)) {
      return <div className="advanced-options-empty">Nenhum conteúdo preenchido</div>;
    }

    if (typeof content === 'string') {
      return <div className="advanced-options-content">{content}</div>;
    }

    return (
      <div className="advanced-options-json">
        <pre>{JSON.stringify(content, null, 2)}</pre>
      </div>
    );
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="advanced-options-modal">
          <DialogHeader>
            <DialogTitle className="advanced-options-modal-title">⚙️ Opções Avançadas</DialogTitle>
            <DialogDescription className="advanced-options-modal-description">
              Edite manualmente os campos do seu assistente
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="descricao_negocio" className="advanced-options-tabs">
            <TabsList className="advanced-options-tabs-list">
              {fields.map(field => (
                <TabsTrigger key={field.id} value={field.id} className="advanced-options-tab">
                  {field.label}
                </TabsTrigger>
              ))}
            </TabsList>

            {fields.map(field => (
              <TabsContent key={field.id} value={field.id} className="advanced-options-tab-content">
                <div className="advanced-options-field-container">
                  <div className="advanced-options-field-header">
                    <h4 className="advanced-options-field-title">{field.label}</h4>
                    <Button
                      size="sm"
                      onClick={() => handleEditField(field)}
                      className="advanced-options-edit-button"
                    >
                      <Edit2 className="w-3.5 h-3.5 mr-1.5" />
                      Edição Avançada
                    </Button>
                  </div>
                  <div className="advanced-options-field-preview">
                    {renderFieldContent(field.id)}
                  </div>
                </div>
              </TabsContent>
            ))}
          </Tabs>

          <div className="advanced-options-footer">
            <Button variant="outline" onClick={onClose} className="advanced-options-close-button">
              <X className="w-4 h-4 mr-2" />
              Fechar
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {editingField && (
        <EditableFieldModal
          isOpen={!!editingField}
          onClose={() => setEditingField(null)}
          fieldId={editingField.id}
          fieldLabel={editingField.label}
          currentValue={memory[editingField.id]}
          type={editingField.type}
          businessType={memory.tipo_negocio || 'GERAL'}
          onSave={(fieldId, newValue) => {
            setEditingField(null);
          }}
        />
      )}
    </>
  );
}