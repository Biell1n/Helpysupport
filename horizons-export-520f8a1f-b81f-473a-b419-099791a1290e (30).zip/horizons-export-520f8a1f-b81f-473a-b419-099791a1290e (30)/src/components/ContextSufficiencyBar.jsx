import React from 'react';
import { motion } from 'framer-motion';

export default function ContextSufficiencyBar({ score = 0 }) {
  let statusText = "Gathering Information";
  let colorClass = "bg-red-500";
  
  if (score >= 85) {
    statusText = "Ready to Create";
    colorClass = "bg-green-500";
  } else if (score >= 71) {
    statusText = "Almost Ready";
    colorClass = "bg-yellow-400";
  } else if (score >= 41) {
    statusText = "Good Progress";
    colorClass = "bg-orange-400";
  }

  return (
    <div className="w-full bg-neutral-900/50 p-4 rounded-xl border border-white/10 mb-6">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm font-medium text-neutral-300">{statusText}</span>
        <span className="text-sm font-bold text-white">{score}%</span>
      </div>
      <div className="h-2 w-full bg-neutral-800 rounded-full overflow-hidden">
        <motion.div 
          className={`h-full ${colorClass}`}
          initial={{ width: 0 }}
          animate={{ width: `${score}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}