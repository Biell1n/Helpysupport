import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { X, Lock, UserPlus, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function AnonymousRestrictionModal({ isOpen, onClose }) {
  const navigate = useNavigate();

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden"
        >
          <div className="p-6 text-center">
            <div className="w-16 h-16 bg-neutral-800 rounded-full flex items-center justify-center mx-auto mb-4 border border-neutral-700">
              <Lock className="w-8 h-8 text-violet-500" />
            </div>
            
            <h2 className="text-xl font-bold text-white mb-2">Esta ação requer cadastro</h2>
            <p className="text-neutral-400 mb-8">
              Para acessar este recurso e salvar seu histórico, você precisa criar uma conta gratuita.
            </p>

            <div className="space-y-3">
              <Button 
                onClick={() => navigate('/register')}
                className="w-full bg-violet-600 hover:bg-violet-700 text-white h-12 text-base"
              >
                <UserPlus className="w-5 h-5 mr-2" />
                Cadastrar-se
              </Button>
              
              <Button 
                variant="outline"
                onClick={onClose}
                className="w-full border-neutral-700 text-neutral-300 hover:bg-neutral-800 hover:text-white h-12"
              >
                Continuar Navegando
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}