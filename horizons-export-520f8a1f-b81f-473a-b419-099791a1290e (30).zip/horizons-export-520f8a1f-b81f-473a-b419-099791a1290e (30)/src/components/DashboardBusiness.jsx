// ============================================================
// HELPY — DashboardBusiness v9 — ARQUIVO COMPLETO
//
// Painel OPERACIONAL, com linguagem própria — não a do builder.
// Montserrat, layout largo, informação densa.
//
// O que ele entrega, além da lista de assistentes:
//  - atendimentos em três colunas por estado
//  - lacunas: o que perguntaram e o assistente não soube responder
//  - métricas de conversa dos últimos 7 dias
//
// Sem tela de carregamento bloqueando: a estrutura aparece na hora e
// cada parte preenche quando chega.
// ============================================================

import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import ConfirmDialog from '@/components/builder/ConfirmDialog';
import '@/styles/painel.css';

/**
 * Revela o bloco quando ele entra na tela. Uma vez só — reanimar a cada
 * rolagem irrita mais do que enfeita.
 */
function useRevelar() {
  const ref = useRef(null);
  const [visivel, setVisivel] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el || visivel) return;
    if (!('IntersectionObserver' in window)) return setVisivel(true);

    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setVisivel(true);
          obs.disconnect();
        }
      },
      { rootMargin: '-40px' }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [visivel]);

  return [ref, visivel];
}

function Bloco({ children, atraso = 0, ...resto }) {
  const [ref, visivel] = useRevelar();
  return (
    <div
      ref={ref}
      className="hd-rise"
      data-vis={visivel ? 'true' : 'false'}
      style={{ transitionDelay: `${atraso}ms` }}
      {...resto}
    >
      {children}
    </div>
  );
}

const minutosPara = (a, b) => {
  if (!a || !b) return null;
  const m = (new Date(b) - new Date(a)) / 60000;
  return m >= 0 ? m : null;
};

const duracao = (min) => {
  if (min == null) return '—';
  if (min < 60) return `${Math.round(min)}min`;
  if (min < 1440) return `${(min / 60).toFixed(1)}h`;
  return `${Math.round(min / 1440)}d`;
};

const quando = (iso) => {
  if (!iso) return '';
  const d = new Date(iso);
  const min = Math.round((Date.now() - d.getTime()) / 60000);
  if (min < 1) return 'agora';
  if (min < 60) return `${min}min`;
  if (min < 1440) return `${Math.round(min / 60)}h`;
  return `${Math.round(min / 1440)}d`;
};

/**
 * Nome de quem está do outro lado.
 * Ordem: o que ele deu ao assistente, o do cadastro, e só então o
 * genérico. "Visitante" agora só aparece para quem realmente não tem
 * conta — antes aparecia até para quem tinha.
 */
const estrelas = (n) => '\u2605'.repeat(n) + '\u2606'.repeat(5 - n);

const nomeCliente = (c) =>
  c.lead_nome?.trim() ||
  c.visitor_name?.trim() ||
  (c.user_id ? 'Sem nome no cadastro' : 'Visitante');

const COLUNAS = [
  { chave: 'escalated', titulo: 'Aguardando', vazio: 'Nada aguardando.' },
  { chave: 'assumido', titulo: 'Em atendimento', vazio: 'Ninguém em atendimento.' },
  { chave: 'closed', titulo: 'Resolvidos', vazio: 'Nenhum resolvido ainda.' },
];

export default function DashboardBusiness() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const [assistentes, setAssistentes] = useState(null);
  const [conversas, setConversas] = useState(null);
  const [lacunas, setLacunas] = useState(null);
  const [tabelas, setTabelas] = useState(null);
  const [erro, setErro] = useState(null);

  const [busca, setBusca] = useState('');
  const [ordem, setOrdem] = useState('data');
  const [aExcluir, setAExcluir] = useState(null);

  // Cada consulta preenche sua parte quando chega. Nada de bloquear a
  // tela inteira esperando a mais lenta.
  const carregar = useCallback(async () => {
    if (!user) return;

    supabase
      .from('assistants').select('*').eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .then(({ data, error }) => {
        if (error) setErro(error.message);
        else setAssistentes(data ?? []);
      });

    supabase
      .from('assistant_conversations').select('*').eq('owner_id', user.id)
      .order('last_message_at', { ascending: false }).limit(120)
      .then(({ data }) => setConversas(data ?? []));

    supabase
      .from('tabelas')
      .select('id, nome, proposito, alterada_em, tabela_linhas(count)')
      .eq('owner_id', user.id)
      .order('alterada_em', { ascending: false })
      .limit(6)
      .then(({ data }) => setTabelas(data ?? []));

    supabase
      .from('assistant_gaps').select('*').eq('owner_id', user.id)
      .is('resolvido_em', null)
      .order('vezes', { ascending: false }).limit(8)
      .then(({ data }) => setLacunas(data ?? []));
  }, [user]);

  useEffect(() => {
    carregar();
    const t = setInterval(carregar, 30000);
    return () => clearInterval(t);
  }, [carregar]);

  const balde = (c) => {
    if (c.status === 'closed') return 'closed';
    if (c.status === 'escalated') return c.assumido_por ? 'assumido' : 'escalated';
    return null; // conversas só com o assistente não entram no quadro
  };

  const porColuna = useMemo(() => {
    const m = { escalated: [], assumido: [], closed: [] };
    for (const c of conversas ?? []) {
      const b = balde(c);
      if (b) m[b].push(c);
    }
    return m;
  }, [conversas]);

  const metricas = useMemo(() => {
    const lista = conversas ?? [];
    const semana = Date.now() - 7 * 864e5;
    const recentes = lista.filter((c) => new Date(c.started_at || c.last_message_at) >= semana);
    const msgs = recentes.reduce((s, c) => s + (c.message_count ?? 0), 0);
    const leads = lista.filter((c) => c.lead_contato).length;
    const resolvidos = lista.filter((c) => c.status === 'closed');

    // Média de quanto tempo até alguém assumir um chamado.
    const esperas = lista
      .map((c) => minutosPara(c.escalonado_em, c.assumido_em))
      .filter((v) => v != null);
    const respostaMedia = esperas.length
      ? esperas.reduce((a, b) => a + b, 0) / esperas.length
      : null;

    // Média do escalonamento até o encerramento.
    const resolucoes = resolvidos
      .map((c) => minutosPara(c.escalonado_em || c.started_at, c.fechado_em))
      .filter((v) => v != null);
    const resolucaoMedia = resolucoes.length
      ? resolucoes.reduce((a, b) => a + b, 0) / resolucoes.length
      : null;

    // Quantas conversas o assistente resolveu sozinho, sem escalar.
    const semHumano = lista.filter((c) => !c.escalonado_em).length;
    const autonomia = lista.length ? Math.round((semHumano / lista.length) * 100) : null;

    // Sete dias, do mais antigo para hoje.
    const dias = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setHours(0, 0, 0, 0);
      d.setDate(d.getDate() - i);
      const fim = new Date(d).setDate(d.getDate() + 1);
      const n = lista.filter((c) => {
        const t = new Date(c.started_at || c.last_message_at).getTime();
        return t >= d.getTime() && t < fim;
      }).length;
      dias.push({
        rotulo: ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'][d.getDay()],
        n,
      });
    }

    const avaliadas = lista.filter((c) => c.nota != null);
    const satisfacao = avaliadas.length
      ? avaliadas.reduce((a, c) => a + c.nota, 0) / avaliadas.length
      : null;

    return {
      satisfacao,
      avaliadas: avaliadas.length,
      conversas7: recentes.length,
      msgs,
      leads,
      resolvidos: resolvidos.length,
      respostaMedia,
      resolucaoMedia,
      autonomia,
      dias,
      pico: Math.max(1, ...dias.map((d) => d.n)),
      aguardando: porColuna.escalated.length,
      emAtendimento: porColuna.assumido.length,
    };
  }, [conversas, porColuna]);

  const lista = useMemo(() => {
    let r = [...(assistentes ?? [])];
    const q = busca.trim().toLowerCase();
    if (q) {
      r = r.filter(
        (a) => (a.name || '').toLowerCase().includes(q) || (a.description || '').toLowerCase().includes(q)
      );
    }
    if (ordem === 'nome') r.sort((x, y) => (x.name || '').localeCompare(y.name || ''));
    return r;
  }, [assistentes, busca, ordem]);

  const excluir = async () => {
    const id = aExcluir?.id;
    setAExcluir(null);
    if (!id) return;
    const { error } = await supabase.from('assistants').delete().eq('id', id);
    if (error) toast({ variant: 'destructive', title: 'Não deu para remover', description: error.message });
    else {
      setAssistentes((p) => (p ?? []).filter((a) => a.id !== id));
      toast({ title: 'Assistente removido' });
    }
  };

  /** Encerra o atendimento sem sair do painel. */
  const encerrar = async (c) => {
    const { error } = await supabase
      .from('assistant_conversations')
      .update({ status: 'closed', fechado_em: new Date().toISOString() })
      .eq('id', c.id);
    if (error) {
      toast({ variant: 'destructive', title: 'Não deu para encerrar', description: error.message });
      return;
    }
    setConversas((p) =>
      (p ?? []).map((x) =>
        x.id === c.id ? { ...x, status: 'closed', fechado_em: new Date().toISOString() } : x
      )
    );
    toast({ title: 'Atendimento encerrado' });
  };

  const resolverLacuna = async (g) => {
    await supabase
      .from('assistant_gaps')
      .update({ resolvido_em: new Date().toISOString() })
      .eq('id', g.id);
    setLacunas((p) => (p ?? []).filter((x) => x.id !== g.id));
  };

  const primeiro =
    user?.user_metadata?.full_name?.split(' ')[0] || user?.email?.split('@')[0] || '';

  return (
    <div className="hd">
      <header className="hd-bar">
        <div className="hd-brand">
          Helpy<b style={{ color: 'var(--hd-ink-3)' }}> / painel</b>
        </div>
        <div className="hd-bar-r">

          <button type="button" className="hd-nav" onClick={() => navigate('/dashboard/atendimentos')}>
            Atendimentos
            {metricas.aguardando > 0 && (
              <span style={{ color: 'var(--hd-ac)' }}>{metricas.aguardando}</span>
            )}
          </button>
          <button type="button" className="hd-nav" onClick={() => navigate('/dashboard/dados')}>
            Dados
          </button>
          <button type="button" className="hd-nav" onClick={() => navigate('/profile')}>
            Perfil
          </button>
          <button
            type="button"
            className="hd-btn hd-btn--solid"
            onClick={() => navigate('/dashboard/create-assistant')}
          >
            Novo assistente
          </button>
        </div>
      </header>

      <div className="hd-wrap">
        <div className="hd-head">
          <span className="hd-lbl">Visão geral</span>
          <h1 className="hd-h1">
            {primeiro ? `Olá, ${primeiro}.` : 'Painel.'}
            <br />
            <em>
              {assistentes?.length
                ? `${assistentes.length} ${assistentes.length === 1 ? 'assistente' : 'assistentes'} no ar.`
                : 'Nada no ar ainda.'}
            </em>
          </h1>
        </div>

        {erro && <div className="hd-alert" style={{ marginBottom: '1.5rem' }}>{erro}</div>}

        {/* ---------- métricas ---------- */}
        <Bloco>
          <div className="hd-kpis">
            <div className="hd-kpi">
              <div className="hd-kpi-l">Assistentes</div>
              <div className="hd-kpi-v">{assistentes?.length ?? 0}</div>
              <div className="hd-kpi-n">
                {(assistentes ?? []).filter((a) => a.is_public).length} com link ativo
              </div>
            </div>

            <div className={`hd-kpi${metricas.aguardando > 0 ? ' hd-kpi--warn' : ''}`}>
              <div className="hd-kpi-l">Aguardando você</div>
              <div className="hd-kpi-v">{metricas.aguardando}</div>
              <div className="hd-kpi-n">
                {metricas.emAtendimento > 0
                  ? `${metricas.emAtendimento} em atendimento`
                  : 'ninguém na fila'}
              </div>
            </div>

            <div className="hd-kpi">
              <div className="hd-kpi-l">Conversas · 7 dias</div>
              <div className="hd-kpi-v">{metricas.conversas7}</div>
              <div className="hd-kpi-n">{metricas.msgs} mensagens trocadas</div>
            </div>

            <div className={`hd-kpi${metricas.leads > 0 ? ' hd-kpi--ok' : ''}`}>
              <div className="hd-kpi-l">Contatos captados</div>
              <div className="hd-kpi-v">{metricas.leads}</div>
              <div className="hd-kpi-n">pessoas deixaram contato</div>
            </div>
          </div>
        </Bloco>

        <Bloco atraso={80}>
          <div className="hd-kpis" style={{ marginTop: '.875rem' }}>
            <div className="hd-kpi">
              <div className="hd-kpi-l">Satisfação</div>
              <div className="hd-kpi-v">
                {metricas.satisfacao == null ? (
                  '—'
                ) : (
                  <>
                    {metricas.satisfacao.toFixed(1)}
                    <small>/5</small>
                  </>
                )}
              </div>
              <div className="hd-kpi-n">
                {metricas.avaliadas === 0
                  ? 'ninguém avaliou ainda'
                  : `${metricas.avaliadas} ${metricas.avaliadas === 1 ? 'avaliação' : 'avaliações'} · ${metricas.resolvidos} encerrados`}
              </div>
            </div>

            <div className="hd-kpi">
              <div className="hd-kpi-l">Tempo até assumir</div>
              <div className="hd-kpi-v" style={{ fontSize: '1.375rem' }}>
                {duracao(metricas.respostaMedia)}
              </div>
              <div className="hd-kpi-n">média para alguém entrar</div>
            </div>

            <div className="hd-kpi">
              <div className="hd-kpi-l">Tempo de resolução</div>
              <div className="hd-kpi-v" style={{ fontSize: '1.375rem' }}>
                {duracao(metricas.resolucaoMedia)}
              </div>
              <div className="hd-kpi-n">do encaminhamento ao fim</div>
            </div>

            <div className="hd-kpi">
              <div className="hd-kpi-l">Resolvido pelo assistente</div>
              <div className="hd-kpi-v">
                {metricas.autonomia == null ? '—' : <>{metricas.autonomia}<small>%</small></>}
              </div>
              <div className="hd-kpi-n">conversas sem precisar de gente</div>
              <div className="hd-prog">
                <i style={{ width: `${metricas.autonomia ?? 0}%` }} />
              </div>
            </div>
          </div>
        </Bloco>

        {/* ---------- movimento dos 7 dias ---------- */}
        <Bloco atraso={140}>
          <section className="hd-sec">
            <div className="hd-sec-head">
              <h2 className="hd-h2">Movimento</h2>
              <span className="hd-kpi-n">conversas iniciadas nos últimos 7 dias</span>
            </div>
            <div className="hd-box" style={{ padding: '1.125rem 1.25rem 1rem' }}>
              <div className="hd-chart">
                {metricas.dias.map((d, i) => (
                  <div className="hd-bar-col" key={i} title={`${d.n} em ${d.rotulo}`}>
                    <div
                      className="hd-bar-v"
                      data-zero={d.n === 0 ? 'true' : 'false'}
                      style={{
                        height: `${Math.max(4, (d.n / metricas.pico) * 100)}%`,
                        animationDelay: `${i * 70}ms`,
                      }}
                    />
                    <span className="hd-bar-d">{d.rotulo}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </Bloco>

        {/* ---------- atendimentos ---------- */}
        <Bloco atraso={60}>
        <section className="hd-sec">
          <div className="hd-sec-head">
            <h2 className="hd-h2">
              Atendimentos
              {metricas.aguardando > 0 && (
                <span className="hd-count hd-count--warn">{metricas.aguardando} aguardando</span>
              )}
            </h2>
            <button
              type="button"
              className="hd-btn hd-btn--edge hd-btn--sm"
              onClick={() => navigate('/dashboard/atendimentos')}
            >
              Abrir a caixa
            </button>
          </div>

          <div className="hd-cols">
            {COLUNAS.map((col) => (
              <div className="hd-col" key={col.chave}>
                <div className="hd-col-h">
                  <span>{col.titulo}</span>
                  <span className="hd-col-n">{porColuna[col.chave].length}</span>
                </div>
                <div className="hd-col-b">
                  {!conversas && <div className="hd-skel" />}
                  {conversas && porColuna[col.chave].length === 0 && (
                    <div className="hd-empty">{col.vazio}</div>
                  )}
                  {porColuna[col.chave].slice(0, 6).map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      className={`hd-card${col.chave === 'escalated' && !c.lido_em ? ' hd-card--novo' : ''}`}
                      onClick={() => navigate('/dashboard/atendimentos')}
                    >
                      <div className="hd-card-t">
                        <span className="hd-card-who">{nomeCliente(c)}</span>
                        <span className="hd-card-when">{quando(c.last_message_at)}</span>
                      </div>
                      <div className="hd-card-title">
                        {c.titulo || c.escalonado_motivo || 'Atendimento'}
                      </div>
                      {c.resumo && <p className="hd-card-p">{c.resumo}</p>}

                      {/* A avaliação do cliente vive aqui: é o resultado
                          do atendimento, e o lugar de ver resultado é na
                          coluna dos resolvidos. */}
                      {c.nota != null && (
                        <div style={{ marginTop: '.75rem' }}>
                          <span
                            style={{
                              fontSize: '.8125rem',
                              letterSpacing: '.1em',
                              color: c.nota >= 4 ? 'var(--hd-ink)' : 'var(--hd-ac)',
                            }}
                          >
                            {estrelas(c.nota)}
                          </span>
                          {c.feedback_texto && (
                            <p
                              className="hd-card-p"
                              style={{ fontStyle: 'italic', marginTop: '.375rem' }}
                            >
                              "{c.feedback_texto}"
                            </p>
                          )}
                        </div>
                      )}

                      {col.chave === 'closed' && c.nota == null && (
                        <p className="hd-card-p" style={{ marginTop: '.625rem', opacity: .7 }}>
                          Sem avaliação.
                        </p>
                      )}

                      {col.chave === 'assumido' && (
                        <span
                          role="button"
                          tabIndex={0}
                          className="hd-btn hd-btn--edge hd-btn--sm"
                          style={{ marginTop: '.625rem' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            encerrar(c);
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.stopPropagation();
                              encerrar(c);
                            }
                          }}
                        >
                          Marcar resolvido
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
        </Bloco>

        {/* ---------- lacunas ---------- */}
        <Bloco atraso={60}>
        <section className="hd-sec">
          <div className="hd-sec-head">
            <h2 className="hd-h2">
              O que está faltando
              {lacunas?.length > 0 && <span className="hd-count hd-count--warn">{lacunas.length}</span>}
            </h2>
          </div>
          <p className="hd-sub" style={{ marginTop: '-.5rem', marginBottom: '1rem' }}>
            Perguntas que os clientes fizeram e o assistente não soube responder. Preencher isso no
            briefing é o que mais melhora o atendimento.
          </p>

          <div className="hd-box">
            {!lacunas && <div style={{ padding: '.625rem' }}><div className="hd-skel" /></div>}
            {lacunas?.length === 0 && (
              <div className="hd-empty">
                Nada em aberto. Quando alguém perguntar algo que o assistente não sabe, aparece aqui.
              </div>
            )}
            {(lacunas ?? []).map((g) => (
              <div className="hd-gap" key={g.id}>
                <span className="hd-gap-n">{g.vezes}×</span>
                <div className="hd-gap-b">
                  <div className="hd-gap-t">{g.assunto}</div>
                  <div className="hd-gap-q">"{g.pergunta}"</div>
                </div>
                <button
                  type="button"
                  className="hd-btn hd-btn--edge hd-btn--sm"
                  onClick={() => resolverLacuna(g)}
                  title="Marcar como resolvido"
                >
                  Resolvido
                </button>
              </div>
            ))}
          </div>
        </section>
        </Bloco>

        {/* ---------- dados ---------- */}
        <Bloco atraso={60}>
        <section className="hd-sec">
          <div className="hd-sec-head">
            <h2 className="hd-h2">
              Dados
              {tabelas?.length > 0 && <span className="hd-count">{tabelas.length}</span>}
            </h2>
            <button
              type="button"
              className="hd-btn hd-btn--edge hd-btn--sm"
              onClick={() => navigate('/dashboard/dados')}
            >
              {tabelas?.length ? 'Abrir tabelas' : 'Criar tabela'}
            </button>
          </div>

          {!tabelas && <div className="hd-skel" />}

          {tabelas?.length === 0 && (
            <p className="hd-sub" style={{ marginTop: 0 }}>
              Listas grandes — produtos com estoque, procedimentos com duração, turmas, imóveis —
              ficam melhor numa tabela do que no briefing. Você define as colunas e o assistente
              consulta na hora de responder.
            </p>
          )}

          {tabelas?.length > 0 && (
            <div style={{ borderTop: '1px solid var(--hd-line)' }}>
              {tabelas.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => navigate('/dashboard/dados')}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '1fr auto',
                    gap: '1.5rem',
                    alignItems: 'baseline',
                    width: '100%',
                    textAlign: 'left',
                    background: 'none',
                    border: 'none',
                    borderBottom: '1px solid var(--hd-line)',
                    padding: '1.25rem 0',
                    cursor: 'pointer',
                    color: 'inherit',
                    font: 'inherit',
                  }}
                >
                  <span style={{ minWidth: 0 }}>
                    <span style={{ fontSize: '1rem', fontWeight: 400, display: 'block' }}>
                      {t.nome}
                    </span>
                    {t.proposito && (
                      <span className="hd-kpi-n" style={{ display: 'block', marginTop: '.25rem' }}>
                        {t.proposito}
                      </span>
                    )}
                  </span>
                  <span className="hd-col-n" style={{ fontSize: '1.125rem' }}>
                    {t.tabela_linhas?.[0]?.count ?? 0}
                  </span>
                </button>
              ))}
            </div>
          )}
        </section>
        </Bloco>

        {/* ---------- assistentes ---------- */}
        <section className="hd-sec">
          <div className="hd-sec-head">
            <h2 className="hd-h2">
              Assistentes
              <span className="hd-count">{assistentes?.length ?? 0}</span>
            </h2>
            {(assistentes?.length ?? 0) > 1 && (
              <div style={{ display: 'flex', gap: '.5rem' }}>
                <input
                  className="hd-in"
                  placeholder="Buscar"
                  value={busca}
                  onChange={(e) => setBusca(e.target.value)}
                  style={{ width: '10rem' }}
                />
                <select className="hd-sel" value={ordem} onChange={(e) => setOrdem(e.target.value)}>
                  <option value="data">Recentes</option>
                  <option value="nome">Nome</option>
                </select>
              </div>
            )}
          </div>

          {!assistentes && (
            <div className="hd-grid">
              <div className="hd-skel" style={{ height: '9rem' }} />
              <div className="hd-skel" style={{ height: '9rem' }} />
            </div>
          )}

          {assistentes?.length === 0 && (
            <div className="hd-box" style={{ padding: '2.5rem', textAlign: 'center' }}>
              <p className="hd-sub" style={{ marginBottom: '1.25rem' }}>
                Você ainda não criou nenhum assistente.
              </p>
              <button
                type="button"
                className="hd-btn hd-btn--solid"
                onClick={() => navigate('/dashboard/create-assistant')}
              >
                Criar o primeiro
              </button>
            </div>
          )}

          {lista.length > 0 && (
            <div className="hd-grid">
              {lista.map((a) => (
                <article className="hd-ast" key={a.id}>
                  <div className="hd-ast-h">
                    <div style={{ minWidth: 0 }}>
                      <h3 className="hd-ast-n">{a.name || 'Sem nome'}</h3>
                      <div className="hd-tags">
                        {(a.business_type || a.niche) && (
                          <span className="hd-tag">{a.business_type || a.niche}</span>
                        )}
                        {a.is_public && a.public_token && <span className="hd-tag hd-tag--on">link ativo</span>}
                        {typeof a.onboarding_progress === 'number' && (
                          <span className="hd-tag">{a.onboarding_progress}%</span>
                        )}
                      </div>
                    </div>
                    <button
                      type="button"
                      className="hd-ico hd-ico--kill"
                      onClick={() => setAExcluir(a)}
                      title="Excluir"
                      aria-label={`Excluir ${a.name}`}
                    >
                      <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4">
                        <path d="M3 5h10M6.5 5V3.5h3V5M5 5l.5 8h5L11 5" strokeLinecap="round" />
                      </svg>
                    </button>
                  </div>

                  <p className="hd-ast-p">{a.description || 'Sem descrição.'}</p>

                  <div className="hd-ast-f">
                    <button
                      type="button"
                      className="hd-btn hd-btn--edge hd-btn--sm"
                      onClick={() => navigate(`/assistant/${a.id}`)}
                    >
                      Testar
                    </button>
                    <button
                      type="button"
                      className="hd-btn hd-btn--edge hd-btn--sm"
                      onClick={() => navigate(`/assistant/${a.id}/edit`)}
                    >
                      Editar
                    </button>
                    {a.public_token && a.is_public && (
                      <button
                        type="button"
                        className="hd-btn hd-btn--sm"
                        onClick={() => {
                          navigator.clipboard?.writeText(`${window.location.origin}/c/${a.public_token}`);
                          toast({ title: 'Link copiado' });
                        }}
                      >
                        Copiar link
                      </button>
                    )}
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>

      <ConfirmDialog
        open={!!aExcluir}
        eyebrow="Excluir assistente"
        title={`Apagar o ${aExcluir?.name || 'assistente'}?`}
        body="O briefing, o histórico de conversas e o link público vão embora com ele. Não dá para desfazer."
        confirmLabel="Apagar"
        cancelLabel="Manter"
        destructive
        onConfirm={excluir}
        onCancel={() => setAExcluir(null)}
      />
    </div>
  );
}