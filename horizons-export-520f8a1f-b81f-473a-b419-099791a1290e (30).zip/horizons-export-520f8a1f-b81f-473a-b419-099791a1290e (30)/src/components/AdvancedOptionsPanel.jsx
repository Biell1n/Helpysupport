import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';
import { useToast } from '@/components/ui/use-toast';
import { Save, X, Plus, Trash2 } from 'lucide-react';

export default function AdvancedOptionsPanel({ isOpen, onClose }) {
  const { 
    state,
    updateDescricao,
    updateCatalogo,
    updateContato,
    updatePersonalidade,
    updateRegras,
    updateTrigger
  } = useAssistantMemoryContext();
  
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    descricao: '',
    catalogo: [],
    contato: [],
    personalidade: { estilo: '', comportamento: '' },
    regras: []
  });

  // Sync with context state
  useEffect(() => {
    if (isOpen) {
      setFormData({
        descricao: state.descricao || '',
        catalogo: state.catalogo || [],
        contato: state.contato || [],
        personalidade: state.personalidade || { estilo: '', comportamento: '' },
        regras: state.regras || []
      });
    }
  }, [isOpen, state, updateTrigger]);

  const addProduct = () => {
    setFormData(prev => ({
      ...prev,
      catalogo: [...prev.catalogo, { name: '', priceMin: '', priceMax: '' }]
    }));
  };

  const updateProduct = (index, field, value) => {
    setFormData(prev => {
      const newCatalogo = [...prev.catalogo];
      newCatalogo[index] = { ...newCatalogo[index], [field]: value };
      return { ...prev, catalogo: newCatalogo };
    });
  };

  const removeProduct = (index) => {
    setFormData(prev => ({
      ...prev,
      catalogo: prev.catalogo.filter((_, i) => i !== index)
    }));
  };

  const addContact = () => {
    setFormData(prev => ({
      ...prev,
      contato: [...prev.contato, { type: '', value: '' }]
    }));
  };

  const updateContact = (index, field, value) => {
    setFormData(prev => {
      const newContato = [...prev.contato];
      newContato[index] = { ...newContato[index], [field]: value };
      return { ...prev, contato: newContato };
    });
  };

  const removeContact = (index) => {
    setFormData(prev => ({
      ...prev,
      contato: prev.contato.filter((_, i) => i !== index)
    }));
  };

  const addRule = () => {
    setFormData(prev => ({
      ...prev,
      regras: [...prev.regras, '']
    }));
  };

  const updateRule = (index, value) => {
    setFormData(prev => {
      const newRegras = [...prev.regras];
      newRegras[index] = value;
      return { ...prev, regras: newRegras };
    });
  };

  const removeRule = (index) => {
    setFormData(prev => ({
      ...prev,
      regras: prev.regras.filter((_, i) => i !== index)
    }));
  };

  const handleSave = async () => {
    if (formData.contato.length === 0) {
      toast({
        title: 'Erro',
        description: 'Você precisa de pelo menos 1 canal de contato.',
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);
    try {
      await updateDescricao(formData.descricao);
      await updateCatalogo(formData.catalogo);
      await updateContato(formData.contato);
      await updatePersonalidade(formData.personalidade);
      await updateRegras(formData.regras);

      toast({
        title: 'Sucesso',
        description: 'Alterações salvas e sincronizadas!'
      });
      onClose();
    } catch (err) {
      console.error('Save error:', err);
      toast({
        title: 'Erro',
        description: 'Falha ao salvar alterações.',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-hidden bg-neutral-900 border-white/10 text-white">
        <DialogHeader className="border-b border-white/10 pb-4">
          <DialogTitle className="text-2xl font-bold">Opções Avançadas</DialogTitle>
          <DialogDescription className="text-neutral-400">
            Edite manualmente todos os campos do assistente
          </DialogDescription>
        </DialogHeader>

        <div className="overflow-y-auto max-h-[calc(90vh-200px)] custom-scrollbar pr-4">
          <div className="space-y-8 py-6">
            <div>
              <Label className="text-white font-bold mb-2 block">Descrição do Negócio</Label>
              <Textarea
                value={formData.descricao}
                onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                placeholder="Descreva seu negócio..."
                className="min-h-[120px] bg-black border-white/10 text-white"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-white font-bold">Catálogo de Produtos</Label>
                <Button onClick={addProduct} size="sm" variant="outline" className="border-white/10">
                  <Plus className="w-4 h-4 mr-1" /> Adicionar
                </Button>
              </div>
              <div className="space-y-3">
                {formData.catalogo.map((product, index) => (
                  <div key={index} className="bg-black/40 p-4 rounded-xl border border-white/10">
                    <div className="grid grid-cols-[1fr_auto] gap-3 mb-3">
                      <Input
                        value={product.name}
                        onChange={(e) => updateProduct(index, 'name', e.target.value)}
                        placeholder="Nome do produto"
                        className="bg-neutral-950 border-white/10 text-white"
                      />
                      <Button onClick={() => removeProduct(index)} size="sm" variant="ghost" className="text-red-400 hover:text-red-300">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        value={product.priceMin}
                        onChange={(e) => updateProduct(index, 'priceMin', e.target.value)}
                        placeholder="Preço mínimo"
                        className="bg-neutral-950 border-white/10 text-white"
                      />
                      <Input
                        value={product.priceMax}
                        onChange={(e) => updateProduct(index, 'priceMax', e.target.value)}
                        placeholder="Preço máximo"
                        className="bg-neutral-950 border-white/10 text-white"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-white font-bold">Canais de Contato</Label>
                <Button onClick={addContact} size="sm" variant="outline" className="border-white/10">
                  <Plus className="w-4 h-4 mr-1" /> Adicionar
                </Button>
              </div>
              <div className="space-y-3">
                {formData.contato.map((contact, index) => (
                  <div key={index} className="bg-black/40 p-4 rounded-xl border border-white/10">
                    <div className="grid grid-cols-[1fr_1fr_auto] gap-3">
                      <Input
                        value={contact.type}
                        onChange={(e) => updateContact(index, 'type', e.target.value)}
                        placeholder="Tipo"
                        className="bg-neutral-950 border-white/10 text-white"
                      />
                      <Input
                        value={contact.value}
                        onChange={(e) => updateContact(index, 'value', e.target.value)}
                        placeholder="Valor"
                        className="bg-neutral-950 border-white/10 text-white"
                      />
                      <Button onClick={() => removeContact(index)} size="sm" variant="ghost" className="text-red-400 hover:text-red-300 self-end">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label className="text-white font-bold mb-3 block">Personalidade</Label>
              <div className="space-y-3">
                <Input
                  value={formData.personalidade.estilo}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    personalidade: { ...prev.personalidade, estilo: e.target.value }
                  }))}
                  placeholder="Estilo"
                  className="bg-black border-white/10 text-white"
                />
                <Textarea
                  value={formData.personalidade.comportamento}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    personalidade: { ...prev.personalidade, comportamento: e.target.value }
                  }))}
                  placeholder="Comportamento"
                  className="bg-black border-white/10 text-white min-h-[80px]"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-white font-bold">Regras (Opcional)</Label>
                <Button onClick={addRule} size="sm" variant="outline" className="border-white/10">
                  <Plus className="w-4 h-4 mr-1" /> Adicionar
                </Button>
              </div>
              <div className="space-y-2">
                {formData.regras.map((rule, index) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      value={rule}
                      onChange={(e) => updateRule(index, e.target.value)}
                      placeholder="Regra"
                      className="bg-black border-white/10 text-white"
                    />
                    <Button onClick={() => removeRule(index)} size="sm" variant="ghost" className="text-red-400 hover:text-red-300">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-4 flex justify-end gap-3">
          <Button onClick={onClose} variant="outline" className="border-white/10">
            <X className="w-4 h-4 mr-2" /> Cancelar
          </Button>
          <Button onClick={handleSave} disabled={saving} className="bg-white text-black hover:bg-neutral-200">
            {saving ? <Save className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
            Salvar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}