import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Brain, Package, Phone, Sparkles, ShieldAlert, Loader2, XCircle } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function AssistantMemoryDisplay({ assistantId }) {
  const [memory, setMemory] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!assistantId) return;

    const fetchMemory = async () => {
      try {
        const { data, error } = await supabase
          .from('assistant_memory')
          .select('*')
          .eq('assistant_id', assistantId)
          .single();
        
        if (error && error.code !== 'PGRST116') throw error;
        setMemory(data);
      } catch (err) {
        console.error("Error fetching memory:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchMemory();
  }, [assistantId]);

  if (loading) {
    return <div className="p-4 flex items-center text-neutral-500 text-sm"><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Carregando base de conhecimento...</div>;
  }

  if (!memory) {
    return <div className="p-4 text-neutral-500 text-sm italic">Nenhuma memória estruturada encontrada para este assistente. (Assistente criado antes da atualização).</div>;
  }

  const refusedFieldsList = memory.refused_fields ? Object.keys(memory.refused_fields).filter(k => memory.refused_fields[k]) : [];

  return (
    <ScrollArea className="h-full max-h-[500px]">
      <div className="p-4 space-y-6">
        <div className="flex items-center gap-2 border-b border-white/10 pb-4">
          <Brain className="w-5 h-5 text-purple-400" />
          <h3 className="font-bold text-white text-lg">Memória do Assistente</h3>
        </div>

        {/* Descrição */}
        {memory.descricao_negocio && (
           <div className="space-y-2">
             <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-500 flex items-center gap-2"><Sparkles className="w-3 h-3" /> Foco</h4>
             <p className="text-sm text-neutral-300 bg-neutral-900/50 p-3 rounded-xl border border-white/5">{memory.descricao_negocio}</p>
           </div>
        )}

        {/* Produtos/Serviços */}
        {memory.produtos && memory.produtos.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-500 flex items-center gap-2"><Package className="w-3 h-3" /> Catálogo</h4>
            <div className="space-y-2">
              {memory.produtos.map((p, i) => (
                <div key={i} className="bg-neutral-900/50 p-3 rounded-xl border border-white/5">
                  <span className="font-semibold text-blue-400 text-sm block">{p.nome || 'Item sem nome'}</span>
                  <span className="text-xs text-neutral-400 block mt-1">{p.descricao}</span>
                  {p.preco && <span className="text-xs font-bold text-green-400 mt-2 block">{p.preco}</span>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Contato */}
        {memory.contato && Object.keys(memory.contato).length > 0 && (
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-500 flex items-center gap-2"><Phone className="w-3 h-3" /> Contato</h4>
            <div className="bg-neutral-900/50 p-3 rounded-xl border border-white/5 text-sm text-neutral-300 space-y-1">
              {memory.contato.email && <div><strong className="text-neutral-500">Email:</strong> {memory.contato.email}</div>}
              {memory.contato.telefone && <div><strong className="text-neutral-500">Tel:</strong> {memory.contato.telefone}</div>}
              {memory.contato.endereco && <div><strong className="text-neutral-500">End:</strong> {memory.contato.endereco}</div>}
              {memory.contato.site && <div><strong className="text-neutral-500">Site:</strong> {memory.contato.site}</div>}
            </div>
          </div>
        )}

        {/* Regras - Now explicitly optional */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-500 flex items-center gap-2">
            <ShieldAlert className="w-3 h-3" /> Regras e Restrições 
            <span className="bg-neutral-800 text-neutral-400 text-[9px] px-1.5 py-0.5 rounded ml-1">Opcional</span>
          </h4>
          {memory.regras_fala && memory.regras_fala.length > 0 ? (
            <ul className="list-disc list-inside text-sm text-orange-200/80 bg-orange-950/20 p-3 rounded-xl border border-orange-500/20">
              {memory.regras_fala.map((r, i) => <li key={i}>{r}</li>)}
            </ul>
          ) : (
            <div className="text-xs text-neutral-600 italic bg-neutral-900/30 p-2 rounded-lg border border-white/5">
              Nenhuma regra de atendimento definida.
            </div>
          )}
        </div>

        {/* Refused Fields Display */}
        {refusedFieldsList.length > 0 && (
          <div className="space-y-2 mt-6 pt-4 border-t border-red-900/30">
             <h4 className="text-xs font-bold uppercase tracking-wider text-red-500/70 flex items-center gap-2">
               <XCircle className="w-3 h-3" /> Informações Recusadas
             </h4>
             <div className="flex flex-wrap gap-2">
               {refusedFieldsList.map((field, i) => (
                 <span key={i} className="bg-red-950/30 text-red-400/80 text-[10px] px-2 py-1 rounded-md border border-red-900/50">
                   {field}
                 </span>
               ))}
             </div>
             <p className="text-[10px] text-neutral-500 mt-1">O assistente não solicitará essas informações novamente.</p>
          </div>
        )}
      </div>
    </ScrollArea>
  );
}