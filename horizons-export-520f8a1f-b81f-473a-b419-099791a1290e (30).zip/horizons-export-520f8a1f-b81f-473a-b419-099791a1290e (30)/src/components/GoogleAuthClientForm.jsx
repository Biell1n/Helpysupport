import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { Link } from 'react-router-dom';

export default function GoogleAuthClientForm() {
  const [fullName, setFullName] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  
  const email = location.state?.email || '';
  const userId = location.state?.userId;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!termsAccepted) {
      toast({ title: 'Termos obrigatórios', description: 'Você precisa aceitar os Termos de Uso.', variant: 'destructive' });
      return;
    }
    if (!fullName.trim()) {
      toast({ title: 'Nome obrigatório', description: 'Por favor, informe seu nome completo.', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      // Using upsert instead of pure insert because Supabase Auth triggers might have already created a row
      const { error } = await supabase.from('users').upsert({
        id: userId,
        email: email,
        full_name: fullName,
        user_type: 'cliente',
        plan: 'free',
        is_anonymous: false
      });

      if (error) throw error;
      
      toast({ title: 'Conta configurada!', description: 'Bem-vindo ao Helpy.' });
      navigate('/dashboard');
    } catch (error) {
      console.error(error);
      toast({ title: 'Erro', description: 'Ocorreu um erro ao configurar sua conta.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5 w-full mt-6">
      <div className="space-y-2">
        <Label htmlFor="full_name" className="text-neutral-300">Nome Completo</Label>
        <Input 
          id="full_name" 
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          required
          className="bg-neutral-900 border-none outline-none text-white focus:ring-0 transition-colors h-14 rounded-xl px-4"
          placeholder="Seu nome completo"
        />
      </div>

      <div className="flex items-start space-x-3 py-3">
        <Checkbox 
          id="client-terms" 
          checked={termsAccepted}
          onCheckedChange={setTermsAccepted}
          className="mt-1 data-[state=checked]:bg-white data-[state=checked]:border-none data-[state=checked]:text-black border-neutral-600 outline-none focus:ring-0"
        />
        <Label 
          htmlFor="client-terms" 
          className="text-sm text-neutral-400 leading-tight font-normal cursor-pointer select-none"
        >
          Aceito os <Link to="/terms" target="_blank" className="text-white font-medium transition-colors hover:underline">Termos de Uso</Link> e a <Link to="/privacy" target="_blank" className="text-white font-medium transition-colors hover:underline">Política de Privacidade</Link>.
        </Label>
      </div>
      <Button type="submit" disabled={loading} className="w-full bg-white hover:bg-neutral-200 text-black font-bold py-6 text-lg rounded-xl shadow-lg border-none outline-none focus:ring-0">
        {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Concluir Cadastro"}
      </Button>
    </form>
  );
}