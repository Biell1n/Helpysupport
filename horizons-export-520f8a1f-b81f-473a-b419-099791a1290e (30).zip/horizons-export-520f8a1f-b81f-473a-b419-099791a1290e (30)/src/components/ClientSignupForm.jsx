import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Link, useNavigate } from 'react-router-dom';

export default function ClientSignupForm({ onSuccess }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!termsAccepted) {
      toast({ title: 'Termos obrigatórios', description: 'Você precisa aceitar os Termos de Uso.', variant: 'destructive' });
      return;
    }
    if (password.length < 8) {
      toast({ title: 'Senha fraca', description: 'A senha deve ter pelo menos 8 caracteres.', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const result = await register(email, password, 'pending', 'free', null, fullName);
      if (result.success) {
        if (onSuccess) onSuccess();
        navigate('/complete-cadastro');
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5 w-full">
      <div className="space-y-2">
        <Label htmlFor="client-fullname" className="text-neutral-300">Nome Completo</Label>
        <Input 
          id="client-fullname" 
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          required
          className="bg-neutral-900 border-none outline-none text-white focus:ring-0 transition-colors h-14 rounded-xl px-4"
          placeholder="Seu nome completo"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="client-email" className="text-neutral-300">Email</Label>
        <Input 
          id="client-email" 
          type="email" 
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="bg-neutral-900 border-none outline-none text-white focus:ring-0 transition-colors h-14 rounded-xl px-4"
          placeholder="seu@email.com"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="client-password" className="text-neutral-300">Senha</Label>
        <Input 
          id="client-password" 
          type="password" 
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="bg-neutral-900 border-none outline-none text-white focus:ring-0 transition-colors h-14 rounded-xl px-4"
          placeholder="••••••••"
        />
      </div>
      <div className="flex items-start space-x-3 py-3">
        <Checkbox 
          id="client-terms" 
          checked={termsAccepted}
          onCheckedChange={setTermsAccepted}
          className="mt-1 data-[state=checked]:bg-white data-[state=checked]:border-none data-[state=checked]:text-black border-neutral-600 outline-none focus:ring-0"
        />
        <Label 
          htmlFor="client-terms" 
          className="text-sm text-neutral-400 leading-tight font-normal cursor-pointer select-none"
        >
          Aceito os <Link to="/terms" target="_blank" className="text-white font-medium transition-colors hover:underline">Termos de Uso</Link> e a <Link to="/privacy" target="_blank" className="text-white font-medium transition-colors hover:underline">Política de Privacidade</Link>.
        </Label>
      </div>
      <Button type="submit" disabled={loading} className="w-full bg-white hover:bg-neutral-200 text-black font-bold py-6 text-lg rounded-xl shadow-lg border-none outline-none focus:ring-0">
        {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Criar Conta"}
      </Button>
    </form>
  );
}