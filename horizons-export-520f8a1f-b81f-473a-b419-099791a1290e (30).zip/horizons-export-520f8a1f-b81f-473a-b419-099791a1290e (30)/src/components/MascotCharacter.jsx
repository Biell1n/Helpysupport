// Component removed as requested
export default function MascotCharacter() {
  return null;
}