import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2 } from 'lucide-react';

export default function EditableFieldModal({
  isOpen,
  onClose,
  fieldId,
  fieldLabel,
  currentValue,
  type = 'text',
  businessType,
  onSave
}) {
  const [value, setValue] = useState(currentValue);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setValue(currentValue);
  }, [currentValue, isOpen]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await onSave(fieldId, value);
      onClose();
    } catch (err) {
      console.error('Save error:', err);
    } finally {
      setSaving(false);
    }
  };

  const renderField = () => {
    if (type === 'textarea') {
      return (
        <Textarea
          value={value || ''}
          onChange={(e) => setValue(e.target.value)}
          rows={6}
          className="bg-neutral-900 border-white/10 text-white"
          placeholder="Digite a descrição..."
        />
      );
    }

    if (type === 'product') {
      return (
        <div className="space-y-4">
          <div>
            <Label className="text-white">Nome do Produto</Label>
            <Input
              value={value?.name || ''}
              onChange={(e) => setValue({ ...value, name: e.target.value })}
              className="bg-neutral-900 border-white/10 text-white"
              placeholder="Ex: Bolo de Chocolate"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white">Preço Mínimo</Label>
              <Input
                value={value?.priceMin || ''}
                onChange={(e) => setValue({ ...value, priceMin: e.target.value })}
                className="bg-neutral-900 border-white/10 text-white"
                placeholder="Ex: 30"
              />
            </div>
            <div>
              <Label className="text-white">Preço Máximo</Label>
              <Input
                value={value?.priceMax || ''}
                onChange={(e) => setValue({ ...value, priceMax: e.target.value })}
                className="bg-neutral-900 border-white/10 text-white"
                placeholder="Ex: 80"
              />
            </div>
          </div>
        </div>
      );
    }

    if (type === 'contact') {
      return (
        <div className="space-y-4">
          <div>
            <Label className="text-white">Tipo de Contato</Label>
            <Input
              value={value?.type || ''}
              onChange={(e) => setValue({ ...value, type: e.target.value })}
              className="bg-neutral-900 border-white/10 text-white"
              placeholder="Ex: WhatsApp, Email, Instagram"
            />
          </div>
          <div>
            <Label className="text-white">Valor</Label>
            <Input
              value={value?.value || ''}
              onChange={(e) => setValue({ ...value, value: e.target.value })}
              className="bg-neutral-900 border-white/10 text-white"
              placeholder="Ex: 11 99999-9999"
            />
          </div>
        </div>
      );
    }

    if (type === 'personality') {
      return (
        <div className="space-y-4">
          <div>
            <Label className="text-white">Estilo</Label>
            <Input
              value={value?.estilo || ''}
              onChange={(e) => setValue({ ...value, estilo: e.target.value })}
              className="bg-neutral-900 border-white/10 text-white"
              placeholder="Ex: Amigável, Formal, Descontraído"
            />
          </div>
          <div>
            <Label className="text-white">Comportamento</Label>
            <Textarea
              value={value?.comportamento || ''}
              onChange={(e) => setValue({ ...value, comportamento: e.target.value })}
              rows={4}
              className="bg-neutral-900 border-white/10 text-white"
              placeholder="Ex: Direto e objetivo, sempre disposto a ajudar"
            />
          </div>
        </div>
      );
    }

    return (
      <Input
        value={value || ''}
        onChange={(e) => setValue(e.target.value)}
        className="bg-neutral-900 border-white/10 text-white"
        placeholder="Digite o valor..."
      />
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-neutral-950 border-white/10 text-white">
        <DialogHeader>
          <DialogTitle>{fieldLabel}</DialogTitle>
          <DialogDescription className="text-neutral-400">
            Edite as informações abaixo
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {renderField()}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="border-white/10">
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Salvando...
              </>
            ) : (
              'Salvar'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}