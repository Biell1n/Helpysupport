import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, CheckCircle2, AlertCircle, HelpCircle, Lightbulb } from 'lucide-react';
import { getFrameworkByType, calculateFrameworkScore } from '@/lib/descriptionFramework';

export default function FrameworkGuidance({ businessType, analysis, onElementClick }) {
  const [expandedSections, setExpandedSections] = useState({ comum: true, especifico: false });
  const framework = getFrameworkByType(businessType);
  const score = calculateFrameworkScore(analysis);

  const toggleSection = (section) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const getElementStatus = (elementId, category) => {
    const missingList = analysis?.missingElements?.[category] || [];
    return missingList.includes(elementId) ? 'missing' : 'complete';
  };

  const renderElement = (element, category) => {
    const status = getElementStatus(element.id, category);
    const isComplete = status === 'complete';

    return (
      <motion.div
        initial={{ opacity: 0, y: 5 }}
        animate={{ opacity: 1, y: 0 }}
        key={element.id}
        onClick={() => onElementClick?.(element, category)}
        className={`p-4 rounded-xl border cursor-pointer transition-all hover:shadow-md ${
          isComplete 
            ? 'bg-green-950/20 border-green-500/30 hover:border-green-500/50' 
            : 'bg-orange-950/20 border-orange-500/30 hover:border-orange-500/50'
        }`}
      >
        <div className="flex items-start gap-3">
          <div className={`p-1.5 rounded-full shrink-0 ${isComplete ? 'bg-green-500/20' : 'bg-orange-500/20'}`}>
            {isComplete ? (
              <CheckCircle2 className="w-4 h-4 text-green-400" />
            ) : (
              <AlertCircle className="w-4 h-4 text-orange-400" />
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <h4 className={`font-semibold text-sm mb-1 ${isComplete ? 'text-green-300' : 'text-orange-300'}`}>
              {element.label}
            </h4>
            <p className="text-xs text-neutral-400 mb-2">{element.description}</p>
            
            {!isComplete && (
              <div className="flex items-start gap-2 mt-2 p-2 bg-black/40 rounded-lg border border-white/5">
                <Lightbulb className="w-3.5 h-3.5 text-yellow-400 shrink-0 mt-0.5" />
                <p className="text-xs text-yellow-200/80 leading-relaxed">
                  Exemplo: {element.examples[0]}
                </p>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    );
  };

  const renderSection = (section, category) => {
    const isExpanded = expandedSections[category];
    const missingCount = (analysis?.missingElements?.[category] || []).length;
    const totalCount = section.elements.length;
    const completedCount = totalCount - missingCount;

    return (
      <div className="bg-neutral-900/50 border border-white/10 rounded-2xl overflow-hidden">
        <button
          onClick={() => toggleSection(category)}
          className="w-full p-5 flex items-center justify-between hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              missingCount === 0 ? 'bg-green-500/20 text-green-400' : 'bg-orange-500/20 text-orange-400'
            }`}>
              {missingCount === 0 ? <CheckCircle2 className="w-5 h-5" /> : <HelpCircle className="w-5 h-5" />}
            </div>
            <div className="text-left">
              <h3 className="font-bold text-white">{section.label}</h3>
              <p className="text-xs text-neutral-400">
                {completedCount} de {totalCount} completos
              </p>
            </div>
          </div>
          
          <motion.div
            animate={{ rotate: isExpanded ? 180 : 0 }}
            transition={{ duration: 0.2 }}
          >
            <ChevronDown className="w-5 h-5 text-neutral-400" />
          </motion.div>
        </button>

        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden"
            >
              <div className="p-5 pt-0 space-y-3">
                {section.elements.map(element => renderElement(element, category))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Progress Header */}
      <div className="bg-gradient-to-r from-blue-950/30 to-purple-950/30 border border-blue-500/30 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white">Framework de Descrição Profissional</h2>
          <div className="text-right">
            <div className="text-3xl font-black text-white mb-1">{score}%</div>
            <p className="text-xs text-neutral-400">Completude do Framework</p>
          </div>
        </div>
        
        <div className="w-full bg-black/40 rounded-full h-3 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${score}%` }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            className={`h-full rounded-full ${
              score >= 80 ? 'bg-gradient-to-r from-green-500 to-green-400' :
              score >= 50 ? 'bg-gradient-to-r from-orange-500 to-orange-400' :
              'bg-gradient-to-r from-red-500 to-red-400'
            }`}
          />
        </div>
      </div>

      {/* Framework Sections */}
      <div className="space-y-4">
        {renderSection(framework.comum, 'comum')}
        {renderSection(framework.especifico, 'especifico')}
      </div>

      {/* Suggestions Summary */}
      {analysis?.suggestions && analysis.suggestions.length > 0 && (
        <div className="bg-blue-950/20 border border-blue-500/30 rounded-2xl p-5">
          <h3 className="font-bold text-blue-300 mb-3 flex items-center gap-2">
            <Lightbulb className="w-5 h-5" />
            Próximas Ações Recomendadas
          </h3>
          <ul className="space-y-2">
            {analysis.suggestions.slice(0, 3).map((suggestion, idx) => (
              <li key={idx} className="text-sm text-blue-200 flex items-start gap-2">
                <span className="text-blue-400 font-bold shrink-0">{idx + 1}.</span>
                <span className="leading-relaxed">{suggestion}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}