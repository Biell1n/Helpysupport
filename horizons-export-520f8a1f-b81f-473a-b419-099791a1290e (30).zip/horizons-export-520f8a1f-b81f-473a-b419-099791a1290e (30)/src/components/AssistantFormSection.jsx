import React from 'react';
import { motion } from 'framer-motion';

export default function AssistantFormSection({ title, description, children, delay = 0 }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4 }}
      className="bg-neutral-900/50 p-6 sm:p-8 rounded-3xl"
    >
      <div className="mb-6">
        <h2 className="text-xl font-bold text-white">{title}</h2>
        {description && <p className="text-neutral-400 mt-1">{description}</p>}
      </div>
      <div className="space-y-4">
        {children}
      </div>
    </motion.div>
  );
}