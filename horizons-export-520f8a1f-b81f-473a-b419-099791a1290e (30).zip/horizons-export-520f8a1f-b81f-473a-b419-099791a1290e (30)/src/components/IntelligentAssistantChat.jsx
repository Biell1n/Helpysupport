import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Send, Bot, User, Loader2, AlertCircle, RefreshCcw } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';
import { handleAuthError } from '@/lib/authUtils';
import { toast } from 'sonner';
import UpdatePreviewModal from './UpdatePreviewModal';
import { usePolicyEnforcement } from '@/hooks/usePolicyEnforcement';
import { useSound } from '@/hooks/useSound';
import { countMessageTokens } from '@/lib/tokenCounter';
import { useRefusalTracking } from '@/hooks/useRefusalTracking';
import { 
  buildContextWithMemory, 
  saveToMemoryHistory 
} from '@/lib/assistantMemory';

export default function IntelligentAssistantChat({ formData, onApplySuggestion, onUpdateSummary, assistantId }) {
  const [messages, setMessages] = useState([
    { id: 'welcome', role: 'assistant', content: 'Olá! Sou seu especialista em criação de assistentes voltados para vendas. Me conte sobre seu negócio, produtos, faixas de preços e como quer que eu atenda seus clientes para fecharmos mais negócios!' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [modalState, setModalState] = useState({ isOpen: false, suggestedChanges: null });
  
  const scrollRef = useRef(null);
  const isProcessing = useRef(false);
  const assistantMessageIdRef = useRef(null);
  
  const { validateChatResponse } = usePolicyEnforcement();
  const { playMessageSentSound, playMessageReceivedSound } = useSound();
  
  const refusalTrackingResult = useRefusalTracking();
  const getRefusedFields = refusalTrackingResult?.getRefusedFields || (() => []);

  const tokensCount = countMessageTokens(input);
  const isApproachingLimit = tokensCount >= 3500 && tokensCount <= 4000;
  const isOverLimit = tokensCount > 4000;

  // 4. Initial Load
  useEffect(() => {
    async function loadHistory() {
      if (!assistantId) return;
      try {
        console.log('[CHAT] Loading history for assistant:', assistantId);
        const { data, error } = await supabase
          .from('chat_messages')
          .select('*')
          .eq('assistant_id', assistantId)
          .order('created_at', { ascending: true });
          
        if (error) throw error;
        
        if (data && data.length > 0) {
          const historyMessages = data.map(msg => ({
            id: msg.id,
            role: msg.role,
            content: msg.content
          }));
          setMessages(prev => [...prev.filter(m => m.id === 'welcome'), ...historyMessages]);
          console.log('[CHAT] History loaded:', historyMessages);
        }
      } catch (err) {
        console.error('[CHAT] Error loading history:', err);
      }
    }
    loadHistory();
  }, [assistantId]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const extractSuggestions = (text) => {
    const changes = {};
    
    const nameMatch = text.match(/\*\*Sugestão de Nome:\*\*\s*([^\n]+)/i);
    if (nameMatch) changes.name = nameMatch[1].trim();

    const persMatch = text.match(/\*\*Personalidade Sugerida:\*\*\s*([^\n]+)/i);
    if (persMatch) changes.personality = persMatch[1].trim();

    const descMatch = text.match(/\*\*Descrição Sugerida:\*\*\s*([\s\S]+?)(?=\n\*\*|$)/i);
    if (descMatch) changes.description = descMatch[1].trim();

    const faqSectionMatch = text.match(/\*\*FAQs Sugeridas:\*\*\s*([\s\S]+?)(?=\n\*\*|$)/i);
    if (faqSectionMatch) {
      const faqText = faqSectionMatch[1];
      const faqs = [];
      const faqRegex = /Q:\s*(.+?)\n+A:\s*([\s\S]+?)(?=\n+Q:|$)/gi;
      let match;
      while ((match = faqRegex.exec(faqText)) !== null) {
        faqs.push({ question: match[1].trim(), answer: match[2].trim() });
      }
      if (faqs.length > 0) changes.faq = faqs;
    }

    return Object.keys(changes).length > 0 ? changes : null;
  };

  const handleSend = async (e, retryMsg = null) => {
    e?.preventDefault();
    const userMsg = retryMsg || input.trim();
    
    if (!userMsg || isProcessing.current || isOverLimit) return;
    
    isProcessing.current = true;
    setLoading(true);

    // 5. Detailed Console Logging
    console.log('[CHAT] handleSend called with message:', userMsg);

    if (!retryMsg) {
      setInput('');
      playMessageSentSound();
      
      // 1. Immediate User Message Display
      const userMsgObj = { id: `user-${Date.now()}`, role: 'user', content: userMsg };
      setMessages(prev => {
        const newMessages = [...prev, userMsgObj];
        console.log('[CHAT] setMessages called (user msg). New state:', newMessages);
        return newMessages;
      });
      
      // Save user message to db silently
      if (assistantId) {
        supabase.from('chat_messages').insert([{
          assistant_id: assistantId,
          role: 'user',
          content: userMsg
        }]).then(({ error }) => {
          if (error) console.error('[CHAT] Error saving user message:', error);
        });
      }
    }

    // Create placeholder for assistant response
    const aiMessageId = `ai-${Date.now()}`;
    assistantMessageIdRef.current = aiMessageId;
    
    setMessages(prev => {
      const newMessages = [...prev, { id: aiMessageId, role: 'assistant', content: '', isLoading: true }];
      console.log('[CHAT] setMessages called (assistant placeholder). New state:', newMessages);
      return newMessages;
    });

    try {
      const currentState = {
        descricao: formData?.description || '',
        catalogo: [],
        contato: [],
        personalidade: { estilo: formData?.personality || '', comportamento: '' },
        regras: []
      };
      
      const contextWithMemory = assistantId 
        ? await buildContextWithMemory(assistantId, currentState)
        : { currentState, conversationHistory: [], extractedDataHistory: [] };

      if (onUpdateSummary && !retryMsg) {
        onUpdateSummary(`\nUser: ${userMsg}`);
      }

      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) throw sessionError;

      const functionUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/refine-assistant-chat`;
      
      const charCount = userMsg.length;
      let timeoutMs = 45000; 
      if (charCount >= 500 && charCount <= 2000) timeoutMs = 60000;
      else if (charCount > 2000) timeoutMs = 90000;

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
      
      const refused = getRefusedFields();
      let promptEnhancement = userMsg;
      if (refused.length > 0) {
         promptEnhancement = `[INSTRUÇÃO DE SISTEMA: Você é um ASSISTENTE FOCADO EM VENDAS. Sugira abordagens persuasivas e proativas. Tente entender o cliente. IMPORTANTE: O usuário ignorou preencher: ${refused.join(', ')}. Não insista nestes campos. Você PODE falar sobre preços e valores.]\n\nUser: ${userMsg}`;
      } else {
         promptEnhancement = `[INSTRUÇÃO DE SISTEMA: Você é um ASSISTENTE DE VENDAS proativo. Encoraje abordagens humanizadas. Sugira perguntas clarificadoras ("Qual seu tamanho?"). Seja amigável e conduza à venda.]\n\nUser: ${userMsg}`;
      }

      const response = await fetch(functionUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token || import.meta.env.VITE_SUPABASE_ANON_KEY}`
        },
        body: JSON.stringify({
          message: promptEnhancement,
          currentData: {
            name: formData?.assistantName,
            personality: formData?.personality,
            description: formData?.description,
            faq: formData?.faqItems,
            conversation_summary: formData?.conversation_summary
          },
          contextWithMemory
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
           throw new Error('jwt expired');
        }
        const errorData = await response.json().catch(() => ({ error: 'Falha desconhecida de rede.' }));
        throw new Error(errorData.error || errorData.message || `Erro de conexão HTTP ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let fullText = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        
        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n').filter(line => line.trim() !== '');
        
        for (const line of lines) {
          if (line === 'data: [DONE]') continue;
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              const token = data.choices[0]?.delta?.content || '';
              if (token) {
                fullText += token;
                
                // 5. Detailed Console Logging
                console.log('[CHAT] Streaming chunk arrived:', token);
                
                // 2. Streaming State Updates
                setMessages(prev => {
                  const updated = prev.map(msg => 
                    msg.id === aiMessageId 
                      ? { ...msg, content: fullText, isLoading: false } 
                      : msg
                  );
                  return updated;
                });
              }
            } catch (e) {
              // Ignore parse errors on chunks
            }
          }
        }
      }

      // 3. Complete Event Handling
      console.log('[CHAT] Streaming complete. Final text length:', fullText.length);
      const policyCheck = validateChatResponse(fullText, 'intelligent-refinement-bot');
      
      let finalContentToDisplay = '';
      let suggestions = null;

      if (policyCheck.isViolation) {
        finalContentToDisplay = policyCheck.blockedResponse;
      } else {
        suggestions = extractSuggestions(fullText);
        let visibleText = fullText
          .replace(/\*\*Sugestão de Nome:\*\*\s*([^\n]+)\n?/gi, '')
          .replace(/\*\*Personalidade Sugerida:\*\*\s*([^\n]+)\n?/gi, '')
          .replace(/\*\*Descrição Sugerida:\*\*\s*([\s\S]+?)(?=\n\*\*|$)/gi, '')
          .replace(/\*\*FAQs Sugeridas:\*\*\s*([\s\S]+?)(?=\n\*\*|$)/gi, '')
          .trim();

        if (!visibleText) {
           visibleText = "Preparei algumas sugestões de vendas para você analisar!";
        }
        finalContentToDisplay = visibleText;
      }

      setMessages(prev => {
        const finalMessages = prev.map(msg => 
          msg.id === aiMessageId 
            ? { ...msg, content: finalContentToDisplay, isViolation: policyCheck.isViolation, isLoading: false } 
            : msg
        );
        console.log('[CHAT] Final setMessages called (complete). New state:', finalMessages);
        return finalMessages;
      });

      playMessageReceivedSound();
      
      if (assistantId) {
        await saveToMemoryHistory(assistantId, userMsg, finalContentToDisplay, {});
        // Save to chat_messages silently
        supabase.from('chat_messages').insert([{
          assistant_id: assistantId,
          role: 'assistant',
          content: finalContentToDisplay
        }]).then(({ error }) => {
          if (error) console.error('[CHAT] Error saving assistant message:', error);
        });
      }
      
      if (onUpdateSummary) onUpdateSummary(`\nAssistant: ${finalContentToDisplay}`);

      if (suggestions && !policyCheck.isViolation) {
         setModalState({
            isOpen: true,
            suggestedChanges: suggestions
         });
      }

    } catch (err) {
      if (await handleAuthError(err)) {
        isProcessing.current = false;
        setLoading(false);
        return;
      }
      
      let errorMsg = 'Não foi possível obter resposta da IA.';
      let isTimeout = false;

      if (err.name === 'AbortError' || err.message?.toLowerCase().includes('timeout') || err.message?.toLowerCase().includes('demorou')) {
          errorMsg = 'Processamento demorou muito. Tente novamente.';
          isTimeout = true;
      } else if (err.message?.toLowerCase().includes('token_limit') || err.message?.toLowerCase().includes('muito longa')) {
          errorMsg = 'Mensagem muito longa. Tente encurtar ou dividir em partes.';
      } else {
          errorMsg = err.message || errorMsg;
      }
      
      toast.error(errorMsg);

      setMessages(prev => prev.map(msg => 
        msg.id === assistantMessageIdRef.current
          ? { ...msg, content: `Desculpe, ocorreu um erro: ${errorMsg}`, isError: true, originalUserMessage: userMsg, isLoading: false }
          : msg
      ));
    } finally {
      setLoading(false);
      isProcessing.current = false;
    }
  };

  const removeErrorAndRetry = (errorMsgId, originalText) => {
    setMessages(prev => prev.filter(m => m.id !== errorMsgId));
    handleSend(null, originalText);
  };

  const handleModalApply = (changes) => {
    const mappedChanges = {};
    if (changes.name) mappedChanges.assistantName = changes.name;
    if (changes.description) mappedChanges.description = changes.description;
    if (changes.personality) mappedChanges.personality = changes.personality;
    if (changes.faq) mappedChanges.faqItems = changes.faq;
    
    onApplySuggestion(mappedChanges);
    setModalState({ isOpen: false, suggestedChanges: null });
    
    const msg = "Excelente! As configurações de vendas foram aplicadas. Como quer que o assistente aborde objeções de preço?";
    setMessages(prev => [...prev, { id: `ai-${Date.now()}`, role: 'assistant', content: msg }]);
    playMessageReceivedSound();
    if (onUpdateSummary) onUpdateSummary(`\nSystem: User accepted changes. \nAssistant: ${msg}`);
  };

  const handleModalCancel = () => {
    setModalState({ isOpen: false, suggestedChanges: null });
    const msg = "Tudo bem, descartei essas sugestões. Como você prefere configurar a abordagem de vendas?";
    setMessages(prev => [...prev, { id: `ai-${Date.now()}`, role: 'assistant', content: msg }]);
    playMessageReceivedSound();
    if (onUpdateSummary) onUpdateSummary(`\nSystem: User cancelled changes. \nAssistant: ${msg}`);
  };

  return (
    <>
      <div className="flex flex-col h-[600px] bg-black rounded-2xl overflow-hidden border border-white/10">
        <div className="p-4 bg-neutral-900 border-b border-white/10 flex items-center gap-3">
          <Bot className="w-5 h-5 text-white" />
          <h3 className="font-semibold text-white">Especialista de Vendas IA (GPT-4.1)</h3>
        </div>
        
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
          {messages.map((msg, i) => (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              key={msg.id || i} 
              className={`flex items-start gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div className={`p-2 rounded-full shrink-0 ${msg.role === 'user' ? 'bg-white text-black' : msg.isError || msg.isViolation ? 'bg-red-900/50 text-red-500' : 'bg-neutral-800 text-white'}`}>
                {msg.role === 'user' ? <User className="w-4 h-4" /> : (msg.isError || msg.isViolation) ? <AlertCircle className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>
              <div className={`flex flex-col gap-2 max-w-[85%]`}>
                <div className={`p-3 rounded-2xl text-sm whitespace-pre-wrap leading-relaxed shadow-sm ${
                  msg.role === 'user' 
                    ? 'bg-white text-black rounded-tr-sm font-medium' 
                    : (msg.isError || msg.isViolation)
                      ? 'bg-red-950/30 border border-red-900/50 text-red-200 rounded-tl-sm'
                      : 'bg-neutral-900 border border-white/5 text-neutral-200 rounded-tl-sm'
                }`}>
                  {msg.isLoading && !msg.content ? (
                    <div className="flex items-center gap-2 text-neutral-400">
                      <Loader2 className="w-4 h-4 animate-spin" /> Analisando com memória...
                    </div>
                  ) : (
                    <>
                      {msg.content}
                      {msg.isLoading && <span className="inline-block w-1.5 h-4 bg-white/70 ml-1 animate-pulse align-middle" />}
                    </>
                  )}
                </div>
                {msg.isError && msg.originalUserMessage && (
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => removeErrorAndRetry(msg.id, msg.originalUserMessage)}
                    className="self-start text-xs border-white/10 hover:bg-white/5 text-white"
                  >
                    <RefreshCcw className="w-3 h-3 mr-2" /> Tentar Reenviar
                  </Button>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        <div className="p-3 bg-neutral-900 border-t border-white/10 flex flex-col gap-1">
          <form onSubmit={handleSend} className="flex gap-2">
            <Input 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Descreva catálogo, preços ou objeções comuns..."
              className={`bg-black border-none text-white focus-visible:ring-1 focus-visible:ring-white h-12 ${isOverLimit ? 'ring-1 ring-red-500' : ''}`}
              disabled={loading}
            />
            <Button 
              type="submit" 
              size="icon" 
              disabled={!input.trim() || loading || isOverLimit} 
              className="bg-white text-black hover:bg-neutral-200 shrink-0 h-12 w-12 rounded-xl disabled:opacity-50"
              title={isOverLimit ? "Mensagem excede o limite de 4000 tokens" : "Enviar"}
            >
              <Send className="w-5 h-5" />
            </Button>
          </form>
          <div className="text-xs px-2 flex items-center h-4">
            {input.trim().length > 0 && (
              <>
                <span className={isOverLimit ? "text-red-500 font-bold" : isApproachingLimit ? "text-yellow-500 font-medium" : "text-neutral-500"}>
                  ~{tokensCount} tokens
                </span>
                {isApproachingLimit && !isOverLimit && <span className="text-yellow-500 ml-2 animate-pulse">Mensagem próxima do limite</span>}
                {isOverLimit && <span className="text-red-500 ml-2 font-medium">Mensagem muito longa</span>}
              </>
            )}
          </div>
        </div>
      </div>

      <UpdatePreviewModal 
        isOpen={modalState.isOpen}
        onClose={handleModalCancel}
        currentData={{
          name: formData?.assistantName,
          personality: formData?.personality,
          description: formData?.description,
          faq: formData?.faqItems
        }}
        suggestedChanges={modalState.suggestedChanges}
        onApply={handleModalApply}
      />
    </>
  );
}