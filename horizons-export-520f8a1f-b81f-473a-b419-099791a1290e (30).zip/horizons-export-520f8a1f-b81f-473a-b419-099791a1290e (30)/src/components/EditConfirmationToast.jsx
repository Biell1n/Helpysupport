import React from 'react';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Undo2 } from 'lucide-react';

// Wrapper hook to easily trigger the confirmation toast
export function useEditConfirmationToast() {
  const { toast } = useToast();

  const showConfirmation = ({ action, sectionName, status, onUndo }) => {
    toast({
      title: action || 'Alteração realizada',
      description: (
        <div className="flex flex-col gap-1 mt-1">
          {sectionName && <span className="text-sm">Seção: {sectionName}</span>}
          {status && <span className={`text-xs font-medium ${status === 'critical' ? 'text-red-400' : status === 'incomplete' ? 'text-orange-400' : 'text-green-400'}`}>Status: {status}</span>}
        </div>
      ),
      action: onUndo ? (
        <Button 
          variant="outline" 
          size="sm" 
          onClick={onUndo}
          className="border-white/20 hover:bg-white/10"
        >
          <Undo2 className="w-3 h-3 mr-2" />
          Desfazer
        </Button>
      ) : undefined,
      duration: 5000,
    });
  };

  return { showConfirmation };
}

// Dummy component just to satisfy potential explicit imports if requested
export default function EditConfirmationToast() {
  return null;
}