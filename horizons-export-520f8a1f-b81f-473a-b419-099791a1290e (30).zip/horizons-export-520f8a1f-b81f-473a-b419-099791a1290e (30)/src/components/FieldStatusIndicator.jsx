import React from 'react';
import { CheckCircle2, AlertCircle, XCircle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

export default function FieldStatusIndicator({ isComplete, isIgnored, missing = [] }) {
  if (isIgnored) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger>
            <div className="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full bg-neutral-800 text-neutral-400">
              <XCircle className="w-3 h-3" />
              <span>Ignorado</span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>Este campo foi marcado como ignorado.</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  if (isComplete) {
    return (
      <div className="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full bg-green-500/20 text-green-500">
        <CheckCircle2 className="w-3 h-3" />
        <span>Completo</span>
      </div>
    );
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger>
          <div className="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full bg-yellow-500/20 text-yellow-500">
            <AlertCircle className="w-3 h-3" />
            <span>Incompleto</span>
          </div>
        </TooltipTrigger>
        <TooltipContent>
          {missing.length > 0 ? (
            <div>
              <p className="font-semibold mb-1">Falta preencher:</p>
              <ul className="list-disc pl-4 text-xs">
                {missing.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>
          ) : (
            <p>Este campo precisa ser preenchido.</p>
          )}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}