import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  Info, 
  Target, 
  Lightbulb,
  Plus,
  MessageSquare,
  Phone
} from 'lucide-react';
import { useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';

export default function IntelligentSuggestionsPanel({ 
  suggestions, 
  nextStep, 
  completionStatus,
  progress 
}) {
  const {
    getCompletionStatus,
    getFieldLabel,
    addItem
  } = useAssistantMemoryContext();

  const status = completionStatus || getCompletionStatus();

  const getStatusIcon = (statusCode) => {
    switch (statusCode) {
      case 'green': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'orange': return <Clock className="w-4 h-4 text-orange-500" />;
      case 'red': return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'gray': return <Info className="w-4 h-4 text-gray-400" />;
      default: return <Info className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusBadgeVariant = (statusCode) => {
    switch (statusCode) {
      case 'green': return 'default';
      case 'orange': return 'secondary';
      case 'red': return 'destructive';
      case 'gray': return 'outline';
      default: return 'outline';
    }
  };

  const quickAddWhatsApp = async () => {
    try {
      await addItem('contato', { type: 'WhatsApp', value: '' });
    } catch (err) {
      // Error handled by context
    }
  };

  const quickAddInstagram = async () => {
    try {
      await addItem('contato', { type: 'Instagram', value: '' });
    } catch (err) {
      // Error handled by context
    }
  };

  return (
    <div className="space-y-4 mt-4">
      {progress !== undefined && (
        <Card className="border-l-4 border-l-blue-500 bg-gradient-to-r from-blue-50/5 to-transparent">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-white">Progresso do Seu Assistente</p>
                <p className="text-xs text-neutral-400 mt-1">
                  {progress < 50 ? 'Começando a configurar' : 
                   progress < 100 ? 'Quase completo!' : 
                   'Configuração completa! 🎉'}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-32 h-2 bg-neutral-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-500 to-green-500 transition-all duration-500"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <span className="text-sm font-semibold text-blue-400">{progress}%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {status?.missingMandatory && status.missingMandatory.length > 0 && (
        <Card className="border-l-4 border-l-red-500">
          <CardHeader>
            <CardTitle className="text-lg flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-red-500" />
              <span>Campos Obrigatórios Faltando</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {status.missingMandatory.map((field, idx) => (
              <div key={idx} className="flex items-center gap-2 p-2 rounded-lg bg-red-500/10 border border-red-500/20">
                <AlertCircle className="w-4 h-4 text-red-500" />
                <span className="text-sm text-white">{getFieldLabel(field)}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {nextStep && (
        <Card className="border-l-4 border-l-green-500 bg-gradient-to-r from-green-50/5 to-transparent">
          <CardHeader>
            <CardTitle className="text-lg flex items-center space-x-2">
              <Target className="w-5 h-5 text-green-500" />
              <span>Próximo Passo</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-neutral-300">{nextStep}</p>
          </CardContent>
        </Card>
      )}

      {suggestions && suggestions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center space-x-2">
              <Lightbulb className="w-5 h-5 text-yellow-500" />
              <span>Sugestões Inteligentes</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {suggestions.map((suggestion, index) => (
              <div 
                key={index} 
                className="p-3 rounded-lg border border-white/10 hover:border-blue-500/30 transition-colors bg-neutral-900/30"
              >
                <div className="flex items-start space-x-3">
                  <div className="mt-0.5">
                    {getStatusIcon(suggestion.status || 'gray')}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-sm font-semibold text-white">
                        {suggestion.title || suggestion.field}
                      </h4>
                      {suggestion.status && (
                        <Badge variant={getStatusBadgeVariant(suggestion.status)}>
                          {suggestion.statusLabel || 'Info'}
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-neutral-400">
                      {suggestion.description || suggestion.suggestion}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {status?.missingMandatory?.includes('contato') && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm flex items-center space-x-2">
              <Plus className="w-4 h-4 text-blue-400" />
              <span>Ações Rápidas</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={quickAddWhatsApp}
              className="border-white/10 hover:border-green-500/50"
            >
              <Phone className="w-4 h-4 mr-2 text-green-500" />
              Adicionar WhatsApp
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={quickAddInstagram}
              className="border-white/10 hover:border-pink-500/50"
            >
              <MessageSquare className="w-4 h-4 mr-2 text-pink-500" />
              Adicionar Instagram
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}