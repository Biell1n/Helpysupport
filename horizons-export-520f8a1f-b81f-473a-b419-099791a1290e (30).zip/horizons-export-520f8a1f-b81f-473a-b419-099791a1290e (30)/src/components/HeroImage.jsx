import React, { useEffect, useRef } from 'react';

/**
 * HeroImage Component
 * 
 * Displays a full-screen or container-filling background video.
 * Implements iOS interaction unlock for autoplay and hides all default browser controls/UI.
 */
const HeroImage = ({ 
  videoSrc = "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4", 
  className = "" 
}) => {
  const videoRef = useRef(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    let unlocked = false;

    const removeListeners = () => {
      document.removeEventListener('touchstart', unlockVideo);
      document.removeEventListener('click', unlockVideo);
      window.removeEventListener('scroll', unlockVideo);
    };

    const unlockVideo = async () => {
      if (unlocked || !video) return;
      try {
        await video.play();
        unlocked = true;
        removeListeners();
      } catch (err) {
        // Silently ignore if interaction didn't unlock it yet
      }
    };

    const addListeners = () => {
      document.addEventListener('touchstart', unlockVideo, { passive: true });
      document.addEventListener('click', unlockVideo, { passive: true });
      window.addEventListener('scroll', unlockVideo, { passive: true });
    };

    const attemptPlay = async () => {
      try {
        // Attempt immediate autoplay
        await video.play();
        unlocked = true;
      } catch (error) {
        // Autoplay prevented (iOS restriction/low power mode), wait for user interaction
        addListeners();
      }
    };

    attemptPlay();

    return removeListeners;
  }, []);

  return (
    <div className={`relative w-full h-full overflow-hidden ${className}`}>
      {/* Background layer (lowest) */}
      <div className="absolute inset-0 bg-neutral-900 z-0" />
      
      {/* Video layer (middle) */}
      <video
        ref={videoRef}
        src={videoSrc}
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
        // Prevent browser features like "download", "remote playback", etc.
        controlsList="nodownload nofullscreen noremoteplayback"
        // CSS class handles hiding scrollbars and pointer events for native controls
        className="absolute inset-0 w-full h-full object-cover z-10 pointer-events-none"
        style={{
          // Additional safety to ensure no controls are clickable or visible
          appearance: 'none',
          WebkitAppearance: 'none'
        }}
      />

      {/* Overlay layer (top) */}
      <div className="absolute inset-0 bg-black/40 z-20 pointer-events-none" />
      
      {/* 
        Tailwind and CSS specifically for this component to hide any potential 
        native video controls that might flicker on mobile browsers.
      */}
      <style>{`
        video::-webkit-media-controls {
          display: none !important;
        }
        video::-webkit-media-controls-enclosure {
          display: none !important;
        }
        video::-webkit-media-controls-panel {
          display: none !important;
        }
        video::-webkit-media-controls-play-button {
          display: none !important;
        }
        video::-webkit-media-controls-start-playback-button {
          display: none !important;
          -webkit-appearance: none;
        }
      `}</style>
    </div>
  );
};

export default HeroImage;