import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

export default function HelpyChat({ session, addMessage, updateConfiguration, updateSessionState }) {
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef(null);
  const { toast } = useToast();

  const history = session?.conversation_history || [];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history, isTyping]);

  useEffect(() => {
    if (session && history.length === 0 && session.assistant_type) {
      addMessage('assistant', `Olá! Eu sou o Helpy e vou te ajudar a criar seu assistente do tipo **${session.assistant_type === 'venda' ? 'Vendas' : 'Informativo'}**. Podemos começar preenchendo as informações principais. Qual o nome que você quer dar a ele?`);
    }
  }, [session?.assistant_type, history.length]);

  const handleSend = async (e) => {
    e?.preventDefault();
    if (!input.trim() || !session) return;

    const userMsg = input.trim();
    setInput('');
    await addMessage('user', userMsg);
    setIsTyping(true);

    try {
      const { data, error } = await supabase.functions.invoke('helpy-brain', {
        body: {
          session_id: session.id,
          user_message: userMsg,
          current_configuration: session.configuration,
          conversation_history: session.conversation_history || [],
          active_fields: session.active_fields,
          ignored_fields: session.ignored_fields,
          assistant_type: session.assistant_type
        }
      });

      if (error) throw error;

      if (data.success) {
        if (data.configuration_updates && Object.keys(data.configuration_updates).length > 0) {
          await updateConfiguration(data.configuration_updates);
        }
        
        let newIgnored = { ...session.ignored_fields };
        data.fields_to_ignore?.forEach(f => newIgnored[f] = true);
        data.fields_to_activate?.forEach(f => delete newIgnored[f]);

        await updateSessionState({
          ignored_fields: newIgnored,
          brain_state: data.brain_state
        });

        await addMessage('assistant', data.ai_response);
      } else {
        throw new Error(data.error || 'Unknown error');
      }

    } catch (err) {
      console.error(err);
      toast({ title: 'Erro de comunicação', description: 'Não consegui processar a resposta agora. Tente novamente.', variant: 'destructive' });
      await addMessage('assistant', 'Desculpe, tive um probleminha técnico aqui. Poderia repetir?');
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden relative">
      <div className="p-4 border-b border-neutral-800 bg-neutral-950 flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold">H</div>
        <div>
          <h3 className="font-bold text-white leading-none">Helpy AI</h3>
          <span className="text-xs text-neutral-400">Seu assistente de configuração</span>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {history.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] rounded-2xl p-3 text-sm ${msg.role === 'user' ? 'bg-primary text-primary-foreground rounded-tr-none' : 'bg-neutral-800 text-white rounded-tl-none'}`}>
              {msg.content}
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-neutral-800 text-neutral-400 rounded-2xl rounded-tl-none p-3 text-sm flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin" /> Helpy está pensando...
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSend} className="p-3 bg-neutral-950 border-t border-neutral-800 flex gap-2">
        <Input 
          value={input} 
          onChange={e => setInput(e.target.value)} 
          placeholder="Digite sua mensagem para o Helpy..." 
          className="flex-1 bg-neutral-900 border-neutral-800 text-white placeholder-neutral-500"
          disabled={isTyping || !session?.assistant_type}
        />
        <Button type="submit" disabled={isTyping || !input.trim() || !session?.assistant_type} className="bg-blue-600 hover:bg-blue-700 text-white">
          <Send className="w-4 h-4" />
        </Button>
      </form>
    </div>
  );
}