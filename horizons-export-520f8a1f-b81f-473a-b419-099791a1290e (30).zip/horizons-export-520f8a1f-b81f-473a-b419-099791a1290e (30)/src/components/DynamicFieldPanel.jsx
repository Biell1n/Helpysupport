import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { X, Plus, Trash2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function DynamicFieldPanel({ fieldName, fieldData, onUpdate }) {
  if (!fieldData) return null;

  const getStatusColor = (status) => {
    switch(status) {
      case 'completo': return 'bg-green-500';
      case 'parcial': return 'bg-yellow-500';
      case 'incompleto': return 'bg-red-500';
      case 'ignorado': return 'bg-gray-500';
      default: return 'bg-neutral-500';
    }
  };

  const handleSubfieldChange = (subfieldName, value) => {
    const updatedSubfields = {
      ...fieldData.subfields,
      [subfieldName]: { ...fieldData.subfields[subfieldName], value, status: value ? 'completo' : 'incompleto' }
    };
    onUpdate(fieldName, { subfields: updatedSubfields });
  };

  const handleSubfieldIgnore = (subfieldName) => {
    const isIgnored = fieldData.subfields[subfieldName].ignored;
    const updatedSubfields = {
      ...fieldData.subfields,
      [subfieldName]: { ...fieldData.subfields[subfieldName], ignored: !isIgnored, value: !isIgnored ? '' : fieldData.subfields[subfieldName].value }
    };
    onUpdate(fieldName, { subfields: updatedSubfields });
  };

  const handleItemAdd = (itemTemplate) => {
    onUpdate(fieldName, { items: [...(fieldData.items || []), itemTemplate] });
  };

  const handleItemRemove = (index) => {
    const newItems = [...fieldData.items];
    newItems.splice(index, 1);
    onUpdate(fieldName, { items: newItems });
  };

  const handleItemSubfieldChange = (itemIndex, subfieldName, value) => {
    const newItems = [...fieldData.items];
    newItems[itemIndex].subfields[subfieldName].value = value;
    newItems[itemIndex].subfields[subfieldName].status = value ? 'completo' : 'incompleto';
    onUpdate(fieldName, { items: newItems });
  };

  const handleItemSubfieldIgnore = (itemIndex, subfieldName) => {
    const newItems = [...fieldData.items];
    const isIgnored = newItems[itemIndex].subfields[subfieldName].ignored;
    newItems[itemIndex].subfields[subfieldName].ignored = !isIgnored;
    if (!isIgnored) newItems[itemIndex].subfields[subfieldName].value = '';
    onUpdate(fieldName, { items: newItems });
  };

  return (
    <div className="bg-neutral-900 border border-white/10 rounded-xl p-4 space-y-4 relative">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={`w-3 h-3 rounded-full ${getStatusColor(fieldData.status)}`} />
          <h3 className="font-bold text-white capitalize">{fieldName}</h3>
        </div>
        <span className="text-xs text-neutral-400 bg-neutral-800 px-2 py-1 rounded capitalize">{fieldData.status}</span>
      </div>

      {fieldData.subfields && (
        <div className="space-y-3">
          {Object.entries(fieldData.subfields).map(([sfName, sfData]) => (
            <div key={sfName} className="flex gap-2 items-start">
              <div className="flex-1">
                <label className="text-xs text-neutral-400 capitalize mb-1 block">{sfName}</label>
                {sfData.ignored ? (
                  <div className="p-2 border border-neutral-800 bg-neutral-950 text-neutral-600 rounded text-sm">Ignorado</div>
                ) : (
                  <Input 
                    value={sfData.value} 
                    onChange={(e) => handleSubfieldChange(sfName, e.target.value)}
                    className="bg-neutral-950 border-neutral-800 text-white text-sm"
                  />
                )}
              </div>
              <Button variant="ghost" size="icon" className="mt-5 text-neutral-500 hover:text-white" onClick={() => handleSubfieldIgnore(sfName)}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      )}

      {fieldData.items !== undefined && (
        <div className="space-y-4">
          {fieldData.items.map((item, idx) => (
            <div key={idx} className="bg-neutral-950 p-3 rounded-lg border border-neutral-800 relative">
              <Button variant="ghost" size="icon" className="absolute top-2 right-2 text-red-400 hover:bg-red-900/20" onClick={() => handleItemRemove(idx)}>
                <Trash2 className="w-4 h-4" />
              </Button>
              <h4 className="text-xs font-bold text-neutral-500 mb-3 uppercase">Item {idx + 1}</h4>
              <div className="space-y-3">
                {Object.entries(item.subfields).map(([sfName, sfData]) => (
                  <div key={sfName} className="flex gap-2 items-start">
                    <div className="flex-1">
                      <label className="text-xs text-neutral-400 capitalize mb-1 block">{sfName}</label>
                      {sfData.ignored ? (
                         <div className="p-2 border border-neutral-800 bg-neutral-900/50 text-neutral-600 rounded text-sm">Ignorado</div>
                      ) : (
                        sfName === 'tipo' && fieldName === 'contato' ? (
                          <Select value={sfData.value} onValueChange={(val) => handleItemSubfieldChange(idx, sfName, val)}>
                            <SelectTrigger className="w-full bg-neutral-900 border-neutral-800 text-white">
                              <SelectValue placeholder="Selecione..." />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Telefone">Telefone</SelectItem>
                              <SelectItem value="WhatsApp">WhatsApp</SelectItem>
                              <SelectItem value="Email">Email</SelectItem>
                              <SelectItem value="Rede Social">Rede Social</SelectItem>
                              <SelectItem value="Outro">Outro</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : sfName === 'descricao' ? (
                           <Textarea 
                             value={sfData.value} 
                             onChange={(e) => handleItemSubfieldChange(idx, sfName, e.target.value)}
                             className="bg-neutral-900 border-neutral-800 text-white text-sm"
                           />
                        ) : (
                          <Input 
                            value={sfData.value} 
                            onChange={(e) => handleItemSubfieldChange(idx, sfName, e.target.value)}
                            className="bg-neutral-900 border-neutral-800 text-white text-sm"
                          />
                        )
                      )}
                    </div>
                    <Button variant="ghost" size="icon" className="mt-5 text-neutral-500 hover:text-white" onClick={() => handleItemSubfieldIgnore(idx, sfName)}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          ))}
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full border-dashed border-neutral-700 text-neutral-400 hover:text-white"
            onClick={() => {
              if (fieldName === 'contato') {
                handleItemAdd({ subfields: { tipo: { value: '', status: 'incompleto', ignored: false }, valor: { value: '', status: 'incompleto', ignored: false } } });
              } else if (fieldName === 'produtos') {
                handleItemAdd({ subfields: { nome: { value: '', status: 'incompleto', ignored: false }, preco: { value: '', status: 'incompleto', ignored: false }, descricao: { value: '', status: 'incompleto', ignored: false } } });
              }
            }}
          >
            <Plus className="w-4 h-4 mr-2" /> Adicionar {fieldName === 'contato' ? 'Contato' : 'Produto'}
          </Button>
        </div>
      )}

      {fieldData.diagnostico && (
        <div className="mt-3 p-3 bg-blue-900/10 border border-blue-500/20 rounded text-sm text-blue-200">
          <p className="font-semibold text-xs mb-1 uppercase text-blue-400">Diagnóstico AI</p>
          {fieldData.diagnostico}
        </div>
      )}
    </div>
  );
}