import React from 'react';
import { useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';
import DynamicFieldPanel from '@/components/DynamicFieldPanel';

export default function EditableDataPanel() {
  const { structuredState, updateStructuredField } = useAssistantMemoryContext();

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-10">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white">Dados do Assistente</h2>
        <p className="text-neutral-400 text-sm">Gerencie os dados estruturados do seu assistente.</p>
      </div>

      <div className="grid gap-6">
        {Object.entries(structuredState).map(([key, data]) => (
          <DynamicFieldPanel 
            key={key} 
            fieldName={key} 
            fieldData={data} 
            onUpdate={updateStructuredField} 
          />
        ))}
      </div>
    </div>
  );
}