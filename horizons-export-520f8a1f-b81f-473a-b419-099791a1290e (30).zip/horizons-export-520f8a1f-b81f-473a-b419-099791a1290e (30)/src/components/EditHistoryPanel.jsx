import React from 'react';
import { useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';
import { Undo2, Clock, Trash2, History } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function EditHistoryPanel() {
  const { history, performUndo, canUndo, clearHistory, memory } = useAssistantMemoryContext();

  const handleUndo = () => {
    performUndo();
  };

  const handleClear = () => {
    if (memory.id) {
       clearHistory(memory.id);
    }
  };

  if (!history || history.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-neutral-500 border border-white/10 rounded-2xl bg-neutral-900/30">
        <History className="w-8 h-8 mb-3 opacity-50" />
        <p className="text-sm">Nenhum histórico de edições.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-neutral-900/50 border border-white/10 rounded-2xl overflow-hidden">
      <div className="p-4 border-b border-white/10 flex items-center justify-between bg-neutral-950/50">
        <h3 className="font-bold text-white flex items-center gap-2">
          <Clock className="w-4 h-4 text-blue-400" />
          Histórico de Edições
        </h3>
        <div className="flex gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleClear}
            className="h-8 px-2 text-neutral-400 hover:text-red-400"
            title="Limpar histórico"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleUndo} 
            disabled={!canUndo()}
            className="h-8 border-white/20 bg-transparent text-white hover:bg-white/10"
          >
            <Undo2 className="w-4 h-4 mr-2" />
            Desfazer Último
          </Button>
        </div>
      </div>
      
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-white/10 before:to-transparent">
          {[...history].reverse().map((entry, idx) => {
             const date = new Date(entry.timestamp);
             const timeStr = date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
             
             return (
              <div key={entry.id || idx} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white/10 bg-neutral-900 text-neutral-500 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                   <Clock className="w-4 h-4" />
                </div>
                <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-3 rounded-xl border border-white/5 bg-neutral-900/80 shadow-sm">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-sm text-white">{entry.action}</span>
                    <span className="text-xs text-neutral-500 font-mono">{timeStr}</span>
                  </div>
                  <p className="text-xs text-neutral-400">Seção afetada: <span className="text-neutral-200">{entry.sectionName}</span></p>
                </div>
              </div>
             );
          })}
        </div>
      </ScrollArea>
    </div>
  );
}