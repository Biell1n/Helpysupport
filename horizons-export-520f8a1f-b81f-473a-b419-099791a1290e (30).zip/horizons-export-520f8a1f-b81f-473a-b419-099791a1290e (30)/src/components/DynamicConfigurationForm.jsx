import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { X, Plus, Trash2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAssistantMemoryContext } from '@/contexts/AssistantMemoryProvider';

export default function DynamicConfigurationForm() {
  const { structuredState, updateStructuredField } = useAssistantMemoryContext();

  const handleSubfieldChange = (fieldName, subfieldName, value) => {
    const fieldData = structuredState[fieldName];
    const updatedSubfields = {
      ...fieldData.subfields,
      [subfieldName]: { ...fieldData.subfields[subfieldName], value, status: value ? 'completo' : 'incompleto', ignored: false }
    };
    updateStructuredField(fieldName, { subfields: updatedSubfields });
  };

  const handleSubfieldIgnore = (fieldName, subfieldName) => {
    const fieldData = structuredState[fieldName];
    const updatedSubfields = {
      ...fieldData.subfields,
      [subfieldName]: { value: '', status: 'ignorado', ignored: true }
    };
    updateStructuredField(fieldName, { subfields: updatedSubfields });
  };

  const handleItemAdd = (fieldName, template) => {
    const fieldData = structuredState[fieldName];
    updateStructuredField(fieldName, { items: [...(fieldData.items || []), template] });
  };

  const handleItemRemove = (fieldName, index) => {
    const fieldData = structuredState[fieldName];
    const newItems = [...fieldData.items];
    newItems.splice(index, 1);
    updateStructuredField(fieldName, { items: newItems });
  };

  const handleItemSubfieldChange = (fieldName, itemIndex, subfieldName, value) => {
    const fieldData = structuredState[fieldName];
    const newItems = [...fieldData.items];
    newItems[itemIndex].subfields[subfieldName] = { ...newItems[itemIndex].subfields[subfieldName], value, status: value ? 'completo' : 'incompleto', ignored: false };
    updateStructuredField(fieldName, { items: newItems });
  };

  const handleItemSubfieldIgnore = (fieldName, itemIndex, subfieldName) => {
    const fieldData = structuredState[fieldName];
    const newItems = [...fieldData.items];
    newItems[itemIndex].subfields[subfieldName] = { value: '', status: 'ignorado', ignored: true };
    updateStructuredField(fieldName, { items: newItems });
  };

  const renderSubfields = (fieldName, labels) => {
    const fieldData = structuredState[fieldName];
    if (!fieldData || !fieldData.subfields) return null;

    return (
      <div className="space-y-4 bg-neutral-900 border border-neutral-800 rounded-xl p-5">
        <h3 className="text-lg font-bold text-white capitalize">{fieldName}</h3>
        <div className="grid gap-4">
          {Object.entries(fieldData.subfields).map(([sfKey, sfData]) => (
            <div key={sfKey} className="flex gap-2 items-start">
              <div className="flex-1">
                <label className="text-xs text-neutral-400 capitalize mb-1 block">{labels[sfKey] || sfKey}</label>
                {sfData.ignored ? (
                  <div className="h-10 px-3 flex items-center border border-neutral-800 bg-neutral-950/50 text-neutral-500 rounded-md text-sm">Ignorado</div>
                ) : (
                  <Input 
                    value={sfData.value} 
                    onChange={(e) => handleSubfieldChange(fieldName, sfKey, e.target.value)}
                    className="bg-neutral-950 border-neutral-700 text-white placeholder-neutral-600"
                    placeholder={`Digite ${labels[sfKey] || sfKey}`}
                  />
                )}
              </div>
              <Button variant="ghost" size="icon" className="mt-5 text-neutral-500 hover:text-red-400" onClick={() => handleSubfieldIgnore(fieldName, sfKey)} title="Ignorar este campo">
                <X className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderItems = (fieldName, title, labels, isContato) => {
    const fieldData = structuredState[fieldName];
    if (!fieldData || fieldData.items === undefined) return null;

    return (
      <div className="space-y-4 bg-neutral-900 border border-neutral-800 rounded-xl p-5">
        <h3 className="text-lg font-bold text-white">{title}</h3>
        <div className="space-y-4">
          {fieldData.items.map((item, idx) => (
            <div key={idx} className="bg-neutral-950 p-4 rounded-lg border border-neutral-800 relative">
              <Button variant="ghost" size="icon" className="absolute top-2 right-2 text-red-400 hover:bg-red-900/20" onClick={() => handleItemRemove(fieldName, idx)}>
                <Trash2 className="w-4 h-4" />
              </Button>
              <h4 className="text-xs font-bold text-neutral-500 mb-4 uppercase">Item {idx + 1}</h4>
              <div className="grid gap-3">
                {Object.entries(item.subfields).map(([sfKey, sfData]) => (
                  <div key={sfKey} className="flex gap-2 items-start">
                    <div className="flex-1">
                      <label className="text-xs text-neutral-400 capitalize mb-1 block">{labels[sfKey] || sfKey}</label>
                      {sfData.ignored ? (
                        <div className="h-10 px-3 flex items-center border border-neutral-800 bg-neutral-900/50 text-neutral-600 rounded-md text-sm">Ignorado</div>
                      ) : (
                        isContato && sfKey === 'tipo' ? (
                          <Select value={sfData.value} onValueChange={(val) => handleItemSubfieldChange(fieldName, idx, sfKey, val)}>
                            <SelectTrigger className="w-full bg-neutral-900 border-neutral-700 text-white">
                              <SelectValue placeholder="Selecione..." />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Telefone">Telefone</SelectItem>
                              <SelectItem value="WhatsApp">WhatsApp</SelectItem>
                              <SelectItem value="Email">Email</SelectItem>
                              <SelectItem value="Rede Social">Rede Social</SelectItem>
                              <SelectItem value="Outro">Outro</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : sfKey === 'descricao' ? (
                           <Textarea 
                             value={sfData.value} 
                             onChange={(e) => handleItemSubfieldChange(fieldName, idx, sfKey, e.target.value)}
                             className="bg-neutral-900 border-neutral-700 text-white min-h-[80px]"
                             placeholder={`Digite ${labels[sfKey] || sfKey}`}
                           />
                        ) : (
                          <Input 
                            value={sfData.value} 
                            onChange={(e) => handleItemSubfieldChange(fieldName, idx, sfKey, e.target.value)}
                            className="bg-neutral-900 border-neutral-700 text-white"
                            placeholder={`Digite ${labels[sfKey] || sfKey}`}
                          />
                        )
                      )}
                    </div>
                    <Button variant="ghost" size="icon" className="mt-5 text-neutral-500 hover:text-red-400" onClick={() => handleItemSubfieldIgnore(fieldName, idx, sfKey)} title="Ignorar este campo">
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          ))}
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full border-dashed border-neutral-700 text-neutral-400 hover:text-white"
            onClick={() => {
              if (isContato) {
                handleItemAdd(fieldName, { ignored: false, status: 'incompleto', subfields: { tipo: { value: '', status: 'incompleto', ignored: false }, valor: { value: '', status: 'incompleto', ignored: false } } });
              } else {
                handleItemAdd(fieldName, { ignored: false, status: 'incompleto', subfields: { nome: { value: '', status: 'incompleto', ignored: false }, preco: { value: '', status: 'incompleto', ignored: false }, descricao: { value: '', status: 'incompleto', ignored: false } } });
              }
            }}
          >
            <Plus className="w-4 h-4 mr-2" /> Adicionar {isContato ? 'Contato' : 'Produto'}
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 pb-20 max-w-2xl">
      {renderSubfields('descricao', { nicho: 'Nicho', caracteristicas: 'Características', diferenciais: 'Diferenciais' })}
      {renderSubfields('endereco', { rua: 'Rua', numero: 'Número', bairro: 'Bairro', cidade: 'Cidade', complemento: 'Complemento', referencia: 'Referência' })}
      {renderItems('contato', 'Canais de Contato', { tipo: 'Tipo', valor: 'Valor / Link / Número' }, true)}
      {renderItems('produtos', 'Produtos e Serviços', { nome: 'Nome do Produto', preco: 'Preço', descricao: 'Descrição detalhada' }, false)}
    </div>
  );
}