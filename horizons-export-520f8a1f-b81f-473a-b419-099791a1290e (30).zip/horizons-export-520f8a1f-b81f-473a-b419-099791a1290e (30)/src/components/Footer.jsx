import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer({ className = "" }) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className={`py-12 px-4 border-t border-neutral-900 bg-black text-neutral-400 ${className}`}>
      <div className="container mx-auto max-w-6xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
           <div className="col-span-1 md:col-span-2">
              <Link to="/" className="text-2xl font-bold text-white mb-4 flex items-center gap-2 inline-block">
                <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                  <span className="text-black font-black text-lg">H</span>
                </div>
                Helpy
              </Link>
              <p className="mt-4 max-w-sm text-neutral-500 leading-relaxed">
                Plataforma premium para criação de assistentes virtuais inteligentes. Transforme o atendimento do seu negócio com IA.
              </p>
           </div>
           
           <div>
              <h4 className="text-white font-semibold mb-4">Produto</h4>
              <ul className="space-y-2">
                 <li><Link to="/#features" className="hover:text-white transition-colors">Recursos</Link></li>
                 <li><Link to="/#pricing" className="hover:text-white transition-colors">Preços</Link></li>
                 <li><Link to="/assistants" className="hover:text-white transition-colors">Assistentes</Link></li>
              </ul>
           </div>

           <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2">
                 <li><Link to="/terms" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Termos de Uso</Link></li>
                 <li><Link to="/privacy" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Política de Privacidade</Link></li>
                 <li><a href="mailto:contato@helpy.com" className="hover:text-white transition-colors">Contato</a></li>
              </ul>
           </div>
        </div>

        <div className="border-t border-neutral-900 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm">
          <p>&copy; {currentYear} Helpy AI. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}