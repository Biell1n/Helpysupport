import React from 'react';
import { Lightbulb } from 'lucide-react';

export default function ExampleText({ examples }) {
  if (!examples || examples.length === 0) return null;

  return (
    <div className="bg-blue-950/20 border border-blue-900/30 rounded-lg p-3 mt-2">
      <div className="flex items-center gap-1.5 text-blue-400 text-xs font-bold mb-1.5 uppercase tracking-wider">
        <Lightbulb className="w-3.5 h-3.5" /> Exemplos
      </div>
      <ul className="text-sm text-neutral-300 space-y-1 pl-5 list-disc">
        {examples.map((ex, i) => (
          <li key={i} className="italic">"{ex}"</li>
        ))}
      </ul>
    </div>
  );
}