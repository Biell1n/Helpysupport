import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Loader2, Mail, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

export default function ForgotPasswordModal({ isOpen, onClose }) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { data, error: fnError } = await supabase.functions.invoke('send-reset-email', {
        body: { email }
      });

      if (fnError) throw new Error(fnError.message);
      if (data?.error) throw new Error(data.error);

      setSuccess(true);
      toast({
        title: "Sucesso",
        description: "E-mail de redefinição enviado com sucesso.",
      });
    } catch (err) {
      console.error(err);
      setError(err.message || "Ocorreu um erro ao enviar o e-mail.");
      toast({
        title: "Erro",
        description: err.message || "Erro ao processar solicitação",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setSuccess(false);
    setError('');
    setEmail('');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && handleClose()}>
      <DialogContent className="bg-neutral-950 border-none shadow-none text-white sm:max-w-[425px] rounded-3xl p-10 focus:ring-0 focus:outline-none outline-none">
        <DialogHeader className="mb-6">
          <DialogTitle className="text-3xl font-bold tracking-tight text-white">Redefinir Senha</DialogTitle>
          <DialogDescription className="text-neutral-500 font-light mt-2 text-base">
            Digite seu e-mail para receber um link de acesso.
          </DialogDescription>
        </DialogHeader>

        {success ? (
          <div className="py-6 text-center space-y-8">
            <div className="bg-white/5 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
            <div className="space-y-3">
              <h3 className="text-2xl font-bold text-white">Verifique seu e-mail</h3>
              <p className="text-neutral-500 text-base font-light leading-relaxed">
                Enviamos as instruções de recuperação para sua caixa de entrada.
              </p>
            </div>
            <Button 
              onClick={handleClose} 
              className="w-full bg-white hover:bg-neutral-200 text-black font-bold h-14 rounded-2xl transition-all border-none shadow-none outline-none ring-0 focus:ring-0"
            >
              Voltar ao Login
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-8 mt-2">
            <div className="space-y-3">
              <label className="text-sm font-medium text-neutral-400 ml-1">E-mail</label>
              <div className="relative">
                <Mail className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-600" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-14 pr-6 py-4 h-16 bg-neutral-900 border-none rounded-2xl text-white focus:outline-none focus:ring-0 focus:border-none transition-all placeholder:text-neutral-700 text-lg shadow-none"
                  placeholder="exemplo@email.com"
                />
              </div>
            </div>

            {error && (
              <p className="text-red-400 text-sm bg-red-950/10 p-4 rounded-2xl font-light text-center">
                {error}
              </p>
            )}

            <div className="flex flex-col gap-4 pt-2">
              <Button
                type="submit"
                disabled={loading || !email}
                className="w-full bg-white hover:bg-neutral-200 text-black font-bold h-16 text-lg rounded-2xl transition-all border-none shadow-none outline-none ring-0 focus:ring-0"
              >
                {loading ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : (
                  "Enviar Link"
                )}
              </Button>
              <Button
                type="button"
                variant="ghost"
                onClick={handleClose}
                className="w-full text-neutral-500 hover:text-white hover:bg-white/5 h-12 rounded-2xl transition-all font-medium border-none shadow-none outline-none ring-0 focus:ring-0"
              >
                Cancelar
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}