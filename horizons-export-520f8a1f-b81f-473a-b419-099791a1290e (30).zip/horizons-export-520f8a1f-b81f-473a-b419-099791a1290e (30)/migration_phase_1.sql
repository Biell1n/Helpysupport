-- =====================================================
-- PHASE 1: COMPLETE DATABASE MIGRATION
-- =====================================================
-- This migration creates the foundational database schema for the AI Assistant platform
-- Including all tables, indexes, RLS policies, and storage bucket configuration
-- 
-- TABLES CREATED: 14 core tables
-- - assistants: Main assistant configuration
-- - assistant_profiles: Detailed assistant personality and behavior
-- - assistant_rules: Custom rules and guidelines
-- - services: Service offerings
-- - products: Product catalog
-- - faqs: Frequently asked questions
-- - onboarding_messages: Onboarding conversation history
-- - conversation_messages: Customer chat messages
-- - professionals: Service providers/staff
-- - appointments: Scheduled appointments
-- - uploaded_files: Document uploads
-- - embeddings: Vector embeddings for RAG
-- - usage_logs: API usage tracking
-- - memory_versions: Assistant memory snapshots
-- =====================================================

-- =====================================================
-- SECTION 1: EXTENSIONS
-- =====================================================
-- Enable required PostgreSQL extensions

CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS vector;

-- =====================================================
-- SECTION 2: CREATE ALL 14 TABLES
-- =====================================================

-- -----------------------------------------------------
-- TABLE: assistants
-- Purpose: Main table for AI assistant configurations
-- Relationships: Parent table for all assistant-related data
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS assistants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  logo_url TEXT,
  niche TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'archived')),
  onboarding_completed BOOLEAN DEFAULT FALSE,
  onboarding_progress INTEGER DEFAULT 0 CHECK (onboarding_progress >= 0 AND onboarding_progress <= 100),
  timezone TEXT DEFAULT 'America/Sao_Paulo',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------
-- TABLE: assistant_profiles
-- Purpose: Detailed assistant personality, tone, and behavior configuration
-- Relationships: One-to-one with assistants table
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS assistant_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  company_description TEXT,
  tone_of_voice TEXT,
  personality TEXT,
  behavior_style TEXT,
  onboarding_state JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(assistant_id)
);

-- -----------------------------------------------------
-- TABLE: assistant_rules
-- Purpose: Custom behavioral rules and guidelines for assistant responses
-- Relationships: Many-to-one with assistants table
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS assistant_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  rule_type TEXT NOT NULL CHECK (rule_type IN ('behavior', 'restriction', 'guideline', 'custom')),
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------
-- TABLE: services
-- Purpose: Service offerings that the assistant can book or sell
-- Relationships: Many-to-one with assistants table
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  duration_minutes INTEGER NOT NULL,
  price NUMERIC(10, 2) NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------
-- TABLE: products
-- Purpose: Product catalog for e-commerce functionality
-- Relationships: Many-to-one with assistants table
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10, 2) NOT NULL,
  stock INTEGER,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------
-- TABLE: faqs
-- Purpose: Frequently asked questions and answers
-- Relationships: Many-to-one with assistants table
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS faqs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------
-- TABLE: onboarding_messages
-- Purpose: Stores the assistant onboarding conversation history
-- Relationships: Many-to-one with assistants table
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS onboarding_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  message TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------
-- TABLE: conversation_messages
-- Purpose: Customer chat messages with the assistant
-- Relationships: Many-to-one with assistants table
-- Note: customer_id is TEXT to support anonymous users
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  customer_id TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  message TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------
-- TABLE: professionals
-- Purpose: Service providers/staff who can fulfill appointments
-- Relationships: Many-to-one with assistants table
-- NOTE: This table must be created BEFORE appointments to satisfy FK dependency
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS professionals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role TEXT,
  availability JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------
-- TABLE: appointments
-- Purpose: Scheduled appointments with customers
-- Relationships: Many-to-one with assistants, optional link to professionals
-- Note: All times stored in UTC (TIMESTAMPTZ)
-- Note: professional_id foreign key constraint added later via ALTER TABLE
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  customer_name TEXT NOT NULL,
  customer_contact TEXT NOT NULL,
  professional_id UUID,
  start_time TIMESTAMPTZ NOT NULL,
  end_time TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------
-- TABLE: uploaded_files
-- Purpose: Tracks uploaded documents and their extracted content
-- Relationships: Many-to-one with assistants table
-- Note: file_url points to Supabase Storage location
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS uploaded_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_url TEXT NOT NULL,
  extracted_text TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------
-- TABLE: embeddings
-- Purpose: Vector embeddings for RAG (Retrieval Augmented Generation)
-- Relationships: Many-to-one with assistants table
-- Note: Using pgvector extension for efficient similarity search
-- Vector dimension: 3072 (OpenAI text-embedding-3-large)
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS embeddings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  embedding vector(3072) NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------
-- TABLE: usage_logs
-- Purpose: Track API usage, tokens, and costs for billing/analytics
-- Relationships: Many-to-one with assistants table
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS usage_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  model_used TEXT NOT NULL,
  tokens_input INTEGER NOT NULL,
  tokens_output INTEGER NOT NULL,
  estimated_cost NUMERIC(10, 6) NOT NULL,
  feature_type TEXT NOT NULL CHECK (feature_type IN ('onboarding', 'chat', 'embedding', 'scheduling', 'upload')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------
-- TABLE: memory_versions
-- Purpose: Snapshots of assistant memory for version control/rollback
-- Relationships: Many-to-one with assistants table
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS memory_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assistant_id UUID NOT NULL REFERENCES assistants(id) ON DELETE CASCADE,
  snapshot JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- SECTION 3: ENABLE ROW LEVEL SECURITY (RLS)
-- =====================================================
-- Enable RLS on all tables to enforce user-level data isolation

ALTER TABLE assistants ENABLE ROW LEVEL SECURITY;
ALTER TABLE assistant_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE assistant_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE faqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE onboarding_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversation_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE professionals ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE uploaded_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE embeddings ENABLE ROW LEVEL SECURITY;
ALTER TABLE usage_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE memory_versions ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- SECTION 4: CREATE RLS POLICIES
-- =====================================================
-- Security model: Users can only access data for assistants they own

-- -----------------------------------------------------
-- ASSISTANTS TABLE POLICIES
-- Direct ownership check via user_id
-- -----------------------------------------------------

DROP POLICY IF EXISTS assistants_select_policy ON assistants;
CREATE POLICY assistants_select_policy ON assistants
  FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS assistants_insert_policy ON assistants;
CREATE POLICY assistants_insert_policy ON assistants
  FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS assistants_update_policy ON assistants;
CREATE POLICY assistants_update_policy ON assistants
  FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS assistants_delete_policy ON assistants;
CREATE POLICY assistants_delete_policy ON assistants
  FOR DELETE USING (auth.uid() = user_id);

-- -----------------------------------------------------
-- ASSISTANT_PROFILES TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS assistant_profiles_select_policy ON assistant_profiles;
CREATE POLICY assistant_profiles_select_policy ON assistant_profiles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_profiles.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS assistant_profiles_insert_policy ON assistant_profiles;
CREATE POLICY assistant_profiles_insert_policy ON assistant_profiles
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_profiles.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS assistant_profiles_update_policy ON assistant_profiles;
CREATE POLICY assistant_profiles_update_policy ON assistant_profiles
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_profiles.assistant_id
      AND assistants.user_id = auth.uid()
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_profiles.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS assistant_profiles_delete_policy ON assistant_profiles;
CREATE POLICY assistant_profiles_delete_policy ON assistant_profiles
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_profiles.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- ASSISTANT_RULES TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS assistant_rules_select_policy ON assistant_rules;
CREATE POLICY assistant_rules_select_policy ON assistant_rules
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_rules.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS assistant_rules_insert_policy ON assistant_rules;
CREATE POLICY assistant_rules_insert_policy ON assistant_rules
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_rules.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS assistant_rules_update_policy ON assistant_rules;
CREATE POLICY assistant_rules_update_policy ON assistant_rules
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_rules.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS assistant_rules_delete_policy ON assistant_rules;
CREATE POLICY assistant_rules_delete_policy ON assistant_rules
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = assistant_rules.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- SERVICES TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS services_select_policy ON services;
CREATE POLICY services_select_policy ON services
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = services.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS services_insert_policy ON services;
CREATE POLICY services_insert_policy ON services
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = services.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS services_update_policy ON services;
CREATE POLICY services_update_policy ON services
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = services.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS services_delete_policy ON services;
CREATE POLICY services_delete_policy ON services
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = services.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- PRODUCTS TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS products_select_policy ON products;
CREATE POLICY products_select_policy ON products
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = products.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS products_insert_policy ON products;
CREATE POLICY products_insert_policy ON products
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = products.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS products_update_policy ON products;
CREATE POLICY products_update_policy ON products
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = products.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS products_delete_policy ON products;
CREATE POLICY products_delete_policy ON products
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = products.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- FAQS TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS faqs_select_policy ON faqs;
CREATE POLICY faqs_select_policy ON faqs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = faqs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS faqs_insert_policy ON faqs;
CREATE POLICY faqs_insert_policy ON faqs
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = faqs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS faqs_update_policy ON faqs;
CREATE POLICY faqs_update_policy ON faqs
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = faqs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS faqs_delete_policy ON faqs;
CREATE POLICY faqs_delete_policy ON faqs
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = faqs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- ONBOARDING_MESSAGES TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS onboarding_messages_select_policy ON onboarding_messages;
CREATE POLICY onboarding_messages_select_policy ON onboarding_messages
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = onboarding_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS onboarding_messages_insert_policy ON onboarding_messages;
CREATE POLICY onboarding_messages_insert_policy ON onboarding_messages
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = onboarding_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS onboarding_messages_update_policy ON onboarding_messages;
CREATE POLICY onboarding_messages_update_policy ON onboarding_messages
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = onboarding_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS onboarding_messages_delete_policy ON onboarding_messages;
CREATE POLICY onboarding_messages_delete_policy ON onboarding_messages
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = onboarding_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- CONVERSATION_MESSAGES TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS conversation_messages_select_policy ON conversation_messages;
CREATE POLICY conversation_messages_select_policy ON conversation_messages
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = conversation_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS conversation_messages_insert_policy ON conversation_messages;
CREATE POLICY conversation_messages_insert_policy ON conversation_messages
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = conversation_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS conversation_messages_update_policy ON conversation_messages;
CREATE POLICY conversation_messages_update_policy ON conversation_messages
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = conversation_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS conversation_messages_delete_policy ON conversation_messages;
CREATE POLICY conversation_messages_delete_policy ON conversation_messages
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = conversation_messages.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- PROFESSIONALS TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS professionals_select_policy ON professionals;
CREATE POLICY professionals_select_policy ON professionals
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = professionals.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS professionals_insert_policy ON professionals;
CREATE POLICY professionals_insert_policy ON professionals
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = professionals.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS professionals_update_policy ON professionals;
CREATE POLICY professionals_update_policy ON professionals
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = professionals.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS professionals_delete_policy ON professionals;
CREATE POLICY professionals_delete_policy ON professionals
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = professionals.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- APPOINTMENTS TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS appointments_select_policy ON appointments;
CREATE POLICY appointments_select_policy ON appointments
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = appointments.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS appointments_insert_policy ON appointments;
CREATE POLICY appointments_insert_policy ON appointments
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = appointments.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS appointments_update_policy ON appointments;
CREATE POLICY appointments_update_policy ON appointments
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = appointments.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS appointments_delete_policy ON appointments;
CREATE POLICY appointments_delete_policy ON appointments
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = appointments.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- UPLOADED_FILES TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS uploaded_files_select_policy ON uploaded_files;
CREATE POLICY uploaded_files_select_policy ON uploaded_files
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = uploaded_files.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS uploaded_files_insert_policy ON uploaded_files;
CREATE POLICY uploaded_files_insert_policy ON uploaded_files
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = uploaded_files.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS uploaded_files_update_policy ON uploaded_files;
CREATE POLICY uploaded_files_update_policy ON uploaded_files
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = uploaded_files.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS uploaded_files_delete_policy ON uploaded_files;
CREATE POLICY uploaded_files_delete_policy ON uploaded_files
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = uploaded_files.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- EMBEDDINGS TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS embeddings_select_policy ON embeddings;
CREATE POLICY embeddings_select_policy ON embeddings
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = embeddings.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS embeddings_insert_policy ON embeddings;
CREATE POLICY embeddings_insert_policy ON embeddings
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = embeddings.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS embeddings_update_policy ON embeddings;
CREATE POLICY embeddings_update_policy ON embeddings
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = embeddings.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS embeddings_delete_policy ON embeddings;
CREATE POLICY embeddings_delete_policy ON embeddings
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = embeddings.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- USAGE_LOGS TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS usage_logs_select_policy ON usage_logs;
CREATE POLICY usage_logs_select_policy ON usage_logs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = usage_logs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS usage_logs_insert_policy ON usage_logs;
CREATE POLICY usage_logs_insert_policy ON usage_logs
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = usage_logs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS usage_logs_update_policy ON usage_logs;
CREATE POLICY usage_logs_update_policy ON usage_logs
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = usage_logs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS usage_logs_delete_policy ON usage_logs;
CREATE POLICY usage_logs_delete_policy ON usage_logs
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = usage_logs.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- -----------------------------------------------------
-- MEMORY_VERSIONS TABLE POLICIES
-- Ownership check via assistant_id foreign key
-- -----------------------------------------------------

DROP POLICY IF EXISTS memory_versions_select_policy ON memory_versions;
CREATE POLICY memory_versions_select_policy ON memory_versions
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = memory_versions.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS memory_versions_insert_policy ON memory_versions;
CREATE POLICY memory_versions_insert_policy ON memory_versions
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = memory_versions.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS memory_versions_update_policy ON memory_versions;
CREATE POLICY memory_versions_update_policy ON memory_versions
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = memory_versions.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS memory_versions_delete_policy ON memory_versions;
CREATE POLICY memory_versions_delete_policy ON memory_versions
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM assistants
      WHERE assistants.id = memory_versions.assistant_id
      AND assistants.user_id = auth.uid()
    )
  );

-- =====================================================
-- SECTION 5: CREATE INDEXES
-- =====================================================
-- Performance optimization indexes for common query patterns

-- Assistants table indexes
CREATE INDEX IF NOT EXISTS idx_assistants_user_id ON assistants(user_id);

-- Assistant profiles table indexes
CREATE INDEX IF NOT EXISTS idx_assistant_profiles_assistant_id ON assistant_profiles(assistant_id);

-- Assistant rules table indexes
CREATE INDEX IF NOT EXISTS idx_assistant_rules_assistant_id ON assistant_rules(assistant_id);

-- Services table indexes
CREATE INDEX IF NOT EXISTS idx_services_assistant_id ON services(assistant_id);

-- Products table indexes
CREATE INDEX IF NOT EXISTS idx_products_assistant_id ON products(assistant_id);

-- FAQs table indexes
CREATE INDEX IF NOT EXISTS idx_faqs_assistant_id ON faqs(assistant_id);

-- Onboarding messages table indexes
CREATE INDEX IF NOT EXISTS idx_onboarding_messages_assistant_id ON onboarding_messages(assistant_id);

-- Conversation messages table indexes
CREATE INDEX IF NOT EXISTS idx_conversation_messages_assistant_id ON conversation_messages(assistant_id);
CREATE INDEX IF NOT EXISTS idx_conversation_messages_customer_id ON conversation_messages(customer_id);

-- Professionals table indexes
CREATE INDEX IF NOT EXISTS idx_professionals_assistant_id ON professionals(assistant_id);

-- Appointments table indexes (composite for time-based queries)
CREATE INDEX IF NOT EXISTS idx_appointments_assistant_id ON appointments(assistant_id);
CREATE INDEX IF NOT EXISTS idx_appointments_start_time ON appointments(start_time);

-- Uploaded files table indexes
CREATE INDEX IF NOT EXISTS idx_uploaded_files_assistant_id ON uploaded_files(assistant_id);

-- Embeddings table indexes
CREATE INDEX IF NOT EXISTS idx_embeddings_assistant_id ON embeddings(assistant_id);
-- Vector similarity search index using IVFFlat with cosine distance
CREATE INDEX IF NOT EXISTS idx_embeddings_vector ON embeddings USING ivfflat (embedding vector_cosine_ops);

-- Usage logs table indexes
CREATE INDEX IF NOT EXISTS idx_usage_logs_assistant_id ON usage_logs(assistant_id);

-- Memory versions table indexes
CREATE INDEX IF NOT EXISTS idx_memory_versions_assistant_id ON memory_versions(assistant_id);

-- =====================================================
-- SECTION 6: ADD FOREIGN KEY CONSTRAINTS
-- =====================================================
-- Add appointments.professional_id foreign key constraint after table creation

ALTER TABLE appointments
ADD CONSTRAINT fk_appointments_professional_id
FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE SET NULL;

-- =====================================================
-- SECTION 7: STORAGE BUCKET CONFIGURATION
-- =====================================================
-- Create storage bucket for assistant documents with RLS policies

-- Create the storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('assistant_documents', 'assistant_documents', false)
ON CONFLICT (id) DO NOTHING;

-- -----------------------------------------------------
-- STORAGE BUCKET RLS POLICIES
-- Users can only upload/read files in their own user_id folder
-- File path structure: {user_id}/{assistant_id}/{filename}
-- -----------------------------------------------------

-- Policy: Users can upload files to their own folder
DROP POLICY IF EXISTS "Users can upload files to their own folder" ON storage.objects;
CREATE POLICY "Users can upload files to their own folder"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'assistant_documents' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Policy: Users can read files from their own folder
DROP POLICY IF EXISTS "Users can read files from their own folder" ON storage.objects;
CREATE POLICY "Users can read files from their own folder"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'assistant_documents' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Policy: Users can update files in their own folder
DROP POLICY IF EXISTS "Users can update files in their own folder" ON storage.objects;
CREATE POLICY "Users can update files in their own folder"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'assistant_documents' AND
  auth.uid()::text = (storage.foldername(name))[1]
)
WITH CHECK (
  bucket_id = 'assistant_documents' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Policy: Users can delete files from their own folder
DROP POLICY IF EXISTS "Users can delete files from their own folder" ON storage.objects;
CREATE POLICY "Users can delete files from their own folder"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'assistant_documents' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- =====================================================
-- SECTION 8: COMPLETION COMMENTS
-- =====================================================

-- Migration complete! The following has been created:
-- 
-- ✅ pgvector extension enabled for vector similarity search
-- ✅ 14 core tables with proper relationships and constraints
-- ✅ Performance indexes on all foreign keys and common query patterns
-- ✅ Vector similarity index on embeddings table (IVFFlat with cosine distance)
-- ✅ Row Level Security enabled on all tables
-- ✅ Comprehensive RLS policies enforcing user-level data isolation
-- ✅ Storage bucket 'assistant_documents' with secure RLS policies
-- ✅ Foreign key constraint for appointments.professional_id added via ALTER TABLE
-- 
-- Security Model:
-- - All data is scoped to the authenticated user (auth.uid())
-- - Users can only access assistants they own (user_id = auth.uid())
-- - Child tables inherit ownership through assistant_id foreign key
-- - Storage files are isolated by user_id folder structure
-- 
-- Vector Search:
-- - embeddings table uses pgvector with 3072-dimensional vectors
-- - IVFFlat index optimized for cosine similarity search
-- - Compatible with OpenAI text-embedding-3-large model
-- 
-- Next Steps:
-- 1. Run this migration in Supabase SQL Editor
-- 2. Verify tables and policies in Supabase Dashboard
-- 3. Test data isolation by creating test assistants
-- 4. Implement Edge Functions for business logic
-- 
-- Foreign Key Relationships:
-- assistants (parent) ──┬─→ assistant_profiles (1:1)
--                       ├─→ assistant_rules (1:many)
--                       ├─→ services (1:many)
--                       ├─→ products (1:many)
--                       ├─→ faqs (1:many)
--                       ├─→ onboarding_messages (1:many)
--                       ├─→ conversation_messages (1:many)
--                       ├─→ professionals (1:many)
--                       ├─→ appointments (1:many)
--                       ├─→ uploaded_files (1:many)
--                       ├─→ embeddings (1:many)
--                       ├─→ usage_logs (1:many)
--                       └─→ memory_versions (1:many)
--
-- professionals (parent) ─→ appointments.professional_id (1:many, optional)