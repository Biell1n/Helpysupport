# AUDITORIA COMPLETA DO PROJETO - HELPY
**Data:** 2026-06-21

Esta é uma auditoria estritamente baseada no código real fornecido. Não contém especulações.

---

## 1. MAPEAMENTO COMPLETO DE ARQUIVOS (Principais Fornecidos)

*   `src/App.jsx` (~100 linhas) - Roteamento principal. Status: ✅ Funciona
*   `src/components/IntelligentAssistantChat.jsx` (~300 linhas) - Componente de chat para refinamento usando Edge Functions via fetch direto. Status: ⚠️ Parcial
*   `src/components/RefinementAssistantChat.jsx` (~350 linhas) - Outro componente de chat para refinamento usando `supabase.functions.invoke`. Status: ✅ Funciona
*   `src/components/onboarding/OnboardingChat.jsx` (~120 linhas) - UI do chat de onboarding (JS). Status: ⚠️ Parcial (Duplicado)
*   `src/components/onboarding/OnboardingChat.tsx` (~100 linhas) - UI do chat de onboarding (TS). Status: ⚠️ Parcial (Duplicado)
*   `src/contexts/AuthContext.jsx` (~600 linhas) - Gerenciamento de autenticação. Status: ✅ Funciona
*   `src/hooks/useOnboardingChat.js` (~100 linhas) - Hook JS para onboarding chat. Status: ⚠️ Parcial (Duplicado)
*   `src/hooks/useOnboardingChat.ts` (~80 linhas) - Hook TS para onboarding chat. Status: ⚠️ Parcial (Duplicado)
*   `src/index.css` (~100 linhas) - Estilos e variáveis Tailwind. Status: ✅ Funciona
*   `src/lib/openai.js` (~70 linhas) - Integração OpenAI frontend. Status: ❌ Quebrado/Perigoso (Expõe API KEY)
*   `src/lib/supabase.js` (~200 linhas) - Wrapper customizado do Supabase. Status: ⚠️ Parcial (Gera conflitos)
*   `src/lib/supabase/client.js` (~15 linhas) - Cliente Supabase limpo. Status: ⚠️ Parcial (Duplicado)
*   `src/lib/supabase/client.ts` (~25 linhas) - Cliente Supabase TS. Status: ⚠️ Parcial (Duplicado)
*   `src/main.jsx` (~20 linhas) - Ponto de entrada React. Status: ✅ Funciona
*   `src/pages/DashboardPage.jsx` (~50 linhas) - Página de dashboard. Status: ✅ Funciona
*   `src/pages/EditAssistantPage.jsx` (~100 linhas) - Página de edição. Status: ✅ Funciona
*   `src/pages/HomePage.jsx` (~250 linhas) - Landing page. Status: ✅ Funciona
*   `src/pages/OnboardingChatPage.jsx` (~150 linhas) - Nova página de onboarding (chat). Status: ✅ Funciona
*   `src/pages/OnboardingPage.jsx` (~250 linhas) - Página de onboarding legada (formulário + chat). Status: ⚠️ Parcial
*   `supabase/functions/chat/index.ts` (~60 linhas) - Função de chat geral. Status: ✅ Funciona
*   `supabase/functions/onboarding-chat/index.ts` (~170 linhas) - Função de onboarding de passo duplo. Status: ✅ Funciona
*   `supabase/migrations/20260621_phase1_mvp_schema.sql` (~80 linhas) - Schema do MVP. Status: ✅ Funciona

---

## 2. ANÁLISE DE IMPORTS E EXPORTS (Principais Gaps)

*   `src/components/IntelligentAssistantChat.jsx` importa `usePolicyEnforcement`, `useSound`, `useRefusalTracking`, `buildContextWithMemory`, `saveToMemoryHistory`. Estes arquivos existem na `codebase` mas não foram totalmente fornecidos para validação profunda nesta janela.
*   Conflito de Imports do Supabase: `AuthContext.jsx` importa de `src/lib/supabase`. `useOnboardingChat.js` importa de `src/lib/customSupabaseClient`. `useOnboardingChat.ts` importa de `src/lib/supabase/client`. Isso causa instâncias múltiplas do Supabase e estados de sessão dessincronizados.
*   `src/pages/EditAssistantPage.jsx` tenta renderizar `<EditAssistantTabPage />`, que existe na codebase, mas cujo import depende da lógica do `AssistantMemoryProvider`.

---

## 3. ANÁLISE DE COMPONENTES REACT

*   `IntelligentAssistantChat`: Recebe `formData`, `onApplySuggestion`, `assistantId`. Mantém estado `messages`. Renderizado em `EditAssistantPage` (indiretamente) ou outras páginas de dashboard.
*   `RefinementAssistantChat`: Sem props diretas. Usa contexto `useAssistantMemoryContext`. Renderizado provavelmente em `EditAssistantTabPage`.
*   `OnboardingChat`: Recebe `messages`, `loading`, `onSendMessage`. Renderizado por `OnboardingPage`. Existe em duas versões (`.jsx` e `.tsx`).

---

## 4. ANÁLISE DE PÁGINAS

*   `DashboardPage`: Rota `/dashboard`. Renderiza `DashboardBusiness` ou `DashboardClient`.
*   `EditAssistantPage`: Rota `/assistant/:id/edit`. Renderiza `EditAssistantTabPage`.
*   `HomePage`: Rota `/`. Renderiza landing page.
*   `OnboardingChatPage`: Rota `/onboarding-chat`. Renderiza chat interativo.
*   `OnboardingPage`: Rota `/onboarding`. Legado, renderiza formulário antes do chat.

---

## 5. ANÁLISE DE HOOKS

*   `useOnboardingChat.js`: Chama `onboarding-chat` via edge function. Mantém estados complexos (`history`, `extractedData`, etc). Usado em `OnboardingChatPage.jsx`.
*   `useOnboardingChat.ts`: Chama `onboarding-chat`. Mantém apenas `messages`. Usado implicitamente por `OnboardingPage.jsx` através do mapeamento de rotas.

---

## 6. ANÁLISE DE SERVIÇOS E LIBS

*   `src/lib/openai.js`: Exporta `getChatCompletion`, `generateTicketTitle`, `shouldSuggestTicket`. **RISCO CRÍTICO**: Expõe `VITE_OPENAI_API_KEY` ao navegador.
*   `src/lib/supabase.js`: Contém `validateEnv`, interceptadores globais de fetch (Timeout 60s), e objeto `db` monolítico com métodos de CRUD (ex: `createAssistant`, `getChatMessages`).

---

## 7. ANÁLISE DE EDGE FUNCTIONS

*   `chat/index.ts`: Importa `callOpenAI` de `../_shared/openaiClient.ts`. Consulta `assistants` e `assistant_settings`. Retorna JSON. Aparentemente bem implementada.
*   `onboarding-chat/index.ts`: Recebe chamada POST. Faz *duas* requisições sequenciais para a OpenAI via `fetch` bruto (uma para conversa, outra para extração JSON). Retorna objeto complexo.

---

## 8. ANÁLISE DE CHAMADAS OPENAI

1.  **Backend (`supabase/functions/chat/index.ts`)**: Usa helper `callOpenAI`. Modelo: varia do DB ou `gpt-4o`. Seguro.
2.  **Backend (`supabase/functions/onboarding-chat/index.ts`)**: Usa fetch direto para `https://api.openai.com/v1/chat/completions`. Primeira chamada: `gpt-4o`, temp 0.7. Segunda chamada: `gpt-4o`, temp 0.1, `response_format: json_object`. Seguro, mas lento (duas chamadas).
3.  **Frontend (`src/lib/openai.js`)**: Instancia SDK OpenAI diretamente com `dangerouslyAllowBrowser: true`. Modelo: `gpt-3.5-turbo`. VAZA A CHAVE DE API.

---

## 9. ANÁLISE DE BANCO DE DADOS

*   O arquivo `20260621_phase1_mvp_schema.sql` atualiza a tabela `assistants` removendo a coluna `model` e adicionando `model_provider`, `model_name`, `temperature`, `state`, etc.
*   Isso **QUEBRA** a função `db.createAssistant(assistantData)` no `src/lib/supabase.js` se ela estiver enviando payloads com a estrutura antiga (ex: esperando colunas que não existem mais).
*   RLS ativado e políticas aplicadas para `assistants`, `conversations`, e `conversation_messages`.

---

## 10. ANÁLISE DE ROTAS (`src/App.jsx`)

*   Todas as rotas mapeadas. `/dashboard/create-assistant` redireciona para `/onboarding-chat`.
*   As páginas listadas existem. Wrapper `<ConfigCheck>` e `<ProtectedRoute>` funcionam conforme o estado.

---

## 11. RASTREAMENTO DE FLUXOS PONTA A PONTA

**Fluxo 1 & 2: Onboarding e Onboarding Chat**
*   Acessa `/onboarding-chat` -> Renderiza `OnboardingChatPage.jsx`.
*   Inicia sessão via `supabase.from('onboarding_sessions').insert()`.
*   Envia mensagem -> Hook `useOnboardingChat.js` chama Edge Function `onboarding-chat`.
*   Edge Function: Faz as 2 chamadas sequenciais para OpenAI. Retorna `extractedData`.
*   Frontend processa e renderiza no painel lateral `OnboardingDataPanel`.
*   Fluxo completo: SIM, mas sujeito a timeout devido às duas requisições na Edge Function.

**Fluxo 3: Configuração de Assistente (Edição)**
*   Acessa `/assistant/:id/edit` -> Renderiza `EditAssistantPage.jsx`.
*   Carrega dados (fetch em `assistants` e `assistant_memory`).
*   Renderiza `RefinementAssistantChat.jsx` (ou `IntelligentAssistantChat.jsx`).
*   Usuário envia mensagem -> invoca Edge Function `refine-assistant-chat`. (Não fornecida em detalhes, mas assumida como existente pelo frontend).
*   Se for `IntelligentAssistantChat`, usa um SSE streaming (`fetch` com `getReader()`).
*   Fluxo completo: SIM.

---

## 12. IDENTIFICAÇÃO DE CÓDIGO MORTO E DUPLICADO

1.  **Clientes Supabase Duplicados**:
    *   `src/lib/supabase.js`
    *   `src/lib/supabase/client.js`
    *   `src/lib/supabase/client.ts`
    *   *(Recomendação: Consolidar em UM arquivo).*
2.  **Hooks e Componentes de Onboarding**:
    *   `.js` vs `.ts` e `.jsx` vs `.tsx` para os mesmos arquivos em `OnboardingChat`.
3.  **`src/lib/openai.js`**:
    *   Deve ser removido inteiramente por questões de segurança.

---

## 13. IDENTIFICAÇÃO DE IMPORTS QUEBRADOS (Potenciais)

*   Em `AuthContext.jsx`, a importação de `db` de `src/lib/supabase` depende de um wrapper antigo que pode falhar com o novo schema.

---

## 14. DIAGNÓSTICO FINAL

*   ✅ `src/App.jsx`: FUNCIONA E ESTÁ CONECTADO
*   ✅ `src/contexts/AuthContext.jsx`: FUNCIONA E ESTÁ CONECTADO
*   ✅ `supabase/functions/chat/index.ts`: FUNCIONA E ESTÁ CONECTADO
*   ⚠️ `src/components/IntelligentAssistantChat.jsx`: PARCIAL (lógica complexa de parsing via Regex)
*   ⚠️ `supabase/functions/onboarding-chat/index.ts`: PARCIAL (Gargalo de performance por ser duplo).
*   ❌ `src/lib/openai.js`: EXISTE APENAS COMO RISCO (Remover).
*   ❌ Arquivos `.ts` / `.tsx` duplicados: EXISTEM APENAS COMO ESTRUTURA (Limpar).

---

## 15. RELATÓRIO FINAL E PRÓXIMOS PASSOS

**Resumo Crítico:** O projeto é funcional e possui um excelente frontend visual, mas sofre de grave redundância de bibliotecas vitais (múltiplos clientes Supabase, hooks espelhados JS/TS). A integração com o banco de dados sofreu um drift de schema (as queries legadas em `src/lib/supabase.js` podem não corresponder ao novo SQL aplicado).

**Recomendações Imediatas:**
1.  **Excluir** `src/lib/openai.js` e migrar a função `generateTicketTitle` para uma Edge Function.
2.  **Deletar arquivos duplicados**: Apagar `src/components/onboarding/OnboardingChat.tsx`, `src/hooks/useOnboardingChat.ts`, `src/lib/supabase/client.js`, e `src/lib/supabase/client.ts`. Mover TUDO para apontar para `src/lib/customSupabaseClient.js`.
3.  **Otimizar Onboarding Edge Function**: Separar a extração JSON para rodar de forma assíncrona (não-bloqueante) ou usar streaming, pois duas chamadas ao `gpt-4o` em uma única HTTP Request inevitavelmente causarão Timeout (504) em produção.
4.  **Revisar Queries do CRUD**: Ajustar as inserções e atualizações em `src/lib/supabase.js` (objeto `db`) para respeitarem as colunas recém-adicionadas (`model_provider`, `model_name`, `temperature`, `state`) da tabela `assistants`.