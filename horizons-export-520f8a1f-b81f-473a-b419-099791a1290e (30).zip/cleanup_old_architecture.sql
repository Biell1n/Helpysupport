-- =====================================================
-- CLEANUP OLD ARCHITECTURE SCRIPT
-- =====================================================
-- This script safely removes the old database architecture while preserving
-- Supabase authentication system (auth schema).
--
-- ⚠️ WARNING: This script will permanently delete all old tables and data.
-- ALWAYS create a backup before running this script.
--
-- Execution time: ~30 seconds
-- Expected deletions: 15+ tables, 60+ policies, 5 functions, 4 triggers
-- =====================================================

-- =====================================================
-- SECTION 1: DISABLE RLS TEMPORARILY
-- =====================================================
-- Temporarily disable RLS to avoid policy-related errors during cleanup

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 1/8: Disabling Row Level Security...';
END $$;

ALTER TABLE IF EXISTS assistants DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS assistant_profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS assistant_memory DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS assistant_products DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS assistant_contacts DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS assistant_memory_history DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS support_tickets DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS ticket_messages DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS chat_messages DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS chats DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS verification_codes DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS password_reset_tokens DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS users DISABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  RAISE NOTICE '✅ RLS disabled successfully';
END $$;

-- =====================================================
-- SECTION 2: DROP ALL OLD RLS POLICIES
-- =====================================================
-- Remove all Row Level Security policies from old tables

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 2/8: Dropping old RLS policies...';
END $$;

-- Assistants table policies
DROP POLICY IF EXISTS "Users can create assistants" ON assistants;
DROP POLICY IF EXISTS "Users can view their own assistants" ON assistants;
DROP POLICY IF EXISTS "Owners can delete their own assistants" ON assistants;
DROP POLICY IF EXISTS "Users can update their own assistants" ON assistants;

-- Assistant memory policies
DROP POLICY IF EXISTS "Users can manage their assistant memory" ON assistant_memory;

-- Assistant memory history policies
DROP POLICY IF EXISTS "Users can manage their assistant memory history" ON assistant_memory_history;

-- Assistant products policies
DROP POLICY IF EXISTS "Users can manage their assistant products" ON assistant_products;

-- Assistant contacts policies
DROP POLICY IF EXISTS "Users can manage their assistant contacts" ON assistant_contacts;

-- Support tickets policies
DROP POLICY IF EXISTS "Users can create tickets" ON support_tickets;
DROP POLICY IF EXISTS "Owners can update their tickets" ON support_tickets;
DROP POLICY IF EXISTS "Users can view their tickets" ON support_tickets;

-- Ticket messages policies
DROP POLICY IF EXISTS "Users can insert ticket messages" ON ticket_messages;
DROP POLICY IF EXISTS "Users can view ticket messages" ON ticket_messages;

-- Chat messages policies
DROP POLICY IF EXISTS "Anyone can view chat messages" ON chat_messages;
DROP POLICY IF EXISTS "Users can insert chat messages" ON chat_messages;

-- Chats policies
DROP POLICY IF EXISTS "Anyone can read chats" ON chats;
DROP POLICY IF EXISTS "Anyone can insert chats" ON chats;
DROP POLICY IF EXISTS "Anyone can update chats" ON chats;

-- Verification codes policies
DROP POLICY IF EXISTS "Users can insert their own verification codes" ON verification_codes;
DROP POLICY IF EXISTS "Users can view their own verification codes" ON verification_codes;
DROP POLICY IF EXISTS "Users can view their own codes" ON verification_codes;
DROP POLICY IF EXISTS "Users can delete their own verification codes" ON verification_codes;

-- Password reset tokens policies
DROP POLICY IF EXISTS "deny all access" ON password_reset_tokens;

-- Profiles policies
DROP POLICY IF EXISTS "Users can insert their own profile" ON profiles;
DROP POLICY IF EXISTS "profiles_select_own" ON profiles;
DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON profiles;
DROP POLICY IF EXISTS "Users can view their own profile" ON profiles;

-- Users table policies
DROP POLICY IF EXISTS "Users can insert their own data" ON users;
DROP POLICY IF EXISTS "Users can update their own data" ON users;
DROP POLICY IF EXISTS "Users can view their own data" ON users;

DO $$
BEGIN
  RAISE NOTICE '✅ Old RLS policies dropped successfully';
END $$;

-- =====================================================
-- SECTION 3: DROP ALL OLD TRIGGERS
-- =====================================================
-- Remove triggers that maintain updated_at timestamps

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 3/8: Dropping old triggers...';
END $$;

DROP TRIGGER IF EXISTS on_profiles_updated ON profiles;
DROP TRIGGER IF EXISTS on_assistants_updated ON assistants;
DROP TRIGGER IF EXISTS update_assistant_products_updated_at ON assistant_products;
DROP TRIGGER IF EXISTS update_assistant_contacts_updated_at ON assistant_contacts;
DROP TRIGGER IF EXISTS trigger_update_last_message ON assistant_memory;

DO $$
BEGIN
  RAISE NOTICE '✅ Old triggers dropped successfully';
END $$;

-- =====================================================
-- SECTION 4: DROP ALL OLD VIEWS
-- =====================================================
-- Remove materialized views and regular views

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 4/8: Dropping old views...';
END $$;

DROP VIEW IF EXISTS assistant_complete_data CASCADE;

DO $$
BEGIN
  RAISE NOTICE '✅ Old views dropped successfully';
END $$;

-- =====================================================
-- SECTION 5: DROP ALL OLD TABLES
-- =====================================================
-- Drop tables in correct dependency order (children first, then parents)
-- CASCADE ensures dependent objects are also removed

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 5/8: Dropping old tables (this may take a moment)...';
END $$;

-- Drop child tables first (tables with foreign keys)
DROP TABLE IF EXISTS ticket_messages CASCADE;
DROP TABLE IF EXISTS support_tickets CASCADE;
DROP TABLE IF EXISTS chat_messages CASCADE;
DROP TABLE IF EXISTS chats CASCADE;
DROP TABLE IF EXISTS assistant_memory_history CASCADE;
DROP TABLE IF EXISTS assistant_products CASCADE;
DROP TABLE IF EXISTS assistant_contacts CASCADE;
DROP TABLE IF EXISTS assistant_memory CASCADE;
DROP TABLE IF EXISTS assistant_profiles CASCADE;
DROP TABLE IF EXISTS verification_codes CASCADE;
DROP TABLE IF EXISTS password_reset_tokens CASCADE;

-- Drop parent tables
DROP TABLE IF EXISTS assistants CASCADE;
DROP TABLE IF EXISTS profiles CASCADE;

-- Drop users table (only if it's part of old architecture, not auth system)
-- Note: If users table is linked to auth.users, consider keeping it
DROP TABLE IF EXISTS users CASCADE;

DO $$
BEGIN
  RAISE NOTICE '✅ Old tables dropped successfully';
END $$;

-- =====================================================
-- SECTION 6: DROP ALL OLD INDEXES
-- =====================================================
-- Remove standalone indexes (table-level indexes are auto-dropped with tables)

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 6/8: Dropping old indexes...';
END $$;

-- Note: Most indexes are automatically dropped when tables are dropped
-- This section handles any standalone indexes that might remain

DO $$
DECLARE
  idx_record RECORD;
BEGIN
  FOR idx_record IN 
    SELECT indexname 
    FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND indexname LIKE 'idx_%'
  LOOP
    EXECUTE 'DROP INDEX IF EXISTS public.' || idx_record.indexname || ' CASCADE';
  END LOOP;
END $$;

DO $$
BEGIN
  RAISE NOTICE '✅ Old indexes dropped successfully';
END $$;

-- =====================================================
-- SECTION 7: DROP OLD STORAGE BUCKETS
-- =====================================================
-- Remove old storage buckets and their policies

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 7/8: Dropping old storage buckets...';
END $$;

-- Drop storage bucket policies first
DROP POLICY IF EXISTS "Public Access Assistant Photos" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload assistant photos" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload profile photos" ON storage.objects;
DROP POLICY IF EXISTS "Users can update profile photos" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete profile photos" ON storage.objects;
DROP POLICY IF EXISTS "Public Access Profile Photos" ON storage.objects;
DROP POLICY IF EXISTS "Allow public read for landing videos" ON storage.objects;
DROP POLICY IF EXISTS "Public 1uja572_0" ON storage.objects;

-- Delete bucket contents and bucket itself
DELETE FROM storage.objects WHERE bucket_id = 'assistant-photos';
DELETE FROM storage.buckets WHERE id = 'assistant-photos';

-- Note: Keeping profile-photos and landing-videos as they may be used elsewhere
-- If you want to remove them too, uncomment the lines below:
-- DELETE FROM storage.objects WHERE bucket_id = 'profile-photos';
-- DELETE FROM storage.buckets WHERE id = 'profile-photos';
-- DELETE FROM storage.objects WHERE bucket_id = 'landing-videos';
-- DELETE FROM storage.buckets WHERE id = 'landing-videos';

DO $$
BEGIN
  RAISE NOTICE '✅ Old storage buckets cleaned successfully';
END $$;

-- =====================================================
-- SECTION 8: DROP OLD FUNCTIONS
-- =====================================================
-- Remove custom database functions from old architecture

DO $$
BEGIN
  RAISE NOTICE '⏳ Step 8/8: Dropping old functions...';
END $$;

DROP FUNCTION IF EXISTS public.handle_new_user() CASCADE;
DROP FUNCTION IF EXISTS public.handle_updated_at() CASCADE;
DROP FUNCTION IF EXISTS public.update_assistant_memory_last_message() CASCADE;
DROP FUNCTION IF EXISTS public.update_updated_at_column() CASCADE;
DROP FUNCTION IF EXISTS public.update_updated_at_timestamp() CASCADE;

DO $$
BEGIN
  RAISE NOTICE '✅ Old functions dropped successfully';
END $$;

-- =====================================================
-- SECTION 9: VERIFICATION QUERIES
-- =====================================================
-- Verify that all old objects have been removed

DO $$
BEGIN
  RAISE NOTICE '';
  RAISE NOTICE '========================================';
  RAISE NOTICE '🔍 CLEANUP VERIFICATION';
  RAISE NOTICE '========================================';
END $$;

-- Count remaining old tables
DO $$
DECLARE
  table_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO table_count
  FROM information_schema.tables
  WHERE table_schema = 'public'
  AND table_name IN (
    'assistants', 'assistant_profiles', 'assistant_memory', 
    'assistant_products', 'assistant_contacts', 'assistant_memory_history',
    'support_tickets', 'ticket_messages', 'chat_messages', 'chats',
    'verification_codes', 'password_reset_tokens', 'profiles', 'users'
  );
  
  IF table_count = 0 THEN
    RAISE NOTICE '✅ All old tables removed (0 remaining)';
  ELSE
    RAISE NOTICE '⚠️  Warning: % old table(s) still exist', table_count;
  END IF;
END $$;

-- Count remaining old functions
DO $$
DECLARE
  function_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO function_count
  FROM pg_proc p
  JOIN pg_namespace n ON p.pronamespace = n.oid
  WHERE n.nspname = 'public'
  AND p.proname IN (
    'handle_new_user', 'handle_updated_at', 'update_assistant_memory_last_message',
    'update_updated_at_column', 'update_updated_at_timestamp'
  );
  
  IF function_count = 0 THEN
    RAISE NOTICE '✅ All old functions removed (0 remaining)';
  ELSE
    RAISE NOTICE '⚠️  Warning: % old function(s) still exist', function_count;
  END IF;
END $$;

-- Verify auth system is intact
DO $$
DECLARE
  auth_tables_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO auth_tables_count
  FROM information_schema.tables
  WHERE table_schema = 'auth'
  AND table_name IN ('users', 'sessions', 'refresh_tokens');
  
  IF auth_tables_count = 3 THEN
    RAISE NOTICE '✅ Supabase auth system intact (3 core tables verified)';
  ELSE
    RAISE NOTICE '⚠️  Warning: Auth system may be incomplete (found % tables)', auth_tables_count;
  END IF;
END $$;

DO $$
BEGIN
  RAISE NOTICE '';
  RAISE NOTICE '========================================';
  RAISE NOTICE '✅ CLEANUP COMPLETED SUCCESSFULLY';
  RAISE NOTICE '========================================';
  RAISE NOTICE '';
  RAISE NOTICE 'Next step: Run migration_phase_1_final.sql to create new architecture';
  RAISE NOTICE '';
END $$;