-- Execute this SQL in Supabase to remove all onboarding-related tables and data
DROP TABLE IF EXISTS public.onboarding_messages CASCADE;
DROP TABLE IF EXISTS public.onboarding_sessions CASCADE;
DROP TABLE IF EXISTS public.business_type_definitions CASCADE;
DROP TABLE IF EXISTS public.field_updates CASCADE;
DROP TABLE IF EXISTS public.context_snapshots CASCADE;
DROP TABLE IF EXISTS public.assistant_brains CASCADE;
DROP TABLE IF EXISTS public.brain_snapshots CASCADE;
DROP TABLE IF EXISTS public.context_summaries CASCADE;
DROP TABLE IF EXISTS public.brain_edits CASCADE;
DROP TABLE IF EXISTS public.assistant_profiles CASCADE;