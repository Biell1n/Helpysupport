# AUDITORIA DE EDGE FUNCTIONS

## 1. onboarding-chat/index.ts

### Propósito
Processar mensagens do chat de onboarding de um usuário, analisar a conversa usando OpenAI, extrair dados estruturados do negócio, calcular suficiência de contexto e salvar o progresso no banco de dados.

### Assinatura
`Deno.serve(async (req) => { ... })`

### Parâmetros
Recebidos via `req.json()`:
- `message` (string, obrigatório)
- `onboarding_session_id` (uuid, obrigatório)
- `user_id` (uuid, obrigatório)

### Retorno