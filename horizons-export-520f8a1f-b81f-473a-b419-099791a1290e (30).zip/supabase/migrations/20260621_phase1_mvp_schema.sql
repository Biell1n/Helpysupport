-- ==========================================
-- PHASE 1 MVP SCHEMA MIGRATION
-- ==========================================

-- 1. ASSISTANTS TABLE UPDATES
-- Removing old jsonb model column and adding distinct columns for LLM configuration and state
ALTER TABLE public.assistants DROP COLUMN IF EXISTS model;

ALTER TABLE public.assistants 
    ADD COLUMN IF NOT EXISTS model_provider text DEFAULT 'openai',
    ADD COLUMN IF NOT EXISTS model_name text DEFAULT 'gpt-4o-mini',
    ADD COLUMN IF NOT EXISTS temperature numeric DEFAULT 0.7,
    ADD COLUMN IF NOT EXISTS top_p numeric DEFAULT 1,
    ADD COLUMN IF NOT EXISTS max_tokens integer DEFAULT 1500,
    ADD COLUMN IF NOT EXISTS custom_instructions text,
    ADD COLUMN IF NOT EXISTS state jsonb DEFAULT '{}'::jsonb,
    ADD COLUMN IF NOT EXISTS published boolean DEFAULT false,
    ADD COLUMN IF NOT EXISTS published_at timestamp with time zone,
    ADD COLUMN IF NOT EXISTS greeting_message text,
    ADD COLUMN IF NOT EXISTS fallback_behavior jsonb DEFAULT '{}'::jsonb,
    ADD COLUMN IF NOT EXISTS created_from_onboarding_session_id uuid;

-- Update status check constraint safely
DO $$ 
BEGIN
    ALTER TABLE public.assistants DROP CONSTRAINT IF EXISTS assistants_status_check;
EXCEPTION
    WHEN undefined_object THEN null;
END $$;

ALTER TABLE public.assistants 
    ADD CONSTRAINT assistants_status_check 
    CHECK (status IN ('draft', 'active', 'published', 'archived'));

-- Create new indexes on assistants
CREATE INDEX IF NOT EXISTS idx_assistants_user_status ON public.assistants(user_id, status);
CREATE INDEX IF NOT EXISTS idx_assistants_published ON public.assistants(published, published_at);


-- 2. ASSISTANT VERSIONS TABLE
-- Stores full state snapshots of the assistant to allow rollbacks and precise prompt tracking
CREATE TABLE IF NOT EXISTS public.assistant_versions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    assistant_id uuid NOT NULL REFERENCES public.assistants(id) ON DELETE CASCADE,
    version_number integer NOT NULL,
    snapshot jsonb NOT NULL,
    generated_prompt_snapshot text NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
    change_description text,
    CONSTRAINT uq_assistant_version UNIQUE(assistant_id, version_number)
);

CREATE INDEX IF NOT EXISTS idx_assistant_versions_assistant_id_number ON public.assistant_versions(assistant_id, version_number DESC);


-- 3. CONVERSATIONS TABLE
-- Represents a single chat session between an end-user and the assistant
CREATE TABLE IF NOT EXISTS public.conversations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    assistant_id uuid NOT NULL REFERENCES public.assistants(id) ON DELETE CASCADE,
    channel text NOT NULL, -- e.g., web, whatsapp, email, telegram, slack
    status text DEFAULT 'active' CHECK (status IN ('active', 'closed', 'archived')),
    user_identifier text,
    user_name text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    closed_at timestamp with time zone
);

CREATE INDEX IF NOT EXISTS idx_conversations_assistant_status ON public.conversations(assistant_id, status);
CREATE INDEX IF NOT EXISTS idx_conversations_assistant_created ON public.conversations(assistant_id, created_at DESC);


-- 4. CONVERSATION MESSAGES TABLE
-- Individual messages within a conversation session
CREATE TABLE IF NOT EXISTS public.conversation_messages (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
    role text NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
    content text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_conversation_messages_conv_created ON public.conversation_messages(conversation_id, created_at);


-- ==========================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==========================================

-- Enable RLS on new tables
ALTER TABLE public.assistant_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversation_messages ENABLE ROW LEVEL SECURITY;

-- Assistant Versions: Users can only see/manage versions of assistants they own
DROP POLICY IF EXISTS "Users can manage versions of their own assistants" ON public.assistant_versions;
CREATE POLICY "Users can manage versions of their own assistants" 
    ON public.assistant_versions FOR ALL USING (
        EXISTS (SELECT 1 FROM public.assistants WHERE id = assistant_versions.assistant_id AND user_id = auth.uid())
    );

-- Conversations: Users can only see/manage conversations belonging to their assistants
DROP POLICY IF EXISTS "Users can manage conversations of their own assistants" ON public.conversations;
CREATE POLICY "Users can manage conversations of their own assistants" 
    ON public.conversations FOR ALL USING (
        EXISTS (SELECT 1 FROM public.assistants WHERE id = conversations.assistant_id AND user_id = auth.uid())
    );

-- Conversation Messages: Users can only see/manage messages from conversations belonging to their assistants
DROP POLICY IF EXISTS "Users can manage messages of their own assistants" ON public.conversation_messages;
CREATE POLICY "Users can manage messages of their own assistants" 
    ON public.conversation_messages FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.conversations c 
            JOIN public.assistants a ON a.id = c.assistant_id
            WHERE c.id = conversation_messages.conversation_id AND a.user_id = auth.uid()
        )
    );