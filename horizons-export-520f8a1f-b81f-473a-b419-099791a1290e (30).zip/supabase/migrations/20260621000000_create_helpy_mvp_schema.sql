-- ==========================================
-- HELPY MVP ARCHITECTURE: 3-TABLE SCHEMA
-- ==========================================

-- 1. ASSISTANTS TABLE
CREATE TABLE IF NOT EXISTS public.assistants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'archived')),
    
    -- Configuration fields stored as JSONB for pragmatic flexibility
    model JSONB DEFAULT '{"provider": "openai", "model": "gpt-4o-mini", "temperature": 0.7, "max_tokens": 1500, "top_p": 1}'::jsonb,
    identity JSONB DEFAULT '{}'::jsonb,
    personality JSONB DEFAULT '{}'::jsonb,
    tone JSONB DEFAULT '{}'::jsonb,
    responsibilities JSONB DEFAULT '[]'::jsonb,
    restrictions JSONB DEFAULT '[]'::jsonb,
    escalation_rules JSONB DEFAULT '[]'::jsonb,
    tools JSONB DEFAULT '[]'::jsonb,
    channels JSONB DEFAULT '[]'::jsonb,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_assistants_user_id ON public.assistants(user_id);
CREATE INDEX IF NOT EXISTS idx_assistants_status ON public.assistants(status);
CREATE INDEX IF NOT EXISTS idx_assistants_created_at ON public.assistants(created_at);


-- 2. ASSISTANT VERSIONS TABLE
CREATE TABLE IF NOT EXISTS public.assistant_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    assistant_id UUID NOT NULL REFERENCES public.assistants(id) ON DELETE CASCADE,
    version_number INTEGER NOT NULL,
    snapshot JSONB NOT NULL,
    generated_prompt_snapshot TEXT NOT NULL,
    change_description TEXT,
    created_by UUID REFERENCES public.users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    
    -- Ensure version numbers are unique per assistant
    CONSTRAINT uq_assistant_version UNIQUE(assistant_id, version_number)
);

CREATE INDEX IF NOT EXISTS idx_assistant_versions_assistant_id ON public.assistant_versions(assistant_id);
CREATE INDEX IF NOT EXISTS idx_assistant_versions_number ON public.assistant_versions(assistant_id, version_number);


-- 3. ASSISTANT KNOWLEDGE SOURCES TABLE
CREATE TABLE IF NOT EXISTS public.assistant_knowledge_sources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    assistant_id UUID NOT NULL REFERENCES public.assistants(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    name TEXT NOT NULL,
    source_url TEXT,
    status TEXT DEFAULT 'processing' CHECK (status IN ('active', 'processing', 'error', 'archived')),
    metadata JSONB DEFAULT '{}'::jsonb,
    vector_store_id TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_knowledge_sources_assistant_id ON public.assistant_knowledge_sources(assistant_id);


-- ==========================================
-- TRIGGERS & RLS POLICIES
-- ==========================================

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION update_mvp_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc'::text, now());
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_assistants_updated_at
    BEFORE UPDATE ON public.assistants
    FOR EACH ROW
    EXECUTE FUNCTION update_mvp_updated_at_column();

CREATE TRIGGER update_knowledge_sources_updated_at
    BEFORE UPDATE ON public.assistant_knowledge_sources
    FOR EACH ROW
    EXECUTE FUNCTION update_mvp_updated_at_column();

-- RLS Enablement
ALTER TABLE public.assistants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assistant_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assistant_knowledge_sources ENABLE ROW LEVEL SECURITY;

-- Assistants Policies
CREATE POLICY "Users can manage their own assistants" 
    ON public.assistants FOR ALL USING (auth.uid() = user_id);

-- Assistant Versions Policies
CREATE POLICY "Users can manage versions of their own assistants" 
    ON public.assistant_versions FOR ALL USING (
        EXISTS (SELECT 1 FROM public.assistants WHERE id = assistant_versions.assistant_id AND user_id = auth.uid())
    );

-- Knowledge Sources Policies
CREATE POLICY "Users can manage knowledge sources of their own assistants" 
    ON public.assistant_knowledge_sources FOR ALL USING (
        EXISTS (SELECT 1 FROM public.assistants WHERE id = assistant_knowledge_sources.assistant_id AND user_id = auth.uid())
    );