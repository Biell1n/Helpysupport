CREATE TABLE IF NOT EXISTS business_type_definitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_type text UNIQUE,
  display_name text,
  critical_fields jsonb,
  important_fields jsonb,
  optional_fields jsonb,
  field_descriptions jsonb,
  aprofundamento_questions jsonb,
  created_at timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS field_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid REFERENCES onboarding_sessions(id) ON DELETE CASCADE,
  field_name text,
  old_value text,
  new_value text,
  update_intent text,
  confidence numeric,
  updated_at timestamp with time zone,
  created_at timestamp with time zone DEFAULT now()
);

ALTER TABLE onboarding_sessions
  ADD COLUMN IF NOT EXISTS business_type text,
  ADD COLUMN IF NOT EXISTS critical_fields jsonb,
  ADD COLUMN IF NOT EXISTS important_fields jsonb,
  ADD COLUMN IF NOT EXISTS optional_fields jsonb,
  ADD COLUMN IF NOT EXISTS field_definitions jsonb,
  ADD COLUMN IF NOT EXISTS depth_analysis jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS update_count integer DEFAULT 0;