/**
 * DEPRECATED AND REMOVED.
 * This file has been cleared as part of the onboarding cleanup process.
 * The environment does not support file deletion, so the contents have been emptied.
 * Please delete the `supabase/functions/onboarding-chat/` directory manually from your local repository.
 */
import { corsHeaders } from "../_shared/cors.ts";

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }
  return new Response(
    JSON.stringify({ error: "This endpoint has been deprecated and removed." }), 
    { status: 410, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
});