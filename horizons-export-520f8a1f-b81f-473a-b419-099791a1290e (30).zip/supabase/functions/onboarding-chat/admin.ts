/**
 * DEPRECATED AND REMOVED.
 * This file has been cleared as part of the onboarding cleanup process.
 * The environment does not support file deletion, so the contents have been emptied.
 * Please delete the `supabase/functions/onboarding-chat/` directory manually from your local repository.
 */