export interface Message {
  role: 'system' | 'user' | 'assistant';
  content: string;
  timestamp?: string;
}

export interface ModelConfig {
  model: string;
  temperature: number;
  max_tokens: number;
  top_p: number;
}

export function createOpenAIClient() {
  const apiKey = Deno.env.get('OPENAI_API_KEY');
  if (!apiKey) {
    throw new Error('OPENAI_API_KEY is not defined in environment variables');
  }
  return {
    apiKey,
    baseUrl: 'https://api.openai.com/v1/chat/completions'
  };
}

export async function callOpenAI(messages: Message[], modelConfig: ModelConfig) {
  try {
    const client = createOpenAIClient();
    
    // Logging (simulado via console.log no Deno)
    console.log(`[OpenAI Call] Model: ${modelConfig.model}, Temp: ${modelConfig.temperature}, Tokens: ${modelConfig.max_tokens}, MsgCount: ${messages.length}`);

    const response = await fetch(client.baseUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${client.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: modelConfig.model,
        messages: messages.map(m => ({ role: m.role, content: m.content })),
        temperature: modelConfig.temperature,
        max_tokens: modelConfig.max_tokens,
        top_p: modelConfig.top_p,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenAI API Error (${response.status}): ${errorText}`);
    }

    const data = await response.json();
    return {
      success: true,
      message: data.choices[0]?.message?.content || '',
      usage: data.usage
    };
  } catch (error: any) {
    console.error('[OpenAI Error]', error);
    return {
      success: false,
      error: error.message || 'Unknown error occurred while calling OpenAI',
      message: ''
    };
  }
}