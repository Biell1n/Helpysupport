import { serve } from "https://deno.land/std@0.192.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
import { corsHeaders } from '../_shared/cors.ts';
import { callOpenAI, type Message } from '../_shared/openaiClient.ts';

const DEFAULT_MODEL = {
  model: 'gpt-4o',
  temperature: 0.7,
  max_tokens: 4096,
  top_p: 1.0,
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { message, conversation_id, assistant_id } = await req.json();

    if (!message || !conversation_id || !assistant_id) {
      return new Response(JSON.stringify({ error: 'message, conversation_id, and assistant_id required' }), { status: 400, headers: { ...corsHeaders } });
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    const supabase = createClient(supabaseUrl!, supabaseKey!);

    // Carregar configurações do assistente
    const { data: assistant, error: astError } = await supabase
      .from('assistants')
      .select('system_prompt, model')
      .eq('id', assistant_id)
      .single();

    const { data: settings } = await supabase
      .from('assistant_settings')
      .select('model, temperature, max_tokens, top_p')
      .eq('assistant_id', assistant_id)
      .single();

    if (astError || !assistant) {
      throw new Error('Assistant not found');
    }

    const modelConfig = {
      model: settings?.model || assistant.model || DEFAULT_MODEL.model,
      temperature: settings?.temperature || DEFAULT_MODEL.temperature,
      max_tokens: settings?.max_tokens || DEFAULT_MODEL.max_tokens,
      top_p: settings?.top_p || DEFAULT_MODEL.top_p,
    };

    // Histórico
    const { data: messages, error: msgError } = await supabase
      .from('conversation_messages')
      .select('role, content')
      .eq('conversation_id', conversation_id)
      .order('created_at', { ascending: true })
      .limit(20);

    const history: Message[] = (messages || []).map((m: any) => ({ role: m.role, content: m.content }));

    const messagesToSend: Message[] = [
      { role: 'system', content: assistant.system_prompt },
      ...history,
      { role: 'user', content: message }
    ];

    // Chamar IA
    const aiResponse = await callOpenAI(messagesToSend, modelConfig);

    if (!aiResponse.success) throw new Error(aiResponse.error);

    // Salvar no BD
    await supabase.from('conversation_messages').insert([
      { conversation_id, role: 'user', content: message },
      { conversation_id, role: 'assistant', content: aiResponse.message }
    ]);

    return new Response(JSON.stringify({
      success: true,
      message: aiResponse.message,
      conversationId: conversation_id
    }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

  } catch (error: any) {
    return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});