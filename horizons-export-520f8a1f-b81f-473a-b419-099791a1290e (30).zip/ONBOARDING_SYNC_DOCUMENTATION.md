# Onboarding Synchronization Documentation

This document outlines the architecture, data flow, and guardrails implemented in the integrated PASS 1 (Conversational) and PASS 2 (Analysis) onboarding system.

## 1. System Architecture

The onboarding edge function (`onboarding-chat`) is orchestrated into a single synchronized request-response cycle that ensures the AI Assistant always has the most up-to-date context regarding what has been collected and what is pending.

*   **PASS 1 (Conversation Layer):** A dynamic system prompt is built using the current session state. The LLM generates a conversational response, prioritizing critical missing information.
*   **PASS 2 (Analysis Layer):** The entire conversation context is analyzed to extract structured data. Extracted fields are marked with a `status: "confirmed"`, preventing them from being repeatedly asked.

## 2. Data Flow Diagram

1.  **User Message Received** -> Saved to `onboarding_messages`.
2.  **Load Session State** -> Fetch `extracted_data` (confirmed metadata) and `missing_information`.
3.  **PASS 1** -> Generate response. Guardrails check if the AI asked a critical question when critical fields are pending.
4.  **PASS 2** -> Extract new structured data. Merge with existing `extracted_data` (respecting previously confirmed fields).
5.  **State Recalculation** -> Remove confirmed fields from `missing_information`. Calculate new `next_objective` and `context_sufficiency` (progress).
6.  **Update Session State** -> Save to `onboarding_sessions`.
7.  **Return Response** -> Returns the conversational message, updated session state, validation flags, and progress payload to the frontend.

## 3. Guardrails & Constraints

*   **Critical Fields Enforced:** The conversational AI will append a question if critical fields remain pending and the AI failed to naturally include a question.
*   **Data Memory:** By injecting `extracted_data` into the system prompt and using `"status": "confirmed"`, the AI knows precisely what not to ask again.
*   **Important Fields (Optional):** Important fields are suggested gently only if all critical fields are covered.
*   **Missing Information Cleanup:** Handled strictly in code during PASS 2 to guarantee the AI doesn't get confused by stale objectives.

## 4. Configuration

*   **Extracted Data Schema:**