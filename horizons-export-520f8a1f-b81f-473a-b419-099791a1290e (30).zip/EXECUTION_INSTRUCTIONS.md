# Database Migration Execution Instructions

This guide provides step-by-step instructions for safely migrating from the old architecture to the new Phase 1 modular architecture.

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Backup Recommendations](#backup-recommendations)
3. [Execution Order](#execution-order)
4. [Step-by-Step Execution](#step-by-step-execution)
5. [Verification Steps](#verification-steps)
6. [Rollback Instructions](#rollback-instructions)
7. [Troubleshooting](#troubleshooting)
8. [Post-Migration Tasks](#post-migration-tasks)

---

## 🔧 Prerequisites

Before running the migration scripts, ensure you have:

### Required Access
- ✅ Supabase project access with **admin privileges**
- ✅ Access to Supabase SQL Editor (Dashboard → SQL Editor)
- ✅ Ability to create database backups

### Environment Verification
- ✅ PostgreSQL version 14+ (Supabase default)
- ✅ Sufficient database storage (check current usage + 20% buffer)
- ✅ No active users or critical operations running

### Extension Requirements
The migration will automatically install these extensions:
- `uuid-ossp` - UUID generation
- `pgcrypto` - Cryptographic functions
- `vector` - Vector similarity search (pgvector)

---

## 💾 Backup Recommendations

### ⚠️ CRITICAL: Always backup before migration

### Option 1: Supabase Dashboard Backup (Recommended for small databases)
1. Go to Supabase Dashboard → Database → Backups
2. Click "Create backup"
3. Name it: `pre-phase1-migration-YYYY-MM-DD`
4. Wait for completion (green checkmark)

### Option 2: Manual pg_dump Backup (Recommended for large databases)