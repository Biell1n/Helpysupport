# AUDITORIA DE QUALIDADE DE CÓDIGO

## 1. Imports e Aliases
- O sistema utiliza extensamente o path alias `@/`. A resolução está configurada corretamente no `vite.config.js`.
- Foram encontradas inconsistências entre arquivos JS e TS importados misturados. Ex: `import { ExtractionService } from './extraction.service'` (TS) sendo invocado em hooks `.js`.

## 2. Duplicação de Arquivos e Código Morto
- **Problema de Cliente Supabase:** Temos `src/lib/supabase.js`, `src/lib/supabaseClient.js`, `src/lib/customSupabaseClient.js`, `src/lib/supabase/client.js`, e `src/lib/supabase/client.ts`. Isso fragmenta configurações de autenticação e timeouts.
- **Duplicação de Hooks de Onboarding:** Existem `useOnboarding.ts`, `useOnboardingChat.js`, `useOnboardingChat.ts`. Todos lidam com o estado do chat de onboarding de formas diferentes.
- **Serviços de Onboarding Duplicados:** `onboardingService.js`, `onboardingService.ts`, `services/onboardingService.js`, `services/onboarding/onboarding.service.ts`.

## 3. Segurança
- O arquivo `openai.js` instancia o cliente OpenAI diretamente no frontend permitindo o acesso à API usando `dangerouslyAllowBrowser: true`. Isso significa que a chave `VITE_OPENAI_API_KEY` (que é pública no bundle) pode ser extraída e usada por terceiros, resultando em abuso financeiro da conta OpenAI.
- Exposição de senhas ou chaves em Plaintext: `VITE_OPENAI_API_KEY` consta no `<supabase_secrets>`.

## 4. Race Conditions e Lógica Assíncrona
- **Edge Functions:** A Deno Function de Onboarding Chat possui um tempo de execução longo devido a dois prompts seriais pesados. Sem SSE no onboarding original, a conexão frequentemente resultará em Timeout (a maioria dos proxies encerra após 30-60s).
- O `AssistantMemoryProvider.jsx` possui chamadas assíncronas de atualização de estado mescladas com lógica síncrona, que podem sobrescrever dados caso cliques rápidos ocorram na UI (`updateTrigger`).

## 5. Estruturas Defasadas
- Há muitos comentários TODO espalhados e arquivos indicando `"Available in Phase 3"`.
- Estilos `Tailwind` sendo manipulados via concatenação de strings sem `clsx`/`twMerge` em alguns componentes antigos.

## STATUS GERAL: ⚠️ ALERTA
A base de código sofre de severo débito técnico originado da migração não finalizada de JS para TS, e de Múltiplos Padrões (vários desenvolvedores ou prompts iterativos que sobrepuseram arquivos em vez de refatorar).