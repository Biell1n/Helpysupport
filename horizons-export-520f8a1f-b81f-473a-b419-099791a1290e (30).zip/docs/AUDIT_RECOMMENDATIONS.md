# RECOMENDAÇÕES DE CORREÇÃO

## AÇÃO IMEDIATA (O que corrigir antes de continuar)

1. **Reconciliação do Banco de Dados e Serviços:**
   - Reescrever o `src/lib/assistantService.js` para usar a sintaxe correta do schema recém-aplicado. Substituir a inserção do objeto `{ model: {...} }` para as colunas planas `model_provider`, `model_name`, `temperature`, `max_tokens` e `top_p`.
   - Limpar o banco de dados. Remover todas as tabelas legadas (`assistant_profiles`, `assistant_rules`, `assistant_settings`) que foram suplantadas pelas colunas JSON de `assistants` e `assistant_versions`.

2. **Sanitização de Chaves API:**
   - Remover imediatamente `OPENAI_API_KEY` do frontend (`openai.js`).
   - Apagar o arquivo `openai.js` e migrar a funcionalidade `generateTicketTitle` para uma Edge Function segura.

3. **Consolidação de Módulos (DRY):**
   - Apagar todos os clones de Supabase client e manter APENAS `src/lib/customSupabaseClient.js` como determina a regra base do projeto.
   - Apagar os clones de Onboarding Service mantendo apenas a versão mais atual (`useOnboardingChat.js`).

## MÉDIO PRAZO (O que refatorar)

1. **Otimização do Onboarding:**
   - Refatorar `onboarding-chat/index.ts`. Atualmente ele bloqueia a thread esperando o GPT-4 terminar o processamento de extração (JSON). Isso deve ser movido para uma tarefa paralela, ou utilizar streaming SSE (como foi feito no `refine-assistant-chat`).

2. **Políticas RLS para Usuários Finais:**
   - Configurar o webhook ou edge function de "Chat Púbico" para agir com o Client Admin do Supabase ao processar e salvar logs de conversa, já que o usuário não está autenticado como "Dono" do assistente.

## LONGO PRAZO E PRÓXIMOS PASSOS

1. **Aprimorar Logs e Rate Limiting:**
   - Implementar Rate Limiting na invocação de Edge Functions (Limitar chamadas de Chat/Completions baseados no IP do visitante ou no UUID da sessão) para evitar abstenção de custos.
   
2. **Integração Real RAG (Phase 2):**
   - Atualmente a estrutura tem apenas o arquivo `ragPipeline.js` com mocks. As tabelas de `embeddings` estão criadas (pgvector), mas o pipeline precisará de uma rotina real via LlamaIndex, LangChain ou Supabase Vector natively nas Edge Functions.