# COMPREHENSIVE CODE AUDIT - HELPY CODEBASE

**Date:** 2026-06-21
**Scope:** Entire frontend React application, Supabase configuration, Database schema, and Edge Functions.

---

## SECTION 1: PROJECT STRUCTURE ANALYSIS

**Overview:** The project exhibits a mix of `.js`, `.jsx`, `.ts`, and `.tsx` files, indicating a partial migration to TypeScript. There are severe redundancies in core services and database clients.

**Key Issues Found:**
*   **Duplicate Supabase Clients:** `src/lib/supabase.js`, `src/lib/supabaseClient.js`, `src/lib/supabase/client.js`, `src/lib/supabase/client.ts`, and `src/lib/customSupabaseClient.js` all exist.
*   **Duplicate Services/Hooks:** `src/hooks/useOnboardingChat.js` vs `src/hooks/useOnboardingChat.ts`. `src/services/onboardingService.js` vs `src/services/onboarding/onboarding.service.ts`.
*   **Orphaned Files:** Legacy architecture documents and scripts (`cleanup_old_architecture.sql`, `database-schema.sql`).

---

## SECTION 2: DATABASE SCHEMA VALIDATION

**Target:** `supabase/migrations/20260621_phase1_mvp_schema.sql` vs `<database>` state.

**Findings:**
*   **Schema Mismatch (CRITICAL):** The `assistants` table dropped the JSONB `model` column and added flat columns (`model_provider`, `model_name`, `temperature`, `top_p`, `max_tokens`). However, `src/lib/assistantService.js` still attempts to `insert({ model: config.model, ... })`. **This completely breaks Assistant creation.**
*   **RLS Gaps:** `conversation_messages` has policies restricted to the assistant owner (`user_id = auth.uid()`). This prevents public/anonymous users from sending messages to published assistants.
*   **Orphaned Legacy Tables:** The database still contains `assistant_settings`, `assistant_memory`, `assistant_contacts`, `chats`, `chat_messages` which overlap with the new `assistants` and `conversations` tables.

---

## SECTION 3: SUPABASE CLIENT VALIDATION

**Targets:** `src/lib/supabase.js`, `src/lib/supabaseClient.js`, `src/lib/customSupabaseClient.js`

**Findings:**
*   `src/lib/supabaseClient.js` initializes standard `@supabase/supabase-js`.
*   `src/lib/supabase.js` wraps initialization in a heavily custom `db` object with timeouts and intercepted auth errors.
*   **Issue:** The codebase imports from different clients randomly, causing inconsistent behavior (e.g., some queries timeout at 15s, others don't; some intercept `auth_error` and force logout, others fail silently).

---

## SECTION 4: CORE SERVICE VALIDATION

**`src/lib/assistantService.js`:**
*   `createAssistant()`: ❌ **BROKEN**. Fails on insert due to deprecated `model`, `identity`, `personality`, `tone` columns (which are now replaced by `state` or flat columns in SQL).
*   `updateAssistant()`: ❌ **BROKEN**. Same schema mismatch as `createAssistant()`.
*   `getAssistant()`, `listAssistants()`, `deleteAssistant()`: ⚠️ Work partially but fetch obsolete fields.

**`src/lib/assistantVersioning.js`:**
*   `createVersion()`: ⚠️ Works, but relies on the broken schema objects from `assistantService.js`.
*   `getVersionHistory()`, `restoreVersion()`: ⚠️ Restoring will crash because it attempts an `update` using the obsolete JSON structures.

**`src/lib/ragPipeline.js`:**
*   `uploadKnowledgeSource()`: ✅ Works (uploads to `assistant-knowledge` bucket).
*   `parseDocument()`, `generateEmbeddings()`, `storeInVectorDB()`, `searchKnowledge()`: ❌ **MOCKS ONLY**. No actual LangChain, LlamaIndex, or OpenAI embeddings integration implemented here.

**`src/lib/migrationHelpers.js`:**
*   ⚠️ Testing/Seeding scripts. Only usable in dev, likely broken due to schema mismatches.

---

## SECTION 5: EDGE FUNCTIONS VALIDATION

*   `supabase/functions/chat/index.ts`: ⚠️ Implemented. Relies on `callOpenAI` internal abstraction. Lacks rate limiting.
*   `supabase/functions/onboarding-chat/index.ts`: ⚠️ Implemented but performs two sequential OpenAI calls (Chat + Extraction), leading to extremely high latency (>15s) and potential timeouts.
*   `supabase/functions/refine-assistant-chat/index.ts`: ✅ Implemented with SSE (Streaming). Good resilience.
*   `supabase/functions/process-upload/admin.ts`: ❌ Skeleton structure. No real OCR or vectorization.

---

## SECTION 6 & 7: REACT COMPONENTS AND PAGES VALIDATION

**Components:**
*   `OnboardingChat`, `IntelligentAssistantChat`: ✅ Functioning well, UI is highly polished.
*   `RefinementAssistantChat`: ⚠️ Works but relies on complex memory states.
*   `KanbanBoard`, `DashboardBusiness`: ✅ Rendering correctly.

**Pages:**
*   `OnboardingChatPage.jsx`, `CreateAssistantPage.jsx`: ✅ Renders properly, but the "Save/Publish" button triggers the broken `assistantService.js`.
*   `AuthPage.jsx`, `HomePage.jsx`: ✅ Functioning correctly.

---

## SECTION 8: ROUTING VALIDATION

**Target:** `src/App.jsx`
*   ✅ Valid configuration using `react-router-dom`.
*   ✅ `ConfigCheck` wrapper catches missing env vars effectively.
*   ✅ Uses `ProtectedRoute` for private routes.
*   ⚠️ `dashboard/create-assistant` redirects to `onboarding-chat`, which is fine, but there is also `CreateAssistantPage.jsx` and `CreateAssistantOnboardingPage.jsx` causing path confusion.

---

## SECTION 9 & 10: HOOKS AND TYPESCRIPT VALIDATION

**Hooks:**
*   `useOnboardingChat.js` / `.ts`: ❌ Duplicate logic. `js` version expects standard JSON, `.ts` version uses streams. Components mix these up.
*   `useAssistant.ts`: ⚠️ Typings refer to outdated schema interfaces.
*   `useChat.ts`: ✅ Connected properly for standard chats.

**TypeScript Types (`src/types/`):**
*   `assistant.types.ts`, `database.types.ts`: ❌ **Defunct**. Do not match the `20260621_phase1_mvp_schema.sql` database reality. The compiler will hide errors because many files use `.js` bypassing strict type checks.

---

## SECTION 11: END-TO-END FLOW TRACING

1.  **"Create Assistant" Flow:** `OnboardingChatPage` ➔ `useOnboardingChat` ➔ `onboarding-chat` Edge Function (Success, returns JSON) ➔ User clicks Publish ➔ `assistantService.createAssistant` ➔ `supabase.insert()` ➔ **[CRASH]** (Schema column `model` does not exist).
2.  **"Chat with Assistant" Flow:** User loads `IntelligentAssistantChat` ➔ Sends message ➔ `chat` Edge Function ➔ Insert into `conversation_messages` ➔ **[BLOCKED BY RLS]** (If user is anonymous, insert fails).

---

## SECTION 12: OPENAI INTEGRATION AUDIT

*   **`src/lib/openai.js` (CRITICAL SECURITY VULNERABILITY):** Instantiates the OpenAI SDK *directly* in the browser using `dangerouslyAllowBrowser: true` and `import.meta.env.VITE_OPENAI_API_KEY`. This exposes the API key to the client.
*   **Edge Functions (`chat`, `onboarding-chat`):** Hardcodes `gpt-4o` and `gpt-3.5-turbo` sporadically. No uniform model configuration. Extraction uses `response_format: { type: "json_object" }` successfully but without timeout fallbacks.

---

## SECTION 13: DEAD CODE ANALYSIS

*   **Duplicate Clients:** `src/lib/supabase/client.js`, `src/lib/supabase/client.ts`
*   **Unused legacy contexts:** Legacy memory processors in `src/lib/assistantMemory.js`
*   **Unused legacy tables:** DB tables like `assistant_profiles`, `assistant_rules`, `assistant_settings` are still present but bypassed by the MVP Phase 1 SQL.

---

## SECTION 14: RUNTIME ERROR ANALYSIS

*   **DB Insert Exception:** The application compiles perfectly (Vite ignores `.js` type errors), but immediately throws HTTP 400 (Bad Request - Column not found) on Assistant Save.
*   **Auth Timeout Loop:** `src/lib/supabase.js` aggressively intercepts timeouts as "Auth Errors" and forces local storage wipes, causing accidental logouts on slow mobile connections when the OpenAI function takes > 15s.

---

## SECTION 15 & 16: PACKAGE.JSON & CONFIGURATION VALIDATION

*   **`package.json`:** ✅ Valid. Includes `openai`, `@supabase/supabase-js`, `react-router-dom`, `framer-motion`, `lucide-react`, and standard shadcn UI packages.
*   **`vite.config.js`:** ✅ Custom error overlay plugins are standard for the sandbox environment. Path aliases (`@/`) are correctly mapped.

---

## SECTION 17: FINAL DIAGNOSTIC CLASSIFICATION

### ✅ FUNCIONA E ESTÁ CONECTADO
*   `src/App.jsx` (Routing)
*   `src/contexts/AuthContext.jsx` (Authentication)
*   `src/components/onboarding/OnboardingChat.jsx` (UI/UX)
*   `supabase/functions/refine-assistant-chat/` (Streaming Endpoint)

### ⚠️ EXISTE MAS ESTÁ PARCIALMENTE CONECTADO
*   `supabase/functions/onboarding-chat/` (Slow, synchronous)
*   `src/lib/assistantVersioning.js` (Logic is sound, payload is outdated)
*   `src/hooks/useStreamingChat.js` (Valid but lacks auto-reconnect)
*   `src/lib/ragPipeline.js` (Just pure mocked stubs)

### ❌ EXISTE APENAS COMO ESTRUTURA (DEAD/BROKEN)
*   `src/lib/assistantService.js` (Broken due to schema drift)
*   `src/types/*.ts` (Defunct types)
*   `src/lib/openai.js` (Security risk, must be moved to backend)
*   Duplicate files (`src/services/onboardingService.js` vs `src/services/onboarding/onboarding.service.ts`)

---

## SECTION 18: SUMMARY & RECOMMENDATIONS

### CRITICAL ISSUES (FIX IMMEDIATELY)
1.  **Schema Mismatch in CRUD:** Update `src/lib/assistantService.js` to map payloads to the flat columns (`model_provider`, `model_name`, `temperature`) created in `20260621_phase1_mvp_schema.sql`.
2.  **API Key Exposure:** Delete `src/lib/openai.js` and move the `generateTicketTitle` function to a secure Supabase Edge Function to prevent `VITE_OPENAI_API_KEY` theft.
3.  **RLS Policies on Chat:** Modify the `conversation_messages` RLS policy to allow anonymous insertions if the `conversation_id` is valid, OR run the chat Edge Function using the `SUPABASE_SERVICE_ROLE_KEY` to bypass RLS for incoming client messages.

### WARNINGS & REFACTORING
1.  **Duplicate Files:** Perform a massive cleanup of the `src/services` and `src/hooks` folders to eliminate the duplicated TS and JS versions of the onboarding tools.
2.  **Auth Timeout Trap:** Remove the aggressive auto-logout on timeout in `src/lib/supabase.js` (`handleDbAuthError`), as LLM latency will constantly trigger this logic and frustrate users.
3.  **Edge Function Latency:** Refactor `onboarding-chat` to return the conversational string immediately and fire the JSON extraction asynchronously to prevent HTTP 504 Gateway Timeouts.