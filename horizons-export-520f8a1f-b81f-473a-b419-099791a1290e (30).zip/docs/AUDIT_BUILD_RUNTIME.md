# AUDITORIA DE BUILD E RUNTIME

## 1. Compilação (Build) (⚠️)
- O Vite processará os arquivos `.js` e `.jsx` com babel sem muitos problemas, porém o compilador de TypeScript apontará múltiplos erros de tipos não correspondentes (`any` explícito e implícito, interfaces conflitantes nos arquivos duplicados de types).
- Erros de ESLint esperados devido a imports não utilizados na raiz dos múltiplos serviços de onboarding (arquivos mortos).

## 2. Runtime (❌)
- **Onboarding Ponta a Ponta:** Funciona até o momento de "Create Assistant".
- **Criação do Assistente:** **QUEBRA**. Ao clicar para salvar o assistente, a chamada a `supabase.from('assistants').insert(...)` falhará pois a API tentará escrever num field `model` que não existe mais. 
- **Acesso ao Chat:** Falhará em renderizar o avatar do assistente se as consultas SQL não ajustarem para pegar `model_name` e `model_provider` em vez de desestruturar `assistant.model.provider`.
- **Autenticação:** O wrapper intercepta timeouts e pode forçar um "Logout" indesejado (`handleDbAuthError` no `supabase.js`) se a chamada demorar muito, o que é frequente em respostas pesadas da LLM.

## 3. Resiliência do Sistema (⚠️)
- Os alertas da UI falham silenciosamente dependendo da resposta do backend.
- A função de auto-detect business type (`businessTypeDetector.js`) funciona bem, mas sua integração reativa pode disparar múltiplos re-renders se conectada incorretamente ao `useEffect` do `useDynamicTraining.js`.

## STATUS GERAL: ❌ QUEBRADO EM RUNTIME
O projeto compila (pois Vite com React/JS é permissivo), mas falha catastroficamente ao tentar realizar as operações centrais de negócio (CRUD do Assistente).