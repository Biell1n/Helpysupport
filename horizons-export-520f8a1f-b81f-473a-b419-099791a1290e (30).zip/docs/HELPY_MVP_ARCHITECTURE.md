# HELPY MVP Pragmatic Architecture

## 1. Schema Overview
The HELPY MVP adopts a highly pragmatic, 3-table architecture designed for rapid iteration, flexibility, and scalability without overengineering. Instead of heavily normalizing every assistant attribute into separate tables (which requires complex joins and rigid schemas), we utilize PostgreSQL's powerful `JSONB` columns for configurations.

**The 3 Tables:**
1. `assistants`: The core table containing the assistant's metadata and configuration via structured JSONB columns.
2. `assistant_versions`: Tracks every configuration change, enabling rollbacks, audit trails, and deterministic prompt tracking.
3. `assistant_knowledge_sources`: Manages uploaded files, synchronization metadata, and RAG (Retrieval-Augmented Generation) references.

**Why JSONB?**
- **Flexibility**: As we discover new assistant capabilities, traits, or tool configurations, we can add them without database migrations.
- **Performance**: Fetching an assistant requires a single query, eliminating the N+1 problem and complex joins.
- **Versioning**: Creating a snapshot for versioning is as simple as copying the row data.

## 2. Table Schemas

### `assistants`
- `id` (uuid, PK)
- `user_id` (uuid, FK)
- `name` (text)
- `description` (text)
- `status` (text: draft|active|archived)
- `model` (jsonb)
- `identity` (jsonb)
- `personality` (jsonb)
- `tone` (jsonb)
- `responsibilities` (jsonb)
- `restrictions` (jsonb)
- `escalation_rules` (jsonb)
- `tools` (jsonb)
- `channels` (jsonb)
- `created_at`, `updated_at` (timestamps)

### `assistant_versions`
- `id` (uuid, PK)
- `assistant_id` (uuid, FK)
- `version_number` (integer)
- `snapshot` (jsonb - copy of the assistant configuration at this point)
- `generated_prompt_snapshot` (text)
- `change_description` (text)
- `created_by` (uuid)
- `created_at` (timestamp)

### `assistant_knowledge_sources`
- `id` (uuid, PK)
- `assistant_id` (uuid, FK)
- `type` (text: pdf|docx|csv|txt|etc)
- `name` (text)
- `source_url` (text)
- `status` (text: active|processing|error)
- `metadata` (jsonb - size, pages, tags)
- `vector_store_id` (text)
- `created_at`, `updated_at` (timestamps)

## 3. JSONB Structures

**model**: