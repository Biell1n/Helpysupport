# Intelligent Onboarding System Guide

## Overview
The Intelligent Onboarding System is a 4-layer architecture designed to dynamically adapt to the user's business type, intelligently evaluate the depth of responses, recognize data updates mid-conversation, and dynamically construct prompts to avoid rigid checklists.

### Layer 1 - Dynamic Discovery
- **Business Type Detection**: The AI analyzes the user's initial messages to detect their business type (e.g., clinic, store, consultancy).
- **Dynamic Fields**: Based on the detected type, it loads `critical_fields`, `important_fields`, and `optional_fields` from `business_type_definitions`.

### Layer 2 - Investigative Depth
- **Depth Analysis**: Every user response is analyzed for depth (Level 1: Superficial, Level 2: Moderate, Level 3: Comprehensive).
- **Aprofundamento**: If a field is only "partial" (Level 1 or 2), the system generates contextual questions from `aprofundamento_questions` to gather more detail.

### Layer 3 - Real Changes
- **Update Intent Detection**: The AI continuously monitors messages for intents to change previously provided information (e.g., "Actually, my hours are 9-5, not 8-4").
- **Field Updates Tracker**: High-confidence updates replace the data in `extracted_data` and are logged in the `field_updates` table.

### Layer 4 - Dynamic Never Checklist
- **Dynamic Prompts**: The conversation builder constructs the system prompt on the fly. It prioritizes critical unconfirmed fields, then "partial" fields, then important fields.
- **Natural Flow**: It prevents the AI from sounding like a static form by constantly adjusting the `next_objective`.

## Testing Scenarios
1. **Dynamic Discovery**: Start a chat and say "I have a clinic." Verify that the fields switch to clinic-specific goals (specialties, operating hours).
2. **Depth Analysis**: Give a short answer like "I sell shoes." The AI should mark `products_sold` as "partial" and ask for more details.
3. **Update Detection**: Say "Actually, change my target audience to teenagers." The system should detect the update, log it, and confirm the change.

## Database Schema
- `business_type_definitions`: Stores templates for business types.
- `field_updates`: Audit log for mid-conversation data changes.
- `onboarding_sessions`: Enhanced with `depth_analysis`, `business_type`, and dynamic field arrays.