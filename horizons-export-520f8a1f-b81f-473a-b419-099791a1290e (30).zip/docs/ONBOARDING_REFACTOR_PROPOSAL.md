# ONBOARDING REFACTOR PROPOSAL

## 1. CURRENT STATE ANALYSIS

**Current Schema (onboarding_sessions):**
- `id` (uuid, PK)
- `user_id` (uuid, FK)
- `business_type` (text)
- `business_description` (text)
- `assistant_goal` (text)
- `onboarding_progress` (integer)
- `collected_data` (jsonb)
- `status` (text)
- `created_at`, `updated_at` (timestamp)
- `extracted_data` (jsonb)
- `missing_information` (jsonb)
- `context_sufficiency` (integer)
- `assistant_capabilities` (jsonb)
- `conversation_history` (jsonb)
- `next_objective` (text)

**Identified Issues:**
- **Duplication:** `conversation_history` (jsonb array in sessions table) duplicates the actual messages stored in the `onboarding_messages` table. This creates synchronization risks and bloats the sessions table.
- **Redundancy:** `collected_data` and `extracted_data` serve virtually identical purposes.
- **Inconsistency:** The edge function currently attempts to infer `business_type_detected` but defaults to writing it to `business_type` in the database, blurring the line between user-provided and AI-detected types.

**Data Flow:**
Currently, the edge function performs multiple passes (one conversational, one extraction), leading to high latency and redundant token usage.

---

## 2. PROPOSED SCHEMA CHANGES