# AUDITORIA DO FLUXO PONTA A PONTA

## ETAPA 1: Onboarding
- **Verificar se `onboarding_sessions` está sendo criada corretamente:** ✅ Sim (via `useGetOrCreateSession` e front-end).
- **Verificar se dados estão sendo salvos:** ✅ Sim.
- **Verificar conversas em `onboarding_messages`:** ✅ Sim, a edge function salva a mensagem do usuário e do assistente.
- **Verificar extração de dados estruturados:** ⚠️ Parcial. O JSON está sendo extraído, mas a lógica de merge não lida bem com arrays aninhados em alguns cenários.
- **Verificar validação de contexto:** ✅ Funcional via IA e regras estáticas no front.
- **Status:** ⚠️ PARCIAL. A etapa roda, mas é lenta devido às chamadas sequenciais da OpenAI na Edge Function.

## ETAPA 2: Criação do Assistente
- **Uso de dados do onboarding:** ✅ Sim, vinculados.
- **Criação em `assistants`:** ❌ ERRO CRÍTICO. O arquivo `assistantService.js` faz um insert passando um objeto `model: config.model` (JSONB). Porém, a migration `20260621_phase1_mvp_schema.sql` apagou a coluna `model` e dividiu em `model_provider`, `model_name`, etc. O insert vai falhar.
- **Primeira versão em `assistant_versions`:** ❌ Falhará porque a criação do assistente falha antes.
- **Status `draft` e `published`:** Configurados no código, mas bloqueados pelo erro de schema.
- **Status:** ❌ NÃO PRONTO. Quebrado por inconsistência de banco.

## ETAPA 3: Configuração
- **Carregamento de dados:** ✅ Sim.
- **Salvamento de edições:** ❌ ERRO CRÍTICO. Mesma falha do Insert. O Update no `assistantService.js` tenta gravar na coluna `model` e `identity`, mas o banco e outros serviços usam estruturas diferentes.
- **Status:** ❌ NÃO PRONTO.

## ETAPA 4: Versionamento
- **Criação a cada mudança:** ⚠️ Implementado em `assistantVersioning.js`, porém depende da gravação bem-sucedida do assistente.
- **Cálculo do `version_number`:** ✅ Feito corretamente via consulta da última versão e incremento (+1).
- **Rollback:** ⚠️ Restauraria o estado antigo, mas o update usaria o formato obsoleto (`model` jsonb).
- **Status:** ⚠️ PARCIAL.

## ETAPA 5: Publicação
- **Mudança de status:** ⚠️ Código existe, mas o status check no BD (`draft`, `active`, `published`, `archived`) conflita com chamadas de legado que podem tentar enviar outros status.
- **`published_at`:** ✅ Previsto no schema.
- **Status:** ⚠️ PARCIAL.

## ETAPA 6: Conversas
- **Criação em `conversations`:** ✅ Funciona.
- **Status `active`:** ✅ Validado.
- **Status:** ✅ PRONTO.

## ETAPA 7: Mensagens
- **Salvamento da mensagem do usuário:** ✅ Funciona (Edge function `chat` e `onboarding-chat`).
- **Metadata preenchido:** ⚠️ Parcial. Latência e tokens nem sempre são gravados dependendo da função usada.
- **Status:** ✅ PRONTO.

## ETAPA 8: LLM
- **Geração do System Prompt:** ⚠️ Confuso. Existe `assistantPromptGenerator.js`, mas o banco de dados tem uma coluna `system_prompt`. O sistema às vezes tenta gerar em tempo real, e outras vezes tenta ler da coluna.
- **Inclusão de histórico:** ✅ Feito via consulta ao DB com limite (20 mensagens).
- **Status:** ⚠️ PARCIAL.

## ETAPA 9: Resposta
- **Salvamento de resposta:** ✅ Feito na Edge Function após a IA responder.
- **Retorno ao usuário:** ✅ Via SSE (streaming) ou JSON síncrono.
- **Status:** ✅ PRONTO.