# LISTA DE PROBLEMAS ENCONTRADOS

## 1. Mismatch de Schema SQL e Serviço JS (CRÍTICO)
- **Descrição:** O `assistantService.js` faz inserts enviando colunas que foram deletadas na última migration (como `model` em formato JSON). 
- **Impacto:** Impossibilita a criação e edição de assistentes. Quebra o fluxo principal.
- **Localização:** `src/lib/assistantService.js` (linhas de insert/update).
- **Solução:** Atualizar o mapeamento de DTOs no front-end para nivelar e corresponder às colunas planas recém criadas (`model_provider`, `model_name`, `temperature`, etc.).
- **Prioridade:** 1 (Bloqueante)

## 2. Chave da API da OpenAI Exposta no Frontend (ALTO)
- **Descrição:** O arquivo `openai.js` instancia a SDK da OpenAI diretamente no client usando a flag de browser insegura e utilizando `VITE_OPENAI_API_KEY`.
- **Impacto:** Qualquer usuário pode abrir o painel de desenvolvedor, capturar a chave e abusar da conta da OpenAI.
- **Localização:** `src/lib/openai.js`.
- **Solução:** Migrar qualquer geração feita no cliente (como `generateTicketTitle`) para uma Edge Function dedicada no Supabase.
- **Prioridade:** 1 (Segurança)

## 3. Duplicação de Arquivos e Código Legado (MÉDIO)
- **Descrição:** Arquivos similares como `client.js`, `client.ts`, `customSupabaseClient.js` e múltiplos serviços de onboarding poluem o projeto.
- **Impacto:** Dificuldade extrema de manutenção. Risco de fixar bugs em um arquivo e o sistema continuar usando o arquivo defasado.
- **Localização:** Pastas `src/lib/supabase/`, `src/services/`, `src/hooks/`.
- **Solução:** Padronizar tudo para uma única versão, apagar as redundantes.
- **Prioridade:** 2 

## 4. Latência Elevada na Função `onboarding-chat` (MÉDIO)
- **Descrição:** A Edge Function roda duas chamadas LLM de forma síncrona na mesma requisição.
- **Impacto:** Demora mais de 10-15s, resultando em timeouts (504/500) intermitentes em conexões mais lentas.
- **Localização:** `supabase/functions/onboarding-chat/index.ts`.
- **Solução:** Desacoplar a extração. Responder primeiro a mensagem conversacional, e rodar a extração em background usando Webhooks ou processamento assíncrono.
- **Prioridade:** 2

## 5. RLS Bloqueando Mensagens de Clientes Anônimos (ALTO)
- **Descrição:** A tabela `conversation_messages` tem uma policy baseada em `auth.uid()` do dono do assistente. Se o visitante não for o dono, o select/insert falha.
- **Impacto:** Assistentes publicados não conseguirão receber mensagens dos visitantes finais a menos que o backend bypass a RLS (usando Service Key).
- **Localização:** `20260621_phase1_mvp_schema.sql`.
- **Solução:** Ajustar a Edge function do chat para rodar com Service Key ao inserir mensagens, ou permitir inserção anonima restrita ao `conversation_id` verificado.
- **Prioridade:** 2