# HELPY MVP Implementation Guide

## Quick Start
The HELPY MVP is built around a simplified 3-table architecture using PostgreSQL `JSONB` to store complex, extensible configurations.

### Directory Structure
- `docs/HELPY_MVP_ARCHITECTURE.md`: High-level reasoning and schema documentation.
- `supabase/migrations/*_create_helpy_mvp_schema.sql`: SQL to create the tables.
- `src/lib/assistantSchema.js`: Types, Enums, Default configs.
- `src/lib/assistantService.js`: Core CRUD operations.
- `src/lib/assistantVersioning.js`: Version control and rollbacks.
- `src/lib/assistantPromptGenerator.js`: Pure deterministic prompt builder.
- `src/lib/ragPipeline.js`: MVP methods for document ingestion.
- `src/lib/assistantExamples.js`: JSON examples of full assistant setups.

---

## 1. Creating an Assistant Programmatically
Instead of manually manipulating JSON arrays, use the `assistantService` to ensure validation and auto-versioning.