# AUDITORIA DE APIS E INTEGRAÇÕES - OPENAI

## 1. `supabase/functions/chat/index.ts`
- **Endpoint Utilizado:** Abstraído via `callOpenAI` (internamente usa `/chat/completions`).
- **Modelo:** Lê do banco de dados (tabela `assistant_settings` ou `assistants`), com fallback para `gpt-4o`.
- **Parâmetros:** `temperature`, `max_tokens`, `top_p` lidos do banco, default `0.7`, `4096`, `1.0`.
- **Tratamento de Erros:** Possui bloco `try/catch`. Retorna status 500 com a mensagem de erro.
- **Rate Limiting:** Não implementado na Edge Function.
- **Timeout:** Não especificado explicitamente na requisição (depende do limite do Deno/Supabase, tipicamente 60s).
- **Retry Logic:** Não implementado.
- **Autenticação:** Usa `SUPABASE_SERVICE_ROLE_KEY` para buscar dados e validação implícita de invocação, mas a chamada para OpenAI dentro de `callOpenAI` usa `OPENAI_API_KEY`.
- **Possíveis problemas:** Falta de rate limiting pode levar a abuso. Se o histórico for muito longo, pode estourar o limite de tokens (não há truncamento explícito além do `limit(20)`).

## 2. `supabase/functions/onboarding-chat/index.ts`
- **Endpoint Utilizado:** `https://api.openai.com/v1/chat/completions` (Chamada direta via `fetch`).
- **Modelo:** Hardcoded `gpt-4o` (usado duas vezes: uma para conversa, outra para extração).
- **Parâmetros:** 
  - Conversa: `temperature: 0.7`.
  - Extração: `temperature: 0.1`, `response_format: { type: "json_object" }`.
- **Tratamento de Erros:** `try/catch` geral, validação `!response.ok` lançando erro. Retorna status 500.
- **Rate Limiting:** Não implementado.
- **Timeout:** Não especificado.
- **Retry Logic:** Não implementado.
- **Autenticação:** Lê `OPENAI_API_KEY` do `Deno.env`.
- **Possíveis problemas:** Faz duas chamadas síncronas sequenciais à API da OpenAI (Conversa -> Extração), o que duplica a latência e o custo. O timeout pode ser atingido facilmente se a OpenAI demorar a responder na extração JSON.

## 3. `supabase/functions/refine-assistant-chat/index.ts` (Referenciado)
- *(Com base no uso via front-end `useStreamingChat` / `IntelligentAssistantChat`)*
- **Integração:** Usa Server-Sent Events (SSE) para streaming.
- **Possíveis problemas:** Conexões streaming podem ser instáveis sem reconexão. Tratamento de erro no front-end precisa prever interrupções de stream.

## 4. `src/lib/openai.js` (Frontend Genérico)
- **Endpoint Utilizado:** SDK da OpenAI (`openai.chat.completions.create`).
- **Modelo:** Hardcoded `gpt-3.5-turbo`.
- **Parâmetros:** `temperature: 0.7`, `max_tokens: 500`. (Para geração de título de ticket: `temperature: 0.5`, `max_tokens: 50`).
- **Tratamento de Erros:** `try/catch` lançando erros em português. Verifica erro 401.
- **Rate Limiting / Retry:** Não implementado.
- **Segurança:** Usa `dangerouslyAllowBrowser: true`. **⚠️ Risco Crítico de Segurança:** Chave de API exposta no client-side.

## 5. `src/services/onboarding/extraction.service.ts`
- **Endpoint Utilizado:** SDK da OpenAI.
- **Modelo:** Hardcoded `gpt-4o`.
- **Parâmetros:** `temperature: 0.3`, `response_format: { type: 'json_object' }`.
- **Tratamento de Erros:** Captura o erro e retorna um objeto JSON de fallback válido via Zod.
- **Segurança:** `dangerouslyAllowBrowser: true` (se instanciado no front).

## RESUMO DE ACHADOS GERAIS
- **Falta de Padronização:** Algumas funções usam o SDK da OpenAI, outras usam `fetch` direto, outras usam o wrapper `callOpenAI`.
- **Exposição de Chaves:** O SDK sendo instanciado no cliente (`dangerouslyAllowBrowser: true`) é um risco grave. A chave de API está exposta.
- **Ausência de Resiliência:** Nenhuma das chamadas possui Retry com Exponential Backoff no lado do servidor.
- **Latência Duplicada:** No onboarding-chat, chamadas seriais sem paralelismo prejudicam a experiência do usuário.