# AUDITORIA DO BANCO DE DADOS

*Baseado no schema extraído e no arquivo `20260621_phase1_mvp_schema.sql`.*

## 1. Migrations e Criação de Tabelas
- As tabelas principais foram criadas: `assistants`, `assistant_versions`, `conversations`, `conversation_messages`.
- **Inconsistência Grave:** A migration dropou a coluna `model` e adicionou colunas planas (`model_provider`, `model_name`, etc.), mas tabelas do legado continuam no banco (`assistant_settings`, `chats`, `chat_messages`, `assistant_profiles`). Existem dois sistemas convivendo em paralelo.
- As colunas de estado (`state`, `fallback_behavior`, `custom_instructions`) foram adicionadas em `assistants`.

## 2. RLS Policies
- **`assistants`:** A política antiga foi atualizada? A migration atualiza políticas apenas para novas tabelas (`assistant_versions`, `conversations`, `conversation_messages`).
- **`assistant_versions`:** `EXISTS (SELECT 1 FROM public.assistants WHERE id = assistant_versions.assistant_id AND user_id = auth.uid())` - ✅ Certo.
- **`conversations`:** A política garante que apenas donos do assistente possam gerenciar conversas. ✅ Certo.
- **Brechas de Segurança:** Para que clientes finais possam enviar mensagens em `conversation_messages`, a RLS atual bloqueia inserções públicas/anônimas. A política atual exige que o dono (`auth.uid()`) gerencie. Usuários não autenticados ou clientes do assistente não poderão inserir mensagens sem o Service Role bypass.

## 3. Foreign Keys
- `assistant_versions.assistant_id -> assistants(id)` ON DELETE CASCADE. ✅
- `conversations.assistant_id -> assistants(id)` ON DELETE CASCADE. ✅
- `conversation_messages.conversation_id -> conversations(id)` ON DELETE CASCADE. ✅
- `assistants.user_id -> auth.users(id)`: O schema mostra que o `assistants` tem `user_id`, mas em alguns pontos do código antigo era chamado de `owner_id`. A nova RLS usa `user_id`.

## 4. Índices
- `idx_assistants_user_status` criado. ✅
- `idx_assistants_published` criado. ✅
- `idx_conversations_assistant_status` e `idx_conversation_messages_conv_created` criados. ✅

## 5. Constraints e Legado
- Foi alterada a constraint `assistants_status_check` para permitir 'published'. ✅
- **Resíduos do Legado:**
  - Tabelas `assistant_profiles`, `assistant_rules`, `assistant_settings`, `services`, `products`, `faqs`, `assistant_memory`. Elas não foram dropadas (o script de cleanup não foi executado ou comitou-se a migration sem dropar o legado).
  - Isso resulta em "duas fontes da verdade": O `assistantService.js` grava em `assistants.identity` (JSON), mas existe uma tabela `assistant_profiles`.

## STATUS GERAL: ❌ CRÍTICO
O banco de dados está em um estado "esquizofrênico" misturando a arquitetura antiga altamente normalizada (Fase 0) com a arquitetura pragmática baseada em JSONB (MVP Fase 1) e colunas planas. Isso quebra as aplicações front-end de forma imediata.