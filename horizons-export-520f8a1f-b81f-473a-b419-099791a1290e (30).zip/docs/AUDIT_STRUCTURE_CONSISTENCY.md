# AUDITORIA DE CONSISTÊNCIA DE ESTRUTURAS

## 1. Schema SQL vs TypeScript/JavaScript (❌)
- **Descompasso da Tabela Assistants:** O código `assistantService.js` envia um objeto para a tabela `assistants` contendo as chaves `{ model, identity, personality, tone, responsibilities, restrictions, escalation_rules, tools, channels }`. No entanto, a nova migration removeu a coluna `model` e não possui colunas JSON nativas para a maioria dessas coisas no formato esperado (ex: `channels`, `tools`).
- **Conflito:** O SQL tem as colunas em JSONB mas a forma que o código tenta acessar ou inserir falhará devido ao schema mismatch ou ausência de validação DTO (Zod / TS Types).

## 2. TypeScript vs Edge Functions (⚠️)
- **Onboarding Payload:** A Deno function espera `business_type`, `business_description`, mas o frontend está enviando a partir do contexto que às vezes vem com camelCase (`businessType`, `businessDescription`). 
- **Conversões:** O payload JSON que a Edge Function `onboarding-chat` retorna não é verificado via Zod ou tipagem estrita antes de ser setado no state do React, podendo causar "undefined is not an object".

## 3. Edge Functions vs React (⚠️)
- Algumas edge functions retornam streaming (SSE) enquanto outras retornam JSON em bloco. O frontend usa `useStreamingChat.js` para ler streams, mas o `useOnboardingChat.ts` espera um retorno JSON síncrono da função `onboarding-chat`.

## 4. Versionamento e Snapshots (✅/⚠️)
- O Snapshot em `assistant_versions` é um JSONB genérico. Isso significa que ele vai capturar qualquer objeto que for passado. A restauração também funciona, mas como a estrutura base de inserção está quebrada, o snapshot registrará estados inválidos.
- A geração de Prompt em `assistantPromptGenerator.js` é determinística, mas depende da estrutura antiga (`assistant.identity.business_type`), que agora pode estar defasada.

## STATUS GERAL: ❌ CRÍTICO
A estrutura de dados que flui do Formulário React -> Serviço JS -> Banco de Dados está gravemente rompida na camada Serviço <-> Banco, impossibilitando a persistência correta do Assistente.