# HELPY Scalable Platform Architecture

This document defines the complete, decoupled architectural proposal for HELPY—a highly scalable, context-driven AI Assistant platform. It details the normalized data model, configuration flows, integration mechanisms, and scalability strategies.

---

## 1. ARCHITECTURE OVERVIEW

### Decoupled Architecture Principle
HELPY relies on a strictly decoupled architecture: **Configuration (Source of Truth) → System Prompt (Derived) → Conversation History (Execution)**. 
- The user's configuration across distinct relational tables serves as the absolute Source of Truth.
- The `system_prompt` is dynamically generated (or regenerated) from these normalized tables.
- Conversation states and context never mutate the assistant's core behavior directly; they only interact via defined RAG sources and tools.

### Relationship Diagram & Data Flow