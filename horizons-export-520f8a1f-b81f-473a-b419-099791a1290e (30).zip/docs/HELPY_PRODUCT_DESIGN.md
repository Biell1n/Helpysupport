# HELPY Product Design Documentation

This document validates the complete user experience, flows, layouts, and data structure for the HELPY application BEFORE implementation. It serves as the definitive reference for Phase 1 (MVP) and future phases.

---

## 1. COMPLETE FLOW - CREATE ASSISTANT

**The 4-Step Creation Flow:**

*   **Step 1: Initialization** 
    *   User clicks "Create Assistant" from the dashboard.
    *   Opens a modal or full page containing two main tabs: `[ CREATE ]` and `[ CONFIGURE ]`.
    *   The `CREATE` tab is active by default.
*   **Step 2: Chat with HELPY (CREATE tab active)**
    *   **Greeting:** HELPY introduces itself: "Hello! I'm HELPY. I'm here to help you build your perfect AI assistant. Let's start with the basics. What is your assistant's name?"
    *   **Assistant Name:** User responds (e.g., "Consultora de Moda").
    *   **Business Type & Audience:** HELPY asks about the business and target audience. User responds.
    *   **Document Upload:** HELPY prompts for reference materials. User uploads `catalogo.pdf` and `precos.xlsx`.
    *   **Processing Feedback:** HELPY shows a processing state, then confirms: "Great! I've analyzed your catalog with 45 products and your price list. Your assistant will know everything about them."
    *   **Refinement Questions:** HELPY asks targeted questions about personality and tone based on the business type.
    *   **Completion:** HELPY announces: "Your assistant is ready in draft mode! Let's review the settings." Shows a `[ Go to Configure → ]` button.
*   **Step 3: Configuration (CONFIGURE tab)**
    *   The `CONFIGURE` tab opens automatically (or via button click).
    *   All onboarding data extracted from the chat is pre-filled into the respective structured sections (Personality, Tone, Responsibilities, etc.).
    *   Uploaded documents appear processing/active in the `Knowledge` section.
*   **Step 4: Publication**
    *   User reviews the generated prompt and sections.
    *   User clicks "Publish".
    *   Status changes from `"draft"` to `"published"`. `published_at` is set to `now()`. The assistant is live and ready to receive conversations.

---

## 2. LAYOUT - CREATE TAB (Chat with HELPY)