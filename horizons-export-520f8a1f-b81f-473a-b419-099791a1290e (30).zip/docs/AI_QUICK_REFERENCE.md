# Referência Rápida: Integração de IA no Horizons

## Checklist: Nova Edge Function com IA
1. Crie a pasta da function em `supabase/functions/`.
2. Importe o `openaiClient` do diretório `_shared`.
3. Defina a configuração usando o padrão ou importe `AI_MODELS`.
4. Monte o array de `messages` iniciando sempre com o `system prompt`.
5. Valide a resposta (`aiResponse.success`).
6. Salve a interação no Supabase (tabela `conversation_messages` ou `onboarding_sessions`).

## Template Básico