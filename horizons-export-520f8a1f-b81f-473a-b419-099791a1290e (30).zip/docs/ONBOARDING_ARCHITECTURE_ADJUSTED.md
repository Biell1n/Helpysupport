# ONBOARDING ARCHITECTURE - ADJUSTED PROPOSAL

This document outlines the revised architecture for the AI assistant onboarding flow, incorporating deterministic capability derivation, a refined database schema, and explicit rules for determining when sufficient context has been gathered.

---

## 1. SCHEMA SQL AJUSTADO

The `onboarding_sessions` table is streamlined to remove duplication and speculative data, focusing strictly on structured extraction and explicit state tracking.