# Documentação de Configuração de Modelos de IA

## 1. Modelo Padrão: GPT-4o
O modelo `gpt-4o` foi adotado como o padrão para todo o sistema Horizons.
**Justificativa:** Oferece a melhor combinação de capacidade de reasoning, janela de contexto (128k tokens) ideal para analisar dados complexos de empresas, velocidade de resposta superior para chats em tempo real e eficiência de custos quando comparado ao seu antecessor GPT-4.

## 2. Configurações Padrões
- **Temperature:** `0.7` (Equilíbrio ideal entre consistência estrutural e fluidez conversacional).
- **Max Tokens:** `4096` (Garante espaço suficiente para retornos longos, listas de produtos e detalhamentos de onboarding sem cortes abruptos).
- **Top_P:** `1.0` (Permite amostragem completa de vocabulário).

## 3. Perfis de Uso (AI_MODELS)
As configurações estão centralizadas em `src/config/aiModels.ts`:
- **SYSTEM_ONBOARDING_ASSISTANT:** Gerencia o setup de novos clientes. Necessita de alta precisão contextual. (`gpt-4o`, `0.7`).
- **COMPANY_ASSISTANT:** Instância final para atendimento aos clientes das empresas. (`gpt-4o`, `0.7`).
- **PROMPT_GENERATOR:** Utilizado internamente para gerar system prompts rígidos baseados em JSON. Usa `temperature: 0.5` para evitar alucinações de schema.

## 4. Estrutura Padrão de Mensagens
Toda requisição deve seguir a interface `Message`: